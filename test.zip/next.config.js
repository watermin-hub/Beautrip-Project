/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  // ✅ Firebase Hosting 정적 배포용
  output: "export",

  images: {
    // ✅ 정적 배포에서는 next/image 최적화 서버가 없어서 필요
    unoptimized: true,

    // ✅ 외부 이미지 도메인 허용
    remotePatterns: [
      { protocol: "https", hostname: "i.namu.wiki" },
      { protocol: "https", hostname: "play-lh.googleusercontent.com" },
      { protocol: "https", hostname: "upload.wikimedia.org" },
    ],
  },
};

module.exports = nextConfig;
