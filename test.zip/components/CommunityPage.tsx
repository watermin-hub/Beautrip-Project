"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Header from "./Header";
import BottomNavigation from "./BottomNavigation";
import CommunityHeader from "./CommunityHeader";
import PostList from "./PostList";
import CommunityFloatingButton from "./CommunityFloatingButton";
import InformationalContentSection from "./InformationalContentSection";
import CategoryCommunityPage from "./CategoryCommunityPage";
import ConsultationPage from "./ConsultationPage";

type CommunityTab = "info" | "popular" | "latest" | "category" | "consultation";

export default function CommunityPage() {
  const searchParams = useSearchParams();

  const [activeTab, setActiveTab] = useState<CommunityTab>("info");

  useEffect(() => {
    const tab = searchParams.get("tab") as CommunityTab | null;
    if (
      tab &&
      ["info", "popular", "latest", "category", "consultation"].includes(tab)
    ) {
      setActiveTab(tab);
      // 탭 변경 시 상단으로 스크롤
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [searchParams]);

  const handleTabChange = (tab: CommunityTab) => {
    setActiveTab(tab);
    // 탭 변경 시 상단으로 스크롤
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-white max-w-md mx-auto w-full">
      <Header />
      <CommunityHeader activeTab={activeTab} onTabChange={handleTabChange} />

      {/* Content */}
      <div className="mt-4">
        {activeTab === "info" ? (
          <div className="px-4">
            <InformationalContentSection />
          </div>
        ) : activeTab === "popular" ? (
          <PostList activeTab="popular" />
        ) : activeTab === "latest" ? (
          <PostList activeTab="latest" />
        ) : activeTab === "category" ? (
          <CategoryCommunityPage />
        ) : activeTab === "consultation" ? (
          <ConsultationPage />
        ) : null}
      </div>

      <div className="pb-20">
        <BottomNavigation />
      </div>

      {/* 커뮤니티 플로팅 버튼 (글 쓰기 / 내 글 관리) */}
      <CommunityFloatingButton />
    </div>
  );
}
