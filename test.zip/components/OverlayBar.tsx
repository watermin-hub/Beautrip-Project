"use client";

// OverlayBar는 더 이상 사용하지 않습니다 (리뷰 작성 버튼이 HomePage에 통합됨)
export default function OverlayBar() {
  return null;
}
