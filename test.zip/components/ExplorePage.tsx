"use client";

import ExploreScrollPage from "./ExploreScrollPage";

export default function ExplorePage() {
  return <ExploreScrollPage />;
}
