module.exports = [
"[project]/.next-internal/server/app/treatment/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_treatment_%5Bid%5D_page_actions_27a271ea.js.map