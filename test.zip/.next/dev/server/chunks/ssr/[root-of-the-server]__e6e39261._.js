module.exports = [
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/lib/supabase.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$esm$2f$wrapper$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs [app-ssr] (ecmascript)");
;
// Supabase 클라이언트 생성
// 환경 변수에서 URL과 API Key를 가져옵니다
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://jkvwtdjkylzxjzvgbwud.supabase.co";
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imprdnd0ZGpreWx6eGp6dmdid3VkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU0NDMwNzgsImV4cCI6MjA4MTAxOTA3OH0.XdyU1XtDFY2Vauj_ddQ1mKqAjxjnNJts5pdW_Ob1TDI";
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$esm$2f$wrapper$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createClient"])(supabaseUrl, supabaseAnonKey);
}),
"[project]/lib/api/beautripApi.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Beautrip API 관련 유틸리티 함수
__turbopack_context__.s([
    "calculateRecommendationScore",
    ()=>calculateRecommendationScore,
    "extractHospitalInfo",
    ()=>extractHospitalInfo,
    "getCategoryRankings",
    ()=>getCategoryRankings,
    "getHospitalAutocomplete",
    ()=>getHospitalAutocomplete,
    "getKBeautyRankings",
    ()=>getKBeautyRankings,
    "getRecoveryInfoByCategoryMid",
    ()=>getRecoveryInfoByCategoryMid,
    "getScheduleBasedRecommendations",
    ()=>getScheduleBasedRecommendations,
    "getThumbnailUrl",
    ()=>getThumbnailUrl,
    "getTreatmentAutocomplete",
    ()=>getTreatmentAutocomplete,
    "getTreatmentRankings",
    ()=>getTreatmentRankings,
    "loadAllData",
    ()=>loadAllData,
    "loadCategoryTreatTimeRecovery",
    ()=>loadCategoryTreatTimeRecovery,
    "loadConcernPosts",
    ()=>loadConcernPosts,
    "loadHospitalMaster",
    ()=>loadHospitalMaster,
    "loadHospitalReviews",
    ()=>loadHospitalReviews,
    "loadHospitalTreatments",
    ()=>loadHospitalTreatments,
    "loadHospitalsPaginated",
    ()=>loadHospitalsPaginated,
    "loadKeywordMonthlyTrends",
    ()=>loadKeywordMonthlyTrends,
    "loadProcedureReviews",
    ()=>loadProcedureReviews,
    "loadRelatedTreatments",
    ()=>loadRelatedTreatments,
    "loadTreatmentById",
    ()=>loadTreatmentById,
    "loadTreatments",
    ()=>loadTreatments,
    "loadTreatmentsPaginated",
    ()=>loadTreatmentsPaginated,
    "parseProcedureTime",
    ()=>parseProcedureTime,
    "parseRecoveryPeriod",
    ()=>parseRecoveryPeriod,
    "saveConcernPost",
    ()=>saveConcernPost,
    "saveHospitalReview",
    ()=>saveHospitalReview,
    "saveProcedureReview",
    ()=>saveProcedureReview,
    "sortTreatmentsByPlatform",
    ()=>sortTreatmentsByPlatform
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-ssr] (ecmascript)");
;
// Supabase 테이블 이름
const TABLE_NAMES = {
    TREATMENT_MASTER: "treatment_master",
    CATEGORY_TREATTIME_RECOVERY: "category_treattime_recovery",
    HOSPITAL_MASTER: "hospital_master",
    KEYWORD_MONTHLY_TRENDS: "keyword_monthly_trends"
};
// 공통 데이터 정리 함수 (NaN을 null로 변환)
function cleanData(data) {
    return data.map((item)=>{
        const cleaned = {};
        for(const key in item){
            const value = item[key];
            cleaned[key] = value === "NaN" || typeof value === "number" && isNaN(value) ? null : value;
        }
        return cleaned;
    });
}
async function loadTreatments() {
    try {
        const allData = [];
        const pageSize = 1000; // Supabase 기본 limit
        let from = 0;
        let hasMore = true;
        console.log("🔄 전체 데이터 로드 시작...");
        // 페이지네이션으로 모든 데이터 가져오기
        while(hasMore){
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from(TABLE_NAMES.TREATMENT_MASTER).select("*").range(from, from + pageSize - 1);
            if (error) {
                throw new Error(`Supabase 오류: ${error.message}`);
            }
            if (!data) {
                throw new Error("데이터를 가져올 수 없습니다.");
            }
            if (!Array.isArray(data)) {
                throw new Error("데이터 형식이 올바르지 않습니다. 배열이 아닙니다.");
            }
            // 데이터 추가
            const cleanedData = cleanData(data);
            allData.push(...cleanedData);
            console.log(`📥 ${from + 1}~${from + data.length}개 로드 완료 (총 ${allData.length}개)`);
            // 더 가져올 데이터가 있는지 확인
            if (data.length < pageSize) {
                hasMore = false;
            } else {
                from += pageSize;
            }
        }
        console.log(`✅ 전체 데이터 로드 완료: ${allData.length}개`);
        // 플랫폼 우선순위로 정렬 (gangnamunni → yeoti → babitalk)
        const sortedData = sortTreatmentsByPlatform(allData);
        console.log(`🔄 플랫폼 우선순위 정렬 완료`);
        return sortedData;
    } catch (error) {
        console.error("시술 데이터 로드 실패:", error);
        throw error;
    }
}
async function loadTreatmentsPaginated(page = 1, pageSize = 50, filters) {
    try {
        let query = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from(TABLE_NAMES.TREATMENT_MASTER).select("*", {
            count: "exact"
        });
        // 필터 적용 (최소 2글자 이상일 때만 검색)
        if (filters?.searchTerm && filters.searchTerm.trim().length >= 2) {
            const term = filters.searchTerm.toLowerCase().trim();
            query = query.or(`treatment_name.ilike.%${term}%,hospital_name.ilike.%${term}%,treatment_hashtags.ilike.%${term}%`);
        } else if (filters?.searchTerm && filters.searchTerm.trim().length === 1) {
            // 1글자일 때는 검색하지 않음 (빈 결과 반환)
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        if (filters?.categoryLarge) {
            query = query.eq("category_large", filters.categoryLarge);
        }
        if (filters?.categoryMid) {
            query = query.eq("category_mid", filters.categoryMid);
        }
        // 페이지네이션
        const from = (page - 1) * pageSize;
        const to = from + pageSize - 1;
        const { data, error, count } = await query.range(from, to);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        const cleanedData = cleanData(data);
        // 랭킹 페이지는 플랫폼 정렬을 건너뛰고 원본 순서 유지 (랭킹 알고리즘이 정렬함)
        const sortedData = filters?.skipPlatformSort ? cleanedData : sortTreatmentsByPlatform(cleanedData);
        const total = count || 0;
        const hasMore = to < total - 1;
        return {
            data: sortedData,
            total,
            hasMore
        };
    } catch (error) {
        console.error("시술 데이터 페이지네이션 로드 실패:", error);
        throw error;
    }
}
async function getTreatmentAutocomplete(searchTerm, limit = 10) {
    try {
        if (!searchTerm || searchTerm.length < 1) {
            return {
                treatmentNames: [],
                hospitalNames: []
            };
        }
        const term = searchTerm.toLowerCase();
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from(TABLE_NAMES.TREATMENT_MASTER).select("category_small, hospital_name").or(`category_small.ilike.%${term}%,hospital_name.ilike.%${term}%`).limit(limit * 2);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return {
                treatmentNames: [],
                hospitalNames: []
            };
        }
        // category_small만 반환 (소분류 기준)
        const treatmentNames = Array.from(new Set(data.map((t)=>t.category_small).filter((name)=>name && name.toLowerCase().includes(term)))).slice(0, limit);
        const hospitalNames = Array.from(new Set(data.map((t)=>t.hospital_name).filter((name)=>name && name.toLowerCase().includes(term)))).slice(0, limit);
        return {
            treatmentNames,
            hospitalNames
        };
    } catch (error) {
        console.error("자동완성 데이터 로드 실패:", error);
        return {
            treatmentNames: [],
            hospitalNames: []
        };
    }
}
async function loadCategoryTreatTimeRecovery() {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from(TABLE_NAMES.CATEGORY_TREATTIME_RECOVERY).select("*");
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data || !Array.isArray(data)) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("카테고리 시술 시간/회복 기간 데이터 로드 실패:", error);
        throw error;
    }
}
async function getRecoveryInfoByCategoryMid(categoryMid) {
    try {
        if (!categoryMid) return null;
        const recoveryData = await loadCategoryTreatTimeRecovery();
        const categoryMidTrimmed = categoryMid.trim();
        // 디버깅: 첫 번째 항목의 중분류 확인
        if (recoveryData.length > 0) {
            console.log("🔍 디버깅 - 첫 번째 recoveryData 항목:", {
                중분류: recoveryData[0].중분류,
                "회복기간_max(일)": recoveryData[0]["회복기간_max(일)"],
                "회복기간_min(일)": recoveryData[0]["회복기간_min(일)"],
                모든키: Object.keys(recoveryData[0])
            });
        }
        // 중분류 컬럼과 category_mid를 매칭
        const matched = recoveryData.find((item)=>{
            const 중분류 = (item.중분류 || "").trim();
            if (!중분류) return false;
            // 정확히 일치하는 경우
            if (중분류 === categoryMidTrimmed) {
                console.log(`✅ 정확 일치: "${categoryMidTrimmed}" === "${중분류}"`);
                return true;
            }
            // 부분 일치도 확인 (대소문자 무시)
            const partialMatch = 중분류.toLowerCase().includes(categoryMidTrimmed.toLowerCase()) || categoryMidTrimmed.toLowerCase().includes(중분류.toLowerCase());
            if (partialMatch) {
                console.log(`⚠️ 부분 일치: "${categoryMidTrimmed}" <-> "${중분류}"`);
            }
            return partialMatch;
        });
        if (!matched) {
            console.warn(`⚠️ 회복 기간 정보를 찾을 수 없습니다. category_mid: "${categoryMidTrimmed}"`);
            console.log("🔍 사용 가능한 중분류 샘플:", recoveryData.slice(0, 10).map((item)=>item.중분류).filter(Boolean));
            return null;
        }
        // 실제 컬럼명: 회복기간_min(일), 회복기간_max(일)
        console.log("🔍 매칭된 객체의 모든 키:", Object.keys(matched));
        console.log("🔍 매칭된 객체에서 회복기간 값 확인:", {
            "회복기간_max(일)": matched["회복기간_max(일)"],
            "회복기간_min(일)": matched["회복기간_min(일)"],
            타입_max: typeof matched["회복기간_max(일)"],
            타입_min: typeof matched["회복기간_min(일)"]
        });
        const recoveryMax = matched["회복기간_max(일)"] || matched["회복기간_min(일)"] || 0;
        const recoveryMin = matched["회복기간_min(일)"] || 0;
        console.log(`✅ 매칭 성공! category_mid: "${categoryMidTrimmed}", 회복기간_max: ${recoveryMax}, 회복기간_min: ${recoveryMin}`);
        if (recoveryMax === 0 && recoveryMin === 0) {
            console.warn(`⚠️ 회복 기간 값이 0입니다. category_mid: "${categoryMidTrimmed}", 매칭된 항목:`, matched);
            console.warn("🔍 사용 가능한 모든 키:", Object.keys(matched));
        }
        // 회복 기간에 맞는 텍스트 컬럼 선택 (회복기간_max 기준)
        let recoveryText = null;
        if (recoveryMax >= 1 && recoveryMax <= 3) {
            recoveryText = matched["1~3"] || null;
        } else if (recoveryMax >= 4 && recoveryMax <= 7) {
            recoveryText = matched["4~7"] || null;
        } else if (recoveryMax >= 8 && recoveryMax <= 14) {
            recoveryText = matched["8~14"] || null;
        } else if (recoveryMax >= 15 && recoveryMax <= 21) {
            recoveryText = matched["15~21"] || null;
        }
        return {
            recoveryMin,
            recoveryMax,
            recoveryText
        };
    } catch (error) {
        console.error("회복 기간 정보 로드 실패:", error);
        return null;
    }
}
async function loadHospitalMaster() {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from(TABLE_NAMES.HOSPITAL_MASTER).select("*");
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data || !Array.isArray(data)) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("병원 데이터 로드 실패:", error);
        throw error;
    }
}
async function loadTreatmentById(treatmentId) {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from(TABLE_NAMES.TREATMENT_MASTER).select("*").eq("treatment_id", treatmentId).single();
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return null;
        }
        return cleanData([
            data
        ])[0];
    } catch (error) {
        console.error("시술 데이터 로드 실패:", error);
        return null;
    }
}
async function loadRelatedTreatments(treatmentName, excludeId) {
    try {
        let query = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from(TABLE_NAMES.TREATMENT_MASTER).select("*").eq("treatment_name", treatmentName);
        if (excludeId) {
            query = query.neq("treatment_id", excludeId);
        }
        const { data, error } = await query.limit(50);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("관련 시술 데이터 로드 실패:", error);
        return [];
    }
}
async function loadHospitalTreatments(hospitalName, excludeId) {
    try {
        let query = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from(TABLE_NAMES.TREATMENT_MASTER).select("*").eq("hospital_name", hospitalName);
        if (excludeId) {
            query = query.neq("treatment_id", excludeId);
        }
        const { data, error } = await query.limit(10);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("병원 시술 데이터 로드 실패:", error);
        return [];
    }
}
async function loadHospitalsPaginated(page = 1, pageSize = 50, filters) {
    try {
        let query = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from(TABLE_NAMES.HOSPITAL_MASTER).select("*", {
            count: "exact"
        });
        // 필터 적용 (최소 2글자 이상일 때만 검색)
        if (filters?.searchTerm && filters.searchTerm.trim().length >= 2) {
            const term = filters.searchTerm.toLowerCase().trim();
            query = query.ilike("hospital_name", `%${term}%`);
        } else if (filters?.searchTerm && filters.searchTerm.trim().length === 1) {
            // 1글자일 때는 검색하지 않음 (빈 결과 반환)
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        // 페이지네이션
        const from = (page - 1) * pageSize;
        const to = from + pageSize - 1;
        const { data, error, count } = await query.range(from, to);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        const cleanedData = cleanData(data);
        const total = count || 0;
        const hasMore = to < total - 1;
        return {
            data: cleanedData,
            total,
            hasMore
        };
    } catch (error) {
        console.error("병원 데이터 페이지네이션 로드 실패:", error);
        throw error;
    }
}
async function getHospitalAutocomplete(searchTerm, limit = 10) {
    try {
        if (!searchTerm || searchTerm.length < 1) {
            return [];
        }
        const term = searchTerm.toLowerCase();
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from(TABLE_NAMES.HOSPITAL_MASTER).select("hospital_name").ilike("hospital_name", `%${term}%`).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return Array.from(new Set(data.map((h)=>h.hospital_name).filter(Boolean)));
    } catch (error) {
        console.error("병원 자동완성 데이터 로드 실패:", error);
        return [];
    }
}
async function loadKeywordMonthlyTrends() {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from(TABLE_NAMES.KEYWORD_MONTHLY_TRENDS).select("*");
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data || !Array.isArray(data)) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("키워드 트렌드 데이터 로드 실패:", error);
        throw error;
    }
}
async function loadAllData() {
    try {
        const [treatments, categoryData, hospitals, trends] = await Promise.all([
            loadTreatments(),
            loadCategoryTreatTimeRecovery(),
            loadHospitalMaster(),
            loadKeywordMonthlyTrends()
        ]);
        return {
            treatments,
            categoryTreatTimeRecovery: categoryData,
            hospitals,
            keywordTrends: trends
        };
    } catch (error) {
        console.error("전체 데이터 로드 실패:", error);
        throw error;
    }
}
function extractHospitalInfo(treatments) {
    const hospitalMap = new Map();
    treatments.forEach((treatment)=>{
        if (!treatment.hospital_name) return;
        const hospitalName = treatment.hospital_name;
        if (!hospitalMap.has(hospitalName)) {
            hospitalMap.set(hospitalName, {
                hospital_name: hospitalName,
                treatments: [],
                averageRating: 0,
                totalReviews: 0,
                procedures: [],
                categories: new Set()
            });
        }
        const hospital = hospitalMap.get(hospitalName);
        hospital.treatments.push(treatment);
        if (treatment.treatment_name) {
            hospital.procedures.push(treatment.treatment_name);
        }
        if (treatment.category_large) {
            hospital.categories.add(treatment.category_large);
        }
        if (treatment.rating) {
            hospital.averageRating += treatment.rating;
        }
        if (treatment.review_count) {
            hospital.totalReviews += treatment.review_count;
        }
    });
    // 평균 평점 계산 및 데이터 정리
    const hospitals = Array.from(hospitalMap.values()).map((hospital)=>{
        const treatmentCount = hospital.treatments.length;
        const avgRating = treatmentCount > 0 && hospital.averageRating > 0 ? hospital.averageRating / treatmentCount : 0;
        // 중복 제거 및 정렬
        const uniqueProcedures = Array.from(new Set(hospital.procedures)).slice(0, 10);
        return {
            ...hospital,
            averageRating: Math.round(avgRating * 10) / 10,
            procedures: uniqueProcedures,
            categories: hospital.categories
        };
    });
    // 평점 순으로 정렬
    return hospitals.sort((a, b)=>b.averageRating - a.averageRating);
}
function getThumbnailUrl(treatment) {
    // API에서 제공하는 main_image_url이 있으면 우선 사용
    if (treatment.main_image_url && treatment.main_image_url.trim() !== "") {
        return treatment.main_image_url;
    }
    // main_image_url이 없을 경우 고유한 플레이스홀더 생성
    const categoryColors = {
        리프팅: "667eea",
        피부: "f093fb",
        눈: "4facfe",
        코: "43e97b",
        입술: "fa709a",
        볼: "fee140",
        쁘띠: "30cfd0",
        기타: "667eea"
    };
    const category = treatment.category_large || "기타";
    const color = categoryColors[category] || "667eea";
    // treatment_id를 기반으로 고유한 이미지 생성
    const treatmentId = treatment.treatment_id || Math.random() * 1000;
    const seed = treatmentId % 1000;
    // 시술명의 첫 글자
    const firstChar = treatment.treatment_name ? treatment.treatment_name.charAt(0) : category.charAt(0);
    // data URI로 플레이스홀더 생성 (외부 서비스 의존성 제거)
    return `data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="300"%3E%3Crect fill="%23${color}" width="400" height="300"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="white" font-size="48" font-weight="bold"%3E${encodeURIComponent(firstChar)}%3C/text%3E%3C/svg%3E`;
}
function calculateRecommendationScore(treatment) {
    const rating = treatment.rating || 0;
    const reviewCount = treatment.review_count || 0;
    const price = treatment.selling_price || 0;
    // 평점 가중치 (40%)
    const ratingScore = rating * 40;
    // 리뷰 수 가중치 (30%) - 리뷰가 많을수록 좋음 (로그 스케일 사용)
    const reviewScore = Math.log10(reviewCount + 1) * 10 * 3;
    // 가격 인기도 점수 (20%) - 합리적인 가격대일수록 높은 점수
    // 평균 가격대 근처일수록 높은 점수 (간단한 휴리스틱)
    const priceScore = price > 0 && price < 1000000 ? 20 : 10;
    // 할인율 보너스 (10%)
    const discountBonus = treatment.dis_rate ? treatment.dis_rate * 0.1 : 0;
    return ratingScore + reviewScore + priceScore + discountBonus;
}
function getCategoryRankings(treatments, category) {
    let filtered = treatments;
    if (category) {
        filtered = treatments.filter((t)=>t.category_large === category || t.category_mid === category);
    }
    // 추천 점수 계산 후 정렬
    return filtered.map((treatment)=>({
            ...treatment,
            recommendationScore: calculateRecommendationScore(treatment)
        })).sort((a, b)=>b.recommendationScore - a.recommendationScore);
}
function getTreatmentRankings(treatments) {
    const treatmentMap = new Map();
    // 시술명으로 그룹화
    treatments.forEach((treatment)=>{
        if (!treatment.treatment_name) return;
        const name = treatment.treatment_name;
        if (!treatmentMap.has(name)) {
            treatmentMap.set(name, []);
        }
        treatmentMap.get(name).push(treatment);
    });
    // 랭킹 데이터 생성
    const rankings = Array.from(treatmentMap.entries()).map(([treatmentName, treatmentList])=>{
        const ratings = treatmentList.map((t)=>t.rating || 0).filter((r)=>r > 0);
        const reviews = treatmentList.map((t)=>t.review_count || 0).reduce((sum, count)=>sum + count, 0);
        const prices = treatmentList.map((t)=>t.selling_price || 0).filter((p)=>p > 0);
        const averageRating = ratings.length > 0 ? ratings.reduce((sum, r)=>sum + r, 0) / ratings.length : 0;
        const averagePrice = prices.length > 0 ? prices.reduce((sum, p)=>sum + p, 0) / prices.length : 0;
        // 대표 시술 3개 선택 (평점 높은 순)
        const topTreatments = [
            ...treatmentList
        ].sort((a, b)=>(b.rating || 0) - (a.rating || 0)).slice(0, 3);
        // 추천 점수 계산
        const representativeTreatment = {
            ...topTreatments[0],
            rating: averageRating,
            review_count: reviews
        };
        const recommendationScore = calculateRecommendationScore(representativeTreatment);
        return {
            treatmentName,
            treatments: treatmentList,
            averageRating,
            totalReviews: reviews,
            averagePrice,
            recommendationScore,
            topTreatments
        };
    }).sort((a, b)=>b.recommendationScore - a.recommendationScore);
    return rankings;
}
// K-beauty 관련 시술 필터링 (키워드 기반)
const KBEAUTY_KEYWORDS = [
    "리쥬란",
    "인모드",
    "슈링크",
    "윤곽",
    "주사",
    "보톡스",
    "필러",
    "리프팅",
    "탄력",
    "미백",
    "백옥",
    "프락셀",
    "피코",
    "레이저"
];
function getKBeautyRankings(treatments) {
    return treatments.filter((treatment)=>{
        const name = (treatment.treatment_name || "").toLowerCase();
        const hashtags = (treatment.treatment_hashtags || "").toLowerCase();
        const category = (treatment.category_large || "").toLowerCase();
        return KBEAUTY_KEYWORDS.some((keyword)=>name.includes(keyword.toLowerCase()) || hashtags.includes(keyword.toLowerCase()) || category.includes(keyword.toLowerCase()));
    }).map((treatment)=>({
            ...treatment,
            recommendationScore: calculateRecommendationScore(treatment)
        })).sort((a, b)=>b.recommendationScore - a.recommendationScore);
}
function parseRecoveryPeriod(downtime) {
    if (!downtime) return 0;
    if (typeof downtime === "number") return downtime;
    // 문자열인 경우 "1일", "2일", "1-2일" 등의 형식 파싱
    const match = downtime.toString().match(/(\d+)/);
    return match ? parseInt(match[1]) : 0;
}
function parseProcedureTime(surgeryTime) {
    if (!surgeryTime) return 0;
    if (typeof surgeryTime === "number") return surgeryTime;
    // 문자열인 경우 "30분", "60분" 등의 형식 파싱
    const match = surgeryTime.toString().match(/(\d+)/);
    return match ? parseInt(match[1]) : 0;
}
// 대분류 카테고리 매핑 (사용자 선택 카테고리 -> API 카테고리)
const CATEGORY_MAPPING = {
    눈성형: [
        "눈",
        "눈성형"
    ],
    리프팅: [
        "리프팅",
        "윤곽",
        "볼륨"
    ],
    보톡스: [
        "보톡스",
        "주사"
    ],
    "안면윤곽/양악": [
        "안면",
        "윤곽",
        "양악",
        "턱"
    ],
    제모: [
        "제모",
        "레이저"
    ],
    지방성형: [
        "지방",
        "체형",
        "다이어트",
        "지방흡입"
    ],
    코성형: [
        "코",
        "코성형"
    ],
    피부: [
        "피부",
        "피부관리"
    ],
    필러: [
        "필러",
        "주사"
    ],
    가슴성형: [
        "가슴",
        "유방",
        "보형물"
    ],
    기타: [
        "기타"
    ],
    전체: []
};
function getScheduleBasedRecommendations(treatments, categoryLarge, startDate, endDate) {
    // 여행 일수 계산
    const start = new Date(startDate);
    const end = new Date(endDate);
    const travelDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1; // n박 n일
    // 대분류 카테고리로 필터링
    const mappedCategories = CATEGORY_MAPPING[categoryLarge] || [
        categoryLarge
    ];
    const categoryFiltered = treatments.filter((t)=>{
        if (!t.category_large) return false;
        // "전체"인 경우 모든 시술 포함
        if (categoryLarge === "전체") {
            return true;
        }
        // "기타"인 경우: 다른 카테고리에 속하지 않는 것만
        if (categoryLarge === "기타") {
            const allOtherCategories = [
                "눈",
                "눈성형",
                "리프팅",
                "윤곽",
                "볼륨",
                "보톡스",
                "주사",
                "안면",
                "양악",
                "턱",
                "제모",
                "레이저",
                "지방",
                "체형",
                "다이어트",
                "지방흡입",
                "코",
                "코성형",
                "피부",
                "피부관리",
                "필러",
                "가슴",
                "유방",
                "보형물"
            ];
            const categoryLower = t.category_large?.toLowerCase() || "";
            const midCategoryLower = t.category_mid?.toLowerCase() || "";
            // 다른 카테고리에 속하지 않는지 확인
            const isInOtherCategory = allOtherCategories.some((otherCat)=>categoryLower.includes(otherCat.toLowerCase()) || midCategoryLower.includes(otherCat.toLowerCase()));
            return !isInOtherCategory;
        }
        // 일반 카테고리: category_large를 우선적으로 확인
        // category_large가 매핑된 카테고리 중 하나와 일치하는지 확인
        const categoryLargeLower = (t.category_large || "").toLowerCase();
        const categoryMidLower = (t.category_mid || "").toLowerCase();
        // category_large가 매핑된 카테고리 중 하나와 일치하는 경우
        const matchesLarge = mappedCategories.some((mapped)=>{
            const mappedLower = mapped.toLowerCase();
            return categoryLargeLower.includes(mappedLower);
        });
        if (matchesLarge) {
            return true;
        }
        // category_large가 매칭되지 않으면, category_mid만으로는 선택하지 않음
        // (이렇게 하면 다른 대분류의 시술이 잘못 필터링되는 것을 방지)
        //
        // TODO: 데이터가 10,000개 이상일 때는 더 엄격한 필터링 필요
        // - category_large와 category_mid 모두 정확히 매칭되어야 함
        // - 키워드 포함 검사 대신 정확한 문자열 매칭 사용
        // - 예: category_large === mapped (정확히 일치) && category_mid가 매핑된 중분류와 일치
        return false;
    });
    console.log(`[일정 기반 추천] 선택 카테고리: ${categoryLarge}, 필터링된 데이터: ${categoryFiltered.length}개`);
    // 중분류별로 그룹화 (대분류 + 중분류 조합으로 키 생성하여 중복 방지)
    const midCategoryMap = new Map();
    // "정맥주사" 중복 확인을 위한 디버깅
    const jeongmaekjusaTreatments = [];
    categoryFiltered.forEach((treatment)=>{
        const categoryLarge = treatment.category_large || "";
        const midCategory = treatment.category_mid || "기타";
        // "정맥주사" 데이터 수집 (선택된 카테고리 정보 포함)
        if (midCategory === "정맥주사" || midCategory.includes("정맥주사")) {
            jeongmaekjusaTreatments.push({
                categoryLarge,
                categoryMid: midCategory,
                treatmentName: treatment.treatment_name || "이름 없음",
                treatmentId: treatment.treatment_id,
                selectedCategory: categoryLarge
            });
        }
        // 대분류와 중분류를 조합하여 고유 키 생성
        const uniqueKey = `${categoryLarge}::${midCategory}`;
        if (!midCategoryMap.has(uniqueKey)) {
            midCategoryMap.set(uniqueKey, []);
        }
        midCategoryMap.get(uniqueKey).push(treatment);
    });
    // "정맥주사" 중복 확인 로그 - 각 대분류별로 다른 시술인지 확인
    if (jeongmaekjusaTreatments.length > 0) {
        const categoryLargeSet = new Set(jeongmaekjusaTreatments.map((t)=>t.categoryLarge));
        console.log("🔍 [정맥주사 데이터 분석]");
        console.log(`- 선택된 카테고리: ${categoryLarge}`);
        console.log(`- 총 ${jeongmaekjusaTreatments.length}개의 정맥주사 시술 발견`);
        console.log(`- 속한 대분류(category_large): ${Array.from(categoryLargeSet).join(", ")}`);
        console.log(`- 대분류 개수: ${categoryLargeSet.size}개`);
        // 대분류별로 그룹화하여 상세 정보 출력
        const byCategory = new Map();
        jeongmaekjusaTreatments.forEach((t)=>{
            const existing = byCategory.get(t.categoryLarge) || {
                count: 0,
                treatments: []
            };
            existing.count += 1;
            existing.treatments.push({
                name: t.treatmentName,
                id: t.treatmentId
            });
            byCategory.set(t.categoryLarge, existing);
        });
        // 각 대분류별 시술 목록 출력
        byCategory.forEach((data, cat)=>{
            console.log(`\n📋 [${cat}] 대분류의 정맥주사 시술 (${data.count}개):`);
            const treatmentNames = data.treatments.map((t)=>t.name);
            const treatmentIds = data.treatments.map((t)=>t.id).filter((id)=>id !== undefined);
            console.log(`  시술명: ${treatmentNames.slice(0, 5).join(", ")}${treatmentNames.length > 5 ? ` ... 외 ${treatmentNames.length - 5}개` : ""}`);
            console.log(`  시술 ID: ${treatmentIds.slice(0, 5).join(", ")}${treatmentIds.length > 5 ? ` ... 외 ${treatmentIds.length - 5}개` : ""}`);
        });
        // 중복 시술 확인 (같은 시술 ID가 여러 대분류에 있는지)
        const allTreatmentIds = new Map();
        jeongmaekjusaTreatments.forEach((t)=>{
            if (t.treatmentId !== undefined) {
                const existing = allTreatmentIds.get(t.treatmentId) || [];
                if (!existing.includes(t.categoryLarge)) {
                    existing.push(t.categoryLarge);
                }
                allTreatmentIds.set(t.treatmentId, existing);
            }
        });
        const duplicateTreatments = [];
        allTreatmentIds.forEach((categories, id)=>{
            if (categories.length > 1) {
                const treatment = jeongmaekjusaTreatments.find((t)=>t.treatmentId === id);
                if (treatment) {
                    duplicateTreatments.push({
                        id,
                        name: treatment.treatmentName,
                        categories
                    });
                }
            }
        });
        if (duplicateTreatments.length > 0) {
            console.error("❌ [문제 발견] 같은 시술이 여러 대분류에 중복되어 있습니다:");
            duplicateTreatments.forEach((d)=>{
                console.error(`  - 시술 ID ${d.id} (${d.name}): ${d.categories.join(", ")} 대분류에 중복`);
            });
            console.error("💡 이는 필터링 로직 문제로 인해 발생할 수 있습니다. 각 대분류별로 다른 시술이 표시되어야 합니다.");
        } else {
            console.log("✅ 각 대분류별로 다른 시술이 표시되고 있습니다.");
        }
        if (categoryLargeSet.size > 1) {
            console.warn("⚠️ 정맥주사가 여러 대분류에 속해있습니다:", Array.from(categoryLargeSet));
            console.log("💡 이는 데이터 상에서 '정맥주사' 중분류가 실제로 여러 대분류에 속해있기 때문입니다.");
        }
    }
    // 중분류별로 추천 데이터 생성
    const recommendations = Array.from(midCategoryMap.entries()).map(([uniqueKey, treatmentList])=>{
        // uniqueKey에서 중분류 이름만 추출 (대분류::중분류 형식)
        const categoryMid = uniqueKey.split("::")[1] || "기타";
        // 여행 기간에 맞는 시술만 필터링
        // 회복 기간이 여행 일수보다 작거나 같은 시술만 선택
        const suitableTreatments = treatmentList.filter((treatment)=>{
            const recoveryPeriod = parseRecoveryPeriod(treatment.downtime);
            // 회복기간 정보가 없으면 포함 (기본적으로 표시)
            if (recoveryPeriod === 0) return true;
            // 여행 일수에서 최소 1일은 여유를 둠 (시술 당일 제외)
            return recoveryPeriod <= travelDays - 1;
        });
        // 필터링 결과가 없거나 회복기간 정보가 없으면 전체 시술 표시 (최대 10개)
        // 회복기간 정보가 있는 경우에만 필터링 적용
        const hasRecoveryData = treatmentList.some((t)=>parseRecoveryPeriod(t.downtime) > 0);
        const finalTreatments = hasRecoveryData && suitableTreatments.length > 0 ? suitableTreatments : [
            ...treatmentList
        ].sort((a, b)=>{
            // 추천 점수로 정렬
            const scoreA = calculateRecommendationScore(a);
            const scoreB = calculateRecommendationScore(b);
            return scoreB - scoreA;
        }).slice(0, 20); // 최대 20개
        // 평균 회복 기간 계산
        const recoveryPeriods = finalTreatments.map((t)=>parseRecoveryPeriod(t.downtime)).filter((r)=>r > 0);
        const averageRecoveryPeriod = recoveryPeriods.length > 0 ? recoveryPeriods.reduce((sum, r)=>sum + r, 0) / recoveryPeriods.length : 0;
        // 평균 시술 시간 계산
        const procedureTimes = finalTreatments.map((t)=>parseProcedureTime(t.surgery_time)).filter((t)=>t > 0);
        const averageProcedureTime = procedureTimes.length > 0 ? procedureTimes.reduce((sum, t)=>sum + t, 0) / procedureTimes.length : 0;
        // 추천 점수로 정렬
        const sortedTreatments = finalTreatments.map((treatment)=>({
                ...treatment,
                recommendationScore: calculateRecommendationScore(treatment)
            })).sort((a, b)=>b.recommendationScore - a.recommendationScore);
        return {
            categoryMid,
            treatments: sortedTreatments,
            averageRecoveryPeriod: Math.round(averageRecoveryPeriod * 10) / 10,
            averageProcedureTime: Math.round(averageProcedureTime)
        };
    }).filter((rec)=>rec.treatments.length > 0) // 치료가 있는 중분류만
    .sort((a, b)=>{
        // 회복 기간이 짧은 순으로 정렬 (여행에 적합한 순서)
        if (a.averageRecoveryPeriod !== b.averageRecoveryPeriod) {
            return a.averageRecoveryPeriod - b.averageRecoveryPeriod;
        }
        // 추천 점수 순으로 정렬
        const scoreA = a.treatments[0]?.recommendationScore || 0;
        const scoreB = b.treatments[0]?.recommendationScore || 0;
        return scoreB - scoreA;
    });
    return recommendations;
}
// 플랫폼 우선순위 (높을수록 우선)
const PLATFORM_PRIORITY = {
    gangnamunni: 3,
    yeoti: 2,
    babitalk: 1
};
function sortTreatmentsByPlatform(treatments) {
    return [
        ...treatments
    ].sort((a, b)=>{
        const platformA = (a.platform || "").toLowerCase();
        const platformB = (b.platform || "").toLowerCase();
        const priorityA = PLATFORM_PRIORITY[platformA] || 0;
        const priorityB = PLATFORM_PRIORITY[platformB] || 0;
        // 우선순위가 높은 것이 앞에 오도록 (내림차순)
        return priorityB - priorityA;
    });
}
async function saveProcedureReview(data) {
    try {
        const reviewData = {
            user_id: data.user_id ?? 0,
            category: data.category,
            procedure_name: data.procedure_name,
            hospital_name: data.hospital_name || null,
            cost: data.cost,
            procedure_rating: data.procedure_rating,
            hospital_rating: data.hospital_rating,
            gender: data.gender,
            age_group: data.age_group,
            surgery_date: data.surgery_date || null,
            content: data.content,
            images: data.images && data.images.length > 0 ? data.images : null
        };
        const { data: insertedData, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("procedure_reviews").insert([
            reviewData
        ]).select("id").single();
        if (error) {
            console.error("시술후기 저장 실패:", error);
            return {
                success: false,
                error: error.message
            };
        }
        return {
            success: true,
            id: insertedData?.id
        };
    } catch (error) {
        console.error("시술후기 저장 중 오류:", error);
        return {
            success: false,
            error: error?.message || "시술후기 저장에 실패했습니다."
        };
    }
}
async function saveHospitalReview(data) {
    try {
        const reviewData = {
            user_id: data.user_id ?? 0,
            hospital_name: data.hospital_name,
            category_large: data.category_large,
            procedure_name: data.procedure_name || null,
            visit_date: data.visit_date || null,
            overall_satisfaction: data.overall_satisfaction || null,
            hospital_kindness: data.hospital_kindness || null,
            has_translation: data.has_translation ?? false,
            translation_satisfaction: data.has_translation && data.translation_satisfaction ? data.translation_satisfaction : null,
            content: data.content,
            images: data.images && data.images.length > 0 ? data.images : null
        };
        const { data: insertedData, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("hospital_reviews").insert([
            reviewData
        ]).select("id").single();
        if (error) {
            console.error("병원후기 저장 실패:", error);
            return {
                success: false,
                error: error.message
            };
        }
        return {
            success: true,
            id: insertedData?.id
        };
    } catch (error) {
        console.error("병원후기 저장 중 오류:", error);
        return {
            success: false,
            error: error?.message || "병원후기 저장에 실패했습니다."
        };
    }
}
async function saveConcernPost(data) {
    try {
        const postData = {
            user_id: data.user_id ?? 0,
            title: data.title,
            concern_category: data.concern_category,
            content: data.content
        };
        const { data: insertedData, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("concern_posts").insert([
            postData
        ]).select("id").single();
        if (error) {
            console.error("고민글 저장 실패:", error);
            return {
                success: false,
                error: error.message
            };
        }
        return {
            success: true,
            id: insertedData?.id
        };
    } catch (error) {
        console.error("고민글 저장 중 오류:", error);
        return {
            success: false,
            error: error?.message || "고민글 저장에 실패했습니다."
        };
    }
}
async function loadProcedureReviews(limit = 50) {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("procedure_reviews").select("*").order("created_at", {
            ascending: false
        }).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return data;
    } catch (error) {
        console.error("시술 후기 로드 실패:", error);
        return [];
    }
}
async function loadHospitalReviews(limit = 50) {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("hospital_reviews").select("*").order("created_at", {
            ascending: false
        }).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return data;
    } catch (error) {
        console.error("병원 후기 로드 실패:", error);
        return [];
    }
}
async function loadConcernPosts(limit = 50) {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("concern_posts").select("*").order("created_at", {
            ascending: false
        }).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return data;
    } catch (error) {
        console.error("고민글 로드 실패:", error);
        return [];
    }
}
}),
"[project]/components/AutocompleteInput.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AutocompleteInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
"use client";
;
;
;
function AutocompleteInput({ value, onChange, placeholder = "검색...", suggestions, onSuggestionSelect, onEnter, className = "" }) {
    const [showSuggestions, setShowSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [focusedIndex, setFocusedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(-1);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const suggestionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // 외부 클릭 시 자동완성 닫기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleClickOutside = (event)=>{
            if (inputRef.current && !inputRef.current.contains(event.target) && suggestionsRef.current && !suggestionsRef.current.contains(event.target)) {
                setShowSuggestions(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>document.removeEventListener("mousedown", handleClickOutside);
    }, []);
    // 검색어가 변경되면 자동완성 표시
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setShowSuggestions(value.length > 0 && suggestions.length > 0);
        setFocusedIndex(-1);
    }, [
        value,
        suggestions
    ]);
    const handleInputChange = (e)=>{
        onChange(e.target.value);
    };
    const handleSuggestionClick = (suggestion)=>{
        onChange(suggestion);
        setShowSuggestions(false);
        if (onSuggestionSelect) {
            onSuggestionSelect(suggestion);
        }
        inputRef.current?.blur();
    };
    const handleKeyDown = (e)=>{
        if (e.key === "Enter") {
            if (showSuggestions && suggestions.length > 0 && focusedIndex >= 0) {
                // 자동완성 항목이 선택된 경우
                e.preventDefault();
                handleSuggestionClick(suggestions[focusedIndex]);
            } else if (onEnter) {
                // 자동완성 항목이 선택되지 않은 경우 Enter 키 처리
                e.preventDefault();
                onEnter();
            }
            return;
        }
        if (!showSuggestions || suggestions.length === 0) return;
        if (e.key === "ArrowDown") {
            e.preventDefault();
            setFocusedIndex((prev)=>prev < suggestions.length - 1 ? prev + 1 : prev);
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setFocusedIndex((prev)=>prev > 0 ? prev - 1 : -1);
        } else if (e.key === "Escape") {
            setShowSuggestions(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-3 top-1/2 transform -translate-y-1/2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiSearch"], {
                            className: "text-gray-400 text-sm"
                        }, void 0, false, {
                            fileName: "[project]/components/AutocompleteInput.tsx",
                            lineNumber: 99,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 98,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: inputRef,
                        type: "text",
                        value: value,
                        onChange: handleInputChange,
                        onKeyDown: handleKeyDown,
                        onFocus: ()=>{
                            if (value.length > 0 && suggestions.length > 0) {
                                setShowSuggestions(true);
                            }
                        },
                        placeholder: placeholder,
                        className: `w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-main ${className}`
                    }, void 0, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 101,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/AutocompleteInput.tsx",
                lineNumber: 97,
                columnNumber: 7
            }, this),
            showSuggestions && suggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: suggestionsRef,
                className: "absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto",
                children: suggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>handleSuggestionClick(suggestion),
                        onMouseEnter: ()=>setFocusedIndex(index),
                        className: `w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${index === focusedIndex ? "bg-gray-50" : ""}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiSearch"], {
                                    className: "text-gray-400 text-xs"
                                }, void 0, false, {
                                    fileName: "[project]/components/AutocompleteInput.tsx",
                                    lineNumber: 134,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: suggestion
                                }, void 0, false, {
                                    fileName: "[project]/components/AutocompleteInput.tsx",
                                    lineNumber: 135,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AutocompleteInput.tsx",
                            lineNumber: 133,
                            columnNumber: 15
                        }, this)
                    }, index, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 124,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/AutocompleteInput.tsx",
                lineNumber: 119,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/AutocompleteInput.tsx",
        lineNumber: 96,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/SearchModal.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SearchModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AutocompleteInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AutocompleteInput.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
const MAX_RECENT_SEARCHES = 10; // 최대 최근 검색어 개수
const recommendedSearches = [
    {
        id: 1,
        name: "리쥬란힐러",
        badge: "BEST"
    },
    {
        id: 2,
        name: "써마지",
        badge: "BEST"
    },
    {
        id: 3,
        name: "쥬베룩",
        badge: "BEST"
    },
    {
        id: 4,
        name: "울쎄라",
        badge: "up"
    },
    {
        id: 5,
        name: "LDM",
        badge: "up"
    },
    {
        id: 6,
        name: "스킨부"
    },
    {
        id: 7,
        name: "올리지"
    },
    {
        id: 8,
        name: "튠페"
    },
    {
        id: 9,
        name: "쎄라플"
    },
    {
        id: 10,
        name: "리프터"
    }
];
const quickIcons = [
    {
        id: 1,
        label: "블프 세일 대축제",
        icon: "🛍️"
    },
    {
        id: 2,
        label: "요즘인기시술",
        icon: "⭐"
    },
    {
        id: 3,
        label: "혜택 플러스",
        icon: "💎"
    },
    {
        id: 4,
        label: "포인트 적립백서",
        icon: "📝"
    },
    {
        id: 5,
        label: "부작용 안심케어",
        icon: "🛡️"
    }
];
const recentEvents = [
    {
        id: 1,
        title: "Shurink Universe",
        clinic: "본연_슈링크 유니버스",
        location: "서울 강남역·본연성...",
        price: "120,000원",
        image: ""
    },
    {
        id: 2,
        title: "Eight longtime #인모드 #슈링크",
        clinic: "지방소멸 롱타임 인모드리프팅 슈링...",
        location: "서울 압구정역·에이...",
        price: "₩108,900",
        image: ""
    },
    {
        id: 3,
        title: "시술 시간 걱정 없이 인모드는 롱~모드로!",
        clinic: "롱모드 인모드 풀페이스 10분 FX...",
        location: "서울 홍대입구역·리...",
        price: "99,000원",
        image: ""
    },
    {
        id: 4,
        title: "후기 6,000+ 디에이 자려한 코성형",
        clinic: "예쁘면DA야_자려한 코성형_비순각코수...",
        location: "서울 역삼역·디에이...",
        price: "1,088,000원",
        image: ""
    }
];
const interestProcedures = [
    "인모드리프팅",
    "슈링크리프팅",
    "슈링크유니버스",
    "코재수술",
    "아이슈링크"
];
const categories = [
    {
        icon: "👁️",
        label: "눈성형"
    },
    {
        icon: "👃",
        label: "코성형"
    },
    {
        icon: "😊",
        label: "안면윤곽/양악"
    },
    {
        icon: "💪",
        label: "가슴성형"
    },
    {
        icon: "🏃",
        label: "지방성형"
    },
    {
        icon: "💉",
        label: "필러"
    },
    {
        icon: "💉",
        label: "보톡스"
    },
    {
        icon: "✨",
        label: "리프팅"
    },
    {
        icon: "🌟",
        label: "피부"
    },
    {
        icon: "✂️",
        label: "제모"
    },
    {
        icon: "💇",
        label: "모발이식"
    },
    {
        icon: "🦷",
        label: "치아"
    },
    {
        icon: "🍵",
        label: "한방"
    },
    {
        icon: "📦",
        label: "기타"
    }
];
function SearchModal({ isOpen, onClose }) {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedRegion, setSelectedRegion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("지역");
    const [recentSearches, setRecentSearches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [autocompleteSuggestions, setAutocompleteSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    // localStorage에서 최근 검색어 불러오기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }, []);
    // 자동완성 데이터 로드
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const loadAutocomplete = async ()=>{
            if (searchQuery.length < 1) {
                setAutocompleteSuggestions([]);
                return;
            }
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTreatmentAutocomplete"])(searchQuery, 10);
            const allSuggestions = [
                ...result.treatmentNames,
                ...result.hospitalNames
            ];
            setAutocompleteSuggestions(allSuggestions);
        };
        const debounceTimer = setTimeout(()=>{
            loadAutocomplete();
        }, 300);
        return ()=>clearTimeout(debounceTimer);
    }, [
        searchQuery
    ]);
    // 최근 검색어에 추가하는 함수
    const addToRecentSearches = (query)=>{
        const trimmedQuery = query.trim();
        if (!trimmedQuery) return;
        setRecentSearches((prev)=>{
            // 중복 제거 (기존 항목 제거 후 맨 앞에 추가)
            const filtered = prev.filter((item)=>item !== trimmedQuery);
            const updated = [
                trimmedQuery,
                ...filtered
            ].slice(0, MAX_RECENT_SEARCHES);
            // localStorage에 저장
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            return updated;
        });
    };
    // 개별 검색어 삭제
    const removeRecentSearch = (query, e)=>{
        e.stopPropagation(); // 버튼 클릭 이벤트 전파 방지
        setRecentSearches((prev)=>{
            const updated = prev.filter((item)=>item !== query);
            // localStorage에 저장
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            return updated;
        });
    };
    // 전체 검색어 삭제
    const clearAllRecentSearches = ()=>{
        setRecentSearches([]);
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    };
    const handleSearch = ()=>{
        if (searchQuery.trim()) {
            // 최근 검색어에 추가
            addToRecentSearches(searchQuery.trim());
            // 탐색 페이지로 이동하면서 검색어와 섹션 정보 전달
            router.push(`/explore?search=${encodeURIComponent(searchQuery.trim())}&section=procedure`);
            onClose();
        }
    };
    const handleKeyPress = (e)=>{
        if (e.key === "Enter") {
            handleSearch();
        }
    };
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[100] bg-white overflow-y-auto max-w-md mx-auto left-1/2 transform -translate-x-1/2 pb-20 w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sticky top-0 z-50 bg-white border-b border-gray-100 px-4 py-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClose,
                                className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                                    className: "text-gray-700 text-xl"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 216,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 212,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 relative",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AutocompleteInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    value: searchQuery,
                                    onChange: setSearchQuery,
                                    placeholder: "시술명/수술명을 입력해 주세요.",
                                    suggestions: autocompleteSuggestions,
                                    onSuggestionSelect: (suggestion)=>{
                                        setSearchQuery(suggestion);
                                        // 자동완성 선택 시 바로 검색 실행
                                        setTimeout(()=>{
                                            handleSearch();
                                        }, 100);
                                    },
                                    onEnter: handleSearch,
                                    className: "bg-gray-50 border border-gray-200"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 219,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 218,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleSearch,
                                className: "px-3 py-2 text-primary-main text-sm font-medium hover:bg-primary-main/10 rounded-lg transition-colors",
                                children: "검색"
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 235,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 211,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "flex items-center gap-1 text-gray-700 text-sm hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: selectedRegion
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 246,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiChevronDown"], {
                                    className: "text-gray-500 text-sm"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 247,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/SearchModal.tsx",
                            lineNumber: 245,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 244,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SearchModal.tsx",
                lineNumber: 210,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 py-6 space-y-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative bg-black rounded-2xl overflow-hidden p-6 min-h-[160px] flex items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute inset-0 opacity-5",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-0",
                                    style: {
                                        backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.1) 10px, rgba(255,255,255,0.1) 20px)"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 257,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 256,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative w-full",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start justify-between mb-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-white text-xs",
                                                children: "K-피부시술 세일 페스타, 모든 시술이 한자리에!"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 267,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-primary-main text-white px-3 py-1 rounded-full text-xs font-bold flex-shrink-0 ml-2",
                                                children: "~49% off"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 270,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 266,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-4xl font-black mb-3 leading-tight",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white",
                                                children: "BLACK"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 275,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-primary-light relative",
                                                children: [
                                                    "BEAUTY",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "absolute -top-1 -right-3 text-primary-main text-xs",
                                                        children: "★"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 278,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 276,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white",
                                                children: "FRIDAY"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 282,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 274,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-white text-sm",
                                        children: "11.11 — 12.10"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 284,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 265,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 255,
                        columnNumber: 9
                    }, this),
                    recentSearches.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-base font-bold text-gray-900",
                                        children: "최근 검색어"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 292,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: clearAllRecentSearches,
                                        className: "text-sm text-gray-500 hover:text-gray-700",
                                        children: "전체삭제"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 293,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 291,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 flex-wrap",
                                children: recentSearches.map((search, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setSearchQuery(search);
                                            addToRecentSearches(search); // 클릭 시에도 최근 검색어에 추가 (순서 업데이트)
                                            router.push(`/explore?search=${encodeURIComponent(search)}&section=procedure`);
                                            onClose();
                                        },
                                        className: "flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-full text-sm transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: search
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 316,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: (e)=>removeRecentSearch(search, e),
                                                className: "hover:bg-gray-300 rounded-full p-0.5 transition-colors",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IoClose"], {
                                                    className: "text-gray-500 text-sm"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/SearchModal.tsx",
                                                    lineNumber: 321,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 317,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, index, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 302,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 300,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 290,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-5 gap-4",
                        children: quickIcons.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "flex flex-col items-center gap-2 p-3 hover:bg-gray-50 rounded-xl transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-12 h-12 bg-gradient-to-br from-primary-light/20 to-primary-main/30 rounded-full flex items-center justify-center text-xl",
                                        children: item.icon
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 336,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-700 text-center leading-tight",
                                        children: item.label
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 339,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, item.id, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 332,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 330,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-base font-bold text-gray-900 mb-4",
                                children: "추천 검색어"
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 348,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-4",
                                children: recommendedSearches.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setSearchQuery(item.name);
                                            addToRecentSearches(item.name); // 추천 검색어 클릭 시에도 최근 검색어에 추가
                                            router.push(`/explore?search=${encodeURIComponent(item.name)}&section=procedure`);
                                            onClose();
                                        },
                                        className: "flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors text-left",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-primary-main font-bold text-sm min-w-[20px]",
                                                        children: item.id
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 368,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-gray-900 text-sm",
                                                        children: item.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 371,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 367,
                                                columnNumber: 17
                                            }, this),
                                            item.badge === "BEST" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "bg-primary-light/20 text-primary-main px-2 py-0.5 rounded text-xs font-semibold",
                                                children: "BEST"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 374,
                                                columnNumber: 19
                                            }, this),
                                            item.badge === "up" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-3 h-3 text-primary-main",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    fillRule: "evenodd",
                                                    d: "M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z",
                                                    clipRule: "evenodd"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/SearchModal.tsx",
                                                    lineNumber: 384,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 379,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, item.id, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 353,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 351,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 347,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SearchModal.tsx",
                lineNumber: 253,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/SearchModal.tsx",
        lineNumber: 208,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/Header.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/bs/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SearchModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SearchModal.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
function Header({ hasRankingBanner = false }) {
    const [isSearchOpen, setIsSearchOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLanguageOpen, setIsLanguageOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [logoError, setLogoError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const globeButtonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { language, setLanguage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [dropdownPosition, setDropdownPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        top: 0,
        right: 0
    });
    const languages = [
        {
            code: "KR",
            name: "한국어",
            flag: "🇰🇷"
        },
        {
            code: "EN",
            name: "English",
            flag: "🇺🇸"
        },
        {
            code: "JP",
            name: "日本語",
            flag: "🇯🇵"
        },
        {
            code: "CN",
            name: "中文",
            flag: "🇨🇳"
        }
    ];
    const selectedLanguage = languages.find((lang)=>lang.code === language) || languages[0];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (isLanguageOpen && globeButtonRef.current) {
            const rect = globeButtonRef.current.getBoundingClientRect();
            setDropdownPosition({
                top: rect.bottom + 8,
                right: window.innerWidth - rect.right
            });
        }
    }, [
        isLanguageOpen
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: `sticky ${hasRankingBanner ? "top-[41px]" : "top-0"} z-40 bg-white border-b border-gray-100 px-4 py-3`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>router.push("/"),
                            className: "flex items-center gap-2 hover:opacity-80 transition-opacity cursor-pointer",
                            children: !logoError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/beautrip-logo.png",
                                alt: "BeauTrip",
                                className: "h-6 w-auto object-contain",
                                onError: ()=>setLogoError(true)
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 63,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BsCloud"], {
                                className: "text-primary-main text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 70,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4 relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setIsSearchOpen(true),
                                    className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiSearch"], {
                                        className: "text-gray-700 text-xl"
                                    }, void 0, false, {
                                        fileName: "[project]/components/Header.tsx",
                                        lineNumber: 81,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            ref: globeButtonRef,
                                            onClick: ()=>setIsLanguageOpen(!isLanguageOpen),
                                            className: "p-2 hover:bg-gray-50 rounded-full transition-colors relative z-[100]",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiGlobe"], {
                                                className: "text-gray-700 text-xl"
                                            }, void 0, false, {
                                                fileName: "[project]/components/Header.tsx",
                                                lineNumber: 89,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this),
                                        isLanguageOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "fixed inset-0 z-[99]",
                                                    onClick: ()=>setIsLanguageOpen(false)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Header.tsx",
                                                    lineNumber: 93,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "fixed bg-white border border-gray-200 rounded-lg shadow-lg z-[100] min-w-[150px]",
                                                    style: {
                                                        top: `${dropdownPosition.top}px`,
                                                        right: `${dropdownPosition.right}px`
                                                    },
                                                    children: languages.map((lang)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>{
                                                                setLanguage(lang.code);
                                                                setIsLanguageOpen(false);
                                                            },
                                                            className: `w-full text-left px-4 py-2 hover:bg-gray-50 transition-colors flex items-center gap-2 ${selectedLanguage.code === lang.code ? "bg-primary-main/10" : ""}`,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: lang.flag
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 117,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-gray-700",
                                                                    children: lang.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 118,
                                                                    columnNumber: 25
                                                                }, this),
                                                                selectedLanguage.code === lang.code && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "ml-auto text-primary-main",
                                                                    children: "✓"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 122,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, lang.code, true, {
                                                            fileName: "[project]/components/Header.tsx",
                                                            lineNumber: 105,
                                                            columnNumber: 23
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Header.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 83,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "p-2 hover:bg-gray-50 rounded-full transition-colors relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiBell"], {
                                            className: "text-gray-700 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 131,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/Header.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/Header.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SearchModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isSearchOpen,
                onClose: ()=>setIsSearchOpen(false)
            }, void 0, false, {
                fileName: "[project]/components/Header.tsx",
                lineNumber: 137,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/components/BottomNavigation.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BottomNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
const navItems = [
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiHome"],
        labelKey: "nav.home",
        path: "/"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiCompass"],
        labelKey: "nav.explore",
        path: "/explore"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiUsers"],
        labelKey: "nav.community",
        path: "/community"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiCalendar"],
        labelKey: "nav.schedule",
        path: "/schedule"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiUser"],
        labelKey: "nav.mypage",
        path: "/mypage"
    }
];
function BottomNavigation({ disabled = false }) {
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLanguage"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: `fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 z-50 ${disabled ? "pointer-events-none" : ""}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-around items-center py-2",
            children: navItems.map((item)=>{
                const Icon = item.icon;
                const isActive = pathname === item.path;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    href: item.path,
                    className: `flex flex-col items-center justify-center gap-1 py-1 px-2 min-w-0 flex-1 transition-colors ${disabled ? "text-gray-300 cursor-not-allowed" : isActive ? "text-primary-main" : "text-gray-500"}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                            className: `text-xl ${disabled ? "text-gray-300" : isActive ? "text-primary-main" : "text-gray-500"}`
                        }, void 0, false, {
                            fileName: "[project]/components/BottomNavigation.tsx",
                            lineNumber: 43,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: `text-xs whitespace-nowrap ${disabled ? "text-gray-300" : isActive ? "text-primary-main font-medium" : "text-gray-500"}`,
                            children: t(item.labelKey)
                        }, void 0, false, {
                            fileName: "[project]/components/BottomNavigation.tsx",
                            lineNumber: 52,
                            columnNumber: 15
                        }, this)
                    ]
                }, item.path, true, {
                    fileName: "[project]/components/BottomNavigation.tsx",
                    lineNumber: 32,
                    columnNumber: 13
                }, this);
            })
        }, void 0, false, {
            fileName: "[project]/components/BottomNavigation.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/BottomNavigation.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/LoginModal.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LoginModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function LoginModal({ isOpen, onClose, onLoginSuccess }) {
    const [showIdLogin, setShowIdLogin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showOtherMethods, setShowOtherMethods] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showPassword, setShowPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [userId, setUserId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [autoLogin, setAutoLogin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLanguageOpen, setIsLanguageOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const languages = [
        {
            code: "KR",
            name: "한국어",
            flag: "🇰🇷"
        },
        {
            code: "EN",
            name: "English",
            flag: "🇺🇸"
        },
        {
            code: "JP",
            name: "日本語",
            flag: "🇯🇵"
        },
        {
            code: "CN",
            name: "中文",
            flag: "🇨🇳"
        }
    ];
    const [selectedLanguage, setSelectedLanguage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(languages[0]);
    if (!isOpen) return null;
    // 기본 화면에 보여줄 3개 버튼
    const mainProviders = [
        {
            id: "line",
            name: "라인으로 시작하기",
            icon: "💚",
            iconUrl: "https://i.namu.wiki/i/kyDav6gHAV_U2HT8cNbKPAFRq_eVp9ejfpLUF6EuASKIdxrnS46Oyp-yTVcMxVizhNtv1sbAqFvPCqL6ZeeJ6gMKZEKYf539mxj2O6M0ualyJigebq1sX3TJK-MRJTjRGD3KxrXMDlTye-Jlyj_LZQ.svg",
            bgColor: "bg-green-500",
            textColor: "text-white",
            hoverColor: "hover:bg-green-600"
        },
        {
            id: "wechat",
            name: "위챗으로 시작하기",
            icon: "💬",
            iconUrl: "https://play-lh.googleusercontent.com/QbSSiRcodmWx6HlezOtNu3vmZeuFqkQZQQO5Y2-Zg_jBRm-mXjhlXX5yFj8iphfqzQ=w240-h480-rw",
            bgColor: "bg-green-600",
            textColor: "text-white",
            hoverColor: "hover:bg-green-700"
        },
        {
            id: "google",
            name: "구글로 시작하기",
            icon: "🔍",
            iconUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Google_%22G%22_logo.svg/40px-Google_%22G%22_logo.svg.png",
            bgColor: "bg-white border-2 border-gray-200",
            textColor: "text-gray-900",
            hoverColor: "hover:bg-gray-50"
        }
    ];
    // "다른 방법으로 시작하기" 클릭 시 보여줄 나머지 5가지
    const otherProviders = [
        {
            id: "kakao",
            name: "카카오로 시작하기",
            icon: "💬",
            iconUrl: "https://i.namu.wiki/i/rfSfq1PXHlLFftR7t2sdPghtMZC40CnXCX5CSJ8Y08AQyFk593III3tyqySD0MQmvpACZkLxAoIlxcN0tzUaicvKMsYQFLciXX9TIULCNAAZ2W85RohnkhEf32u_S8D-bcvx3mUwq8Qk9G9dpl7lsQ.svg",
            bgColor: "bg-yellow-400",
            textColor: "text-gray-900",
            hoverColor: "hover:bg-yellow-500"
        },
        {
            id: "line",
            name: "라인으로 시작하기",
            icon: "💚",
            iconUrl: "https://i.namu.wiki/i/kyDav6gHAV_U2HT8cNbKPAFRq_eVp9ejfpLUF6EuASKIdxrnS46Oyp-yTVcMxVizhNtv1sbAqFvPCqL6ZeeJ6gMKZEKYf539mxj2O6M0ualyJigebq1sX3TJK-MRJTjRGD3KxrXMDlTye-Jlyj_LZQ.svg",
            bgColor: "bg-green-500",
            textColor: "text-white",
            hoverColor: "hover:bg-green-600"
        },
        {
            id: "tiktok",
            name: "틱톡으로 시작하기",
            icon: "🎵",
            iconUrl: "https://i.namu.wiki/i/Nbsu5mYaDa69cyzg3u1AOKe1aehV2_ERa5gUhtfhXLKi5Xfd7qNK_8MtyMITAitHYkB0AC7mOERlBPqTBwSN0ymI4sT89Ww80mk_4dHg3muqVvAqEmoQXLDvxy32IBR7SDLDMbGBwLa5RTioD7UtHA.svg",
            bgColor: "bg-black",
            textColor: "text-white",
            hoverColor: "hover:bg-gray-900"
        },
        {
            id: "wechat",
            name: "위챗으로 시작하기",
            icon: "💬",
            iconUrl: "https://play-lh.googleusercontent.com/QbSSiRcodmWx6HlezOtNu3vmZeuFqkQZQQO5Y2-Zg_jBRm-mXjhlXX5yFj8iphfqzQ=w240-h480-rw",
            bgColor: "bg-green-600",
            textColor: "text-white",
            hoverColor: "hover:bg-green-700"
        },
        {
            id: "x",
            name: "X로 시작하기",
            icon: "✖️",
            iconUrl: "https://i.namu.wiki/i/gNfFK8soCFFM_s8auMRPPWzCEq57AiVdK-IMZDiCOLp72PeTqE119R_sSwFSG1ki_GS7SlWonE_xbKWHOzuxB6ZvvWoGdO9m1v_Ru-uiUXZw4-ti9UZ6VkUm0eIpIk_xk5YXJbAmZYOxWcceqGpbtw.svg",
            bgColor: "bg-black",
            textColor: "text-white",
            hoverColor: "hover:bg-gray-900"
        },
        {
            id: "google",
            name: "구글로 시작하기",
            icon: "🔍",
            iconUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Google_%22G%22_logo.svg/40px-Google_%22G%22_logo.svg.png",
            bgColor: "bg-white border-2 border-gray-200",
            textColor: "text-gray-900",
            hoverColor: "hover:bg-gray-50"
        },
        {
            id: "apple",
            name: "APPLE로 시작하기",
            icon: "🍎",
            iconUrl: "https://i.namu.wiki/i/9tvgJgp73dHAbSbSYOFhw5QONVip7iMZk1EpkDIzrCPEJUHGL-0R78vZZJNdeXaX_31-UI8Qp35cMfWZoQrk2PpWwvornonrXvJNmmBPOcDa99Bu5mpTyu2S6VzRCg3EqQnb_5MtV31Qs4VqoR-WSw.svg",
            bgColor: "bg-black",
            textColor: "text-white",
            hoverColor: "hover:bg-gray-900"
        },
        {
            id: "facebook",
            name: "페이스북으로 시작하기",
            icon: "👤",
            iconUrl: "https://i.namu.wiki/i/gXdLw7t_gTL7CSyitlqoRJBFHeoX7tdCTZPymqNFs0b2W7dZO66PPE-qrojJkT58Zx_lUH0CLnhZneO5Bn9lpA.svg",
            bgColor: "bg-blue-600",
            textColor: "text-white",
            hoverColor: "hover:bg-blue-700"
        }
    ];
    const handleSocialLogin = (provider)=>{
        // TODO: 실제 소셜 로그인 API 연동
        console.log(`Login with ${provider}`);
        // 임시로 사용자 정보 생성 (실제로는 API에서 받아옴)
        const mockUserInfo = {
            username: provider === "kakao" ? "카카오사용자" : `${provider}사용자`,
            provider
        };
        onLoginSuccess(mockUserInfo);
    };
    const handleIdLogin = ()=>{
        if (!userId || !password) {
            alert("아이디와 비밀번호를 입력해주세요.");
            return;
        }
        // TODO: 실제 ID 로그인 API 연동
        console.log("ID Login:", {
            userId,
            password,
            autoLogin
        });
        const mockUserInfo = {
            username: userId,
            provider: "id"
        };
        onLoginSuccess(mockUserInfo);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[100] bg-white max-w-md mx-auto left-1/2 transform -translate-x-1/2 w-full flex flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-shrink-0 bg-white border-b border-gray-100 px-4 py-3 z-10 flex items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onClose,
                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                            className: "text-gray-700 text-xl"
                        }, void 0, false, {
                            fileName: "[project]/components/LoginModal.tsx",
                            lineNumber: 198,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/LoginModal.tsx",
                        lineNumber: 194,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "flex-1 text-center text-lg font-semibold text-gray-900",
                        children: "로그인"
                    }, void 0, false, {
                        fileName: "[project]/components/LoginModal.tsx",
                        lineNumber: 200,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-10"
                    }, void 0, false, {
                        fileName: "[project]/components/LoginModal.tsx",
                        lineNumber: 203,
                        columnNumber: 9
                    }, this),
                    " "
                ]
            }, void 0, true, {
                fileName: "[project]/components/LoginModal.tsx",
                lineNumber: 193,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 flex items-center justify-center overflow-y-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full px-6 py-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center mb-8",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-center mb-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    src: "/beautrip-logo.png",
                                    alt: "BeauTrip",
                                    width: 180,
                                    height: 60,
                                    className: "object-contain"
                                }, void 0, false, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 212,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/LoginModal.tsx",
                                lineNumber: 211,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/LoginModal.tsx",
                            lineNumber: 210,
                            columnNumber: 11
                        }, this),
                        !showIdLogin && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-3 mb-6",
                                    children: mainProviders.map((provider)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>handleSocialLogin(provider.id),
                                            className: `w-full ${provider.bgColor} ${provider.hoverColor} ${provider.textColor} py-4 rounded-xl font-semibold transition-colors flex items-center justify-center gap-3`,
                                            children: [
                                                provider.iconUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    src: provider.iconUrl,
                                                    alt: provider.name,
                                                    width: 24,
                                                    height: 24,
                                                    className: "object-contain"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/LoginModal.tsx",
                                                    lineNumber: 233,
                                                    columnNumber: 23
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xl",
                                                    children: provider.icon
                                                }, void 0, false, {
                                                    fileName: "[project]/components/LoginModal.tsx",
                                                    lineNumber: 241,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: provider.name
                                                }, void 0, false, {
                                                    fileName: "[project]/components/LoginModal.tsx",
                                                    lineNumber: 243,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, provider.id, true, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 227,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 225,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center mb-6",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setShowOtherMethods(true),
                                        className: "text-gray-600 text-sm hover:text-primary-main transition-colors underline",
                                        children: "아이디 또는 다른 방법으로 로그인"
                                    }, void 0, false, {
                                        fileName: "[project]/components/LoginModal.tsx",
                                        lineNumber: 250,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 249,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-center gap-4 pt-4 border-t border-gray-200",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "text-gray-600 text-sm hover:text-primary-main transition-colors",
                                            children: "회원가입"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 260,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-300",
                                            children: "|"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 263,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "text-gray-600 text-sm hover:text-primary-main transition-colors",
                                            children: "아이디 찾기"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 264,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-300",
                                            children: "|"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 267,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "text-gray-600 text-sm hover:text-primary-main transition-colors",
                                            children: "비밀번호 찾기"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 268,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 259,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true),
                        showIdLogin && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "block text-sm font-medium text-gray-700 mb-2",
                                            children: "아이디"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 279,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            value: userId,
                                            onChange: (e)=>setUserId(e.target.value),
                                            placeholder: "아이디를 입력하세요",
                                            className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main focus:border-transparent"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 282,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 278,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "block text-sm font-medium text-gray-700 mb-2",
                                            children: "비밀번호"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 292,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: showPassword ? "text" : "password",
                                                    value: password,
                                                    onChange: (e)=>setPassword(e.target.value),
                                                    placeholder: "비밀번호를 입력하세요",
                                                    className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main focus:border-transparent pr-12"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/LoginModal.tsx",
                                                    lineNumber: 296,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: ()=>setShowPassword(!showPassword),
                                                    className: "absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700",
                                                    children: showPassword ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiEyeOff"], {
                                                        className: "text-xl"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/LoginModal.tsx",
                                                        lineNumber: 309,
                                                        columnNumber: 23
                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiEye"], {
                                                        className: "text-xl"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/LoginModal.tsx",
                                                        lineNumber: 311,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/LoginModal.tsx",
                                                    lineNumber: 303,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 295,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 291,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "checkbox",
                                            id: "autoLogin",
                                            checked: autoLogin,
                                            onChange: (e)=>setAutoLogin(e.target.checked),
                                            className: "w-4 h-4 text-primary-main border-gray-300 rounded focus:ring-primary-main"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 318,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            htmlFor: "autoLogin",
                                            className: "ml-2 text-sm text-gray-700",
                                            children: "자동로그인"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 325,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 317,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleIdLogin,
                                    className: "w-full bg-primary-main hover:bg-primary-light text-white py-4 rounded-xl font-semibold transition-colors",
                                    children: "로그인"
                                }, void 0, false, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 333,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setShowIdLogin(false),
                                    className: "w-full text-gray-600 text-sm hover:text-primary-main transition-colors py-2",
                                    children: "다른 로그인 방법"
                                }, void 0, false, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 340,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-center gap-4 pt-4 border-t border-gray-200",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "text-gray-600 text-sm hover:text-primary-main transition-colors",
                                            children: "회원가입"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 349,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-300",
                                            children: "|"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 352,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "text-gray-600 text-sm hover:text-primary-main transition-colors",
                                            children: "아이디 찾기"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 353,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-300",
                                            children: "|"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 356,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "text-gray-600 text-sm hover:text-primary-main transition-colors",
                                            children: "비밀번호 찾기"
                                        }, void 0, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 357,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 348,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/LoginModal.tsx",
                            lineNumber: 277,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/LoginModal.tsx",
                    lineNumber: 208,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/LoginModal.tsx",
                lineNumber: 207,
                columnNumber: 7
            }, this),
            showOtherMethods && !showIdLogin && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "fixed inset-0 bg-black/50 z-[110] transition-opacity",
                        onClick: ()=>setShowOtherMethods(false)
                    }, void 0, false, {
                        fileName: "[project]/components/LoginModal.tsx",
                        lineNumber: 370,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white rounded-t-3xl z-[120] shadow-2xl transition-transform duration-300 ease-out",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-6 py-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-center gap-4 mb-6 flex-wrap",
                                    children: otherProviders.filter((p)=>!mainProviders.some((mp)=>mp.id === p.id)).map((provider)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>{
                                                handleSocialLogin(provider.id);
                                                setShowOtherMethods(false);
                                            },
                                            className: `w-14 h-14 rounded-full ${provider.bgColor} ${provider.hoverColor} flex items-center justify-center transition-colors`,
                                            children: provider.iconUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                src: provider.iconUrl,
                                                alt: provider.name,
                                                width: 24,
                                                height: 24,
                                                className: "object-contain"
                                            }, void 0, false, {
                                                fileName: "[project]/components/LoginModal.tsx",
                                                lineNumber: 392,
                                                columnNumber: 25
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xl",
                                                children: provider.icon
                                            }, void 0, false, {
                                                fileName: "[project]/components/LoginModal.tsx",
                                                lineNumber: 400,
                                                columnNumber: 25
                                            }, this)
                                        }, provider.id, false, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 383,
                                            columnNumber: 21
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 379,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        setShowOtherMethods(false);
                                        setShowIdLogin(true);
                                    },
                                    className: "w-full bg-white border border-gray-300 rounded-xl text-gray-700 py-3 hover:bg-gray-50 transition-colors text-sm",
                                    children: "아이디로 로그인"
                                }, void 0, false, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 407,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/LoginModal.tsx",
                            lineNumber: 377,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/LoginModal.tsx",
                        lineNumber: 376,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed bottom-6 right-6 z-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setIsLanguageOpen(!isLanguageOpen),
                            className: "bg-primary-main text-white p-3 rounded-full shadow-lg hover:bg-primary-light transition-colors",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiGlobe"], {
                                className: "text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/LoginModal.tsx",
                                lineNumber: 428,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/LoginModal.tsx",
                            lineNumber: 424,
                            columnNumber: 11
                        }, this),
                        isLanguageOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "fixed inset-0 z-40",
                                    onClick: ()=>setIsLanguageOpen(false)
                                }, void 0, false, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 432,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute right-0 bottom-full mb-2 bg-white border border-gray-200 rounded-lg shadow-lg z-50 min-w-[150px]",
                                    children: languages.map((lang)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>{
                                                setSelectedLanguage(lang);
                                                setIsLanguageOpen(false);
                                            },
                                            className: `w-full text-left px-4 py-2 hover:bg-gray-50 transition-colors flex items-center gap-2 ${selectedLanguage.code === lang.code ? "bg-primary-main/10" : ""}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: lang.flag
                                                }, void 0, false, {
                                                    fileName: "[project]/components/LoginModal.tsx",
                                                    lineNumber: 450,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-sm text-gray-700",
                                                    children: lang.name
                                                }, void 0, false, {
                                                    fileName: "[project]/components/LoginModal.tsx",
                                                    lineNumber: 451,
                                                    columnNumber: 21
                                                }, this),
                                                selectedLanguage.code === lang.code && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "ml-auto text-primary-main",
                                                    children: "✓"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/LoginModal.tsx",
                                                    lineNumber: 453,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, lang.code, true, {
                                            fileName: "[project]/components/LoginModal.tsx",
                                            lineNumber: 438,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/components/LoginModal.tsx",
                                    lineNumber: 436,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/LoginModal.tsx",
                    lineNumber: 423,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/LoginModal.tsx",
                lineNumber: 422,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/LoginModal.tsx",
        lineNumber: 191,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/MyPage.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MyPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Header.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/BottomNavigation.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$LoginModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/LoginModal.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
function MyPage() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [isLoggedIn, setIsLoggedIn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showLogin, setShowLogin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [userInfo, setUserInfo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // Check if user is logged in
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const loggedIn = localStorage.getItem("isLoggedIn") === "true";
        const savedUserInfo = localStorage.getItem("userInfo");
        setIsLoggedIn(loggedIn);
        if (savedUserInfo) {
            try {
                setUserInfo(JSON.parse(savedUserInfo));
            } catch (e) {
                console.error("Failed to parse user info", e);
            }
        }
        if (!loggedIn) {
            setShowLogin(true);
        }
    }, []);
    const handleLoginSuccess = (userInfo)=>{
        localStorage.setItem("isLoggedIn", "true");
        if (userInfo) {
            localStorage.setItem("userInfo", JSON.stringify(userInfo));
            setUserInfo(userInfo);
        }
        setIsLoggedIn(true);
        setShowLogin(false);
    };
    const handleLogout = ()=>{
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userInfo");
        setIsLoggedIn(false);
        setUserInfo(null);
        setShowLogin(true);
    };
    // 로그인하지 않았을 때는 로그인 화면만 표시
    if (!isLoggedIn) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$LoginModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            isOpen: true,
            onClose: ()=>{
                router.push("/");
            },
            onLoginSuccess: handleLoginSuccess
        }, void 0, false, {
            fileName: "[project]/components/MyPage.tsx",
            lineNumber: 72,
            columnNumber: 7
        }, this);
    }
    // 로그인했을 때만 마이페이지 내용 표시
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white max-w-md mx-auto w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 py-4 flex items-center justify-between border-b border-gray-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-xl font-bold text-gray-900",
                    children: "마이페이지"
                }, void 0, false, {
                    fileName: "[project]/components/MyPage.tsx",
                    lineNumber: 89,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 88,
                columnNumber: 7
            }, this),
            isLoggedIn && userInfo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-4 mt-4 bg-white border border-gray-200 rounded-xl p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4 mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-16 h-16 bg-gradient-to-br from-primary-light to-primary-main rounded-full flex items-center justify-center text-3xl",
                                children: "😊"
                            }, void 0, false, {
                                fileName: "[project]/components/MyPage.tsx",
                                lineNumber: 96,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 mb-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "text-lg font-bold text-gray-900",
                                                children: userInfo.username
                                            }, void 0, false, {
                                                fileName: "[project]/components/MyPage.tsx",
                                                lineNumber: 101,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "bg-primary-light/20 text-primary-main px-2 py-0.5 rounded text-xs font-semibold",
                                                children: "Lv.1"
                                            }, void 0, false, {
                                                fileName: "[project]/components/MyPage.tsx",
                                                lineNumber: 104,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/MyPage.tsx",
                                        lineNumber: 100,
                                        columnNumber: 15
                                    }, this),
                                    userInfo.provider && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-500",
                                        children: userInfo.provider === "id" ? "일반 로그인" : `${userInfo.provider.toUpperCase()} 로그인`
                                    }, void 0, false, {
                                        fileName: "[project]/components/MyPage.tsx",
                                        lineNumber: 109,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/MyPage.tsx",
                                lineNumber: 99,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 95,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between pt-4 border-t border-gray-100",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-6 h-6 bg-primary-main rounded-full flex items-center justify-center",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-white text-xs font-bold",
                                            children: "P"
                                        }, void 0, false, {
                                            fileName: "[project]/components/MyPage.tsx",
                                            lineNumber: 122,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/MyPage.tsx",
                                        lineNumber: 121,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-sm text-gray-700",
                                        children: "내 포인트"
                                    }, void 0, false, {
                                        fileName: "[project]/components/MyPage.tsx",
                                        lineNumber: 124,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/MyPage.tsx",
                                lineNumber: 120,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-lg font-bold text-primary-main",
                                        children: "5,000 P"
                                    }, void 0, false, {
                                        fileName: "[project]/components/MyPage.tsx",
                                        lineNumber: 127,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                                        className: "text-gray-400"
                                    }, void 0, false, {
                                        fileName: "[project]/components/MyPage.tsx",
                                        lineNumber: 130,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/MyPage.tsx",
                                lineNumber: 126,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 119,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 94,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pb-20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MainContent, {
                    router: router,
                    onLogout: handleLogout
                }, void 0, false, {
                    fileName: "[project]/components/MyPage.tsx",
                    lineNumber: 138,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 137,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 141,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/MyPage.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
// 통합된 메인 컨텐츠
function MainContent({ router, onLogout }) {
    const [favoriteCount, setFavoriteCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        procedures: 0,
        hospitals: 0
    });
    const [scrapCount, setScrapCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [reviewCount, setReviewCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [language, setLanguage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("KR");
    const [currency, setCurrency] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("KRW");
    const [notifications, setNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        push: true,
        email: false,
        sms: false
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // 찜목록 개수 로드
        const favorites = JSON.parse(localStorage.getItem("favorites") || "[]");
        const procedures = favorites.filter((f)=>f.type === "procedure").length;
        const hospitals = favorites.filter((f)=>f.type === "clinic").length;
        setFavoriteCount({
            procedures,
            hospitals
        });
        // 스크랩 개수 로드
        const scraps = JSON.parse(localStorage.getItem("communityScraps") || "[]");
        setScrapCount(scraps.length);
        // 내가 쓴 후기 개수 로드
        const reviews = JSON.parse(localStorage.getItem("reviews") || "[]");
        setReviewCount(reviews.length);
        // 설정 로드
        const savedLanguage = localStorage.getItem("language") || "KR";
        setLanguage(savedLanguage);
        const savedCurrency = localStorage.getItem("currency") || "KRW";
        setCurrency(savedCurrency);
        const savedNotifications = localStorage.getItem("notifications");
        if (savedNotifications) {
            try {
                setNotifications(JSON.parse(savedNotifications));
            } catch (e) {
                console.error("Failed to parse notifications", e);
            }
        }
    }, []);
    const handleLanguageChange = ()=>{
        const languages = [
            "KR",
            "EN",
            "JP",
            "CN"
        ];
        const currentIndex = languages.indexOf(language);
        const nextIndex = (currentIndex + 1) % languages.length;
        const nextLanguage = languages[nextIndex];
        setLanguage(nextLanguage);
        localStorage.setItem("language", nextLanguage);
        window.dispatchEvent(new Event("languageChanged"));
    };
    const handleCurrencyChange = ()=>{
        const currencies = [
            "KRW",
            "USD",
            "JPY",
            "CNY"
        ];
        const currentIndex = currencies.indexOf(currency);
        const nextIndex = (currentIndex + 1) % currencies.length;
        const nextCurrency = currencies[nextIndex];
        setCurrency(nextCurrency);
        localStorage.setItem("currency", nextCurrency);
    };
    const handleNotificationToggle = (type)=>{
        const updated = {
            ...notifications,
            [type]: !notifications[type]
        };
        setNotifications(updated);
        localStorage.setItem("notifications", JSON.stringify(updated));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "px-4 py-4 space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white border border-gray-200 rounded-xl overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiFileText"],
                        label: "AI 리포트",
                        onClick: ()=>{
                            alert("AI 리포트 기능은 준비 중입니다.");
                        }
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 228,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiActivity"],
                        label: "AI 피부분석",
                        onClick: ()=>{
                            alert("AI 피부분석 기능은 준비 중입니다.");
                        },
                        isButton: true
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 235,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 227,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white border border-gray-200 rounded-xl overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-4 py-3 bg-gray-50 border-b border-gray-200",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-sm font-semibold text-gray-900",
                            children: "찜목록"
                        }, void 0, false, {
                            fileName: "[project]/components/MyPage.tsx",
                            lineNumber: 248,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 247,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiHeart"],
                        label: "시술",
                        badge: favoriteCount.procedures,
                        onClick: ()=>router.push("/favorites?type=procedure")
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 250,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiHeart"],
                        label: "병원",
                        badge: favoriteCount.hospitals,
                        onClick: ()=>router.push("/favorites?type=clinic")
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 256,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiBookmark"],
                        label: "글 스크랩",
                        badge: scrapCount,
                        onClick: ()=>{
                            alert("스크랩한 글 목록 기능은 준비 중입니다.");
                        }
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 262,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 246,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white border border-gray-200 rounded-xl overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiEdit3"],
                        label: "내가 쓴 후기",
                        badge: reviewCount,
                        onClick: ()=>{
                            alert("내가 쓴 후기 목록 기능은 준비 중입니다.");
                        }
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 274,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiEdit3"],
                        label: "글 작성",
                        onClick: ()=>{
                            alert("글 작성 기능은 준비 중입니다.");
                        },
                        isButton: true
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 282,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 273,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white border border-gray-200 rounded-xl overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-4 py-3 bg-gray-50 border-b border-gray-200",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-sm font-semibold text-gray-900",
                            children: "언어 / 통화 설정"
                        }, void 0, false, {
                            fileName: "[project]/components/MyPage.tsx",
                            lineNumber: 295,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 294,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiGlobe"],
                        label: "언어",
                        value: language === "KR" ? "한국어" : language === "EN" ? "English" : language === "JP" ? "日本語" : "中文",
                        onClick: handleLanguageChange
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 299,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiDollarSign"],
                        label: "통화",
                        value: currency,
                        onClick: handleCurrencyChange
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 313,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 293,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white border border-gray-200 rounded-xl overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-4 py-3 bg-gray-50 border-b border-gray-200",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-sm font-semibold text-gray-900",
                            children: "알림"
                        }, void 0, false, {
                            fileName: "[project]/components/MyPage.tsx",
                            lineNumber: 324,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 323,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ToggleMenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiBell"],
                        label: "푸시 알림",
                        checked: notifications.push,
                        onChange: ()=>handleNotificationToggle("push")
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 326,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ToggleMenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiBell"],
                        label: "이메일 알림",
                        checked: notifications.email,
                        onChange: ()=>handleNotificationToggle("email")
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 332,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ToggleMenuItem, {
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiBell"],
                        label: "SMS 알림",
                        checked: notifications.sms,
                        onChange: ()=>handleNotificationToggle("sms")
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 338,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 322,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white border border-gray-200 rounded-xl overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MenuItem, {
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiLogOut"],
                    label: "로그아웃",
                    onClick: ()=>{
                        if (confirm("정말 로그아웃 하시겠습니까?")) {
                            onLogout();
                        }
                    },
                    isButton: true
                }, void 0, false, {
                    fileName: "[project]/components/MyPage.tsx",
                    lineNumber: 348,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 347,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/MyPage.tsx",
        lineNumber: 225,
        columnNumber: 5
    }, this);
}
function MenuItem({ icon: Icon, label, badge, value, onClick, isButton = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: onClick,
        className: `w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-b-0 ${isButton ? "bg-primary-main/5" : ""}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                        className: `text-gray-600 text-xl ${isButton ? "text-primary-main" : ""}`
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 386,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `text-sm ${isButton ? "text-primary-main font-semibold" : "text-gray-900"}`,
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 391,
                        columnNumber: 9
                    }, this),
                    badge !== undefined && badge > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "bg-primary-main text-white text-xs font-semibold px-2 py-0.5 rounded-full",
                        children: badge
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 399,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 385,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2",
                children: [
                    value && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-sm text-gray-500",
                        children: value
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 405,
                        columnNumber: 19
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                        className: "text-gray-400"
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 406,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 404,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/MyPage.tsx",
        lineNumber: 379,
        columnNumber: 5
    }, this);
}
function ToggleMenuItem({ icon: Icon, label, checked, onChange }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center justify-between p-4 border-b border-gray-100 last:border-b-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                        className: "text-gray-600 text-xl"
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 426,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-sm text-gray-900",
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/components/MyPage.tsx",
                        lineNumber: 427,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 425,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: onChange,
                className: `relative w-11 h-6 rounded-full transition-colors ${checked ? "bg-primary-main" : "bg-gray-300"}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: `absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${checked ? "translate-x-5" : "translate-x-0"}`
                }, void 0, false, {
                    fileName: "[project]/components/MyPage.tsx",
                    lineNumber: 435,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/MyPage.tsx",
                lineNumber: 429,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/MyPage.tsx",
        lineNumber: 424,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/mypage/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MyPageRoute
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$MyPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/MyPage.tsx [app-ssr] (ecmascript)");
'use client';
;
;
function MyPageRoute() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$MyPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/app/mypage/page.tsx",
        lineNumber: 6,
        columnNumber: 10
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__e6e39261._.js.map