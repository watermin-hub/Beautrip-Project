(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_d5b49a11._.js",
  "static/chunks/node_modules_react-icons_io5_index_esm_e1ec9d20.js",
  "static/chunks/node_modules_react-icons_fi_index_esm_00274d2f.js",
  "static/chunks/node_modules_react-icons_bs_index_esm_f37a2151.js",
  "static/chunks/node_modules_react-icons_lib_esm_fa2222d7._.js",
  "static/chunks/node_modules_next_85a48ffd._.js",
  "static/chunks/node_modules_@supabase_realtime-js_dist_module_a6b8d2d8._.js",
  "static/chunks/node_modules_@supabase_storage-js_dist_module_4307daaa._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_58e31de5._.js",
  "static/chunks/node_modules_bd589865._.js"
],
    source: "dynamic"
});
