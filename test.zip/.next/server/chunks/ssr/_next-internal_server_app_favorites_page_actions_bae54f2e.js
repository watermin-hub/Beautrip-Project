module.exports=[85224,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_favorites_page_actions_bae54f2e.js.map