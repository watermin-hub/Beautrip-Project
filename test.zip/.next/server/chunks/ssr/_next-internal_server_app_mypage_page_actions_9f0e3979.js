module.exports=[91779,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mypage_page_actions_9f0e3979.js.map