module.exports=[3292,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hospital_%5Bid%5D_page_actions_f0cf42c6.js.map