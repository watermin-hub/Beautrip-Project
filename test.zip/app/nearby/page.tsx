'use client'

import NearbyPage from '@/components/NearbyPage'

export default function Nearby() {
  return <NearbyPage />
}

