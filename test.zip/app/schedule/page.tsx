'use client'

import MySchedulePage from '@/components/MySchedulePage'

export default function Schedule() {
  return <MySchedulePage />
}

