'use client'

import MyPage from '@/components/MyPage'

export default function MyPageRoute() {
  return <MyPage />
}

