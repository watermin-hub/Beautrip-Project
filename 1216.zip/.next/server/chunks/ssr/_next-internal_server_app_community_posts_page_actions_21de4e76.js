module.exports=[79099,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_community_posts_page_actions_21de4e76.js.map