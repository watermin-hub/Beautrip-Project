module.exports=[17970,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_community_photo-review_page_actions_aa52815c.js.map