module.exports=[56696,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_community_page_actions_bed73931.js.map