module.exports=[53964,a=>{"use strict";var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call LanguageProvider() from the server but LanguageProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/contexts/LanguageContext.tsx <module evaluation>","LanguageProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useLanguage() from the server but useLanguage is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/contexts/LanguageContext.tsx <module evaluation>","useLanguage");a.s(["LanguageProvider",0,c,"useLanguage",0,d])},84377,a=>{"use strict";var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call LanguageProvider() from the server but LanguageProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/contexts/LanguageContext.tsx","LanguageProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useLanguage() from the server but useLanguage is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/contexts/LanguageContext.tsx","useLanguage");a.s(["LanguageProvider",0,c,"useLanguage",0,d])},40084,a=>{"use strict";a.i(53964);var b=a.i(84377);a.n(b)},72123,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(11857);a.n(d("[project]/node_modules/next/dist/client/script.js <module evaluation>"))},44536,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(11857);a.n(d("[project]/node_modules/next/dist/client/script.js"))},11153,a=>{"use strict";a.i(72123);var b=a.i(44536);a.n(b)},71618,(a,b,c)=>{b.exports=a.r(11153)},6128,a=>{"use strict";let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/AppShell.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/AppShell.tsx <module evaluation>","default");a.s(["default",0,b])},57944,a=>{"use strict";let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/AppShell.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/AppShell.tsx","default");a.s(["default",0,b])},30362,a=>{"use strict";a.i(6128);var b=a.i(57944);a.n(b)},33290,a=>{"use strict";var b=a.i(7997),c=a.i(40084),d=a.i(71618),e=a.i(30362);function f({children:a}){return(0,b.jsxs)("html",{lang:"ko",children:[(0,b.jsxs)("head",{children:[(0,b.jsx)(d.default,{id:"gtm",strategy:"afterInteractive",children:`
            (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','GTM-NSNM597H');
          `}),(0,b.jsx)(d.default,{src:"https://www.googletagmanager.com/gtag/js?id=G-H9Y2PPYJHH",strategy:"afterInteractive"}),(0,b.jsx)(d.default,{id:"ga",strategy:"afterInteractive",children:`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-H9Y2PPYJHH', {
              debug_mode: false
            });
          `}),(0,b.jsx)(d.default,{id:"hotjar-cs",strategy:"afterInteractive",children:`
            (function (c, s, q, u, a, r, e) {
              c.hj=c.hj||function(){(c.hj.q=c.hj.q||[]).push(arguments)};
              c._hjSettings = { hjid: a };
              r = s.getElementsByTagName('head')[0];
              e = s.createElement('script');
              e.async = true;
              e.src = q + c._hjSettings.hjid + u;
              r.appendChild(e);
            })(window, document, 'https://static.hj.contentsquare.net/c/csq-', '.js', 6601517);
          `}),(0,b.jsx)(d.default,{id:"ms-clarity-tag",strategy:"afterInteractive",children:`(function(c,l,a,r,i,t,y){
c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
})(window, document, "clarity", "script", "um9tacq35m");`})]}),(0,b.jsxs)("body",{className:"flex justify-center",children:[(0,b.jsx)("noscript",{children:(0,b.jsx)("iframe",{src:"https://www.googletagmanager.com/ns.html?id=GTM-NSNM597H",height:"0",width:"0",style:{display:"none",visibility:"hidden"}})}),(0,b.jsx)(c.LanguageProvider,{children:(0,b.jsx)(e.default,{children:a})})]})]})}a.s(["default",()=>f,"metadata",0,{title:"☁️BeauTrip - 믿고 찾는 K-Beauty 메디컬 여행 플랫폼✈️"}])}];

//# sourceMappingURL=_d3561d9a._.js.map