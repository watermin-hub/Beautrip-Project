module.exports=[43878,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_treatment_%5Bid%5D_page_actions_27a271ea.js.map