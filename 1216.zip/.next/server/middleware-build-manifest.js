globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/48adc4e12f314bab.js",
    "static/chunks/c4769791a2c00b9f.js",
    "static/chunks/8008d994f91f0fb6.js",
    "static/chunks/0ce1b91260867447.js",
    "static/chunks/497f7b5edc7d3fce.js",
    "static/chunks/turbopack-c609e8df9d59d985.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];