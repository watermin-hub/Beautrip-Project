var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/node_modules_41f37417._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_auth_callback_route_actions_3740e4d4.js")
R.m(76907)
module.exports=R.m(76907).exports
