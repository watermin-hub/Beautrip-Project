(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_86427976._.js",
  "static/chunks/node_modules_next_467aab97._.js",
  "static/chunks/node_modules_react-icons_io5_index_esm_e1ec9d20.js",
  "static/chunks/node_modules_react-icons_fi_index_esm_00274d2f.js",
  "static/chunks/node_modules_react-icons_bs_index_esm_f37a2151.js",
  "static/chunks/node_modules_react-icons_lib_esm_fa2222d7._.js",
  "static/chunks/node_modules_styled-jsx_57a9416f._.js"
],
    source: "dynamic"
});
