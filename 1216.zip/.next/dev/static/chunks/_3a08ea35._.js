(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/AutocompleteInput.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AutocompleteInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function AutocompleteInput({ value, onChange, placeholder = "검색...", suggestions, onSuggestionSelect, onEnter, className = "" }) {
    _s();
    const [showSuggestions, setShowSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [focusedIndex, setFocusedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const [isComposing, setIsComposing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // 한글 입력 조합 중인지 추적
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const suggestionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // 외부 클릭 시 자동완성 닫기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AutocompleteInput.useEffect": ()=>{
            const handleClickOutside = {
                "AutocompleteInput.useEffect.handleClickOutside": (event)=>{
                    if (inputRef.current && !inputRef.current.contains(event.target) && suggestionsRef.current && !suggestionsRef.current.contains(event.target)) {
                        setShowSuggestions(false);
                    }
                }
            }["AutocompleteInput.useEffect.handleClickOutside"];
            document.addEventListener("mousedown", handleClickOutside);
            return ({
                "AutocompleteInput.useEffect": ()=>document.removeEventListener("mousedown", handleClickOutside)
            })["AutocompleteInput.useEffect"];
        }
    }["AutocompleteInput.useEffect"], []);
    // 자동완성 선택으로 인한 value 변경인지 추적
    const isSuggestionSelectedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    // 검색어가 변경되면 자동완성 표시
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AutocompleteInput.useEffect": ()=>{
            // 자동완성 선택으로 인한 value 변경이면 자동완성을 다시 열지 않음
            if (isSuggestionSelectedRef.current) {
                isSuggestionSelectedRef.current = false;
                return;
            }
            setShowSuggestions(value.length > 0 && suggestions.length > 0);
            setFocusedIndex(-1);
        }
    }["AutocompleteInput.useEffect"], [
        value,
        suggestions
    ]);
    const handleInputChange = (e)=>{
        // 항상 onChange 호출 (입력 필드가 업데이트되도록)
        onChange(e.target.value);
    };
    // 한글 입력 조합 시작
    const handleCompositionStart = ()=>{
        setIsComposing(true);
    };
    // 한글 입력 조합 종료
    const handleCompositionEnd = (e)=>{
        setIsComposing(false);
        // 조합이 완료되면 최종 값을 onChange로 전달 (이미 handleInputChange에서 호출되지만 확실히 하기 위해)
        onChange(e.currentTarget.value);
    };
    const handleSuggestionClick = (suggestion)=>{
        // 자동완성 선택 플래그 설정 (value 변경으로 인해 자동완성이 다시 열리지 않도록)
        isSuggestionSelectedRef.current = true;
        // 먼저 자동완성을 닫고, 그 다음에 onChange 호출
        setShowSuggestions(false);
        onChange(suggestion);
        if (onSuggestionSelect) {
            onSuggestionSelect(suggestion);
        }
        inputRef.current?.blur();
    };
    const handleKeyDown = (e)=>{
        if (e.key === "Enter") {
            if (showSuggestions && suggestions.length > 0 && focusedIndex >= 0) {
                // 자동완성 항목이 선택된 경우
                e.preventDefault();
                handleSuggestionClick(suggestions[focusedIndex]);
            } else if (onEnter && value.trim().length >= 2) {
                // 자동완성 항목이 선택되지 않은 경우 Enter 키 처리 (2글자 이상일 때만)
                e.preventDefault();
                onEnter();
            }
            return;
        }
        if (!showSuggestions || suggestions.length === 0) return;
        if (e.key === "ArrowDown") {
            e.preventDefault();
            setFocusedIndex((prev)=>prev < suggestions.length - 1 ? prev + 1 : prev);
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setFocusedIndex((prev)=>prev > 0 ? prev - 1 : -1);
        } else if (e.key === "Escape") {
            setShowSuggestions(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-3 top-1/2 transform -translate-y-1/2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSearch"], {
                            className: "text-gray-400 text-sm"
                        }, void 0, false, {
                            fileName: "[project]/components/AutocompleteInput.tsx",
                            lineNumber: 124,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 123,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: inputRef,
                        type: "text",
                        value: value,
                        onChange: handleInputChange,
                        onCompositionStart: handleCompositionStart,
                        onCompositionEnd: handleCompositionEnd,
                        onKeyDown: handleKeyDown,
                        onFocus: ()=>{
                            if (value.length > 0 && suggestions.length > 0) {
                                setShowSuggestions(true);
                            }
                        },
                        placeholder: placeholder,
                        className: `w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-main ${className}`
                    }, void 0, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/AutocompleteInput.tsx",
                lineNumber: 122,
                columnNumber: 7
            }, this),
            showSuggestions && suggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: suggestionsRef,
                className: "absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto",
                children: suggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>handleSuggestionClick(suggestion),
                        onMouseEnter: ()=>setFocusedIndex(index),
                        className: `w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${index === focusedIndex ? "bg-gray-50" : ""}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSearch"], {
                                    className: "text-gray-400 text-xs"
                                }, void 0, false, {
                                    fileName: "[project]/components/AutocompleteInput.tsx",
                                    lineNumber: 161,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: suggestion
                                }, void 0, false, {
                                    fileName: "[project]/components/AutocompleteInput.tsx",
                                    lineNumber: 162,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AutocompleteInput.tsx",
                            lineNumber: 160,
                            columnNumber: 15
                        }, this)
                    }, index, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 151,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/AutocompleteInput.tsx",
                lineNumber: 146,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/AutocompleteInput.tsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
_s(AutocompleteInput, "+C4g0DflqOSlovvKMUTWVOQq8lc=");
_c = AutocompleteInput;
var _c;
__turbopack_context__.k.register(_c, "AutocompleteInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/SearchModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SearchModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AutocompleteInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AutocompleteInput.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const MAX_RECENT_SEARCHES = 10; // 최대 최근 검색어 개수
const recommendedSearches = [
    {
        id: 1,
        name: "리쥬란힐러",
        badge: "BEST"
    },
    {
        id: 2,
        name: "써마지",
        badge: "BEST"
    },
    {
        id: 3,
        name: "쥬베룩",
        badge: "BEST"
    },
    {
        id: 4,
        name: "울쎄라",
        badge: "up"
    },
    {
        id: 5,
        name: "LDM",
        badge: "up"
    },
    {
        id: 6,
        name: "스킨부"
    },
    {
        id: 7,
        name: "올리지"
    },
    {
        id: 8,
        name: "튠페"
    },
    {
        id: 9,
        name: "쎄라플"
    },
    {
        id: 10,
        name: "리프터"
    }
];
const quickIcons = [
    {
        id: 1,
        label: "블프 세일 대축제",
        icon: "🛍️"
    },
    {
        id: 2,
        label: "요즘인기시술",
        icon: "⭐"
    },
    {
        id: 3,
        label: "혜택 플러스",
        icon: "💎"
    },
    {
        id: 4,
        label: "포인트 적립백서",
        icon: "📝"
    },
    {
        id: 5,
        label: "부작용 안심케어",
        icon: "🛡️"
    }
];
const recentEvents = [
    {
        id: 1,
        title: "Shurink Universe",
        clinic: "본연_슈링크 유니버스",
        location: "서울 강남역·본연성...",
        price: "120,000원",
        image: ""
    },
    {
        id: 2,
        title: "Eight longtime #인모드 #슈링크",
        clinic: "지방소멸 롱타임 인모드리프팅 슈링...",
        location: "서울 압구정역·에이...",
        price: "₩108,900",
        image: ""
    },
    {
        id: 3,
        title: "시술 시간 걱정 없이 인모드는 롱~모드로!",
        clinic: "롱모드 인모드 풀페이스 10분 FX...",
        location: "서울 홍대입구역·리...",
        price: "99,000원",
        image: ""
    },
    {
        id: 4,
        title: "후기 6,000+ 디에이 자려한 코성형",
        clinic: "예쁘면DA야_자려한 코성형_비순각코수...",
        location: "서울 역삼역·디에이...",
        price: "1,088,000원",
        image: ""
    }
];
const interestProcedures = [
    "인모드리프팅",
    "슈링크리프팅",
    "슈링크유니버스",
    "코재수술",
    "아이슈링크"
];
const categories = [
    {
        icon: "👁️",
        label: "눈성형"
    },
    {
        icon: "👃",
        label: "코성형"
    },
    {
        icon: "😊",
        label: "안면윤곽/양악"
    },
    {
        icon: "💪",
        label: "가슴성형"
    },
    {
        icon: "🏃",
        label: "지방성형"
    },
    {
        icon: "💉",
        label: "필러"
    },
    {
        icon: "💉",
        label: "보톡스"
    },
    {
        icon: "✨",
        label: "리프팅"
    },
    {
        icon: "🌟",
        label: "피부"
    },
    {
        icon: "✂️",
        label: "제모"
    },
    {
        icon: "💇",
        label: "모발이식"
    },
    {
        icon: "🦷",
        label: "치아"
    },
    {
        icon: "🍵",
        label: "한방"
    },
    {
        icon: "📦",
        label: "기타"
    }
];
function SearchModal({ isOpen, onClose }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedRegion, setSelectedRegion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("지역");
    const [recentSearches, setRecentSearches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [autocompleteSuggestions, setAutocompleteSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // localStorage에서 최근 검색어 불러오기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SearchModal.useEffect": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                const saved = localStorage.getItem("recentSearches");
                if (saved) {
                    try {
                        setRecentSearches(JSON.parse(saved));
                    } catch (e) {
                        console.error("Failed to parse recent searches", e);
                    }
                }
            }
        }
    }["SearchModal.useEffect"], []);
    // 자동완성 데이터 로드
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SearchModal.useEffect": ()=>{
            const loadAutocomplete = {
                "SearchModal.useEffect.loadAutocomplete": async ()=>{
                    if (searchQuery.length < 1) {
                        setAutocompleteSuggestions([]);
                        return;
                    }
                    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTreatmentAutocomplete"])(searchQuery, 10);
                    const allSuggestions = [
                        ...result.treatmentNames,
                        ...result.hospitalNames
                    ];
                    setAutocompleteSuggestions(allSuggestions);
                }
            }["SearchModal.useEffect.loadAutocomplete"];
            const debounceTimer = setTimeout({
                "SearchModal.useEffect.debounceTimer": ()=>{
                    loadAutocomplete();
                }
            }["SearchModal.useEffect.debounceTimer"], 300);
            return ({
                "SearchModal.useEffect": ()=>clearTimeout(debounceTimer)
            })["SearchModal.useEffect"];
        }
    }["SearchModal.useEffect"], [
        searchQuery
    ]);
    // 최근 검색어에 추가하는 함수
    const addToRecentSearches = (query)=>{
        const trimmedQuery = query.trim();
        if (!trimmedQuery) return;
        setRecentSearches((prev)=>{
            // 중복 제거 (기존 항목 제거 후 맨 앞에 추가)
            const filtered = prev.filter((item)=>item !== trimmedQuery);
            const updated = [
                trimmedQuery,
                ...filtered
            ].slice(0, MAX_RECENT_SEARCHES);
            // localStorage에 저장
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("recentSearches", JSON.stringify(updated));
            }
            return updated;
        });
    };
    // 개별 검색어 삭제
    const removeRecentSearch = (query, e)=>{
        e.stopPropagation(); // 버튼 클릭 이벤트 전파 방지
        setRecentSearches((prev)=>{
            const updated = prev.filter((item)=>item !== query);
            // localStorage에 저장
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("recentSearches", JSON.stringify(updated));
            }
            return updated;
        });
    };
    // 전체 검색어 삭제
    const clearAllRecentSearches = ()=>{
        setRecentSearches([]);
        if ("TURBOPACK compile-time truthy", 1) {
            localStorage.removeItem("recentSearches");
        }
    };
    const handleSearch = ()=>{
        if (searchQuery.trim()) {
            // 최근 검색어에 추가
            addToRecentSearches(searchQuery.trim());
            // 탐색 페이지로 이동하면서 검색어와 섹션 정보 전달
            router.push(`/explore?search=${encodeURIComponent(searchQuery.trim())}&section=procedure`);
            onClose();
        }
    };
    const handleKeyPress = (e)=>{
        if (e.key === "Enter") {
            handleSearch();
        }
    };
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[100] bg-white overflow-y-auto max-w-md mx-auto left-1/2 transform -translate-x-1/2 pb-20 w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sticky top-0 z-50 bg-white border-b border-gray-100 px-4 py-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClose,
                                className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                                    className: "text-gray-700 text-xl"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 218,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 214,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 relative",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AutocompleteInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    value: searchQuery,
                                    onChange: setSearchQuery,
                                    placeholder: "시술명/수술명을 입력해 주세요.",
                                    suggestions: autocompleteSuggestions,
                                    onSuggestionSelect: (suggestion)=>{
                                        setSearchQuery(suggestion);
                                        // 자동완성 선택 시 바로 검색 실행
                                        setTimeout(()=>{
                                            handleSearch();
                                        }, 100);
                                    },
                                    onEnter: handleSearch,
                                    className: "bg-gray-50 border border-gray-200"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 221,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 220,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleSearch,
                                className: "px-3 py-2 text-primary-main text-sm font-medium hover:bg-primary-main/10 rounded-lg transition-colors",
                                children: "검색"
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 237,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 213,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "flex items-center gap-1 text-gray-700 text-sm hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: selectedRegion
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 248,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronDown"], {
                                    className: "text-gray-500 text-sm"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 249,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/SearchModal.tsx",
                            lineNumber: 247,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 246,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SearchModal.tsx",
                lineNumber: 212,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 py-6 space-y-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative bg-black rounded-2xl overflow-hidden p-6 min-h-[160px] flex items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute inset-0 opacity-5",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-0",
                                    style: {
                                        backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.1) 10px, rgba(255,255,255,0.1) 20px)"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 259,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 258,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative w-full",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start justify-between mb-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-white text-xs",
                                                children: "K-피부시술 세일 페스타, 모든 시술이 한자리에!"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 269,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-primary-main text-white px-3 py-1 rounded-full text-xs font-bold flex-shrink-0 ml-2",
                                                children: "~49% off"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 272,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 268,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-4xl font-black mb-3 leading-tight",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white",
                                                children: "BLACK"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 277,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-primary-light relative",
                                                children: [
                                                    "BEAUTY",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "absolute -top-1 -right-3 text-primary-main text-xs",
                                                        children: "★"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 280,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 278,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white",
                                                children: "FRIDAY"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 284,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 276,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-white text-sm",
                                        children: "11.11 — 12.10"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 286,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 267,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 257,
                        columnNumber: 9
                    }, this),
                    recentSearches.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-base font-bold text-gray-900",
                                        children: "최근 검색어"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 294,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: clearAllRecentSearches,
                                        className: "text-sm text-gray-500 hover:text-gray-700",
                                        children: "전체삭제"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 295,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 293,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 flex-wrap",
                                children: recentSearches.map((search, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setSearchQuery(search);
                                            addToRecentSearches(search); // 클릭 시에도 최근 검색어에 추가 (순서 업데이트)
                                            router.push(`/explore?search=${encodeURIComponent(search)}&section=procedure`);
                                            onClose();
                                        },
                                        className: "flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-full text-sm transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: search
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 318,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                onClick: (e)=>{
                                                    e.stopPropagation();
                                                    removeRecentSearch(search, e);
                                                },
                                                className: "hover:bg-gray-300 rounded-full p-0.5 transition-colors cursor-pointer",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoClose"], {
                                                    className: "text-gray-500 text-sm"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/SearchModal.tsx",
                                                    lineNumber: 326,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 319,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, index, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 304,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 302,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 292,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-5 gap-4",
                        children: quickIcons.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "flex flex-col items-center gap-2 p-3 hover:bg-gray-50 rounded-xl transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-12 h-12 bg-gradient-to-br from-primary-light/20 to-primary-main/30 rounded-full flex items-center justify-center text-xl",
                                        children: item.icon
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 341,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-700 text-center leading-tight",
                                        children: item.label
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 344,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, item.id, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 337,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 335,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-base font-bold text-gray-900 mb-4",
                                children: "추천 검색어"
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 353,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-4",
                                children: recommendedSearches.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setSearchQuery(item.name);
                                            addToRecentSearches(item.name); // 추천 검색어 클릭 시에도 최근 검색어에 추가
                                            router.push(`/explore?search=${encodeURIComponent(item.name)}&section=procedure`);
                                            onClose();
                                        },
                                        className: "flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors text-left",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-primary-main font-bold text-sm min-w-[20px]",
                                                        children: item.id
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 373,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-gray-900 text-sm",
                                                        children: item.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 376,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 372,
                                                columnNumber: 17
                                            }, this),
                                            item.badge === "BEST" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "bg-primary-light/20 text-primary-main px-2 py-0.5 rounded text-xs font-semibold",
                                                children: "BEST"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 379,
                                                columnNumber: 19
                                            }, this),
                                            item.badge === "up" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-3 h-3 text-primary-main",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    fillRule: "evenodd",
                                                    d: "M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z",
                                                    clipRule: "evenodd"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/SearchModal.tsx",
                                                    lineNumber: 389,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 384,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, item.id, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 358,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 356,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 352,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SearchModal.tsx",
                lineNumber: 255,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/SearchModal.tsx",
        lineNumber: 210,
        columnNumber: 5
    }, this);
}
_s(SearchModal, "RfQBDmNVGE2WOvqHX2rzPVGKT74=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = SearchModal;
var _c;
__turbopack_context__.k.register(_c, "SearchModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Header.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/bs/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SearchModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SearchModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function Header({ hasRankingBanner = false }) {
    _s();
    const [isSearchOpen, setIsSearchOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLanguageOpen, setIsLanguageOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [logoError, setLogoError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const globeButtonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { language, setLanguage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [dropdownPosition, setDropdownPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        top: 0,
        right: 0
    });
    const languages = [
        {
            code: "KR",
            name: "한국어",
            flag: "🇰🇷"
        },
        {
            code: "EN",
            name: "English",
            flag: "🇺🇸"
        },
        {
            code: "JP",
            name: "日本語",
            flag: "🇯🇵"
        },
        {
            code: "CN",
            name: "中文",
            flag: "🇨🇳"
        }
    ];
    const selectedLanguage = languages.find((lang)=>lang.code === language) || languages[0];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Header.useEffect": ()=>{
            if (isLanguageOpen && globeButtonRef.current) {
                const rect = globeButtonRef.current.getBoundingClientRect();
                setDropdownPosition({
                    top: rect.bottom + 8,
                    right: window.innerWidth - rect.right
                });
            }
        }
    }["Header.useEffect"], [
        isLanguageOpen
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: `sticky ${hasRankingBanner ? "top-[41px]" : "top-0"} z-40 bg-white border-b border-gray-100 px-4 py-3`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>router.push("/"),
                            className: "flex items-center gap-2 hover:opacity-80 transition-opacity cursor-pointer",
                            children: !logoError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/beautrip-logo.png",
                                alt: "BeauTrip",
                                className: "h-6 w-auto object-contain",
                                onError: ()=>setLogoError(true)
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 63,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BsCloud"], {
                                className: "text-primary-main text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 70,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4 relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setIsSearchOpen(true),
                                    className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSearch"], {
                                        className: "text-gray-700 text-xl"
                                    }, void 0, false, {
                                        fileName: "[project]/components/Header.tsx",
                                        lineNumber: 81,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            ref: globeButtonRef,
                                            onClick: ()=>setIsLanguageOpen(!isLanguageOpen),
                                            className: "p-2 hover:bg-gray-50 rounded-full transition-colors relative z-[100]",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiGlobe"], {
                                                className: "text-gray-700 text-xl"
                                            }, void 0, false, {
                                                fileName: "[project]/components/Header.tsx",
                                                lineNumber: 89,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this),
                                        isLanguageOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "fixed inset-0 z-[99]",
                                                    onClick: ()=>setIsLanguageOpen(false)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Header.tsx",
                                                    lineNumber: 93,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "fixed bg-white border border-gray-200 rounded-lg shadow-lg z-[100] min-w-[150px]",
                                                    style: {
                                                        top: `${dropdownPosition.top}px`,
                                                        right: `${dropdownPosition.right}px`
                                                    },
                                                    children: languages.map((lang)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>{
                                                                setLanguage(lang.code);
                                                                setIsLanguageOpen(false);
                                                            },
                                                            className: `w-full text-left px-4 py-2 hover:bg-gray-50 transition-colors flex items-center gap-2 ${selectedLanguage.code === lang.code ? "bg-primary-main/10" : ""}`,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: lang.flag
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 117,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-gray-700",
                                                                    children: lang.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 118,
                                                                    columnNumber: 25
                                                                }, this),
                                                                selectedLanguage.code === lang.code && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "ml-auto text-primary-main",
                                                                    children: "✓"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 122,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, lang.code, true, {
                                                            fileName: "[project]/components/Header.tsx",
                                                            lineNumber: 105,
                                                            columnNumber: 23
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Header.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 83,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "p-2 hover:bg-gray-50 rounded-full transition-colors relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiBell"], {
                                            className: "text-gray-700 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 131,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/Header.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/Header.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SearchModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isSearchOpen,
                onClose: ()=>setIsSearchOpen(false)
            }, void 0, false, {
                fileName: "[project]/components/Header.tsx",
                lineNumber: 137,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(Header, "wHAZrX0YKQ6dHEhrD591unZdiTg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/BottomNavigation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BottomNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const navItems = [
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHome"],
        labelKey: "nav.home",
        path: "/"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCompass"],
        labelKey: "nav.explore",
        path: "/explore"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiUsers"],
        labelKey: "nav.community",
        path: "/community"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCalendar"],
        labelKey: "nav.schedule",
        path: "/schedule"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiUser"],
        labelKey: "nav.mypage",
        path: "/mypage"
    }
];
function BottomNavigation({ disabled = false }) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: `fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 z-50 ${disabled ? "pointer-events-none" : ""}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-around items-center py-2",
            children: navItems.map((item)=>{
                const Icon = item.icon;
                const isActive = pathname === item.path;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: item.path,
                    className: `flex flex-col items-center justify-center gap-1 py-1 px-2 min-w-0 flex-1 transition-colors ${disabled ? "text-gray-300 cursor-not-allowed" : isActive ? "text-primary-main" : "text-gray-500"}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                            className: `text-xl ${disabled ? "text-gray-300" : isActive ? "text-primary-main" : "text-gray-500"}`
                        }, void 0, false, {
                            fileName: "[project]/components/BottomNavigation.tsx",
                            lineNumber: 43,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: `text-xs whitespace-nowrap ${disabled ? "text-gray-300" : isActive ? "text-primary-main font-medium" : "text-gray-500"}`,
                            children: t(item.labelKey)
                        }, void 0, false, {
                            fileName: "[project]/components/BottomNavigation.tsx",
                            lineNumber: 52,
                            columnNumber: 15
                        }, this)
                    ]
                }, item.path, true, {
                    fileName: "[project]/components/BottomNavigation.tsx",
                    lineNumber: 32,
                    columnNumber: 13
                }, this);
            })
        }, void 0, false, {
            fileName: "[project]/components/BottomNavigation.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/BottomNavigation.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_s(BottomNavigation, "xidiIFVahZXU1vxN+08Jg/l1pJo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = BottomNavigation;
var _c;
__turbopack_context__.k.register(_c, "BottomNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/content/recoveryGuideContent.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "recoveryGuideContent",
    ()=>recoveryGuideContent
]);
const recoveryGuideContent = {
    KR: {
        jaw: {
            title: "턱·윤곽·양악 수술",
            badge: "뼈 수술",
            summary: "턱·윤곽·양악 등 얼굴 뼈 구조가 크게 변하는 수술군",
            recommended: "권장 회복 기간: 4주 이상",
            procedures: "V라인축소술, 사각턱수술, 턱끝수술, 턱끝축소, 피질절골, 교근축소술, 비절개턱성형, 이중턱근육묶기, 하악수술, 상악수술, 양악수술, 턱끝보형물, 턱끝보형물제거, 턱끝이물질제거",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "몸이 ‘수술을 인지하고 가장 강하게 반응하는 시기’",
                    description: [
                        "수술 부위와 주변 조직이 ‘얼굴 구조에 큰 변화가 생겼다’는 사실을 인지하며 붓기, 멍, 당김, 압박감을 가장 강하게 만들어내는 단계입니다.",
                        "뼈의 위치가 바뀌고, 그 위를 덮고 있던 근육·피부·신경이 아직 새로운 위치에 적응하지 못해 얼굴은 실제 결과보다 더 부어 있고, 더 넓고, 더 둔탁해 보이는 것이 정상입니다.",
                        "이 시기의 외형은 수술 결과를 판단할 수 있는 기준이 아니며, 의학적으로도 ‘회복 전 단계의 임시 모습’에 해당합니다.",
                        "몸의 입장에서는 아직 회복이 본격적으로 진행되기보다는 ‘회복을 시작하기 위한 준비 단계’라고 이해하시면 됩니다."
                    ],
                    tips: [
                        "가능한 한 일정은 최소화하고, 회복을 최우선으로 두기",
                        "수면 시 머리를 살짝 높여 붓기 압력 줄이기",
                        "하루 여러 번, 방 안이나 복도에서 3–5분 정도 짧게 걷기 (혈액순환과 붓기 관리에 도움이 됩니다)"
                    ],
                    cautions: [
                        "거울을 자주 보며 결과를 평가하지 않기",
                        "무리한 외출, 장시간 이동 피하기",
                        "통증·붓기가 있다고 해서 ‘문제가 생겼다’고 단정하지 않기"
                    ],
                    quote: "이 시기의 목표는 ‘얼굴이 예뻐 보이게 만드는 것’이 아니라 ‘붓기를 키우지 않고, 몸이 회복을 시작하도록 돕는 것’입니다."
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "강한 붓기는 줄고, ‘변화의 방향’이 보이기 시작하는 시기",
                    description: [
                        "2주차부터는 수술 직후의 강한 염증 반응이 조금씩 가라앉으면서 얼굴 전체 부피감이 서서히 줄어듭니다.",
                        "아직은 큰 붓기와 잔붓기가 섞여 있는 과도기이기 때문에 아침에는 둔탁하고, 오후에는 조금 가벼워지는 ‘아침–저녁 컨디션 차이’를 느낄 수 있습니다.",
                        "이 패턴은 턱·윤곽·양악 수술에서 매우 흔한 회복 양상이며, 회복이 잘못되고 있다는 신호가 아닙니다.",
                        "이 시점에서는 ‘윤곽이 이런 방향으로 바뀌는구나’ 정도의 큰 흐름만 가볍게 확인하시면 충분합니다."
                    ],
                    tips: [
                        "카페·쇼핑몰처럼 앉아서 쉬는 시간이 포함된 일정 위주로 외출하기",
                        "사진은 조명·각도를 고정해서 기록용으로만 남기기",
                        "가벼운 산책은 붓기 순환에 도움이 됩니다."
                    ],
                    cautions: [
                        "수술 전 사진이나 타인의 후기와 과도하게 비교하지 않기",
                        "과음·밤샘 일정은 붓기 회복을 늦출 수 있으므로 피하기",
                        "‘왜 아직도 부어 있지?’라는 조급한 판단 줄이기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "겉으로는 자연스러워 보이고, 몸은 적응을 마무리하는 시기",
                    description: [
                        "3주차에는 외관상 붓기가 많이 정리되어 주변 사람들은 이미 자연스럽다고 느끼는 경우가 많습니다.",
                        "하지만 턱 주변 근육·관절·저작 근육은 여전히 새로운 위치와 사용 패턴에 적응을 마무리하는 단계에 있습니다.",
                        "하루 일정을 많이 소화했거나 말을 많이 한 날에는 턱이 뻐근하거나 피로감이 다시 느껴질 수 있는데, 이는 적응 과정에서 나타나는 정상적인 신호입니다."
                    ],
                    tips: [
                        "사진 촬영, 가벼운 여행 일정은 가능합니다.",
                        "일정 중간중간 의도적으로 쉬는 시간을 넣어주기",
                        "피곤한 날은 일정을 줄이는 것도 회복의 일부라고 생각하기"
                    ],
                    cautions: [
                        "격한 운동이나 턱을 과하게 쓰는 활동은 아직 피하기",
                        "‘이제 다 끝났다’는 생각으로 무리하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "일상은 정상, 회복은 아직 진행 중인 시기",
                    description: [
                        "4주차가 되면 일상생활·출근·일반적인 여행은 대부분 가능합니다.",
                        "하지만 턱·윤곽·양악 수술의 진짜 안정화는 3–6개월에 걸쳐 진행되기 때문에, 지금 모습은 ‘최종 결과’라기보다 안정적으로 회복되고 있는 중간 단계입니다.",
                        "이 시점에서 너무 엄격하게 결과를 평가하면 불필요한 불안만 커질 수 있습니다."
                    ],
                    tips: [
                        "가벼운 운동은 의료진이 허용한 범위 내에서 천천히 시작",
                        "1·2주차 기록 사진과 비교하며 변화 확인하기",
                        "피로 신호가 오면 휴식을 최우선으로 두기"
                    ],
                    cautions: [
                        "4주차에 결과를 단정 짓지 않기",
                        "‘아직 불편하다 = 실패’로 연결하지 않기"
                    ],
                    quote: "지금 얼굴은 이미 충분히 회복이 잘 진행되고 있고, 앞으로 더 편안해질 여지가 남아 있는 상태입니다."
                }
            ],
            summaryTitle: "이 그룹의 핵심 정리",
            summaryBody: [
                "턱·윤곽·양악 수술의 회복은 속도가 아니라 순서입니다.",
                "지금 주차에 맞는 관리만 꾸준히 해주고 있다면, 결과는 대부분 그 다음에 자연스럽게 따라옵니다."
            ]
        },
        // 나머지 그룹들은 우선 간단한 요약 버전만 구성 (필요 시 점진적으로 세부 문구 보강)
        breast: {
            title: "가슴 + 유두·유륜 + 여유증 + 부유방",
            badge: "가슴 수술",
            summary: "보형물·지방이식·거상·축소 및 유두·유륜·여유증·부유방 수술군의 회복 흐름",
            procedures: "가슴보형물 / 가슴보형물+지방이식 / 가슴거상술 / 가슴거상술+확대 / 가슴축소 / 가슴보형물제거 / 가슴이물질제거 / 가슴재수술 / 가슴지방이식 / 부유방흡입 / 부유방제거수술 / 몽고메리결절제거 / 유두축소 / 유륜미백 / 유륜축소 / 유륜문신 / 함몰유두교정 / 여유증(시술) / 여유증수술",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "몸이 '상체 구조 변화'를 강하게 인지하는 시기",
                    description: [
                        "가슴뿐 아니라 흉곽·겨드랑이·등·어깨까지 상체 전체가 무게 중심과 구조가 바뀌었다는 사실을 인지하며 통증, 압박감, 묵직함, 당김을 강하게 느끼는 단계입니다.",
                        "겉으로 보이는 모양은 실제 결과보다 더 위로 올라가 있고 단단하며 부자연스럽게 보일 수 있지만, 이 시기의 외형은 최종 결과와 직접적인 연관이 없습니다."
                    ],
                    tips: [
                        "상체를 완전히 눕히지 말고 베개를 이용해 살짝 세운 자세로 휴식",
                        "압박 브라·붕대는 불편해도 지시된 기간 동안 유지",
                        "팔 사용을 최소화하고 모든 동작은 천천히 하기"
                    ],
                    cautions: [
                        "팔을 머리 위로 드는 동작, 갑작스러운 상체 회전 금지",
                        "무거운 가방이나 캐리어 들지 않기",
                        "거울을 자주 보며 모양을 평가하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "통증은 줄고, 묵직함이 중심이 되는 시기",
                    description: [
                        "날카로운 통증보다는 묵직함·당김·뻐근함이 중심이 되는 시기입니다.",
                        "보형물·거상 수술은 아직 윗가슴이 높고 단단하게 느껴질 수 있고, 축소·여유증 수술은 어깨와 목이 가벼워지면서 절개 부위가 예민해질 수 있습니다."
                    ],
                    tips: [
                        "앉아서 쉴 수 있는 짧은 일정 위주로 구성",
                        "앞에서 여미는 옷, 부드러운 면 소재 착용",
                        "흉터 부위는 문지르지 말고 처방된 연고만 사용"
                    ],
                    cautions: [
                        "와이어 브라, 타이트한 상의 착용 금지",
                        "쇼핑처럼 팔을 반복적으로 많이 쓰는 일정 자제",
                        "흉터 색·가슴 위치를 하루 단위로 비교하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "일상 동작은 가능하지만, 상체 보호는 계속 필요한 시기",
                    description: [
                        "카페·쇼핑·가벼운 외출 등 대부분의 일상 동작이 가능해집니다.",
                        "사진상으로는 자연스러워 보이지만 촉감·움직임에서는 아직 완전히 내 몸 같은 느낌까지는 아닐 수 있습니다."
                    ],
                    tips: [
                        "실내 위주 일정, 짧은 근교 이동 추천",
                        "앉아서 쉴 수 있는 동선을 우선 선택",
                        "쿠션 있는 의자를 사용해 상체 부담 줄이기"
                    ],
                    cautions: [
                        "점프, 상체 근력 운동, 격한 팔 동작은 아직 금지",
                        "‘이제 다 괜찮다’는 생각으로 관리를 갑자기 줄이지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "겉보기엔 안정적이지만, 조직은 계속 자리 잡는 중",
                    description: [
                        "외출·출근·여행이 대부분 가능해지고 타인이 보기엔 수술 티가 거의 나지 않을 수 있습니다.",
                        "다만 안쪽 조직의 안정은 3–6개월에 걸쳐 진행되므로 지금 모습은 완성이 아니라 중간 단계에 해당합니다."
                    ],
                    tips: [
                        "일상 복귀는 가능하되 피로 누적 시 휴식 우선",
                        "담당의 허용 시 가벼운 유산소 운동부터 시작",
                        "흉터 관리 루틴을 생활화하기"
                    ],
                    cautions: [
                        "고강도 운동·수영·웨이트는 반드시 의료진 상담 후 진행",
                        "1개월 차 모습을 최종 결과로 확정 짓지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "가슴 수술은 짧은 시간에 완성되는 수술이 아니라 시간을 두고 점점 자연스러워지는 수술입니다.",
                "지금의 모습은 이미 회복이 안정적으로 진행되고 있는 상태이며, 앞으로 더 편안하고 자연스러운 형태로 이어질 가능성이 충분합니다."
            ]
        },
        body: {
            title: "바디 지방흡입 · 거상 · 재수술 + 힙업 · 골반지방이식",
            badge: "바디 라인",
            summary: "몸 전체 실루엣과 힙업·골반 볼륨을 다루는 수술·시술군",
            procedures: "등지방흡입 / 러브핸들지방흡입 / 복부지방흡입 / 복부피부지방절제술 / 허벅지지방흡입 / 종아리지방흡입 / 발목지방흡입 / 무릎지방흡입 / 팔지방흡입 / 전신지방흡입 / 지방흡입재수술 / 복부거상술 / 팔거상술 / 목주름거상술 / 엉덩이지방이식 / 힙업성형 / 골반지방이식 / 손등지방이식",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "몸이 '바디 실루엣 변화'를 강하게 인지하는 시기",
                    description: [
                        "지방이 제거되거나 이동된 부위뿐 아니라 압박복이 닿는 범위 전체를 하나의 수술 부위로 인식하는 단계입니다.",
                        "겉으로 보기엔 라인이 더 울퉁불퉁해 보이거나 부은 살 때문에 오히려 더 커 보일 수 있지만, 이 시기의 외형은 결과를 판단할 수 있는 단계가 아닙니다."
                    ],
                    tips: [
                        "압박복은 답답해도 의료진 지시에 맞춰 착용 유지",
                        "침대에서 일어날 때는 옆으로 돌아누운 뒤 천천히 움직이기",
                        "방 안이나 복도에서 짧게, 자주 걷기"
                    ],
                    cautions: [
                        "‘지방이 빠졌는데 왜 더 부어 보이지?’라고 걱정하지 않기",
                        "하루 만보 걷기, 무리한 산책은 금지",
                        "압박복을 임의로 더 조이거나 마음대로 벗지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "붓기가 이동하며 실루엣이 오락가락하는 시기",
                    description: [
                        "아침에는 비교적 가벼운데 오후로 갈수록 다리·복부가 무거워지는 붓기 리듬을 느낄 수 있습니다.",
                        "압박복을 벗었을 때 라인이 정리된 듯하다가도 울퉁불퉁해 보이는 과도기적인 모습이 나타날 수 있습니다."
                    ],
                    tips: [
                        "일정은 평지 위주, 엘리베이터 필수 동선으로 선택",
                        "장시간 앉아 있을 땐 30–40분마다 자세 바꾸기",
                        "수분 섭취를 늘려 림프 순환을 돕기"
                    ],
                    cautions: [
                        "압박복을 벗은 상태로 장시간 외출하지 않기",
                        "거울로 허벅지·복부를 확대해서 평가하지 않기",
                        "하체 근력 운동·요가 스트레치는 아직 금지"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "몸이 '가벼워졌다'는 체감을 하기 시작하는 시기",
                    description: [
                        "바지·치마·원피스를 입었을 때 실루엣 변화가 눈에 띄게 느껴지기 시작합니다.",
                        "촉감상 딱딱함이나 뭉침이 남아 있을 수 있지만 대부분 정상적인 회복 과정에 포함됩니다."
                    ],
                    tips: [
                        "근교 이동, 카페 투어 등 사진 위주 일정 가능",
                        "쿠션 있는 의자·카페 좌석을 적극 활용",
                        "가벼운 산책은 회복에 도움"
                    ],
                    cautions: [
                        "달리기·점프·격한 하체 운동은 여전히 금지",
                        "‘라인이 완성된 것 같다’는 생각으로 관리 중단하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "라인은 정리되기 시작하지만, 아직은 중간 단계",
                    description: [
                        "외관상으로는 이미 충분히 달라진 몸처럼 느껴질 수 있습니다.",
                        "하지만 바디 지방흡입·거상·지방이식의 진짜 완성은 3–6개월에 걸쳐 라인이 더 매끈해지면서 이루어집니다."
                    ],
                    tips: [
                        "가벼운 유산소·스트레칭은 단계적으로 시작",
                        "피곤한 날엔 압박복 착용 시간을 다시 늘리기",
                        "장시간 서 있는 일정 뒤에는 휴식을 우선하기"
                    ],
                    cautions: [
                        "고강도 운동·헬스·러닝은 의료진 상담 후 시작",
                        "1개월 차 몸을 최종 결과로 규정하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "바디 수술은 눈에 보이는 변화보다 몸 안에서의 회복이 더 오래 걸리는 수술입니다.",
                "지금의 몸은 이미 회복이 안정 궤도에 올라 있으며, 시간이 지날수록 라인은 더 부드럽고 자연스럽게 이어질 가능성이 충분합니다."
            ]
        },
        upperFace: {
            title: "광대 · 관자 · 이마 · 뒤통수 · 눈썹뼈 · 안면윤곽 재수술",
            badge: "상안면 윤곽",
            summary: "얼굴 윗구조와 안면윤곽 재수술에 해당하는 수술군",
            procedures: "광대보형물 / 광대축소(앞광대·옆광대·전체) / 퀵광대 / 앞광대보형물 / 관자놀이보형물 / 관자놀이축소술 / 이마보형물 / 이마축소 / 눈썹뼈축소술 / 뒤통수보형물 / 광대이물질제거 / 관자놀이이물질제거 / 이마이물질제거 / 심부볼제거 / 안면윤곽재수술",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "얼굴 '윗구조 전체가 바뀌었다'고 인식하는 시기",
                    description: [
                        "광대·관자·이마·눈썹뼈·뒤통수 중 한 부위만 수술했더라도 몸은 상·중안면 전체를 하나의 수술 부위로 인식합니다.",
                        "얼굴 윗부분이 헬멧을 쓴 것처럼 단단하고 무겁게 느껴질 수 있으며, 정면에서 폭이 넓어 보이고 윤곽이 둔탁해 보이는 것이 정상입니다."
                    ],
                    tips: [
                        "머리는 너무 높이지 말고 살짝만 올린 상태로 휴식",
                        "얼굴을 손으로 만지거나 문지르지 않기",
                        "실내 위주로 조용히 지내며 자극 최소화"
                    ],
                    cautions: [
                        "거울을 자주 보며 얼굴 폭·광대 크기 평가하지 않기",
                        "모자를 깊게 눌러 쓰거나 얼굴을 압박하지 않기",
                        "웃음·표정을 과도하게 사용하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "붓기 속에서 윤곽이 보이기 시작하는 시기",
                    description: [
                        "붓기가 한 번에 빠지기보다 부위별로 다르게 움직이며 윤곽이 오락가락하는 느낌을 줄 수 있습니다.",
                        "정면에서는 여전히 넓어 보일 수 있지만, 측면이나 45도 각도에서 이전과 다른 입체감이 보이기 시작합니다."
                    ],
                    tips: [
                        "오전보다 오후 컨디션 기준으로 일정 잡기",
                        "머리카락·앞머리·모자를 활용해 윤곽을 자연스럽게 정리",
                        "카페·전시 등 앉아서 쉬는 일정 위주로 구성"
                    ],
                    cautions: [
                        "조명 강한 장소에서 얼굴 클로즈업 촬영 피하기",
                        "광대·관자 부위를 누르거나 마사지하지 않기",
                        "하루 단위로 얼굴 윤곽을 비교 분석하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "주변에서 변화가 먼저 보이는 시기",
                    description: [
                        "본인보다 주변에서 ‘얼굴 작아졌다’, ‘입체감이 생겼다’는 말을 먼저 듣는 경우가 많아지는 시기입니다.",
                        "사진에서 변화가 특히 잘 드러나며, 여행·촬영 일정도 비교적 자유로워집니다."
                    ],
                    tips: [
                        "한복 스냅, 카페 촬영 등 사진 일정 가능",
                        "장시간 촬영 시 중간중간 휴식 시간 넣기",
                        "머리카락 스타일로 윤곽을 부드럽게 보완"
                    ],
                    cautions: [
                        "격한 표정 연기, 장시간 웃음 유지는 피하기",
                        "밤샘·과음으로 붓기 재발 유발하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "겉보기엔 자연스럽지만, 안쪽 구조는 계속 적응 중",
                    description: [
                        "타인이 보기엔 수술 여부를 알아채기 어려울 정도로 윤곽이 자연스러워질 수 있습니다.",
                        "하지만 뼈·근막·연부조직이 함께 움직인 수술이기 때문에 3–6개월 동안 미세한 변화가 계속됩니다."
                    ],
                    tips: [
                        "일상 복귀는 가능하되 피로 누적 시 즉시 휴식",
                        "가벼운 스트레칭·산책은 회복에 도움",
                        "3개월 차를 기준으로 변화 관찰하기"
                    ],
                    cautions: [
                        "경락·윤곽 마사지·강한 압박은 아직 금지",
                        "미세한 비대칭을 과도하게 확대 해석하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "상안면 윤곽 수술은 짧은 시간에 완성되는 수술이 아니라 시간이 지나면서 자연스럽게 자리 잡는 수술입니다.",
                "지금의 모습은 회복이 매우 정상적으로 진행되고 있는 상태이며, 앞으로 더 부드럽고 안정적인 윤곽으로 이어질 가능성이 충분합니다."
            ]
        },
        nose: {
            title: "코끝 · 콧볼 · 복코 · 비공 라인 개선",
            badge: "코 성형",
            summary: "코끝·콧볼·복코·비공 및 콧대 라인을 다루는 수술·시술군",
            procedures: "복코교정(수술) / 복코교정(시술) / 콧볼축소 / 비절개콧볼축소 / 코끝보형물 / 코끝자가연골 / 코끝기증연골 / 코끝기증진피 / 비공내리기 / 비절개코끝시술 / 미스코 / 하이코 / 고양이수술 / 콧대보형물 / 콧대인공조직 / 콧대자가조직 / 비주연장술 / 코길이연장술 / 비절개코교정",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "코가 '호흡·표정·중심 구조 변화'를 동시에 인지하는 시기",
                    description: [
                        "코끝·콧볼·비공·콧대 중 한 부위만 시술했더라도 얼굴의 중심 구조가 바뀌었다고 인지하며 붓기·압박감·당김·이물감이 가장 강하게 나타나는 단계입니다.",
                        "겉으로 보이는 코는 실제 결과보다 더 크고 뭉툭하거나 더 들려 보일 수 있으며, 콧볼이 넓어 보이거나 코끝이 둔해 보이는 착시가 생기기 쉽습니다."
                    ],
                    tips: [
                        "얼굴을 베개·손에 파묻지 않고 정면을 향한 자세 유지",
                        "물을 자주 마셔 비강·점막 건조를 방지",
                        "병원에서 안내한 세척·연고·찜질 루틴만 정확히 지키기"
                    ],
                    cautions: [
                        "코를 비비거나 만지는 행동 금지",
                        "마스크를 코끝에 강하게 눌러 쓰지 않기",
                        "뜨거운 음식·과음으로 붓기를 유발하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "붓기 속에서 '코 라인의 방향성'이 보이기 시작하는 시기",
                    description: [
                        "코끝과 콧볼의 붓기가 조금씩 정리되며 ‘방향은 이렇게 잡혔구나’라는 느낌이 들기 시작합니다.",
                        "수술 계열은 여전히 단단함과 당김이 남아 있지만, 정면·측면에서 이전과 다른 실루엣이 서서히 보이기 시작합니다."
                    ],
                    tips: [
                        "마스크는 사람 많은 곳에서만 착용하고 압박은 최소화",
                        "카페·쇼핑 등 가벼운 외출 가능",
                        "사진은 자연광에서 정면·45도 각도로 기록"
                    ],
                    cautions: [
                        "콧볼·코끝을 눌러 모양 확인하지 않기",
                        "‘아직 뭔가 어색하다’는 감정을 과도하게 키우지 않기",
                        "강한 햇빛·사우나·찜질방 피하기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "사진과 일상에서 코 변화가 자연스럽게 드러나는 시기",
                    description: [
                        "코가 얼굴 전체에 자연스럽게 섞여 보이기 시작합니다.",
                        "수술 계열도 일반적인 사진·영상에서는 수술 티가 크게 느껴지지 않을 수 있으며, 시술 계열은 가장 예쁘게 라인이 유지되는 시기입니다."
                    ],
                    tips: [
                        "포토부스·카페 촬영·스냅 사진 가능",
                        "살짝 위에서 아래로 찍는 각도가 안정적",
                        "피부톤 위주의 가벼운 메이크업부터 시작"
                    ],
                    cautions: [
                        "사람 많은 곳에서 부딪히지 않도록 주의",
                        "과음·밤샘 일정으로 붓기 재발 유발하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "남에게는 완성처럼 보이지만, 코는 계속 변하는 중",
                    description: [
                        "4주차 코는 주변 사람이 보기에 이미 충분히 자연스럽고 안정적으로 보일 수 있습니다.",
                        "하지만 코끝·콧볼·복코·비공 라인은 연골·연부조직·피부가 함께 적응하는 구조라 3–6개월까지도 미세한 변화가 이어집니다."
                    ],
                    tips: [
                        "일상·여행·비행 대부분 무리 없이 가능",
                        "3개월 차 사진을 기준으로 변화 비교 계획 세우기",
                        "코 주변 자극 없는 생활 습관 유지"
                    ],
                    cautions: [
                        "코 마사지·경락·강한 압박은 아직 금지",
                        "미세한 높이·각도 차이에 집착하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "코 성형과 코 라인 시술은 얼굴 중심에 위치한 만큼 회복 과정에서 심리적 흔들림이 큰 편입니다.",
                "지금의 변화는 정상적인 회복 흐름 안에 있으며, 시간이 지날수록 표정과 조화롭게 어우러진 코로 이어질 가능성이 충분합니다."
            ]
        },
        eyeSurgery: {
            title: "눈 성형 · 트임 · 눈밑 지방 · 재수술",
            badge: "눈 성형",
            summary: "쌍꺼풀·트임·눈밑 수술 및 재수술 전반",
            procedures: "쌍꺼풀(매몰/부분절개/자연유착/절개), 눈매교정, 돌출눈수술, 상안검성형, 아이링, 하안검성형, 앞트임, 뒤트임, 밑트임, 윗트임, 레이저트임성형, 몽고트임, 트임복원, 눈꺼풀지방제거, 눈밑지방재배치, 눈밑지방제거, 눈재수술, 트임재수술",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "눈이 '시야·표정·피로'를 동시에 인지하는 시기",
                    description: [
                        "눈꺼풀·눈꼬리·눈밑 중 어느 한 부위만 수술했더라도 눈 주변 전체가 시야와 표정 구조가 바뀌었다고 인지하며 붓기·압박감·이물감·당김이 가장 강하게 나타나는 단계입니다.",
                        "겉으로 보이는 눈은 실제 결과보다 라인이 높고 두껍게 보이거나, 트임 부위가 과장돼 보이고, 눈밑이 울퉁불퉁하거나 부풀어 보이는 것이 정상입니다."
                    ],
                    tips: [
                        "화면 사용은 최소화하고 눈 감고 쉬는 시간을 자주 갖기",
                        "처방된 냉찜질·안약·인공눈물 루틴을 정확히 지키기",
                        "실내 조명은 부드럽게, 직사광선은 피하기"
                    ],
                    cautions: [
                        "눈 비비기, 세게 깜빡이기 금지",
                        "렌즈 착용, 아이메이크업은 아직 금지",
                        "거울로 라인 높이·대칭을 반복 평가하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "붓기 속에서 '눈 라인의 방향'이 보이기 시작하는 시기",
                    description: [
                        "눈꺼풀과 눈밑 붓기가 조금씩 내려가며 라인이 이렇게 잡히는구나 하는 방향성이 느껴지기 시작합니다.",
                        "쌍꺼풀·눈매교정 수술은 여전히 원하는 라인보다 조금 더 진하고 과장돼 보일 수 있지만, 이는 붓기와 아직 풀리지 않은 근육 반응 때문입니다."
                    ],
                    tips: [
                        "가벼운 외출·카페 일정은 가능",
                        "마스크·선글라스로 눈 주변 자극 최소화",
                        "사진은 정면보다는 45도 각도 위주로 기록"
                    ],
                    cautions: [
                        "진한 아이메이크업·마스카라 사용은 자제",
                        "눈꼬리·눈밑을 손으로 눌러 확인하지 않기",
                        "하루 단위로 라인 변화를 집요하게 비교하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "사진과 표정에서 눈 변화가 자연스럽게 드러나는 시기",
                    description: [
                        "사진·영상·대화 중 표정에서 눈의 변화가 비교적 자연스럽게 드러나는 시기입니다.",
                        "쌍꺼풀·트임·눈밑 수술은 사진상으로 수술 티가 거의 느껴지지 않을 수 있으며, 눈매 인상이 전반적으로 또렷해집니다."
                    ],
                    tips: [
                        "포토부스·셀프사진관·한복 스냅 촬영 가능",
                        "가벼운 아이메이크업은 단계적으로 시작",
                        "자연광에서 찍은 사진으로 변화 기록"
                    ],
                    cautions: [
                        "밤샘·과음으로 눈 붓기 재발 유발하지 않기",
                        "장시간 촬영으로 눈 피로를 누적시키지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "남에게는 자연스럽지만, 눈은 계속 안정되는 중",
                    description: [
                        "4주차가 되면 주변에서 ‘눈이 훨씬 또렷해졌다’는 말을 듣기 쉬운 시기입니다.",
                        "하지만 눈 성형은 라인·흉터·근육 움직임이 3–6개월에 걸쳐 서서히 더 부드러워지는 수술입니다."
                    ],
                    tips: [
                        "일상생활 대부분 무리 없이 가능",
                        "렌즈 착용은 반드시 의료진 허용 후 시작",
                        "눈가 보습·자외선 차단에 신경 쓰기"
                    ],
                    cautions: [
                        "눈가 마사지·경락은 아직 금지",
                        "미세한 라인 차이에 과도하게 집착하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "눈 성형은 얼굴 인상을 크게 바꾸는 수술인 만큼 회복 과정에서 심리적인 기복이 생기기 쉽습니다.",
                "지금의 변화는 정상적인 회복 흐름 안에 있으며, 시간이 지날수록 표정과 자연스럽게 어우러진 눈으로 이어질 가능성이 충분합니다."
            ]
        },
        eyeVolume: {
            title: "눈 지방이식 · 눈물골 · 애교살 · 눈 주변 지방",
            badge: "눈 볼륨 시술",
            summary: "눈밑·눈물골·애교살 지방이식·필러 등 볼륨 교정 시술군",
            procedures: "눈지방이식 / 눈밑지방이식 / 눈물골지방이식 / 애교살지방이식 / 눈주변지방이식 / 눈밑꺼짐교정 / 눈밑꺼짐재수술 / 눈물골필러 / 애교살필러 / 눈밑필러 / 눈지방재배치(보완) / 눈밑지방이식재수술",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "눈 주변이 '볼륨 변화와 압박'을 동시에 인지하는 시기",
                    description: [
                        "피부가 얇고 혈관이 많은 눈밑·눈물골·애교살 부위에 볼륨이 새로 들어오면서 몸이 이를 강하게 인지하는 단계입니다.",
                        "조금만 부어도 다크서클처럼 어둡게 보이거나 눈이 더 부어 보이는 착시가 생기기 쉽습니다."
                    ],
                    tips: [
                        "고개를 너무 숙이지 않고 정면을 향한 자세 유지",
                        "엎드려 자지 말고, 베개를 살짝 높여 수면",
                        "눈 주변을 만지거나 눌러보지 않기"
                    ],
                    cautions: [
                        "눈밑 볼륨을 손으로 만져 확인하지 않기",
                        "거울을 가까이 대고 확대해서 보지 않기",
                        "과한 메이크업으로 억지로 가리려 하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "볼륨이 퍼지며 자연스러움을 찾아가는 시기",
                    description: [
                        "눈밑과 눈물골의 붓기가 서서히 빠지면서 볼륨이 한 지점에 몰려 보이던 느낌이 조금씩 퍼지기 시작합니다.",
                        "지방이식은 자리 잡는 볼륨과 흡수될 볼륨이 섞여 있어 다소 오락가락해 보일 수 있습니다."
                    ],
                    tips: [
                        "자연광에서 정면·45도 각도로 변화 기록",
                        "가벼운 아이메이크업 가능",
                        "눈 밑이 건조하면 보습을 충분히 해주기"
                    ],
                    cautions: [
                        "눈 주변 마사지·경락·지압 금지",
                        "‘빠지는 것 같아 불안하다’는 감정에 휘둘리지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "눈 인상이 부드럽게 바뀌는 시기",
                    description: [
                        "눈밑 꺼짐·눈물골 음영이 완화되면서 피곤해 보이던 인상이 전반적으로 부드러워집니다.",
                        "사진에서 다크서클이 옅어 보이거나 애교살이 자연스럽게 살아나는 변화를 체감하는 경우가 많습니다."
                    ],
                    tips: [
                        "촬영·데이트·약속 일정 무리 없이 가능",
                        "자연스러운 웃는 표정 연습 가능",
                        "충분한 수분 섭취 유지"
                    ],
                    cautions: [
                        "강한 눈 화장으로 볼륨을 과하게 강조하지 않기",
                        "눈 주변을 세게 문지르는 습관을 재개하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "볼륨은 안정되고, 미세 조정만 남은 시기",
                    description: [
                        "눈밑과 애교살 볼륨은 외관상 상당히 안정돼 보이지만 지방이식의 경우 최종 생착률은 아직 확정되지 않은 상태입니다.",
                        "눈 주변 볼륨 시술은 1개월은 안정 단계, 3개월이 진짜 판단 시점에 가깝습니다."
                    ],
                    tips: [
                        "일상·여행·촬영 대부분 무리 없이 가능",
                        "눈가 보습과 자외선 차단을 생활화",
                        "3개월 차를 기준으로 리터치 여부 판단 계획 세우기"
                    ],
                    cautions: [
                        "눈가 마사지·경락은 아직 금지",
                        "미세한 볼륨 차이에 집착하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "눈 주변 볼륨 시술은 눈에 띄는 변화를 주지만 동시에 심리적인 예민함도 커질 수 있는 시술입니다.",
                "지금의 변화는 정상적인 회복 흐름 안에 있으며, 시간이 지날수록 더 자연스럽고 안정된 눈 인상으로 이어질 가능성이 충분합니다."
            ]
        },
        faceFat: {
            title: "얼굴 지방이식 · 팔자 · 풀페이스 볼륨",
            badge: "얼굴 볼륨",
            summary: "얼굴 지방이식·팔자·풀페이스 볼륨 교정 시술군",
            procedures: "얼굴지방이식 / 풀페이스지방이식 / 이마지방이식 / 관자지방이식 / 앞광대지방이식 / 볼지방이식 / 팔자지방이식 / 인디언주름지방이식 / 마리오넷라인지방이식 / 입가주름지방이식 / 얼굴지방이식재수술 / 볼꺼짐교정 / 얼굴볼륨교정",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "얼굴이 '전체 볼륨 변화'를 강하게 인지하는 시기",
                    description: [
                        "특정 부위만 시술했더라도 얼굴 전체가 볼륨 중심이 바뀌었다고 인식하며 붓기·묵직함·당김·압박감을 강하게 느끼는 단계입니다.",
                        "지방이 들어간 부위뿐 아니라 주변 조직까지 함께 반응해 얼굴이 전반적으로 커 보이거나 과하게 통통해 보일 수 있습니다."
                    ],
                    tips: [
                        "얼굴을 아래로 오래 숙이지 않고 정면 자세 유지",
                        "베개를 살짝 높여 붓기 압력을 줄이기",
                        "외출은 최소화하고 숙소에서 충분히 휴식"
                    ],
                    cautions: [
                        "얼굴을 누르거나 만져서 볼륨 확인하지 않기",
                        "‘너무 과한 것 같다’는 생각으로 조급해하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "볼륨이 퍼지며 얼굴 비율이 정리되기 시작하는 시기",
                    description: [
                        "얼굴에 몰려 있던 붓기가 조금씩 퍼지면서 볼륨이 부위별로 정리되기 시작합니다.",
                        "이마·관자·앞광대는 먼저 안정되는 편이고, 팔자·입가·마리오넷 라인은 상대적으로 붓기가 늦게 빠질 수 있습니다."
                    ],
                    tips: [
                        "자연광에서 정면·45도 사진으로 변화 기록",
                        "가벼운 메이크업 가능",
                        "수분 섭취를 늘려 순환을 돕기"
                    ],
                    cautions: [
                        "얼굴 마사지·경락·롤러 사용 금지",
                        "거울을 가까이 대고 확대해서 비교하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "인상이 부드러워지고, 볼륨감이 자연스럽게 느껴지는 시기",
                    description: [
                        "얼굴이 과하게 통통해 보이던 느낌이 줄고 전체 인상이 한결 부드러워집니다.",
                        "사진에서 광대·팔자·입가 라인이 자연스럽게 이어져 보이며 피곤해 보이던 인상이 완화됩니다."
                    ],
                    tips: [
                        "촬영·약속·데이트 일정 무리 없이 가능",
                        "평소 스타일 메이크업으로 점진적 복귀",
                        "충분한 수면으로 생착 환경 유지"
                    ],
                    cautions: [
                        "강한 경락·압박 마사지는 금지",
                        "급격한 체중 감량 시도 피하기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "볼륨은 안정되지만, 최종 판단은 아직 이른 시기",
                    description: [
                        "외관상 얼굴 볼륨이 상당히 자연스럽게 느껴질 수 있습니다.",
                        "하지만 얼굴 지방이식은 1개월은 안정 단계, 3개월이 최종 생착 판단 시점입니다."
                    ],
                    tips: [
                        "일상·여행·촬영 대부분 가능",
                        "자외선 차단과 보습 관리 지속",
                        "체중 변화 없이 생활 리듬 유지"
                    ],
                    cautions: [
                        "얼굴 마사지·고주파 시술은 의료진 상담 후 진행",
                        "1개월 차 얼굴을 최종 결과로 단정하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "얼굴 지방이식과 볼륨 교정은 시간을 두고 자연스럽게 완성되는 시술입니다.",
                "지금의 인상은 회복이 안정적으로 진행되고 있는 상태이며, 시간이 지날수록 표정과 더 조화롭게 어우러진 얼굴로 이어질 가능성이 충분합니다."
            ]
        },
        lifting: {
            title: "안면거상 · 이마거상 · 팔자박리 · 주름 개선 수술",
            badge: "거상 수술",
            summary: "안면거상·이마거상·팔자박리 등 주름 개선 수술군",
            procedures: "안면거상술 / 미니거상 / SMAS거상 / 목거상술 / 이마거상술 / 눈썹거상술 / 팔자박리술 / 마리오넷라인박리 / 중안면거상 / 하안면거상 / 주름개선수술 / 거상재수술",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "얼굴이 '당겨지고 재배치되었다'고 강하게 인지하는 시기",
                    description: [
                        "피부뿐 아니라 그 아래 근막(SMAS)과 연부조직이 함께 이동하면서 얼굴 전체가 강한 당김과 압박 변화를 인지하는 단계입니다.",
                        "겉으로는 더 당겨져 보이거나 귀 주변·두피·턱선이 어색해 보일 수 있지만, 아직 결과 판단 단계는 아닙니다."
                    ],
                    tips: [
                        "얼굴을 과하게 움직이지 않고 표정 사용 최소화",
                        "수면 시 머리를 살짝 높여 당김·부종 완화",
                        "병원에서 안내한 압박 밴드·거즈 관리를 철저히 하기"
                    ],
                    cautions: [
                        "입을 크게 벌리는 동작, 과한 하품은 피하기",
                        "귀 주변·두피를 손으로 만지거나 문지르지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "당김은 줄고, 붓기와 뻣뻣함이 남는 시기",
                    description: [
                        "초기의 강한 당김은 서서히 완화되고 뻣뻣함·묵직함·감각 둔함이 중심이 되는 시기입니다.",
                        "신경과 조직이 새로운 위치에 적응하면서 위화감이 생길 수 있으나 대부분 정상적인 반응입니다."
                    ],
                    tips: [
                        "짧은 외출·카페 일정 가능",
                        "부드러운 음식 위주로 천천히 식사",
                        "얼굴을 아래로 오래 숙이지 않기"
                    ],
                    cautions: [
                        "경락·마사지·롤러 사용 금지",
                        "귀 뒤·두피 절개 부위를 눌러 확인하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "얼굴 윤곽과 주름 개선 효과가 보이기 시작하는 시기",
                    description: [
                        "팔자·마리오넷·턱선이 전보다 정돈돼 보인다는 느낌을 받기 시작합니다.",
                        "주변에서는 ‘피부가 정리됐다’, ‘인상이 단정해졌다’는 말을 먼저 듣는 경우도 많아집니다."
                    ],
                    tips: [
                        "촬영·약속·가벼운 여행 일정 가능",
                        "웃는 표정은 자연스럽게, 과하지 않게",
                        "자외선 차단과 보습 관리에 신경 쓰기"
                    ],
                    cautions: [
                        "장시간 웃거나 말해야 하는 일정은 무리하지 않기",
                        "밤샘·과음으로 붓기 재발 유발하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "겉보기엔 정리됐지만, 안쪽은 계속 안정 중",
                    description: [
                        "타인이 보기엔 주름 개선과 윤곽 변화가 자연스럽게 느껴질 수 있습니다.",
                        "하지만 근막과 조직의 위치를 바꾸는 수술이기 때문에 최종 안정까지 3–6개월이 필요합니다."
                    ],
                    tips: [
                        "일상·출근·외출 대부분 무리 없이 가능",
                        "가벼운 산책·스트레칭부터 단계적으로 운동 재개",
                        "흉터 관리 루틴을 생활화"
                    ],
                    cautions: [
                        "강한 얼굴 마사지·고주파 시술은 의료진 상담 후",
                        "1개월 차 얼굴을 최종 결과로 규정하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "안면거상과 주름 개선 수술은 시간이 지나면서 ‘잘 당긴 얼굴’이 아니라 ‘정돈된 인상’으로 완성되는 수술입니다.",
                "지금의 변화는 정상적인 회복 흐름 안에 있으며, 앞으로 더 부드럽고 자연스러운 인상으로 이어질 가능성이 충분합니다."
            ]
        },
        procedures: {
            title: "시술 (필러 · 보톡스 · 지방분해 · 리프팅 · 레이저)",
            badge: "시술",
            summary: "필러·보톡스·지방분해·리프팅·레이저 전반",
            procedures: "이마필러 / 관자필러 / 앞광대필러 / 볼필러 / 팔자필러 / 마리오넷필러 / 입술필러 / 턱끝필러 / 코필러 / 애교필러 / 눈밑필러 / 필러제거주사 / 필러제거수술 / 보톡스(사각턱·이마·미간·눈가·턱끝·스킨보톡스) / 지방분해주사 / 윤곽주사 / 인모드 / 슈링크 / 울쎄라 / 써마지 / 온다 / 튠페이스 / IPL / 토닝 / 피코레이저 / 프락셀 / 제네시스 / 잡티·홍조·모공 레이저 전반",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "몸이 '자극과 변화'를 동시에 인지하는 시기",
                    description: [
                        "수술이 아닌 시술이라도 피부·지방층·근육·혈관이 외부 자극과 볼륨 변화를 인지하며 붓기·열감·뻐근함·이물감을 보이는 단계입니다.",
                        "필러·보톡스는 주입 직후 모양보다 조직 반응이 먼저 나타나기 때문에 더 부어 보이거나 뭉쳐 보이거나 어색해 보일 수 있습니다."
                    ],
                    tips: [
                        "시술 부위는 만지지 않고 자극을 최소화",
                        "충분한 수분 섭취로 순환 돕기",
                        "세안·메이크업은 병원 안내 시점 이후부터 시작"
                    ],
                    cautions: [
                        "시술 부위를 눌러 모양 확인하지 않기",
                        "사우나·찜질방·격한 운동 피하기",
                        "시술 다음 날 얼굴로 결과 판단하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "자극은 가라앉고, 효과의 방향이 보이기 시작하는 시기",
                    description: [
                        "초기 붓기와 열감이 줄어들며 필러 볼륨·윤곽 변화·피부결 개선의 방향성이 서서히 느껴지기 시작합니다.",
                        "보톡스는 이 시점부터 근육 힘이 약해지거나 표정이 부드러워졌다는 체감이 생깁니다."
                    ],
                    tips: [
                        "가벼운 외출·촬영 가능",
                        "자외선 차단을 철저히 유지",
                        "피부 보습 루틴을 평소보다 강화"
                    ],
                    cautions: [
                        "필러·보톡스 효과를 거울로 집요하게 분석하지 않기",
                        "추가 시술을 즉흥적으로 결정하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "시술 효과가 얼굴에 자연스럽게 섞이는 시기",
                    description: [
                        "필러·보톡스·리프팅 효과가 얼굴 전체 인상에 자연스럽게 녹아들기 시작하는 시기입니다.",
                        "주변에서 ‘뭔가 달라 보인다’는 말을 먼저 듣는 경우가 많아지고, 사진에서도 피부결·윤곽·볼륨 변화가 안정적으로 보입니다."
                    ],
                    tips: [
                        "데이트·여행·촬영 일정 무리 없이 가능",
                        "평소 메이크업 루틴으로 복귀",
                        "충분한 수면과 수분 섭취 유지"
                    ],
                    cautions: [
                        "과음·밤샘으로 시술 효과를 소모시키지 않기",
                        "피부가 안정됐다고 자극적인 관리 재개하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "효과는 유지되고, 다음 관리 시점을 판단하는 시기",
                    description: [
                        "시술 효과는 외관상 충분히 안정돼 보이며, 대부분의 일상·여행·비행 일정에 무리가 없습니다.",
                        "다만 필러·보톡스·리프팅·레이저는 유지 관리가 중요한 시술이므로, 이 시점은 완성이라기보다 다음 관리 시점을 계획하는 단계입니다."
                    ],
                    tips: [
                        "현재 상태를 기준으로 다음 시술 시점을 메모",
                        "자외선 차단·보습·클렌징 루틴 유지",
                        "과한 욕심보다 ‘지금 상태 유지’를 목표로 설정"
                    ],
                    cautions: [
                        "효과가 좋다고 시술 주기를 무리하게 당기지 않기",
                        "미세한 변화에 과도하게 집착하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "시술은 짧은 시간에 인상을 바꿀 수 있지만, 가장 중요한 것은 지금 상태를 어떻게 유지하느냐입니다.",
                "지금의 변화는 정상적인 반응과 효과가 잘 나타난 상태이며, 생활 습관과 관리에 따라 훨씬 더 안정적으로 이어질 수 있습니다."
            ]
        }
    },
    EN: {},
    JP: {},
    CN: {}
};
// EN 버전: 한국어 내용을 간결하게 영어로 정리 (여기서는 jaw 그룹만 예시로 자세히, 나머지는 요약)
const enBase = {
    jaw: {
        title: "Jaw · Contouring · Orthognathic Surgery",
        badge: "Jaw & facial contouring surgery",
        summary: "Procedures that significantly change the jaw and facial bone structure, such as V-line and orthognathic surgery.",
        recommended: "Recommended recovery period: 4+ weeks",
        procedures: "V-line reduction, square jaw reduction, chin surgery, chin reduction, cortical osteotomy, masseter reduction, non-incisional chin contouring, double-chin muscle tie, mandibular surgery, maxillary surgery, bimaxillary surgery, chin implant, chin implant removal, chin foreign-body removal",
        weeks: [
            {
                label: "🕐 Week 1 (Day 0–7)",
                subtitle: "The body reacts most strongly as it recognizes a major structural change",
                description: [
                    "Tissues around the operated area recognize that the facial structure has changed, so swelling, bruising, tightness and pressure are at their peak.",
                    "Because the bone position has changed and muscles, skin and nerves are not yet adapted, it is normal for your face to look more swollen, wider and duller than the final result.",
                    "This is a temporary early‑stage appearance and not a valid basis for judging the outcome.",
                    "Think of this phase as a preparation stage before recovery fully kicks in."
                ],
                tips: [
                    "Keep your schedule to a minimum and make recovery your top priority.",
                    "Sleep with your head slightly elevated to reduce swelling pressure.",
                    "Take short 3–5 minute indoor walks several times a day to support circulation and swelling control."
                ],
                cautions: [
                    "Avoid repeatedly checking the mirror and judging the result.",
                    "Avoid strenuous outings and long travel.",
                    "Don’t jump to conclusions that something is wrong just because you have pain or swelling."
                ],
                quote: "The goal this week is not to “look pretty” but to avoid increasing swelling and to help your body start the healing process."
            },
            {
                label: "🕑 Week 2 (Day 8–14)",
                subtitle: "Strong swelling eases and the overall direction of change becomes visible",
                description: [
                    "Inflammation from surgery gradually settles and total facial volume slowly begins to decrease.",
                    "This is a transition phase where major swelling and residual puffiness coexist, so the face may look heavier in the morning and lighter toward evening.",
                    "This morning‑evening difference is a very common recovery pattern and is not a sign of poor healing.",
                    "At this stage, it’s enough to simply check the overall direction of your new contour without over‑analyzing details."
                ],
                tips: [
                    "Plan outings around places where you can sit and rest, such as cafés or malls.",
                    "If you take photos, keep the same lighting and angle and use them only for tracking, not for harsh evaluation.",
                    "Light walks help circulation and swelling drainage."
                ],
                cautions: [
                    "Avoid excessive comparison with old photos or other people’s results.",
                    "Limit heavy drinking and all‑nighters, which delay recovery.",
                    "Try not to fixate on thoughts like “Why am I still swollen?”."
                ]
            },
            {
                label: "🕒 Week 3 (Day 15–21)",
                subtitle: "The outside looks more natural while the inside is still adapting",
                description: [
                    "By week 3, visible swelling is much improved and many people around you may already say you look natural.",
                    "Inside, however, the jaw muscles, joints and chewing muscles are still finishing their adaptation to the new position and usage pattern.",
                    "On days when you talk a lot or have a busy schedule, it is normal to feel fatigue or dull ache in the jaw again."
                ],
                tips: [
                    "Photo shoots and light trips are usually fine.",
                    "Intentionally schedule short rest breaks throughout the day.",
                    "On very tired days, reducing your schedule is also part of good recovery."
                ],
                cautions: [
                    "Avoid high‑intensity exercise or activities that overuse the jaw.",
                    "Don’t assume that this is the final result and overexert yourself."
                ]
            },
            {
                label: "🕓 Week 4 (Day 22–28)",
                subtitle: "Daily life feels almost normal, but recovery is still in progress",
                description: [
                    "Most people can return to work, school and general travel by week 4.",
                    "Medically, however, true stabilization of jaw and contour surgery takes about 3–6 months, so what you see now is an in‑between stage, not the final result.",
                    "Judging the outcome too strictly at this time only increases unnecessary anxiety."
                ],
                tips: [
                    "Start light exercise only within the range approved by your surgeon.",
                    "Compare with your week‑1 and week‑2 photos to see progress rather than perfection.",
                    "If you feel fatigue signals, prioritize rest over plans."
                ],
                cautions: [
                    "Do not finalize your opinion of the result at 4 weeks.",
                    "Avoid interpreting remaining discomfort as “failure.”"
                ],
                quote: "At this stage your face is recovering well and still has room to become more comfortable and refined over the coming months."
            }
        ],
        summaryTitle: "Key takeaway for this group",
        summaryBody: [
            "Recovery after jaw and facial contouring is about sequence, not speed.",
            "As long as you are following week‑appropriate care, the final result usually follows naturally afterward."
        ]
    },
    breast: {
        ...recoveryGuideContent.KR.breast,
        title: "Breast + Nipple/Areola + Gynecomastia + Accessory Breast",
        badge: "Breast surgery",
        summary: "Covers implant, fat graft, lift, reduction and nipple/areola, gynecomastia and accessory breast procedures."
    },
    body: {
        ...recoveryGuideContent.KR.body,
        title: "Body Liposuction · Lift · Revision + Hip/Buttock & Pelvic Fat Graft",
        badge: "Body contour"
    },
    upperFace: {
        ...recoveryGuideContent.KR.upperFace,
        title: "Zygoma · Temple · Forehead · Occiput · Brow Bone · Contour Revision",
        badge: "Upper‑face contour"
    },
    nose: {
        ...recoveryGuideContent.KR.nose,
        title: "Tip · Alar · Bulbous Nose · Nostril Line",
        badge: "Nose"
    },
    eyeSurgery: {
        ...recoveryGuideContent.KR.eyeSurgery,
        title: "Eye Surgery · Epicanthoplasty · Lower Fat · Revision",
        badge: "Eye surgery"
    },
    eyeVolume: {
        ...recoveryGuideContent.KR.eyeVolume,
        title: "Eye Fat Graft · Tear Trough · Aegyo‑sal · Periorbital Volume",
        badge: "Eye volume"
    },
    faceFat: {
        ...recoveryGuideContent.KR.faceFat,
        title: "Facial Fat Graft · Nasolabial Fold · Full‑face Volume",
        badge: "Facial volume"
    },
    lifting: {
        ...recoveryGuideContent.KR.lifting,
        title: "Facelift · Forehead Lift · Nasolabial Dissection · Wrinkle Surgery",
        badge: "Lifting surgery"
    },
    procedures: {
        ...recoveryGuideContent.KR.procedures,
        title: "Injectables · Fat‑dissolving · Lifting Devices · Lasers",
        badge: "Non‑surgical procedures"
    }
};
recoveryGuideContent.EN = enBase;
recoveryGuideContent.JP = enBase;
recoveryGuideContent.CN = enBase;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/RecoveryGuideDetailPage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RecoveryGuideDetailPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuideContent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/content/recoveryGuideContent.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function RecoveryGuideDetailPage({ groupKey }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { language } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const content = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuideContent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["recoveryGuideContent"][language][groupKey];
    const title = `${content.title}에 대한 회복 가이드🍀`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sticky top-0 z-20 bg-white border-b border-gray-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3 px-4 py-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>router.back(),
                            className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronLeft"], {
                                className: "text-gray-700 text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                lineNumber: 32,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-lg font-bold text-gray-900 line-clamp-1",
                            children: title
                        }, void 0, false, {
                            fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                    lineNumber: 27,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 py-6 pb-20",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs bg-primary-light/20 text-primary-main px-3 py-1.5 rounded-full font-medium",
                                        children: content.badge
                                    }, void 0, false, {
                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                        lineNumber: 45,
                                        columnNumber: 13
                                    }, this),
                                    content.recommended && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-sm text-gray-600 font-medium",
                                        children: content.recommended
                                    }, void 0, false, {
                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                        lineNumber: 49,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                lineNumber: 44,
                                columnNumber: 11
                            }, this),
                            content.procedures && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-gray-50 rounded-lg p-3 mb-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-600 leading-relaxed",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-800",
                                            children: "해당 시술:"
                                        }, void 0, false, {
                                            fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                            lineNumber: 57,
                                            columnNumber: 17
                                        }, this),
                                        " ",
                                        content.procedures
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                    lineNumber: 56,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                lineNumber: 55,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-6",
                        children: content.weeks.map((week, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "border border-gray-200 rounded-xl p-5 bg-white",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-bold text-gray-900 mb-2",
                                        children: week.label
                                    }, void 0, false, {
                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                        lineNumber: 71,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "text-sm font-semibold text-gray-800 mb-3",
                                        children: week.subtitle
                                    }, void 0, false, {
                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                        lineNumber: 74,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-4",
                                        children: week.description.map((desc, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-gray-700 leading-relaxed mb-2 last:mb-0",
                                                children: desc
                                            }, idx, false, {
                                                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                                lineNumber: 81,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                        lineNumber: 79,
                                        columnNumber: 15
                                    }, this),
                                    week.tips.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2 mb-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCheck"], {
                                                        className: "text-primary-main text-sm"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                                        lineNumber: 94,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                                        className: "text-sm font-semibold text-gray-800",
                                                        children: "이 주차에 도움 되는 팁"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                                        lineNumber: 95,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                                lineNumber: 93,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                className: "space-y-1.5 pl-6",
                                                children: week.tips.map((tip, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        className: "text-xs text-gray-700 leading-relaxed list-disc",
                                                        children: tip
                                                    }, idx, false, {
                                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                                        lineNumber: 101,
                                                        columnNumber: 23
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                                lineNumber: 99,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                        lineNumber: 92,
                                        columnNumber: 17
                                    }, this),
                                    week.cautions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2 mb-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiAlertCircle"], {
                                                        className: "text-orange-500 text-sm"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                                        lineNumber: 116,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                                        className: "text-sm font-semibold text-gray-800",
                                                        children: "권고사항"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                                        lineNumber: 117,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                                lineNumber: 115,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                className: "space-y-1.5 pl-6",
                                                children: week.cautions.map((caution, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        className: "text-xs text-gray-700 leading-relaxed list-disc",
                                                        children: caution
                                                    }, idx, false, {
                                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                                        lineNumber: 123,
                                                        columnNumber: 23
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                                lineNumber: 121,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                        lineNumber: 114,
                                        columnNumber: 17
                                    }, this),
                                    week.quote && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-4 pt-4 border-t border-gray-200",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-gray-700 leading-relaxed italic",
                                            children: week.quote
                                        }, void 0, false, {
                                            fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                            lineNumber: 137,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                        lineNumber: 136,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                lineNumber: 67,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                        lineNumber: 65,
                        columnNumber: 9
                    }, this),
                    content.summaryTitle && content.summaryBody && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-8 bg-primary-light/10 border border-primary-light/30 rounded-xl p-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-base font-bold text-primary-main mb-3",
                                children: content.summaryTitle
                            }, void 0, false, {
                                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                lineNumber: 149,
                                columnNumber: 13
                            }, this),
                            content.summaryBody.map((body, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-700 leading-relaxed mb-2 last:mb-0",
                                    children: body
                                }, idx, false, {
                                    fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                    lineNumber: 153,
                                    columnNumber: 15
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                        lineNumber: 148,
                        columnNumber: 11
                    }, this),
                    content.closingTitle && content.closingBody && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-6 bg-blue-50 border border-blue-200 rounded-xl p-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-base font-bold text-blue-800 mb-3 flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "👨‍⚕️👩‍⚕️"
                                    }, void 0, false, {
                                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                        lineNumber: 167,
                                        columnNumber: 15
                                    }, this),
                                    content.closingTitle
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                lineNumber: 166,
                                columnNumber: 13
                            }, this),
                            content.closingBody.map((body, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-700 leading-relaxed mb-2 last:mb-0",
                                    children: body
                                }, idx, false, {
                                    fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                                    lineNumber: 171,
                                    columnNumber: 15
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                        lineNumber: 165,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/RecoveryGuideDetailPage.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
_s(RecoveryGuideDetailPage, "mZhp9gyPskAQ6BottdCfEnWBrSs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = RecoveryGuideDetailPage;
var _c;
__turbopack_context__.k.register(_c, "RecoveryGuideDetailPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/content/recoveryGuidePosts.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// 19개 회복 가이드 글 데이터
// 각 글은 시술/수술명에 대한 회복 가이드입니다.
__turbopack_context__.s([
    "findRecoveryGuideById",
    ()=>findRecoveryGuideById,
    "findRecoveryGuideByKeyword",
    ()=>findRecoveryGuideByKeyword,
    "getAllRecoveryGuides",
    ()=>getAllRecoveryGuides,
    "recoveryGuidePosts",
    ()=>recoveryGuidePosts
]);
const recoveryGuidePosts = [
    // 예시 구조 (실제 19개 글은 사용자가 제공한 마크다운을 기반으로 채워야 함)
    {
        id: "jaw-contour-surgery",
        procedureName: "턱·윤곽·양악 수술",
        title: "턱·윤곽·양악 수술에 대한 회복 가이드🍀",
        description: "턱·윤곽·양악 등 얼굴 뼈 구조가 크게 변하는 수술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 턱·윤곽·양악 수술

권장 회복 기간 : 4주 이상

(해당 시술: V라인축소술, 사각턱수술, 턱끝수술, 턱끝축소술, 피질절골술, 교근축소술, 비절개턱성형, 이중턱근육묶기, 하악수술, 상악수술, 양악수술, 턱끝보형물삽입, 턱끝보형물제거, 턱끝이물질제거)

## 🕐 1주차 (Day 0–7)

### 얼굴 뼈 구조가 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

턱·윤곽·양악 수술은 얼굴의 연부조직이 아니라 뼈 구조 자체가 이동하거나 재배치되는 수술이기 때문에 몸의 반응이 매우 강하게 나타납니다. 이 시기에는 수술 부위뿐 아니라 얼굴 전체가 구조적으로 달라졌다는 사실을 인지하며 붓기, 멍, 압박감, 당김이 동시에 발생하는 것이 정상입니다. 뼈 위를 덮고 있던 근육과 피부, 신경이 새로운 위치에 적응하지 못한 상태이기 때문에 얼굴은 실제 결과보다 더 부어 있고 더 넓고 둔탁해 보일 수 있습니다. 이 시기의 외형은 수술 결과가 아니라 회복을 시작하기 전 나타나는 임시 모습에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 가능한 한 일정을 최소화하고 회복을 최우선으로 두기
- 수면 시 머리를 살짝만 높여 붓기 압력 줄이기
- 하루 여러 번 방 안이나 복도에서 3–5분 정도 가볍게 걷기
- 냉·온찜질은 반드시 병원 지침에 맞춰 진행

⚠ 권고사항

- 거울을 자주 보며 얼굴 폭이나 윤곽을 평가
- 무리한 외출이나 장시간 이동
- 통증·붓기를 문제 상황으로 단정

## 🕑 2주차 (Day 8–14)

### 강한 붓기는 줄고 윤곽 변화의 방향이 보이기 시작하는 시기

2주차부터는 수술 직후의 강한 염증 반응이 서서히 가라앉으며 얼굴 전체의 부피감이 줄어들기 시작합니다. 다만 이 시기는 붓기가 완전히 빠지는 단계가 아니라 큰 붓기와 잔붓기가 공존하는 과도기이기 때문에 아침과 저녁 얼굴 컨디션 차이가 뚜렷하게 나타날 수 있습니다. 이는 회복이 잘못된 것이 아니라 턱·윤곽·양악 수술에서 매우 흔한 정상 회복 패턴입니다. 이 시점에서는 세부 결과보다 윤곽이 어떤 방향으로 바뀌고 있는지 큰 흐름만 확인하는 것이 충분합니다.

✔ 이 주차에 도움 되는 팁

- 앉아서 쉴 수 있는 일정 위주의 외출
- 사진은 같은 조명과 각도로 기록용만 남기기
- 가벼운 산책으로 붓기 순환 돕기

⚠ 권고사항

- 수술 전 사진이나 타인 후기와의 과도한 비교
- 과음이나 밤샘 일정
- 아직 부어 있다는 이유로 조급해하기

## 🕒 3주차 (Day 15–21)

### 겉으로는 자연스러워 보이지만 내부는 적응을 마무리하는 시기

3주차에 접어들면 외관상 붓기는 상당 부분 정리되어 주변에서는 자연스럽다고 느끼는 경우가 많아집니다. 하지만 몸 안에서는 턱 주변 근육과 관절, 저작근이 새로운 위치와 사용 패턴에 적응하는 과정이 계속되고 있어 말이나 표정을 많이 사용한 날에는 뻐근함이나 피로감이 다시 느껴질 수 있습니다. 이는 회복이 나빠진 신호가 아니라 정상적인 적응 과정에서 나타나는 반응입니다.

✔ 이 주차에 도움 되는 팁

- 촬영이나 가벼운 여행 일정 가능
- 일정 중간중간 의도적으로 휴식 시간 넣기
- 피곤한 날은 일정을 줄이는 것도 회복의 일부로 받아들이기

⚠ 권고사항

- 격한 운동이나 턱을 과하게 사용하는 활동
- 이제 다 끝났다는 생각으로 무리

## 🕓 4주차 (Day 22–28)

### 일상은 가능하지만 회복은 아직 진행 중인 시기

4주차에는 일상생활과 출근, 일반적인 여행 일정이 대부분 가능해집니다. 다만 의학적으로 턱·윤곽·양악 수술의 안정화는 3–6개월에 걸쳐 진행되기 때문에 지금의 모습은 최종 결과라기보다 안정적으로 회복되고 있는 중간 단계에 가깝습니다. 이 시점에서 결과를 지나치게 엄격하게 평가하면 불필요한 불안만 커질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 의료진 허용 범위 내에서 가벼운 운동부터 시작
- 1·2주차 기록 사진과 비교해 변화 확인
- 피로 신호가 오면 휴식 우선

⚠ 권고사항

- 4주차에 결과를 단정
- 아직 불편하다는 이유로 실패로 연결

### 의료진 공통 안내

턱·윤곽·양악 수술의 회복은 속도가 아니라 순서입니다. 지금 주차에 맞는 관리만 유지하고 있다면 결과는 대부분 그 다음 단계에서 자연스럽게 따라옵니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "턱",
            "윤곽",
            "양악",
            "V라인",
            "사각턱",
            "턱끝",
            "하악",
            "상악"
        ]
    },
    {
        id: "cheek-temple-forehead-revision",
        procedureName: "광대 · 관자 · 이마 · 뒤통수 · 눈썹뼈 · 안면윤곽 재수술",
        title: "광대 · 관자 · 이마 · 뒤통수 · 눈썹뼈 · 안면윤곽 재수술에 대한 회복 가이드🍀",
        description: "광대, 관자, 이마, 뒤통수, 눈썹뼈 등 얼굴 상·중안면과 두상 구조가 함께 바뀌는 수술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 광대 · 관자 · 이마 · 뒤통수 · 눈썹뼈 · 안면윤곽 재수술

권장 회복 기간 : 3–4주

(해당 시술: 광대축소술, 앞광대축소술, 옆광대축소술, 전체광대축소술, 퀵광대축소술, 광대보형물삽입, 앞광대보형물삽입, 관자놀이보형물삽입, 관자놀이축소술, 이마보형물삽입, 이마축소술, 눈썹뼈축소술, 뒤통수보형물삽입, 광대이물질제거, 관자놀이이물질제거, 이마이물질제거, 안면윤곽재수술)

## 🕐 1주차 (Day 0–7)

### 얼굴 상·중안면과 두상 구조가 함께 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

광대, 관자, 이마, 뒤통수, 눈썹뼈 수술은 얼굴의 앞면뿐 아니라 옆면과 위쪽 구조까지 동시에 변화시키는 수술입니다. 한 부위만 수술했더라도 몸은 얼굴 전체와 두상이 하나의 구조로 바뀌었다고 인식하며 반응합니다. 이 시기에는 얼굴 윗부분이 단단하게 조여진 느낌이 들거나 헬멧을 쓴 것처럼 무겁게 느껴질 수 있고, 고개를 돌리거나 씹는 동작에서도 당김과 욱신거림이 동반될 수 있습니다. 겉으로 보이는 얼굴은 실제 결과보다 폭이 넓어 보이거나 이마·광대 윤곽이 과장돼 보일 수 있는데 이는 조직과 근막이 새로운 위치에 적응하지 못해 나타나는 정상 반응입니다.

✔ 이 주차에 도움 되는 팁

- 머리를 과하게 높이지 말고 살짝만 올린 상태로 휴식
- 얼굴 윤곽을 손으로 만지거나 눌러 확인하지 않기
- 실내 위주로 조용히 지내며 자극 최소화
- 냉·온찜질은 병원 지침에 맞춰 정확히 진행

⚠ 권고사항

- 거울을 자주 보며 광대 폭이나 이마 크기 평가
- 모자를 깊게 눌러 쓰거나 얼굴을 압박
- 웃음·표정을 과도하게 사용하는 행동
- 전보다 더 이상해 보인다는 생각으로 불안해하기

## 🕑 2주차 (Day 8–14)

### 붓기 속에서 윤곽이 정리되는 방향이 느껴지기 시작하는 시기

2주차부터는 수술 직후의 강한 염증 반응이 서서히 가라앉으며 얼굴 전체 부피감이 줄어들기 시작합니다. 다만 붓기가 한 번에 빠지지 않고 부위별로 이동하기 때문에 어떤 날은 광대가 더 도드라져 보이고, 어떤 날은 이마나 관자 쪽이 더 부어 보일 수 있습니다. 정면에서는 아직 넓어 보이더라도 측면이나 45도 각도에서 윤곽의 입체감이 이전과 다르게 느껴지기 시작하는 시기입니다. 이 단계에서는 세부 모양보다 윤곽이 정리되는 방향만 가볍게 확인하는 것이 적절합니다.

✔ 이 주차에 도움 되는 팁

- 오전보다 오후 얼굴 컨디션 기준으로 일정 조절
- 카페·전시처럼 앉아서 쉴 수 있는 일정 위주로 외출
- 사진은 같은 각도와 조명으로 기록
- 충분한 수분 섭취로 순환 돕기

⚠ 권고사항

- 하루 단위로 얼굴 윤곽을 세밀하게 비교
- 강한 햇빛이나 사우나·찜질방
- 붓기가 남아 있다는 이유로 조급해하기

## 🕒 3주차 (Day 15–21)

### 주변에서 변화가 먼저 인지되기 시작하는 시기

3주차에 접어들면 외관상 붓기는 상당 부분 정리되어 주변 사람들은 얼굴이 작아졌거나 인상이 부드러워졌다고 느끼는 경우가 많아집니다. 사진에서는 광대와 이마 윤곽이 자연스럽게 이어져 보이고 두상 라인도 안정적으로 정돈된 인상을 줍니다. 다만 일정이 많거나 표정을 많이 사용한 날에는 뻐근함이나 피로감이 다시 느껴질 수 있는데 이는 회복이 나빠진 것이 아니라 구조 적응 과정에서 나타나는 정상 반응입니다.

✔ 이 주차에 도움 되는 팁

- 촬영·가벼운 여행 일정 무리 없이 가능
- 장시간 일정 중간중간 휴식 시간 확보
- 머리카락 스타일로 윤곽을 자연스럽게 보완
- 자연광에서 사진으로 변화 기록

⚠ 권고사항

- 격한 표정 사용이나 장시간 웃음 유지
- 밤샘이나 과음으로 붓기 재발
- 이제 다 끝났다는 생각으로 관리 소홀

## 🕓 4주차 (Day 22–28)

### 겉보기엔 자연스럽지만 내부 구조는 계속 안정되는 중

4주차에는 타인이 보기엔 수술 여부를 알아채기 어려울 정도로 윤곽이 자연스럽게 보일 수 있습니다. 하지만 광대·관자·이마·두상 윤곽 수술은 뼈와 근막, 연부조직이 함께 적응하는 과정이기 때문에 진짜 안정화는 3–6개월에 걸쳐 진행됩니다. 지금의 얼굴은 최종 결과라기보다 안정적으로 회복되고 있는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 일상생활 대부분 무리 없이 가능
- 가벼운 산책과 스트레칭부터 단계적으로 활동 재개
- 3개월 차를 기준으로 변화 관찰 계획 세우기
- 피로 신호가 오면 즉시 휴식

⚠ 권고사항

- 경락이나 윤곽 마사지 성급히 시작
- 미세한 비대칭을 과도하게 확대 해석
- 1개월 차 얼굴을 최종 결과로 규정

### 의료진 공통 안내

광대·관자·이마·두상 윤곽 수술의 회복은 빠르게 보이는 변화보다 안정적으로 자리 잡는 과정이 더 중요합니다. 지금의 회복 흐름이 유지되고 있다면 시간이 지날수록 더욱 부드럽고 자연스러운 윤곽으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "광대",
            "관자",
            "이마",
            "뒤통수",
            "눈썹뼈",
            "안면윤곽",
            "재수술",
            "광대축소",
            "관자놀이",
            "이마축소"
        ]
    },
    {
        id: "nose-surgery-non-surgical",
        procedureName: "코 수술·비절개·코 시술",
        title: "코 수술·비절개·코 시술에 대한 회복 가이드🍀",
        description: "코 수술, 비절개 코 교정, 코 시술 등 얼굴 중심 축이 바뀌는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 코 수술·비절개·코 시술

권장 회복 기간 : 2–4주

(해당 시술: 콧대보형물삽입, 콧대자가조직이식, 콧대인공조직삽입, 비주연장술, 코길이연장술, 복코교정수술, 비절개코교정, 미스코, 하이코, 고양이수술, 코필러, 코보톡스)

## 🕐 1주차 (Day 0–7)

### 얼굴 중심 축이 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

코는 얼굴의 중심이자 호흡·발음·표정과 연결된 구조이기 때문에 작은 변화에도 몸의 반응이 크게 나타납니다. 이 시기에는 붓기, 압박감, 당김, 이물감이 동시에 느껴질 수 있고 코가 실제 결과보다 더 커 보이거나 둔해 보이는 착시가 흔합니다. 수술과 비절개, 시술 모두 조직 자극이 겹치면서 코 라인이 과장돼 보일 수 있으며 이는 결과가 아니라 회복 전 단계의 정상 반응에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 얼굴을 베개나 손에 파묻지 않고 정면을 향한 수면 자세 유지
- 수분 섭취를 늘려 비강 건조 예방
- 병원 안내에 따른 세척·연고·찜질 루틴 정확히 지키기
- 외출은 최소화하고 실내 위주로 휴식

⚠ 권고사항

- 코를 비비거나 만져 모양 확인
- 마스크를 코에 강하게 눌러 착용
- 뜨거운 음식과 과음
- 초반 사진만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 붓기 속에서 코 라인의 방향성이 보이기 시작하는 시기

2주차부터는 초기 염증 반응이 가라앉으며 정면·측면에서 이전과 다른 실루엣이 느껴지기 시작합니다. 수술 계열은 단단함과 당김이 남아 있을 수 있고 비절개·시술 계열은 이 시점에서 비교적 라인이 또렷해지는 경우가 많습니다. 다만 붓기가 부위별로 이동해 하루하루 인상이 달라 보일 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 사람 많은 곳에서만 마스크 착용해 압박 최소화
- 카페·쇼핑 등 가벼운 외출 가능
- 자연광에서 정면·45도 각도로 사진 기록
- 코 안쪽 건조 시 처방 제품만 사용

⚠ 권고사항

- 콧대나 코끝을 눌러 모양 확인
- 강한 햇빛·사우나·찜질방
- 어색함을 과도하게 확대 해석

## 🕒 3주차 (Day 15–21)

### 코 라인이 얼굴 인상에 자연스럽게 섞이는 시기

3주차에는 코가 얼굴 전체 인상에 자연스럽게 어우러지기 시작합니다. 웃거나 말할 때의 어색함이 줄고 촬영이나 약속 일정이 비교적 자유로워집니다. 다만 일정이 많았던 날에는 미세한 뻐근함이 남을 수 있으나 이는 적응 과정에서 흔히 나타나는 반응입니다.

✔ 이 주차에 도움 되는 팁

- 촬영·여행 일정 무리 없이 가능
- 살짝 위에서 아래로 찍는 각도가 안정적
- 가벼운 메이크업부터 단계적 복귀
- 코 주변 자외선 차단 유지

⚠ 권고사항

- 사람 많은 곳에서 부딪힘 주의
- 과음·밤샘으로 붓기 재발
- 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정되지만 내부 조직은 계속 적응 중

4주차에는 외관상 충분히 자연스럽게 보일 수 있습니다. 하지만 코는 연골·연부조직·피부가 함께 적응하는 구조라 미세한 변화가 3–6개월까지 이어질 수 있습니다. 지금의 코는 최종 결과라기보다 안정적으로 자리 잡아가는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 일상·여행·비행 대부분 무리 없이 가능
- 3개월 차 사진을 기준으로 변화 비교 계획
- 자극 없는 생활 습관 유지
- 건조감·당김이 남으면 보습 관리 지속

⚠ 권고사항

- 코 마사지·경락·강한 압박
- 미세한 높이·각도 차이에 집착
- 1개월 차를 최종 결과로 규정

### 의료진 공통 안내

코 수술·비절개·코 시술은 회복 과정에서 심리적 흔들림이 큰 편이지만 현재의 변화는 정상적인 흐름 안에 있습니다. 주차에 맞는 관리만 유지한다면 시간이 지날수록 얼굴과 조화로운 코 라인으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "코",
            "비절개",
            "콧대",
            "코필러",
            "코보톡스",
            "비주연장",
            "복코",
            "미스코",
            "하이코"
        ]
    },
    {
        id: "eye-surgery-revision",
        procedureName: "눈 성형·트임·재수술",
        title: "눈 성형·트임·재수술에 대한 회복 가이드🍀",
        description: "쌍꺼풀 수술, 눈매교정, 트임 수술, 눈 재수술 등 미세한 근육·피부 구조 변화에 눈이 반응하는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 눈 성형·트임·재수술

권장 회복 기간 : 2–4주

(해당 시술: 쌍꺼풀수술(절개법), 쌍꺼풀수술(매몰법), 쌍꺼풀재수술, 눈매교정수술, 상안검수술, 하안검수술, 앞트임수술, 뒤트임수술, 밑트임수술, 복합트임수술, 눈재수술)

## 🕐 1주차 (Day 0–7)

### 미세한 근육·피부 구조 변화에 눈이 가장 예민하게 반응하는 시기

눈은 피부가 얇고 표정 근육 사용이 잦아 작은 구조 변화에도 반응이 크게 나타납니다. 이 시기에는 붓기, 멍, 당김, 압박감이 동시에 나타날 수 있고 눈이 실제 결과보다 더 커 보이거나 과하게 올라가 보이는 착시가 흔합니다. 절개·재수술의 경우 봉합 부위 긴장으로 눈매가 강해 보일 수 있으며 트임 수술은 눈꼬리 주변이 당겨져 어색하게 느껴질 수 있습니다. 지금의 인상은 결과가 아니라 회복을 시작하기 전의 정상 반응입니다.

✔ 이 주차에 도움 되는 팁

- 눈을 세게 뜨거나 찡그리는 표정 최소화
- 수면 시 머리를 살짝 높여 부종 압력 줄이기
- 냉찜질은 병원 지침에 맞춰 짧게 진행
- 실내 위주 일정으로 휴식 우선

⚠ 권고사항

- 눈을 문지르거나 라인을 눌러 확인
- 장시간 화면 응시
- 진한 아이메이크업
- 초반 사진만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 붓기는 줄고 라인의 방향성이 보이기 시작하는 시기

2주차부터는 강한 붓기와 멍이 서서히 가라앉으며 쌍꺼풀 라인과 눈매 교정 방향이 느껴지기 시작합니다. 다만 아침에는 눈두덩이 두툼해 보이고 오후로 갈수록 가벼워지는 일중 차이가 흔합니다. 트임 수술은 눈꼬리 당김이 남아 있을 수 있으나 점차 완화되는 흐름이 정상입니다.

✔ 이 주차에 도움 되는 팁

- 오전보다 오후 컨디션 기준으로 상태 판단
- 자연광에서 정면 사진으로만 기록
- 처방 연고·안약 루틴 정확히 유지
- 가벼운 외출 가능하되 자극 최소화

⚠ 권고사항

- 좌우 라인을 하루 단위로 비교
- 사우나·찜질방
- "아직 어색하다"는 이유로 조급해하기

## 🕒 3주차 (Day 15–21)

### 눈매가 얼굴 인상에 자연스럽게 섞이는 시기

3주차에는 눈의 붓기가 상당 부분 정리되어 사진과 영상에서 인상이 한결 부드러워집니다. 쌍꺼풀 라인은 피부 움직임에 따라 자연스럽게 접히기 시작하고 눈매교정·트임 효과도 얼굴 전체와 조화롭게 느껴집니다. 다만 피로한 날에는 미세한 붓기나 당김이 다시 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 촬영·약속 일정 무리 없이 가능
- 가벼운 아이메이크업부터 단계적 복귀
- 충분한 수면으로 붓기 재발 방지
- 전체 인상 기준으로 변화 평가

⚠ 권고사항

- 격한 표정 연습
- 과음·밤샘
- 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정되지만 내부 조직은 계속 적응 중

4주차에는 외관상 눈매가 비교적 안정돼 보일 수 있습니다. 그러나 절개·재수술의 경우 내부 조직 안정화는 3–6개월에 걸쳐 진행됩니다. 지금의 눈은 최종 결과라기보다 안정적으로 자리 잡아가는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 일상·여행 대부분 무리 없이 가능
- 자외선 차단과 눈가 보습 루틴 유지
- 3개월 차를 기준으로 변화 비교 계획
- 피로 신호가 오면 휴식 우선

⚠ 권고사항

- 눈가 마사지·경락 성급히 시작
- 미세한 좌우 차이에 집착
- 1개월 차를 최종 결과로 규정

### 의료진 공통 안내

눈 성형·트임·재수술의 회복은 미세한 변화가 누적되며 완성됩니다. 주차에 맞는 관리만 유지한다면 시간이 지날수록 더 자연스럽고 안정적인 눈매로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "눈",
            "쌍꺼풀",
            "눈매교정",
            "트임",
            "눈재수술",
            "상안검",
            "하안검",
            "앞트임",
            "뒤트임"
        ]
    },
    {
        id: "under-eye-fat-dark-circle",
        procedureName: "눈밑·눈 지방·다크서클",
        title: "눈밑·눈 지방·다크서클에 대한 회복 가이드🍀",
        description: "눈밑 지방재배치, 지방제거, 지방이식, 다크서클 개선 등 얇은 피부층과 혈관 변화에 몸이 반응하는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 눈밑·눈 지방·다크서클

권장 회복 기간 : 2–3주

(해당 시술: 눈밑지방재배치, 눈밑지방제거, 눈밑지방이식, 눈물고랑교정, 다크서클지방이식, 눈밑보형물, 눈밑필러)

## 🕐 1주차 (Day 0–7)

### 얇은 피부층과 혈관 변화에 몸이 가장 예민하게 반응하는 시기

눈밑은 얼굴에서 피부가 가장 얇고 혈관과 지방층이 밀집된 부위라 작은 자극에도 색감과 부피 변화가 크게 느껴집니다. 이 시기에는 붓기와 멍, 당김이 동시에 나타나며 눈밑이 실제보다 더 어둡거나 도톰해 보이는 착시가 흔합니다. 눈밑지방재배치나 지방이식 후에는 울퉁불퉁함이나 좌우 차이가 더 도드라져 보일 수 있으나 이는 조직이 아직 자리를 잡지 못한 정상 반응입니다. 지금의 인상은 결과가 아니라 회복을 준비하는 초기 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 냉찜질은 병원 지침에 맞춰 짧게 진행
- 눈을 과도하게 사용하지 않고 휴식 위주 생활
- 수면 시 머리를 살짝 높여 부종 압력 줄이기
- 인공눈물로 눈가 건조 관리

⚠ 권고사항

- 눈밑을 눌러 모양 확인
- 장시간 화면 응시
- 진한 아이메이크업
- 멍이나 색감만으로 결과 단정

## 🕑 2주차 (Day 8–14)

### 색감과 볼륨이 분리되어 보이기 시작하는 시기

2주차부터는 멍과 강한 붓기가 줄어들며 눈밑의 색감과 부피가 구분되어 보이기 시작합니다. 다크서클은 밝아지는 방향성이 느껴질 수 있고 지방 계열 시술은 도톰함이 퍼지며 라인이 정리됩니다. 다만 아침과 저녁, 컨디션에 따라 눈밑 색이 다시 진해 보일 수 있는데 이는 혈류와 순환 변화에 따른 정상적인 회복 패턴입니다.

✔ 이 주차에 도움 되는 팁

- 가벼운 외출과 촬영 일정 가능
- 자연광에서 정면 사진으로 변화 기록
- 눈가 보습과 자외선 차단 유지
- 오후 컨디션 기준으로 상태 판단

⚠ 권고사항

- 하루 단위로 색 변화 집요하게 비교
- 사우나·찜질방
- 수면 부족으로 회복 지연

## 🕒 3주차 (Day 15–21)

### 눈밑 인상이 얼굴 전체에 자연스럽게 섞이는 시기

3주차에 들어서면 눈밑이 얼굴 인상에 자연스럽게 녹아들기 시작합니다. 사진과 영상에서 피곤해 보이던 느낌이 줄고 컨실러 사용량이 줄어드는 경우가 많습니다. 다만 일정이 많았던 날에는 미세한 부종이나 색감 변화가 다시 느껴질 수 있으나 이는 회복 흐름 안에 있는 정상 반응입니다.

✔ 이 주차에 도움 되는 팁

- 일상·여행 일정 무리 없이 가능
- 가벼운 메이크업 단계적 복귀
- 충분한 수면과 수분 섭취 유지
- 월 단위 사진으로 변화 비교

⚠ 권고사항

- 밤샘이나 과음
- 눈가 마사지 성급히 시작
- 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정되지만 미세 변화는 계속되는 시기

4주차에는 외관상 눈밑이 비교적 안정돼 보일 수 있습니다. 다만 지방의 생착과 재배치, 혈관 색감 변화는 3–6개월까지 이어질 수 있어 미세한 인상 변화가 남아 있을 수 있습니다. 지금의 눈밑은 최종 결과라기보다 안정적으로 자리 잡아가는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 생활 리듬을 일정하게 유지
- 눈가 보습·자외선 차단 루틴 지속
- 3개월 차를 기준으로 변화 관찰 계획
- 피로 신호가 오면 휴식 우선

⚠ 권고사항

- 미세한 좌우 차이에 집착
- 1개월 차를 최종 결과로 규정
- 즉흥적인 추가 시술 결정

### 의료진 공통 안내

눈밑·눈 지방·다크서클 개선은 작은 변화가 인상에 크게 작용하는 영역입니다. 회복 주차에 맞는 관리만 유지한다면 시간이 지날수록 더 맑고 안정적인 눈밑 인상으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "눈밑",
            "눈밑지방",
            "다크서클",
            "눈물고랑",
            "눈밑보형물",
            "눈밑필러"
        ]
    },
    {
        id: "eye-area-volume",
        procedureName: "눈 주변 볼륨 시술",
        title: "눈 주변 볼륨 시술에 대한 회복 가이드🍀",
        description: "애교살 필러, 눈물고랑 필러, 눈밑 필러 등 미세한 볼륨 변화가 시야와 표정 감각을 자극하는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 눈 주변 볼륨 시술

권장 회복 기간 : 1–2주

(해당 시술: 애교살필러, 눈물고랑필러, 눈밑필러, 앞볼볼륨시술, 뒤볼볼륨시술, 눈가스킨부스터, 눈가리프팅시술)

## 🕐 1주차 (Day 0–7)

### 미세한 볼륨 변화가 시야와 표정 감각을 동시에 자극하는 시기

눈 주변은 피부가 얇고 움직임이 잦아 소량의 볼륨 변화에도 인상이 크게 달라 보입니다. 이 시기에는 주입 자극과 조직 반응으로 인해 붓기, 당김, 미세한 압박감이 함께 느껴질 수 있으며 애교살이나 눈물고랑이 실제보다 더 도톰하거나 좌우가 달라 보이는 착시가 흔합니다. 주입 부위가 단단하게 만져지거나 표정에 따라 울퉁불퉁해 보일 수 있는데 이는 볼륨이 아직 퍼지지 않은 정상 반응입니다. 지금의 모습은 결과가 아니라 볼륨이 자리를 찾기 전의 임시 상태에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 눈가를 누르거나 만지지 않기
- 수분 섭취를 늘려 조직 순환 돕기
- 화면 사용 시간을 줄이고 휴식 위주로 생활
- 냉찜질은 필요 시 짧게만 진행

⚠ 권고사항

- 눈가 마사지나 문지르기
- 진한 아이메이크업
- 초반 사진만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 볼륨이 퍼지며 인상에 자연스럽게 섞이기 시작하는 시기

2주차에는 초기 붓기가 가라앉으며 눈 주변 볼륨이 퍼져 자연스러운 곡선으로 이어지기 시작합니다. 애교살필러는 웃을 때 더 자연스럽게 보이고 눈물고랑필러는 음영이 완화되는 방향성이 느껴질 수 있습니다. 다만 아침과 저녁, 컨디션에 따라 볼륨감이 달라 보일 수 있는데 이는 순환 차이에 따른 정상적인 변화입니다.

✔ 이 주차에 도움 되는 팁

- 가벼운 외출과 촬영 일정 가능
- 자연광에서 정면·45도 각도로 사진 기록
- 눈가 보습과 자외선 차단 유지
- 오후 컨디션 기준으로 변화 확인

⚠ 권고사항

- 하루 단위로 볼륨 높낮이 비교
- 사우나·찜질방
- 즉흥적인 추가 시술 결정

## 🕒 3주차 (Day 15–21)

### 표정과 함께 볼륨이 자연스럽게 작동하는 시기

3주차에 들어서면 눈 주변 볼륨이 표정에 자연스럽게 반응하며 인상에 안정적으로 녹아듭니다. 사진과 영상에서 과한 티가 줄고 또렷하지만 부드러운 눈매로 보이는 경우가 많습니다. 다만 일정이 많거나 수면이 부족한 날에는 미세한 붓기가 다시 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 메이크업 루틴 단계적 복귀
- 충분한 수면과 수분 섭취 유지
- 월 단위 사진으로 변화 기록
- 눈가 자극 최소화

⚠ 권고사항

- 과음·밤샘
- 눈가 경락·강한 압박
- 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정적이며 유지 관리 시점을 판단하는 시기

4주차에는 외관상 볼륨이 충분히 안정돼 보입니다. 다만 필러·볼륨 시술은 유지 관리가 중요한 영역이므로 이 시점은 완성이라기보다 현재 상태를 기준으로 다음 관리 시점을 계획하는 단계에 가깝습니다.

✔ 이 주차에 도움 되는 팁

- 현재 상태를 기준으로 유지 기간 메모
- 자외선 차단·보습 루틴 지속
- 과한 욕심보다 현 상태 유지에 집중
- 장기 관리 계획 세우기

⚠ 권고사항

- 미세한 좌우 차이에 집착
- 유지 기간을 넘긴 무리한 방치
- 1개월 차를 최종 결과로 규정

### 의료진 공통 안내

눈 주변 볼륨 시술은 소량의 변화가 인상 전체에 크게 작용합니다. 회복 주차에 맞는 관리만 유지한다면 시간이 지날수록 표정과 자연스럽게 어우러진 안정적인 눈가로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "애교살",
            "눈물고랑",
            "눈밑필러",
            "앞볼볼륨",
            "뒤볼볼륨",
            "눈가스킨부스터",
            "눈가리프팅"
        ]
    },
    {
        id: "face-fat-grafting-volume",
        procedureName: "얼굴 지방이식 · 팔자 · 풀페이스 볼륨",
        title: "얼굴 지방이식 · 팔자 · 풀페이스 볼륨에 대한 회복 가이드🍀",
        description: "얼굴 지방이식, 풀페이스 지방이식, 팔자주름 지방이식 등 얼굴 전체의 볼륨 중심이 바뀌는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 얼굴 지방이식 · 팔자 · 풀페이스 볼륨

권장 회복 기간 : 2–4주

(해당 시술: 얼굴지방이식, 풀페이스지방이식, 이마지방이식, 관자지방이식, 앞광대지방이식, 볼지방이식, 팔자주름지방이식, 인디언주름지방이식, 마리오넷라인지방이식, 입가주름지방이식, 얼굴지방이식재수술, 볼꺼짐교정, 얼굴볼륨교정)

## 🕐 1주차 (Day 0–7)

### 얼굴 전체의 볼륨 중심이 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

특정 부위만 지방이식이나 볼륨 교정을 했더라도 얼굴은 이를 부분 변화가 아닌 전체 구조 변화로 인식합니다. 이 시기에는 지방이 들어간 부위뿐 아니라 주변 조직까지 함께 반응하면서 얼굴이 실제보다 더 둥글고 커 보이거나 과하게 통통해 보일 수 있습니다. 붓기, 묵직함, 당김, 압박감이 동시에 느껴지는 것이 정상이며 좌우 비대칭이나 울퉁불퉁함이 더 도드라져 보일 수 있습니다. 이는 지방이 자리를 잡기 전 조직 반응이 가장 활발한 단계로 지금의 외형은 결과가 아니라 회복 전 단계의 임시 모습에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 얼굴을 아래로 오래 숙이지 않고 정면 자세 유지
- 수면 시 베개를 살짝 높여 부종 압력 줄이기
- 냉찜질은 병원 지침에 맞춰 제한적으로 진행
- 외출은 최소화하고 휴식 위주로 생활

⚠ 권고사항

- 얼굴을 눌러 볼륨 확인
- 과한 표정 사용이나 크게 웃기
- Day 3~5 얼굴만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 볼륨이 퍼지며 얼굴 비율이 정리되기 시작하는 시기

2주차부터는 강한 붓기가 서서히 가라앉으며 얼굴에 몰려 있던 볼륨이 퍼지기 시작합니다. 이마와 관자, 앞광대 부위는 비교적 먼저 안정되는 편이고 팔자주름지방이식이나 입가주름지방이식 부위는 상대적으로 붓기가 늦게 빠질 수 있습니다. 지방이식 특성상 빠진 것처럼 보였다가 다시 차오르는 느낌을 받을 수 있는데 이는 흡수와 생착이 동시에 진행되는 정상적인 회복 과정입니다.

✔ 이 주차에 도움 되는 팁

- 자연광에서 정면·45도 사진으로 변화 기록
- 가벼운 메이크업 단계적 복귀
- 수분 섭취를 늘려 순환 도움
- 오전보다 오후 컨디션 기준으로 판단

⚠ 권고사항

- 얼굴 마사지·경락·롤러 사용
- 거울을 가까이 대고 확대 비교
- 하루 단위로 볼륨 변화 집요하게 분석

## 🕒 3주차 (Day 15–21)

### 인상이 부드러워지고 볼륨감이 자연스럽게 느껴지는 시기

3주차에 접어들면 얼굴이 과하게 통통해 보이던 느낌이 줄고 전체 인상이 한결 부드러워집니다. 사진에서 광대와 팔자, 입가 라인이 자연스럽게 이어져 보이며 피곤해 보이던 인상이 완화되는 경우가 많습니다. 다만 일부 부위는 만졌을 때 딱딱함이나 뭉침이 남아 있을 수 있는데 이는 대부분 정상적인 회복 과정에 포함됩니다.

✔ 이 주차에 도움 되는 팁

- 촬영·약속·데이트 일정 무리 없이 가능
- 평소 스타일 메이크업으로 점진적 복귀
- 얼굴 스트레칭은 짧고 가볍게 진행
- 충분한 수면으로 생착 환경 유지

⚠ 권고사항

- 강한 경락이나 압박 마사지
- 급격한 체중 감량 시도
- 이제 다 됐다는 생각으로 관리 중단

## 🕓 4주차 (Day 22–28)

### 볼륨은 안정되지만 최종 판단은 아직 이른 시기

4주차에는 외관상 얼굴 볼륨이 상당히 자연스럽게 느껴질 수 있습니다. 하지만 얼굴지방이식은 1개월은 안정 단계에 해당하며 최종 생착 판단은 3개월을 기준으로 하는 것이 적절합니다. 지금의 얼굴은 이미 충분히 조화롭지만 앞으로 더 잔잔하게 정리될 여지가 남아 있는 중간 단계입니다.

✔ 이 주차에 도움 되는 팁

- 일상·여행·촬영 대부분 가능
- 자외선 차단과 보습 관리 지속
- 체중 변화 없이 생활 리듬 유지
- 3개월 차 사진 기준으로 변화 비교 계획

⚠ 권고사항

- 얼굴 마사지·고주파 시술 성급히 시작
- 미세한 볼륨 차이에 과도하게 집착
- 1개월 차 얼굴을 최종 결과로 단정

### 의료진 공통 안내

얼굴 지방이식과 볼륨 교정은 짧은 시간에 완성되는 시술이 아니라 시간을 두고 자연스럽게 자리 잡는 과정입니다. 현재의 회복 흐름이 유지된다면 시간이 지날수록 표정과 더욱 조화로운 얼굴로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "지방이식",
            "풀페이스",
            "팔자",
            "인디언주름",
            "마리오넷라인",
            "볼륨교정",
            "볼꺼짐"
        ]
    },
    {
        id: "lifting-surgery-thread-laser",
        procedureName: "리프팅 수술 · 실리프팅 · 레이저·고주파 리프팅",
        title: "리프팅 수술 · 실리프팅 · 레이저·고주파 리프팅에 대한 회복 가이드🍀",
        description: "안면거상, 실리프팅, 울쎄라, 써마지, 인모드 등 피부·근막·지지 구조가 동시에 당겨지는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 리프팅 수술 · 실리프팅 · 레이저·고주파 리프팅

권장 회복 기간 : 2–4주

(해당 시술: 안면거상술, 미니거상술, SMAS거상술, 목거상술, 실리프팅, 민트실리프팅, 울쎄라리프팅, 써마지리프팅, 슈링크리프팅, 인모드리프팅, 온다리프팅, 티타늄리프팅, 고주파리프팅, 레이저리프팅 전반)

## 🕐 1주차 (Day 0–7)

### 피부·근막·지지 구조가 동시에 당겨졌다는 사실을 몸이 가장 강하게 인지하는 시기

리프팅 수술과 실리프팅, 레이저·고주파 리프팅은 방식은 다르지만 공통적으로 피부와 그 아래 구조에 당김과 열 자극, 고정 변화가 발생합니다. 이 시기에는 붓기, 뻐근함, 당김, 열감이 동시에 느껴질 수 있으며 얼굴이 실제보다 더 당겨져 보이거나 표정이 어색하게 느껴질 수 있습니다. 특히 울쎄라리프팅, 써마지리프팅, 인모드리프팅 같은 에너지 기반 시술은 겉으로 큰 변화가 없어 보여도 내부 조직 반응이 강하게 일어나는 단계입니다. 지금의 인상은 결과가 아니라 조직이 자극을 인지하고 안정화를 준비하는 초기 반응에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 표정 사용을 최소화하고 얼굴 근육 휴식 우선
- 수면 시 머리를 살짝 높여 붓기 압력 줄이기
- 자외선 차단과 보습을 즉시 루틴화
- 실내 위주 일정으로 열·자극 최소화

⚠ 권고사항

- 얼굴을 눌러 당김 정도 확인
- 사우나·찜질방·격한 운동
- 즉각적인 리프팅 효과를 기대하며 거울 반복 확인

## 🕑 2주차 (Day 8–14)

### 당김은 줄고 리프팅 방향성이 느껴지기 시작하는 시기

2주차부터는 강한 붓기와 열감이 가라앉으며 얼굴이 조금씩 편안해지기 시작합니다. 실리프팅은 고정된 방향이 느껴지고 레이저·고주파 리프팅은 피부결이 정리되며 탄탄해지는 느낌이 먼저 옵니다. 다만 아침과 저녁, 활동량에 따라 당김 정도가 달라질 수 있는데 이는 회복 과정에서 매우 흔한 패턴입니다. 이 시기에는 얼마나 당겨졌는지를 보기보다 얼굴이 어떤 방향으로 정리되는지만 가볍게 확인하는 것이 적절합니다.

✔ 이 주차에 도움 되는 팁

- 앉아서 쉴 수 있는 일정 위주로 외출
- 자연광에서 정면·45도 각도로 사진 기록
- 보습 제품을 평소보다 충분히 사용
- 오후 컨디션 기준으로 상태 판단

⚠ 권고사항

- 하루 단위로 탄력 변화를 집요하게 비교
- 추가 리프팅 시술 즉흥 결정
- 강한 클렌징·마사지

## 🕒 3주차 (Day 15–21)

### 얼굴 인상이 자연스럽게 정돈돼 보이는 시기

3주차에 접어들면 타인이 보기에 인상이 한결 정돈돼 보이고 얼굴선이 부드러워졌다는 느낌을 받는 경우가 많습니다. 실리프팅과 수술 리프팅은 고정감이 안정되고 레이저·고주파 리프팅은 피부 탄력과 결 개선이 체감되기 시작합니다. 다만 일정이 많거나 말을 많이 한 날에는 당김이나 피로감이 다시 느껴질 수 있는데 이는 회복이 후퇴한 것이 아니라 적응 과정의 일부입니다.

✔ 이 주차에 도움 되는 팁

- 촬영·약속·여행 일정 무리 없이 가능
- 가벼운 스트레칭과 산책으로 순환 도움
- 피부 컨디션 좋은 날을 기준으로 변화 기억
- 월 단위 사진 기록 시작

⚠ 권고사항

- 고강도 운동·안면 마사지
- 밤샘·과음으로 붓기 재발
- 이제 끝났다는 생각으로 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정적이지만 내부 구조는 계속 적응 중인 시기

4주차에는 외관상 리프팅 효과가 비교적 안정돼 보입니다. 하지만 수술 리프팅과 실리프팅, 레이저·고주파 리프팅 모두 피부와 근막의 진짜 안정은 3–6개월에 걸쳐 진행됩니다. 지금의 모습은 최종 결과라기보다 효과가 자리 잡아가는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 일상·출근·여행 대부분 무리 없이 가능
- 자외선 차단·보습 루틴 생활화
- 3개월 차를 기준으로 유지·추가 관리 계획
- 피로 신호가 오면 즉시 휴식

⚠ 권고사항

- 리프팅 효과를 단기간으로 단정
- 미세한 처짐 변화에 과도하게 집착
- 1개월 차 얼굴을 최종 결과로 규정

### 의료진 공통 안내

리프팅 수술과 실리프팅, 레이저·고주파 리프팅은 즉각적인 변화보다 시간이 지날수록 자연스럽게 완성되는 관리입니다. 주차에 맞는 생활 관리만 유지한다면 현재의 효과는 보다 안정적으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "리프팅",
            "실리프팅",
            "안면거상",
            "울쎄라",
            "써마지",
            "인모드",
            "고주파",
            "레이저리프팅"
        ]
    },
    {
        id: "face-lift-forehead-wrinkle",
        procedureName: "안면거상·이마거상·주름 개선 수술",
        title: "안면거상·이마거상·주름 개선 수술에 대한 회복 가이드🍀",
        description: "안면거상, 이마거상, 팔자박리, 마리오넷라인박리 등 피부와 근막이 재배치되는 수술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 안면거상·이마거상·주름 개선 수술

권장 회복 기간 : 3–4주

(해당 시술: 안면거상술, 미니거상술, SMAS거상술, 중안면거상술, 하안면거상술, 목거상술, 이마거상술, 눈썹거상술, 팔자박리술, 마리오넷라인박리, 주름개선수술, 거상재수술)

## 🕐 1주차 (Day 0–7)

### 피부와 근막이 재배치되었다는 사실을 몸이 가장 강하게 인지하는 시기

안면거상과 이마거상, 주름 개선 수술은 피부 표면만의 변화가 아니라 근막(SMAS)과 연부조직의 위치가 함께 이동하는 수술입니다. 이 시기에는 강한 당김, 압박감, 묵직함이 느껴질 수 있고 귀 주변·두피·턱선이 어색하게 느껴질 수 있습니다. 겉으로 보이는 얼굴은 실제 결과보다 더 팽팽하거나 당겨져 보일 수 있으나 이는 고정과 부종이 겹친 정상 반응입니다. 지금의 인상은 결과 판단의 기준이 아니라 조직이 새로운 위치에 고정되기 위한 초기 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 표정 사용을 최소화하고 말수 줄이기
- 수면 시 머리를 살짝 높여 부종 압력 완화
- 병원에서 안내한 압박밴드·거즈 관리 철저
- 실내 위주로 조용히 휴식

⚠ 권고사항

- 입을 크게 벌리거나 하품 참기
- 귀 주변·두피 절개 부위 만지기
- 거울로 당김 정도를 반복 확인

## 🕑 2주차 (Day 8–14)

### 당김은 줄고 붓기와 뻣뻣함이 남는 시기

2주차부터는 초기의 강한 당김이 서서히 완화되고 뻣뻣함, 묵직함, 감각 둔함이 중심이 됩니다. 이마거상술은 눈 위가 무겁게 느껴질 수 있고 안면거상술·팔자박리술은 입 주변과 턱선 감각이 둔하게 느껴질 수 있습니다. 이는 신경과 조직이 새로운 위치에 적응하는 과정에서 흔히 나타나는 반응입니다.

✔ 이 주차에 도움 되는 팁

- 짧은 외출과 카페 일정 가능
- 부드러운 음식 위주로 천천히 식사
- 얼굴을 아래로 오래 숙이지 않기
- 오후 컨디션 기준으로 상태 판단

⚠ 권고사항

- 경락·마사지·롤러 사용
- 절개 부위를 눌러 확인
- 하루 단위로 주름 변화를 집요하게 비교

## 🕒 3주차 (Day 15–21)

### 윤곽과 주름 개선 효과가 눈에 띄기 시작하는 시기

3주차에 접어들면 팔자주름과 마리오넷라인, 턱선이 전보다 정돈돼 보이기 시작합니다. 주변에서는 인상이 단정해졌다는 말을 먼저 듣는 경우도 많습니다. 다만 표정을 크게 사용하면 여전히 약간의 뻣뻣함이나 당김 잔여감이 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 촬영·약속·가벼운 여행 일정 가능
- 웃는 표정은 자연스럽게, 과하지 않게
- 자외선 차단과 보습 관리 강화
- 자연광에서 변화 기록

⚠ 권고사항

- 장시간 웃거나 말해야 하는 일정 무리
- 밤샘·과음으로 붓기 재발
- 이제 끝났다는 생각으로 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 정리됐지만 내부 구조는 계속 안정 중인 시기

4주차에는 외관상 주름 개선과 윤곽 변화가 자연스럽게 느껴질 수 있습니다. 하지만 안면거상과 박리 수술은 피부가 아닌 근막과 조직의 위치를 바꾸는 수술이므로 진짜 안정화는 3–6개월에 걸쳐 진행됩니다. 지금의 얼굴은 완성이라기보다 안정적으로 자리 잡아가는 중간 단계입니다.

✔ 이 주차에 도움 되는 팁

- 일상·출근·외출 대부분 무리 없이 가능
- 가벼운 산책·스트레칭부터 단계적 운동 재개
- 흉터 관리 루틴 생활화
- 3개월 차를 기준으로 변화 관찰 계획

⚠ 권고사항

- 강한 얼굴 마사지·고주파 시술 성급히 시작
- 미세한 주름·비대칭에 과도하게 집착
- 1개월 차 얼굴을 최종 결과로 규정

### 의료진 공통 안내

안면거상과 이마거상, 주름 개선 수술은 시간이 지나면서 자연스럽게 완성되는 수술입니다. 주차에 맞는 관리만 유지한다면 현재의 변화는 보다 안정적으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "안면거상",
            "이마거상",
            "주름개선",
            "팔자박리",
            "마리오넷라인",
            "SMAS",
            "목거상",
            "거상재수술"
        ]
    },
    {
        id: "breast-surgery",
        procedureName: "가슴·부유방·여유증 수술",
        title: "가슴·부유방·여유증 수술에 대한 회복 가이드🍀",
        description: "가슴보형물, 가슴지방이식, 가슴거상, 부유방제거, 여유증수술 등 상체 구조와 무게 중심이 바뀌는 수술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 가슴·부유방·여유증 수술

권장 회복 기간 : 3–4주

(해당 시술: 가슴보형물, 가슴보형물지방이식, 가슴지방이식, 가슴거상술, 가슴거상확대술, 가슴축소술, 가슴보형물제거, 가슴이물질제거, 가슴재수술, 부유방흡입, 부유방제거수술, 몽고메리결절제거, 유두축소술, 유륜축소술, 유륜미백, 유륜문신, 함몰유두교정, 여유증시술, 여유증수술)

## 🕐 1주차 (Day 0–7)

### 상체 구조와 무게 중심이 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

가슴 수술은 단순히 가슴 부위만의 변화가 아니라 흉곽, 겨드랑이, 어깨, 등까지 포함한 상체 전체의 균형이 달라지는 수술입니다. 이 시기에는 통증, 압박감, 묵직함, 당김이 동시에 나타날 수 있으며 보형물이나 거상 수술 후에는 가슴이 실제보다 더 위에 위치해 있고 단단하게 느껴지는 것이 정상입니다. 부유방흡입이나 여유증수술을 함께 진행한 경우 겨드랑이와 팔 안쪽 당김이 더 뚜렷하게 느껴질 수 있습니다. 지금의 모양은 결과가 아니라 조직이 새로운 위치에 안착하기 전의 임시 상태에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 상체를 완전히 눕히지 말고 베개로 살짝 세운 자세 유지
- 압박브라·붕대는 불편해도 지시된 기간 동안 착용
- 팔 사용을 최소화하고 모든 동작은 천천히
- 방 안에서 짧게 자주 움직여 순환 유지

⚠ 권고사항

- 팔을 머리 위로 드는 동작
- 캐리어·무거운 가방 들기
- 거울로 가슴 모양을 반복 평가

## 🕑 2주차 (Day 8–14)

### 통증은 줄고 묵직함과 당김이 중심이 되는 시기

2주차부터는 날카로운 통증은 줄어들고 묵직함과 뻐근함이 회복의 중심이 됩니다. 가슴보형물이나 가슴거상술을 한 경우 윗가슴이 여전히 높고 단단하게 느껴질 수 있는데 이는 보형물과 조직이 아직 자연스럽게 내려오는 과정 중이기 때문입니다. 가슴축소술이나 여유증수술을 한 경우 상체가 가벼워진 느낌과 함께 절개 부위 주변이 더 예민하게 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 앉아서 쉴 수 있는 일정 위주로 외출
- 앞에서 여미는 옷과 부드러운 면 소재 착용
- 흉터 부위는 문지르지 말고 처방 연고만 사용
- 오전보다 오후 컨디션 기준으로 일정 조절

⚠ 권고사항

- 와이어 브라 착용
- 팔을 반복적으로 사용하는 쇼핑 일정
- 흉터 색과 가슴 위치를 하루 단위로 비교

## 🕒 3주차 (Day 15–21)

### 일상 동작은 가능하지만 상체 보호는 계속 필요한 시기

3주차에 접어들면 카페, 쇼핑, 가벼운 외출 등 일상적인 이동이 대부분 가능해집니다. 가슴지방이식이나 가슴보형물 수술 후에는 사진상으로는 자연스러워 보이지만 촉감이나 움직임에서는 아직 완전히 내 몸이 된 느낌은 아닐 수 있습니다. 부유방제거수술이나 여유증수술을 한 경우 옷 핏 변화가 뚜렷해져 만족감을 느끼기 쉬운 시기입니다.

✔ 이 주차에 도움 되는 팁

- 실내 위주 일정과 짧은 이동 추천
- 오래 서 있기보다는 앉아서 쉬는 동선 선택
- 사진 촬영은 가능하되 장시간 촬영은 피하기
- 쿠션 있는 의자 사용으로 상체 부담 줄이기

⚠ 권고사항

- 점프·상체 근력 운동
- 브라톱·코르셋 스타일 의상
- 이제 다 괜찮다는 생각으로 관리 소홀

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정적이지만 조직은 계속 자리 잡는 중인 시기

4주차에는 외출과 출근, 여행 일정 대부분이 가능해지고 타인이 보기엔 수술 티가 거의 나지 않을 수 있습니다. 하지만 가슴 수술은 겉모양보다 내부 조직의 안정이 훨씬 늦게 완성되며 보형물 위치와 지방이식 생착, 거상 후 피부 적응은 3–6개월까지도 이어질 수 있습니다. 지금의 가슴은 완성이 아니라 안정적인 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 일상 복귀는 가능하되 피로 누적 시 휴식 우선
- 의료진 허용 시 가벼운 유산소 운동부터 시작
- 흉터 관리 루틴을 생활화
- 몸의 불편 신호를 기준으로 일정 조절

⚠ 권고사항

- 고강도 운동·수영·웨이트 성급히 시작
- 가슴 모양을 매일 세밀하게 평가
- 1개월 차를 최종 결과로 확정

### 의료진 공통 안내

가슴·부유방·여유증 수술은 시간이 지나면서 점점 자연스러워지는 수술입니다. 현재의 회복 흐름이 유지된다면 앞으로 더 편안하고 안정적인 형태로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "가슴",
            "가슴보형물",
            "가슴지방이식",
            "가슴거상",
            "부유방",
            "여유증",
            "유두",
            "유륜"
        ]
    },
    {
        id: "body-liposuction-lift-revision",
        procedureName: "바디 지방흡입·거상·재수술",
        title: "바디 지방흡입·거상·재수술에 대한 회복 가이드🍀",
        description: "복부지방흡입, 허벅지지방흡입, 복부거상, 허벅지거상 등 체형의 부피와 무게 중심이 바뀌는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 바디 지방흡입·거상·재수술

권장 회복 기간 : 3–4주

(해당 시술: 복부지방흡입, 허벅지지방흡입, 팔지방흡입, 등지방흡입, 옆구리지방흡입, 복부거상술, 하복부거상술, 허벅지거상술, 팔거상술, 엉덩이거상술, 바디라인재수술, 지방흡입재수술, 거상재수술)

## 🕐 1주차 (Day 0–7)

### 체형의 부피와 무게 중심이 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

바디 지방흡입과 거상 수술은 특정 부위만의 변화가 아니라 체형 전체의 균형과 움직임 감각에 영향을 주는 시술입니다. 이 시기에는 강한 붓기, 멍, 압통, 묵직함이 동시에 나타날 수 있고 압박복 착용으로 인해 몸이 더 둔하고 불편하게 느껴질 수 있습니다. 거상 수술을 병행한 경우 절개 부위 주변 당김이 뚜렷하며 자세를 바꾸는 것만으로도 피로가 빠르게 누적될 수 있습니다. 지금의 체형은 결과가 아니라 조직이 자리를 잡기 전의 임시 상태에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 압박복은 불편해도 지시된 시간 동안 유지
- 누워 있을 때는 수술 부위가 과도하게 접히지 않도록 베개 활용
- 실내에서 짧게 자주 움직여 순환 유지
- 통증이 줄었다고 무리하지 않기

⚠ 권고사항

- 압박복 임의로 벗기
- 한 자세로 오래 앉거나 누워 있기
- 거울로 라인을 반복 확인

## 🕑 2주차 (Day 8–14)

### 큰 붓기는 줄고 뻣뻣함과 당김이 남는 시기

2주차에는 전반적인 부피감은 줄어들지만 피부 아래가 단단하게 느껴지고 만졌을 때 울퉁불퉁한 느낌이 남아 있을 수 있습니다. 이는 지방층과 피부, 근막이 재배치되며 나타나는 정상적인 회복 반응입니다. 복부거상술이나 팔·허벅지거상술을 한 경우 움직임에 따라 절개 부위가 더 당기게 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 짧은 외출 가능하되 앉아서 쉬는 일정 포함
- 수분 섭취를 늘려 순환과 붓기 관리
- 오후 컨디션을 기준으로 일정 조절
- 압박복 주름이 생기지 않도록 착용 상태 점검

⚠ 권고사항

- 강한 셀프 마사지
- 사우나·찜질방
- 하루 단위로 라인 변화를 세밀하게 비교

## 🕒 3주차 (Day 15–21)

### 라인의 방향성이 눈에 띄기 시작하는 시기

3주차가 되면 옷을 입었을 때 라인이 달라졌다는 느낌을 받는 경우가 많아집니다. 지방흡입 부위는 붓기 속에서도 전체적인 윤곽 방향이 보이기 시작하고 거상 수술 부위는 피부가 점점 밀착되는 감각이 느껴집니다. 다만 장시간 서 있거나 많이 움직인 날에는 다시 묵직함이 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 옷 핏 변화 위주로 체형 변화 확인
- 짧은 산책과 가벼운 스트레칭 가능
- 장시간 이동 시 중간 휴식 필수
- 사진은 동일한 옷·각도로 기록

⚠ 권고사항

- 고강도 유산소·하체 근력 운동
- 장시간 서서 촬영하는 일정
- 이제 다 끝났다는 생각으로 관리 중단

## 🕓 4주차 (Day 22–28)

### 일상은 가능하지만 체형 안정은 계속 진행 중인 시기

4주차에는 대부분의 일상 활동과 외출이 가능해집니다. 다만 지방흡입과 거상 수술은 피부와 지방층이 완전히 밀착되고 안정화되기까지 3–6개월이 걸릴 수 있습니다. 지금의 바디라인은 완성이 아니라 점점 정리되어 가는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 의료진 허용 범위 내에서 가벼운 운동 시작
- 압박복 착용 단계적 조정
- 장기 체형 관리 계획 세우기
- 피로 신호가 오면 즉시 휴식

⚠ 권고사항

- 무리한 다이어트 병행
- 경락·고주파 시술 성급히 시작
- 1개월 차 라인을 최종 결과로 규정

### 의료진 공통 안내

바디 지방흡입과 거상 수술은 시간이 지나면서 체형이 점점 정리되는 수술입니다. 현재의 회복 흐름을 유지한다면 앞으로 더 자연스럽고 안정적인 라인으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "지방흡입",
            "복부거상",
            "허벅지거상",
            "팔거상",
            "바디라인",
            "복부",
            "허벅지",
            "옆구리"
        ]
    },
    {
        id: "hip-up-pelvis-fat-grafting",
        procedureName: "힙업·골반·지방이식",
        title: "힙업·골반·지방이식에 대한 회복 가이드🍀",
        description: "힙지방이식, 골반지방이식, 힙업거상술 등 하체와 골반의 무게 중심이 바뀌는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 힙업·골반·지방이식

권장 회복 기간 : 3–4주

(해당 시술: 힙지방이식, 힙업지방이식, 골반지방이식, 힙딥지방이식, 엉덩이지방이식재수술, 골반보형물, 엉덩이보형물, 힙업거상술, 엉덩이거상술)

## 🕐 1주차 (Day 0–7)

### 하체와 골반의 무게 중심이 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

힙업과 골반, 지방이식 수술은 엉덩이 자체뿐 아니라 허리–골반–허벅지로 이어지는 하체 전체의 균형 감각을 바꾸는 시술입니다. 이 시기에는 엉덩이와 허벅지, 허리 아래가 동시에 묵직하게 느껴질 수 있고 앉거나 일어날 때 강한 당김과 압박감이 동반될 수 있습니다. 지방이식 부위는 실제 결과보다 더 크게 부어 보이거나 단단하게 느껴지는 것이 정상이며 이는 지방이 자리를 잡기 전의 임시 상태입니다.

✔ 이 주차에 도움 되는 팁

- 가능한 한 엎드리거나 옆으로 눕는 자세 유지
- 장시간 앉아야 할 경우 쿠션 활용
- 짧게 자주 움직이며 혈액순환 유지
- 지방채취 부위와 이식 부위 모두 압박·자극 최소화

⚠ 권고사항

- 딱딱한 의자에 오래 앉기
- 엉덩이 부위를 직접 눌러 모양 확인
- 초반 볼륨만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 큰 붓기는 줄고 볼륨감과 당김이 함께 느껴지는 시기

2주차부터는 전반적인 부종이 서서히 가라앉으며 힙과 골반의 윤곽 방향이 조금씩 느껴지기 시작합니다. 지방이식 부위는 여전히 도톰하고 단단하게 느껴질 수 있으나 이는 생착 과정 중 나타나는 정상 반응입니다. 힙거상술이나 보형물을 병행한 경우 앉을 때의 이질감이 남아 있을 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 짧은 외출과 가벼운 이동 가능
- 앉을 때는 체중을 허벅지 쪽으로 분산
- 수분 섭취 늘려 순환 관리
- 오후 컨디션 기준으로 상태 판단

⚠ 권고사항

- 장시간 차량 이동
- 강한 스트레칭이나 하체 운동
- 좌우 볼륨을 하루 단위로 비교

## 🕒 3주차 (Day 15–21)

### 라인과 볼륨의 방향성이 눈에 띄기 시작하는 시기

3주차에는 옷을 입었을 때 힙 라인과 골반 실루엣이 이전과 다르다는 느낌을 받는 경우가 많습니다. 지방이식의 경우 일부 볼륨이 빠진 듯 느껴질 수 있으나 이는 생착이 정리되는 과정에서 흔히 나타나는 변화입니다. 보행과 일상 동작은 비교적 편해지지만 오래 앉아 있으면 피로감이 다시 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 힙 라인을 살려주는 옷으로 변화 확인
- 짧은 산책 위주의 활동 가능
- 사진은 동일한 각도와 의상으로 기록
- 충분한 단백질 섭취로 회복 지원

⚠ 권고사항

- 힙업 운동·스쿼트
- 힙 부위 마사지·경락
- 볼륨 감소에 과도하게 불안해하기

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정되지만 생착과 밀착은 계속 진행 중인 시기

4주차에는 일상생활과 외출 대부분이 가능해지고 힙 라인이 자연스럽게 보이기 시작합니다. 다만 지방이식은 생착률에 따라 3–6개월에 걸쳐 볼륨이 최종적으로 안정되므로 지금의 모습은 완성이라기보다 중간 단계에 가깝습니다.

✔ 이 주차에 도움 되는 팁

- 일상 복귀 가능하되 하체 피로 시 즉시 휴식
- 의료진 허용 시 가벼운 스트레칭부터 시작
- 장기 볼륨 유지 계획 세우기
- 체중 변동 관리

⚠ 권고사항

- 급격한 다이어트
- 고강도 하체 운동 성급히 시작
- 1개월 차 볼륨을 최종 결과로 규정

### 의료진 공통 안내

힙업·골반·지방이식은 시간이 지날수록 자연스러운 곡선으로 완성되는 시술입니다. 현재의 회복 흐름을 유지한다면 보다 안정적이고 균형 잡힌 하체 라인으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "힙업",
            "골반",
            "지방이식",
            "힙지방이식",
            "골반지방이식",
            "힙업거상",
            "엉덩이"
        ]
    },
    {
        id: "fat-dissolving-body-injection",
        procedureName: "지방분해·바디 주사",
        title: "지방분해·바디 주사에 대한 회복 가이드🍀",
        description: "지방분해주사, 윤곽주사, 바디보톡스 등 지방층과 근육층이 자극되는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 지방분해·바디 주사

권장 회복 기간 : 1–2주

(해당 시술: 지방분해주사, 윤곽주사, PPC주사, HPL주사, 카복시주사, 메조테라피, 바디보톡스, 종아리보톡스, 승모근보톡스, 허벅지보톡스, 팔뚝보톡스)

## 🕐 1주차 (Day 0–7)

### 지방층과 근육층이 자극되었다는 사실을 몸이 인지하는 시기

지방분해·바디 주사는 절개가 없더라도 지방층과 근육층에 직접적인 자극을 주는 시술입니다. 이 시기에는 주사 부위 중심으로 붓기, 열감, 압통, 멍이 동시에 나타날 수 있고 만졌을 때 단단하거나 울퉁불퉁하게 느껴질 수 있습니다. 이는 약물이 지방과 조직에 퍼지며 작용하는 정상적인 반응이며 실제 결과보다 부피가 더 커 보이는 착시가 흔합니다. 지금의 라인은 결과가 아니라 반응 단계의 모습에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 주사 부위를 문지르지 말고 자연스럽게 두기
- 수분 섭취를 늘려 대사와 순환 지원
- 짧은 산책으로 림프 순환 돕기
- 처방된 연고나 진통제만 사용

⚠ 권고사항

- 주사 부위 마사지·경락
- 사우나·찜질방·고온 환경
- 초반 붓기만 보고 효과 판단

## 🕑 2주차 (Day 8–14)

### 붓기가 빠지며 라인의 변화가 느껴지기 시작하는 시기

2주차에는 주사 부위의 붓기와 압통이 점차 줄어들고 옷 핏이나 만졌을 때의 촉감에서 변화가 느껴지기 시작합니다. 지방분해주사와 메조테라피는 부위별로 반응 속도가 다를 수 있고 보톡스 계열은 근육 긴장이 서서히 완화되는 느낌이 나타납니다. 다만 효과는 한 번에 완성되기보다 누적되며 드러나는 경우가 많습니다.

✔ 이 주차에 도움 되는 팁

- 체중보다 옷 핏 변화로 효과 확인
- 가벼운 스트레칭과 유산소 운동 가능
- 수분·단백질 섭취 유지
- 2–3주 간격 관리 계획 정리

⚠ 권고사항

- 하루 단위로 사이즈 비교
- 즉각적인 체형 변화 기대
- 다른 시술과 무리하게 병행

### 의료진 공통 안내

지방분해·바디 주사는 절개 수술과 달리 누적 효과로 체형이 정리되는 시술입니다. 현재의 변화가 미미해 보여도 회복 흐름 안에 있다면 시간이 지나며 점진적인 라인 개선으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "지방분해",
            "바디주사",
            "윤곽주사",
            "바디보톡스",
            "종아리보톡스",
            "승모근보톡스",
            "메조테라피"
        ]
    },
    {
        id: "filler-botox-contour-injection",
        procedureName: "필러·보톡스·윤곽주사",
        title: "필러·보톡스·윤곽주사에 대한 회복 가이드🍀",
        description: "이마필러, 미간필러, 사각턱보톡스, 윤곽주사 등 주입된 물질과 근육 반응이 동시에 나타나는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 필러·보톡스·윤곽주사

권장 회복 기간 : 1–2주

(해당 시술: 이마필러, 미간필러, 관자필러, 앞볼필러, 뒤볼필러, 팔자필러, 입술필러, 턱끝필러, 코필러, 애교필러, 사각턱보톡스, 턱보톡스, 침샘보톡스, 종아리보톡스, 승모근보톡스, 윤곽주사, 이중턱윤곽주사)

## 🕐 1주차 (Day 0–7)

### 주입된 물질과 근육 반응이 동시에 나타나는 시기

필러·보톡스·윤곽주사는 절개 없이 진행되지만 주입 직후에는 조직 내에 약물과 볼륨이 공존하는 상태가 됩니다. 이 시기에는 붓기, 압통, 미세한 멍, 이물감이 느껴질 수 있고 필러 부위는 실제보다 더 도톰하거나 단단하게 만져질 수 있습니다. 보톡스 계열은 즉각적인 변화보다 근육 긴장이 서서히 완화되기 전 단계이기 때문에 초반에는 효과가 불분명하게 느껴질 수 있습니다. 지금의 모습은 결과가 아니라 약물이 자리 잡기 전의 반응 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 주입 부위를 만지거나 눌러 모양 확인하지 않기
- 수분 섭취를 늘려 조직 순환 돕기
- 세안·메이크업은 가볍게 진행
- 멍이 생긴 부위는 냉찜질을 짧게 적용

⚠ 권고사항

- 필러 부위 마사지·경락
- 사우나·찜질방·격한 운동
- 시술 직후 사진만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 볼륨과 라인이 얼굴·체형에 자연스럽게 섞이기 시작하는 시기

2주차에는 필러의 볼륨이 퍼지며 얼굴 윤곽에 자연스럽게 녹아들고 윤곽주사는 붓기 감소와 함께 라인의 방향성이 느껴지기 시작합니다. 보톡스 계열은 근육 사용이 줄어들며 얼굴이나 바디 라인이 한층 부드러워지는 변화를 체감하는 경우가 많습니다. 다만 부위별로 반응 속도는 다를 수 있어 변화 시점에 차이가 날 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 자연광에서 정면·45도 각도로 변화 기록
- 체형·윤곽은 옷 핏 위주로 확인
- 다음 관리·리터치 여부는 최소 3–4주 이후 판단
- 충분한 수면과 수분 섭취 유지

⚠ 권고사항

- 하루 단위로 미세한 좌우 차이 비교
- 즉각적인 완성도 기대
- 다른 주입 시술을 겹쳐 진행

### 의료진 공통 안내

필러·보톡스·윤곽주사는 서서히 자리 잡으며 인상과 라인을 완성하는 시술입니다. 주차에 맞는 관리만 유지한다면 현재의 변화는 보다 자연스럽고 안정적인 결과로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "필러",
            "보톡스",
            "윤곽주사",
            "이마필러",
            "팔자필러",
            "입술필러",
            "사각턱보톡스",
            "이중턱"
        ]
    },
    {
        id: "skin-injection-skinbooster",
        procedureName: "피부 주사·스킨부스터",
        title: "피부 주사·스킨부스터에 대한 회복 가이드🍀",
        description: "리쥬란힐러, 쥬베룩, 샤넬주사, 물광주사 등 피부층이 직접적으로 자극되고 재생 신호가 시작되는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 피부 주사·스킨부스터

권장 회복 기간 : 3–7일

(해당 시술: 리쥬란힐러, 리쥬란아이, 리쥬란HB, 쥬베룩, 쥬베룩볼륨, 샤넬주사, 물광주사, 엑소좀주사, 스킨보톡스, PN주사, PDRN주사)

## 🕐 1주차 (Day 0–7)

### 피부층이 직접적으로 자극되고 재생 신호가 시작되는 시기

피부 주사와 스킨부스터는 피부 진피층에 직접 약물을 주입해 재생을 유도하는 시술입니다. 이 시기에는 주사 자국, 붉은기, 미세한 멍, 울퉁불퉁함이 동시에 나타날 수 있고 피부결이 일시적으로 거칠어 보이거나 화장이 잘 먹지 않는 느낌을 받을 수 있습니다. 이는 피부가 손상된 것이 아니라 재생을 시작하기 위한 정상적인 반응입니다. 지금의 피부 상태는 결과가 아니라 회복을 준비하는 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 시술 당일은 세안·메이크업 최소화
- 보습제를 충분히 발라 수분 유지
- 외출 시 자외선 차단 철저
- 미스트·재생크림 위주로 관리

⚠ 권고사항

- 각질 제거·필링 제품 사용
- 사우나·찜질방·격한 운동
- 피부결만 보고 효과 판단

## 🕑 2주차 (Day 8–14)

### 피부결과 광이 서서히 살아나기 시작하는 시기

2주차에는 붉은기와 주사 자국이 대부분 사라지고 피부결이 정돈되는 느낌을 받기 시작합니다. 리쥬란힐러나 쥬베룩 계열은 피부 속에서 재생 반응이 진행되며 피부 밀도와 탄력이 서서히 느껴질 수 있습니다. 다만 드라마틱한 변화보다는 전체적인 컨디션 개선이 중심이 됩니다.

✔ 이 주차에 도움 되는 팁

- 가벼운 메이크업부터 단계적 복귀
- 수분 섭취와 수면 루틴 유지
- 동일한 조명에서 피부 상태 기록
- 다음 시술 간격은 최소 3–4주 유지

⚠ 권고사항

- 즉각적인 광·탄력 효과 기대
- 여러 스킨부스터를 단기간에 병행
- 피부 상태를 하루 단위로 과도하게 비교

### 의료진 공통 안내

피부 주사·스킨부스터는 누적 관리로 피부 컨디션을 끌어올리는 시술입니다. 현재의 변화는 정상적인 재생 과정에 해당하며 시간이 지날수록 보다 안정적이고 건강한 피부 상태로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "리쥬란",
            "쥬베룩",
            "샤넬주사",
            "물광주사",
            "스킨부스터",
            "PN주사",
            "PDRN",
            "스킨보톡스"
        ]
    },
    {
        id: "skin-laser-toning-texture",
        procedureName: "피부 레이저·토닝·결 개선",
        title: "피부 레이저·토닝·결 개선에 대한 회복 가이드🍀",
        description: "레이저토닝, 듀얼토닝, 피코토닝, 루비레이저 등 피부 표면과 색소층이 동시에 자극을 인지하는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 피부 레이저·토닝·결 개선

권장 회복 기간 : 3–7일

(해당 시술: 레이저토닝, 듀얼토닝, 레블라이트토닝, 피코토닝, 루비레이저, 루메카레이저, 브이빔퍼펙타, 시너지MPX, IPL레이저, 골드PTT, 레이저페이셜, 시카레이저, LDM, 뉴스무스빔)

## 🕐 1주차 (Day 0–7)

### 피부 표면과 색소층이 동시에 자극을 인지하는 시기

레이저·토닝·결 개선 시술은 표피와 진피, 색소층에 열·광 자극을 주어 피부 반응을 유도합니다. 이 시기에는 붉은기, 화끈거림, 건조감, 미세한 각질이 나타날 수 있고 피부톤이 일시적으로 더 얼룩져 보이거나 어두워 보이는 착시가 생길 수 있습니다. 이는 색소가 올라왔다가 정리되는 정상적인 과정으로 지금의 피부 상태는 결과가 아니라 반응 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 보습제를 평소보다 넉넉히 사용
- 외출 시 자외선 차단제 수시 덧바르기
- 세안은 미온수로 짧게 진행
- 시술 후 48시간은 열 자극 최소화

⚠ 권고사항

- 각질 제거·필링 제품 사용
- 사우나·찜질방·격한 운동
- 붉은기만 보고 시술 실패 판단

## 🕑 2주차 (Day 8–14)

### 피부톤과 결이 서서히 정돈되어 보이기 시작하는 시기

2주차에는 붉은기와 열감이 대부분 사라지고 피부톤이 균일해 보이기 시작합니다. 토닝 계열은 색소가 정리되는 방향성이 느껴지고 결 개선 레이저는 피부가 매끈해진 느낌을 주는 경우가 많습니다. 다만 잡티나 기미는 한 번에 사라지기보다 반복 시술을 통해 점진적으로 옅어집니다.

✔ 이 주차에 도움 되는 팁

- 자연광에서 피부톤 변화 기록
- 수분 섭취와 충분한 수면 유지
- 동일 레이저 기준으로 시술 간격 관리
- 피부 컨디션 좋은 날 기준으로 상태 판단

⚠ 권고사항

- 하루 단위로 잡티 색 비교
- 여러 레이저를 짧은 간격으로 병행
- 즉각적인 미백 효과 기대

### 의료진 공통 안내

피부 레이저·토닝·결 개선 시술은 누적 관리로 피부톤과 결을 안정적으로 끌어올리는 시술입니다. 현재의 반응은 정상적인 회복 흐름에 있으며 시간이 지날수록 보다 균일하고 깨끗한 피부 상태로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "레이저토닝",
            "듀얼토닝",
            "피코토닝",
            "루비레이저",
            "IPL",
            "레이저페이셜",
            "결개선"
        ]
    },
    {
        id: "acne-pore-redness",
        procedureName: "여드름·모공·홍조 관리",
        title: "여드름·모공·홍조 관리에 대한 회복 가이드🍀",
        description: "여드름압출, 아그네스, PDT레이저, 모공레이저 등 염증 반응과 혈관 반응이 동시에 조절되는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 여드름·모공·홍조 관리

권장 회복 기간 : 3–7일

(해당 시술: 여드름압출, 아그네스, 더마아크네, PDT레이저, PTT레이저, 브이빔퍼펙타, 엑셀V레이저, 시너지MPX, 모공레이저, 프락셀레이저, 피지조절레이저, 홍조레이저)

## 🕐 1주차 (Day 0–7)

### 염증 반응과 혈관 반응이 동시에 조절되는 시기

여드름·모공·홍조 관리는 피부 염증, 피지 분비, 혈관 반응을 동시에 조절하는 시술군입니다. 이 시기에는 붉은기, 열감, 미세한 딱지, 압통이 나타날 수 있고 여드름압출이나 아그네스 후에는 기존 트러블이 더 도드라져 보이는 현상이 생길 수 있습니다. 이는 악화가 아니라 염증이 표면으로 정리되는 정상적인 반응입니다. 지금의 피부는 결과가 아니라 정리 과정에 있는 상태입니다.

✔ 이 주차에 도움 되는 팁

- 손으로 트러블 부위 만지지 않기
- 저자극 세안과 보습 위주 관리
- 냉찜질은 필요 시 짧게만 적용
- 외출 시 자외선 차단 철저

⚠ 권고사항

- 여드름 부위 짜기·뜯기
- 각질 제거·스크럽 사용
- 붉은기만 보고 시술 실패 판단

## 🕑 2주차 (Day 8–14)

### 염증은 가라앉고 피부 표면이 정돈되기 시작하는 시기

2주차에는 큰 붉은기와 열감이 줄어들며 여드름은 마무리 단계로 접어들고 모공과 피부결이 서서히 정돈되는 느낌을 받을 수 있습니다. 홍조 레이저 계열은 얼굴 색이 한층 균일해 보이는 방향성이 느껴지기 시작합니다. 다만 새로운 트러블이 간헐적으로 올라오는 경우도 있으나 이는 회복 흐름 안에 있는 반응입니다.

✔ 이 주차에 도움 되는 팁

- 피부 컨디션 좋은 날을 기준으로 변화 확인
- 수분 섭취와 수면 루틴 유지
- 동일 조명에서 피부 상태 기록
- 필요 시 다음 관리 시점 정리

⚠ 권고사항

- 하루 단위로 트러블 개수 비교
- 여러 여드름·홍조 시술을 단기간에 병행
- 즉각적인 모공 축소 기대

### 의료진 공통 안내

여드름·모공·홍조 관리는 한 번의 시술보다 피부 리듬을 안정시키는 과정이 중요합니다. 현재의 반응이 유지된다면 시간이 지날수록 보다 깨끗하고 균일한 피부 상태로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "여드름",
            "모공",
            "홍조",
            "아그네스",
            "PDT",
            "모공레이저",
            "프락셀",
            "피지조절"
        ]
    },
    {
        id: "peeling-exfoliation-skin-care",
        procedureName: "필링·각질·피부관리",
        title: "필링·각질·피부관리에 대한 회복 가이드🍀",
        description: "아쿠아필링, 밀크필, 라라필, CO2레이저필링 등 피부 표면 장벽이 정리되고 재정렬되는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 필링·각질·피부관리

권장 회복 기간 : 1–3일

(해당 시술: 아쿠아필링, 밀크필, 라라필, 블랙필, 산소필, PHA필링, 쎄라필, 알라딘필링, CO2레이저필링, 모공스케일링, 각질관리, 진정관리, 수분관리)

## 🕐 1주차 (Day 0–7)

### 피부 표면 장벽이 정리되고 재정렬되는 시기

필링·각질·피부관리는 표피의 오래된 각질을 정리하고 피부 장벽 리듬을 재설정하는 시술입니다. 이 시기에는 따끔거림, 건조감, 미세한 각질 들뜸이 나타날 수 있고 피부톤이 일시적으로 밝아졌다가 다시 칙칙해 보이는 착시가 생길 수 있습니다. 이는 각질 탈락과 수분 재균형 과정에서 흔히 나타나는 반응입니다. 지금의 피부는 결과가 아니라 표면이 재정렬되는 과정에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 세안은 미온수로 짧게 진행
- 보습제를 평소보다 넉넉히 사용
- 외출 시 자외선 차단 필수
- 각질이 보여도 자연 탈락 유도

⚠ 권고사항

- 손으로 각질 뜯기
- 필링 직후 스크럽·각질 제거제 사용
- 건조함만 보고 관리 실패 판단

## 🕑 2주차 (Day 8–14)

### 피부결과 톤이 정돈되어 보이기 시작하는 시기

2주차에는 각질 탈락이 마무리되며 피부결이 매끈해지고 화장이 고르게 올라가는 느낌을 받는 경우가 많습니다. 아쿠아필링·라라필·밀크필 계열은 피부가 촉촉하고 맑아 보이는 방향성이 느껴질 수 있습니다. 다만 관리 효과는 일회성보다는 주기적 관리로 유지됩니다.

✔ 이 주차에 도움 되는 팁

- 동일한 조명에서 피부결 변화 확인
- 수분 섭취와 수면 루틴 유지
- 필요 시 다음 필링 간격 메모
- 자극 없는 기초 제품 위주 유지

⚠ 권고사항

- 즉각적인 잡티·모공 개선 기대
- 다른 레이저·주사 시술과 무리한 병행
- 피부 상태를 하루 단위로 과도하게 비교

### 의료진 공통 안내

필링·각질·피부관리는 피부 컨디션을 리셋하고 다음 시술의 효과를 높이는 기반 관리입니다. 현재의 정돈 흐름을 유지한다면 시간이 지날수록 더 안정적이고 건강한 피부 상태로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "필링",
            "각질",
            "아쿠아필링",
            "밀크필",
            "라라필",
            "CO2필링",
            "모공스케일링",
            "피부관리"
        ]
    }
];
function findRecoveryGuideByKeyword(keyword) {
    const normalizedKeyword = keyword.toLowerCase().trim();
    for (const post of recoveryGuidePosts){
        // 시술명 직접 매칭
        if (post.procedureName.toLowerCase().includes(normalizedKeyword)) {
            return post;
        }
        // 키워드 매칭
        if (post.keywords.some((k)=>k.toLowerCase().includes(normalizedKeyword)) || post.keywords.some((k)=>normalizedKeyword.includes(k.toLowerCase()))) {
            return post;
        }
    }
    return null;
}
function findRecoveryGuideById(id) {
    return recoveryGuidePosts.find((post)=>post.id === id) || null;
}
function getAllRecoveryGuides() {
    return recoveryGuidePosts;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/RecoveryGuidePostDetailPage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RecoveryGuidePostDetailPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuidePosts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/content/recoveryGuidePosts.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
// 읽기 좋은 마크다운 렌더링 함수
function renderMarkdown(content) {
    const lines = content.split("\n");
    const elements = [];
    let currentParagraph = [];
    let listItems = [];
    let inList = false;
    let currentCardType = null;
    let cardContent = [];
    let currentWeekCard = null; // 주차 섹션 카드 내용
    let weekCardTitle = null; // 주차 섹션 제목
    let cardCounter = 0; // 고유한 카드 key를 위한 카운터
    // 텍스트를 JSX 요소로 변환 (볼드, 이탤릭 등 처리)
    const parseInline = (text, lineIdx)=>{
        const parts = [];
        let lastIndex = 0;
        // 볼드 텍스트 처리 (**text**)
        const boldRegex = /\*\*(.+?)\*\*/g;
        let match;
        const matches = [];
        while((match = boldRegex.exec(text)) !== null){
            matches.push({
                start: match.index,
                end: match.index + match[0].length,
                text: match[1]
            });
        }
        matches.forEach((m, idx)=>{
            if (m.start > lastIndex) {
                parts.push(text.substring(lastIndex, m.start));
            }
            parts.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                className: "font-bold text-gray-900",
                children: m.text
            }, `bold-${lineIdx}-${idx}`, false, {
                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                lineNumber: 47,
                columnNumber: 9
            }, this));
            lastIndex = m.end;
        });
        if (lastIndex < text.length) {
            parts.push(text.substring(lastIndex));
        }
        return parts.length > 0 ? parts : [
            text
        ];
    };
    const flushParagraph = ()=>{
        if (currentParagraph.length > 0) {
            const paragraphElement = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-700 leading-relaxed mb-2 last:mb-0",
                children: currentParagraph.map((item, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                        children: item
                    }, idx, false, {
                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                        lineNumber: 76,
                        columnNumber: 13
                    }, this))
            }, `p-${elements.length + (cardContent.length || 0) + (currentWeekCard?.length || 0)}`, false, {
                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                lineNumber: 67,
                columnNumber: 9
            }, this);
            if (currentCardType) {
                cardContent.push(paragraphElement);
            } else if (currentWeekCard) {
                currentWeekCard.push(paragraphElement);
            } else {
                elements.push(paragraphElement);
            }
            currentParagraph = [];
        }
    };
    const flushList = ()=>{
        if (listItems.length > 0) {
            const listElement = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "space-y-1.5 pl-6 mb-4 last:mb-0",
                children: listItems.map((item, idx)=>{
                    const cleanItem = item.replace(/^[-*]\s+/, "").replace(/^\d+\.\s+/, "");
                    const parsed = parseInline(cleanItem, idx);
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "text-xs text-gray-700 leading-relaxed list-disc",
                        children: parsed.map((p, pIdx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                                children: p
                            }, pIdx, false, {
                                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                lineNumber: 115,
                                columnNumber: 19
                            }, this))
                    }, idx, false, {
                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                        lineNumber: 110,
                        columnNumber: 15
                    }, this);
                })
            }, `ul-${elements.length + (cardContent.length || 0) + (currentWeekCard?.length || 0)}`, false, {
                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                lineNumber: 96,
                columnNumber: 9
            }, this);
            if (currentCardType) {
                cardContent.push(listElement);
            } else if (currentWeekCard) {
                currentWeekCard.push(listElement);
            } else {
                elements.push(listElement);
            }
            listItems = [];
            inList = false;
        }
    };
    let weekCardCounter = 0; // 고유한 주차 카드 key를 위한 카운터
    const flushWeekCard = ()=>{
        if (currentWeekCard && weekCardTitle) {
            elements.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border border-gray-200 rounded-xl p-5 bg-white mb-6 mt-10 first:mt-0 shadow-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-lg font-bold text-gray-900 mb-2",
                        children: weekCardTitle
                    }, void 0, false, {
                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                        lineNumber: 145,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: currentWeekCard
                    }, void 0, false, {
                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                        lineNumber: 148,
                        columnNumber: 11
                    }, this)
                ]
            }, `week-card-${weekCardCounter++}`, true, {
                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                lineNumber: 141,
                columnNumber: 9
            }, this));
            currentWeekCard = null;
            weekCardTitle = null;
        }
    };
    const flushCard = ()=>{
        if (currentCardType && cardContent.length > 0) {
            const uniqueKey = `card-${cardCounter++}`;
            if (currentCardType === "info") {
                // 의료진 공통 안내 카드
                elements.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-blue-50 border border-blue-200 rounded-xl p-5 mb-6 mt-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-base font-bold text-blue-800 mb-3 flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "👨‍⚕️👩‍⚕️"
                                }, void 0, false, {
                                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                    lineNumber: 167,
                                    columnNumber: 15
                                }, this),
                                "의료진 공통 안내"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                            lineNumber: 166,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: cardContent
                        }, void 0, false, {
                            fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                            lineNumber: 170,
                            columnNumber: 13
                        }, this)
                    ]
                }, uniqueKey, true, {
                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                    lineNumber: 162,
                    columnNumber: 11
                }, this));
            } else {
                const isTip = currentCardType === "tip";
                const cardElement = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 mb-2",
                            children: [
                                isTip ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCheck"], {
                                    className: "text-primary-main text-sm"
                                }, void 0, false, {
                                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                    lineNumber: 179,
                                    columnNumber: 17
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiAlertCircle"], {
                                    className: "text-orange-500 text-sm"
                                }, void 0, false, {
                                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                    lineNumber: 181,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                    className: "text-sm font-semibold text-gray-800",
                                    children: isTip ? "이 주차에 도움 되는 팁" : "권고사항"
                                }, void 0, false, {
                                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                    lineNumber: 183,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                            lineNumber: 177,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "pl-6",
                            children: cardContent
                        }, void 0, false, {
                            fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                            lineNumber: 187,
                            columnNumber: 13
                        }, this)
                    ]
                }, uniqueKey, true, {
                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                    lineNumber: 176,
                    columnNumber: 11
                }, this);
                if (currentWeekCard) {
                    currentWeekCard.push(cardElement);
                } else {
                    elements.push(cardElement);
                }
            }
            cardContent = [];
            currentCardType = null;
        }
    };
    lines.forEach((line, idx)=>{
        const trimmed = line.trim();
        // 카드 시작 감지
        if (trimmed.includes("✔ 이 주차에 도움 되는 팁")) {
            flushParagraph();
            flushList();
            flushCard();
            currentCardType = "tip";
            return;
        }
        if (trimmed.includes("⚠ 권고사항")) {
            flushParagraph();
            flushList();
            flushCard();
            currentCardType = "warning";
            return;
        }
        // 헤더 처리
        if (trimmed.startsWith("##")) {
            flushParagraph();
            flushList();
            flushCard();
            const level = trimmed.match(/^#+/)?.[0].length || 2;
            const text = trimmed.replace(/^#+\s+/, "");
            if (level === 2) {
                // 주차 섹션인지 확인 (🕐, 🕑, 🕒, 🕓 포함)
                const isWeekSection = /[🕐🕑🕒🕓]/.test(text);
                if (isWeekSection) {
                    // 주차 섹션 시작 - 이전 주차 카드 닫기
                    flushWeekCard();
                    // 새 주차 카드 시작
                    currentWeekCard = [];
                    weekCardTitle = text;
                } else {
                    // 시술명 등 일반 h2는 그냥 표시
                    flushWeekCard();
                    elements.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-bold text-gray-900 mt-10 mb-5 first:mt-0 pb-3 border-b-2 border-gray-200",
                        children: text
                    }, `h2-${idx}`, false, {
                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                        lineNumber: 244,
                        columnNumber: 13
                    }, this));
                }
            } else if (level === 3) {
                const h3Element = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-sm font-semibold text-gray-800 mb-3",
                    children: text
                }, `h3-${idx}`, false, {
                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                    lineNumber: 254,
                    columnNumber: 11
                }, this);
                if (currentWeekCard) {
                    currentWeekCard.push(h3Element);
                } else {
                    elements.push(h3Element);
                }
            } else if (level === 4) {
                // 의료진 공통 안내는 카드로 처리
                if (text.includes("의료진 공통 안내")) {
                    flushParagraph();
                    flushList();
                    flushCard();
                    currentCardType = "info";
                // h4는 카드 내부에 표시하지 않고 제목만 사용
                } else {
                    elements.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        className: "text-lg font-semibold text-gray-900 mt-6 mb-3",
                        children: text
                    }, `h4-${idx}`, false, {
                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                        lineNumber: 276,
                        columnNumber: 13
                    }, this));
                }
            }
            return;
        }
        // 리스트 항목 처리
        if (trimmed.match(/^[-*]\s+/) || trimmed.match(/^\d+\.\s+/)) {
            flushParagraph();
            inList = true;
            listItems.push(trimmed);
            return;
        }
        // 리스트가 끝나면 flush
        if (inList && trimmed === "") {
            flushList();
            return;
        }
        // 빈 줄 처리
        if (trimmed === "") {
            flushParagraph();
            flushList();
            return;
        }
        // 일반 텍스트 처리
        if (inList) {
            flushList();
        }
        const parsed = parseInline(trimmed, idx);
        currentParagraph.push(...parsed);
    });
    flushParagraph();
    flushList();
    flushCard();
    flushWeekCard();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: elements
    }, void 0, false, {
        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
        lineNumber: 323,
        columnNumber: 10
    }, this);
}
function RecoveryGuidePostDetailPage({ postId }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const post = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuidePosts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findRecoveryGuideById"])(postId);
    if (!post) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-white",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sticky top-0 z-20 bg-white border-b border-gray-100",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3 px-4 py-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>router.back(),
                                className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronLeft"], {
                                    className: "text-gray-700 text-xl"
                                }, void 0, false, {
                                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                    lineNumber: 345,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                lineNumber: 341,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-lg font-bold text-gray-900",
                                children: "회복 가이드"
                            }, void 0, false, {
                                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                lineNumber: 347,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                        lineNumber: 340,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                    lineNumber: 339,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-4 py-8 text-center text-gray-500",
                    children: "회복 가이드를 찾을 수 없습니다."
                }, void 0, false, {
                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                    lineNumber: 350,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
            lineNumber: 338,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sticky top-0 z-20 bg-white border-b border-gray-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3 px-4 py-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>router.back(),
                            className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronLeft"], {
                                className: "text-gray-700 text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                lineNumber: 366,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                            lineNumber: 362,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-lg font-bold text-gray-900 line-clamp-1",
                            children: post.title
                        }, void 0, false, {
                            fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                            lineNumber: 368,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                    lineNumber: 361,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                lineNumber: 360,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 py-6 pb-20",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs bg-primary-light/20 text-primary-main px-3 py-1.5 rounded-full font-medium",
                                        children: post.category
                                    }, void 0, false, {
                                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                        lineNumber: 379,
                                        columnNumber: 13
                                    }, this),
                                    post.readTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-sm text-gray-600 font-medium",
                                        children: [
                                            post.readTime,
                                            " 읽기"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                        lineNumber: 383,
                                        columnNumber: 15
                                    }, this),
                                    post.views !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-sm text-gray-600 font-medium",
                                        children: [
                                            "조회 ",
                                            post.views.toLocaleString()
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                        lineNumber: 388,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                lineNumber: 378,
                                columnNumber: 11
                            }, this),
                            post.content.includes("(해당 시술:") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-gray-50 rounded-lg p-3 mb-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-600 leading-relaxed",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-800",
                                            children: "해당 시술:"
                                        }, void 0, false, {
                                            fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                            lineNumber: 396,
                                            columnNumber: 17
                                        }, this),
                                        " ",
                                        post.content.match(/\(해당 시술:.*?\)/)?.[0].replace(/^\(해당 시술:\s*/, "").replace(/\)$/, "")
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                    lineNumber: 395,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                lineNumber: 394,
                                columnNumber: 13
                            }, this),
                            post.content.includes("권장 회복 기간") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-sm text-gray-600 font-medium",
                                    children: post.content.match(/권장 회복 기간\s*:\s*[^\n]+/)?.[0].replace(/권장 회복 기간\s*:\s*/, "")
                                }, void 0, false, {
                                    fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                    lineNumber: 406,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                                lineNumber: 405,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                        lineNumber: 377,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "prose prose-gray max-w-none",
                        children: renderMarkdown(post.content)
                    }, void 0, false, {
                        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                        lineNumber: 416,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
                lineNumber: 375,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/RecoveryGuidePostDetailPage.tsx",
        lineNumber: 358,
        columnNumber: 5
    }, this);
}
_s(RecoveryGuidePostDetailPage, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = RecoveryGuidePostDetailPage;
var _c;
__turbopack_context__.k.register(_c, "RecoveryGuidePostDetailPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/community/recovery-guide/[groupKey]/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RecoveryGuideDetailRoute
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Header.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/BottomNavigation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$RecoveryGuideDetailPage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/RecoveryGuideDetailPage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$RecoveryGuidePostDetailPage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/RecoveryGuidePostDetailPage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuidePosts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/content/recoveryGuidePosts.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function RecoveryGuideDetailRoute() {
    _s();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const param = params.groupKey;
    const validGroupKeys = [
        "jaw",
        "breast",
        "body",
        "upperFace",
        "nose",
        "eyeSurgery",
        "eyeVolume",
        "faceFat",
        "lifting",
        "procedures"
    ];
    // 먼저 19개 회복 가이드 글(post)인지 확인
    const recoveryPost = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuidePosts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findRecoveryGuideById"])(param);
    if (recoveryPost) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-white max-w-md mx-auto w-full",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$RecoveryGuidePostDetailPage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    postId: param
                }, void 0, false, {
                    fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
                    lineNumber: 35,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
            lineNumber: 32,
            columnNumber: 7
        }, this);
    }
    // 그 다음 10개 그룹(groupKey)인지 확인
    const groupKey = param;
    if (groupKey && validGroupKeys.includes(groupKey)) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-white max-w-md mx-auto w-full",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$RecoveryGuideDetailPage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    groupKey: groupKey
                }, void 0, false, {
                    fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
                    lineNumber: 46,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
                    lineNumber: 47,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
            lineNumber: 44,
            columnNumber: 7
        }, this);
    }
    // 둘 다 아니면 에러
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white max-w-md mx-auto w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 py-8 text-center text-gray-500",
                children: "잘못된 회복 가이드입니다."
            }, void 0, false, {
                fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
                lineNumber: 56,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/community/recovery-guide/[groupKey]/page.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
_s(RecoveryGuideDetailRoute, "+jVsTcECDRo3yq2d7EQxlN9Ixog=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = RecoveryGuideDetailRoute;
var _c;
__turbopack_context__.k.register(_c, "RecoveryGuideDetailRoute");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_3a08ea35._.js.map