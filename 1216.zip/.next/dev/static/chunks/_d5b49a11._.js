(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/RankingBanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RankingBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const rankings = [
    {
        rank: 1,
        name: "리쥬란힐러",
        status: "best"
    },
    {
        rank: 2,
        name: "써마지",
        status: "best"
    },
    {
        rank: 3,
        name: "쥬베룩",
        status: "best"
    },
    {
        rank: 4,
        name: "울쎄라",
        status: "up"
    },
    {
        rank: 5,
        name: "LDM",
        status: "up"
    },
    {
        rank: 6,
        name: "스킨부스터",
        status: "up"
    },
    {
        rank: 7,
        name: "올리지오",
        status: "down"
    },
    {
        rank: 8,
        name: "튠페이스",
        status: "up"
    },
    {
        rank: 9,
        name: "쎄라필",
        status: "up"
    },
    {
        rank: 10,
        name: "리프테라",
        status: "down"
    }
];
function RankingBanner() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isDropdownOpen, setIsDropdownOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const dropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RankingBanner.useEffect": ()=>{
            const interval = setInterval({
                "RankingBanner.useEffect.interval": ()=>{
                    setCurrentIndex({
                        "RankingBanner.useEffect.interval": (prev)=>(prev + 1) % rankings.length
                    }["RankingBanner.useEffect.interval"]);
                }
            }["RankingBanner.useEffect.interval"], 3000); // 3초마다 자동 넘어감
            return ({
                "RankingBanner.useEffect": ()=>clearInterval(interval)
            })["RankingBanner.useEffect"];
        }
    }["RankingBanner.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RankingBanner.useEffect": ()=>{
            const handleClickOutside = {
                "RankingBanner.useEffect.handleClickOutside": (event)=>{
                    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                        setIsDropdownOpen(false);
                    }
                }
            }["RankingBanner.useEffect.handleClickOutside"];
            if (isDropdownOpen) {
                document.addEventListener("mousedown", handleClickOutside);
            }
            return ({
                "RankingBanner.useEffect": ()=>{
                    document.removeEventListener("mousedown", handleClickOutside);
                }
            })["RankingBanner.useEffect"];
        }
    }["RankingBanner.useEffect"], [
        isDropdownOpen
    ]);
    const currentRanking = rankings[currentIndex];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white border-b border-gray-100 px-4 py-2.5 fixed top-0 left-1/2 transform -translate-x-1/2 w-full max-w-md z-50 cursor-pointer",
                onClick: ()=>setIsDropdownOpen(!isDropdownOpen),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 flex-1 min-w-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-0.5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-primary-main font-bold text-base",
                                            children: currentRanking.rank
                                        }, void 0, false, {
                                            fileName: "[project]/components/RankingBanner.tsx",
                                            lineNumber: 74,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoChevronUp"], {
                                            className: "text-primary-main text-sm"
                                        }, void 0, false, {
                                            fileName: "[project]/components/RankingBanner.tsx",
                                            lineNumber: 77,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/RankingBanner.tsx",
                                    lineNumber: 73,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gray-800 text-sm font-medium truncate",
                                    children: currentRanking.name
                                }, void 0, false, {
                                    fileName: "[project]/components/RankingBanner.tsx",
                                    lineNumber: 79,
                                    columnNumber: 13
                                }, this),
                                currentRanking.status === "best" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "bg-primary-light/20 text-primary-main px-2 py-0.5 rounded text-xs font-semibold whitespace-nowrap",
                                    children: "BEST"
                                }, void 0, false, {
                                    fileName: "[project]/components/RankingBanner.tsx",
                                    lineNumber: 83,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/RankingBanner.tsx",
                            lineNumber: 72,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1 ml-2 flex-shrink-0",
                            children: rankings.map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `h-1.5 rounded-full transition-all duration-300 ${index === currentIndex ? "bg-primary-main w-2" : "bg-gray-300 w-1.5"}`
                                }, index, false, {
                                    fileName: "[project]/components/RankingBanner.tsx",
                                    lineNumber: 92,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/RankingBanner.tsx",
                            lineNumber: 90,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/RankingBanner.tsx",
                    lineNumber: 70,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/RankingBanner.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this),
            isDropdownOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: dropdownRef,
                className: "fixed top-[41px] left-1/2 transform -translate-x-1/2 z-[60] bg-white max-w-md w-full shadow-lg flex flex-col",
                style: {
                    height: "420px"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white border-b border-gray-200 px-3 py-2 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-base font-bold text-gray-900",
                                children: t("banner.ranking.title")
                            }, void 0, false, {
                                fileName: "[project]/components/RankingBanner.tsx",
                                lineNumber: 113,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setIsDropdownOpen(false),
                                className: "p-1.5 hover:bg-gray-50 rounded-full transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                    className: "text-gray-700 text-lg"
                                }, void 0, false, {
                                    fileName: "[project]/components/RankingBanner.tsx",
                                    lineNumber: 120,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/RankingBanner.tsx",
                                lineNumber: 116,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/RankingBanner.tsx",
                        lineNumber: 112,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-3 py-2 space-y-1 overflow-y-auto flex-1",
                        children: rankings.slice(0, 10).map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 px-2 py-1.5 hover:bg-gray-50 rounded transition-colors cursor-pointer",
                                onClick: (e)=>{
                                    e.stopPropagation();
                                    // 탐색 페이지로 이동
                                    router.push(`/explore?section=procedure&search=${encodeURIComponent(item.name)}`);
                                    setIsDropdownOpen(false);
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-1 min-w-[45px]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `font-bold text-sm ${item.rank <= 3 ? "text-primary-main" : "text-gray-600"}`,
                                                children: item.rank
                                            }, void 0, false, {
                                                fileName: "[project]/components/RankingBanner.tsx",
                                                lineNumber: 140,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoChevronUp"], {
                                                className: "text-primary-main text-xs"
                                            }, void 0, false, {
                                                fileName: "[project]/components/RankingBanner.tsx",
                                                lineNumber: 147,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/RankingBanner.tsx",
                                        lineNumber: 139,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-gray-800 text-xs font-medium flex-1",
                                        children: item.name
                                    }, void 0, false, {
                                        fileName: "[project]/components/RankingBanner.tsx",
                                        lineNumber: 149,
                                        columnNumber: 17
                                    }, this),
                                    item.status === "best" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "bg-primary-light/20 text-primary-main px-1.5 py-0.5 rounded text-[10px] font-semibold",
                                        children: "BEST"
                                    }, void 0, false, {
                                        fileName: "[project]/components/RankingBanner.tsx",
                                        lineNumber: 153,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/components/RankingBanner.tsx",
                                lineNumber: 125,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/RankingBanner.tsx",
                        lineNumber: 123,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/RankingBanner.tsx",
                lineNumber: 107,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/RankingBanner.tsx",
        lineNumber: 65,
        columnNumber: 5
    }, this);
}
_s(RankingBanner, "DvIEZ3PtpapE72NC2CvDHptnNUs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = RankingBanner;
var _c;
__turbopack_context__.k.register(_c, "RankingBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/supabase.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$esm$2f$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs [app-client] (ecmascript)");
;
console.log("🔎 NEXT_PUBLIC_SUPABASE_URL =", ("TURBOPACK compile-time value", "https://jkvwtdjkylzxjzvgbwud.supabase.co"));
console.log("🔎 NEXT_PUBLIC_SUPABASE_ANON_KEY =", ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imprdnd0ZGpreWx6eGp6dmdid3VkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU0NDMwNzgsImV4cCI6MjA4MTAxOTA3OH0.XdyU1XtDFY2Vauj_ddQ1mKqAjxjnNJts5pdW_Ob1TDI")?.slice(0, 10));
// Supabase 클라이언트 생성
// 1순위: 환경 변수
// 2순위: 기존에 사용하던 하드코딩 값 (로컬/데모용 fallback)
const supabaseUrl = ("TURBOPACK compile-time value", "https://jkvwtdjkylzxjzvgbwud.supabase.co") || "https://jkvwtdjkylzxjzvgbwud.supabase.co";
const supabaseAnonKey = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imprdnd0ZGpreWx6eGp6dmdid3VkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU0NDMwNzgsImV4cCI6MjA4MTAxOTA3OH0.XdyU1XtDFY2Vauj_ddQ1mKqAjxjnNJts5pdW_Ob1TDI") || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imprdnd0ZGpreWx6eGp6dmdid3VkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU0NDMwNzgsImV4cCI6MjA4MTAxOTA3OH0.XdyU1XtDFY2Vauj_ddQ1mKqAjxjnNJts5pdW_Ob1TDI";
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$esm$2f$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])(supabaseUrl, supabaseAnonKey);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/api/beautripApi.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Beautrip API 관련 유틸리티 함수
__turbopack_context__.s([
    "CATEGORY_MAPPING",
    ()=>CATEGORY_MAPPING,
    "calculateRecommendationScore",
    ()=>calculateRecommendationScore,
    "extractHospitalInfo",
    ()=>extractHospitalInfo,
    "getCategoryRankings",
    ()=>getCategoryRankings,
    "getHospitalAutocomplete",
    ()=>getHospitalAutocomplete,
    "getKBeautyRankings",
    ()=>getKBeautyRankings,
    "getRecoveryInfoByCategoryMid",
    ()=>getRecoveryInfoByCategoryMid,
    "getScheduleBasedRecommendations",
    ()=>getScheduleBasedRecommendations,
    "getThumbnailUrl",
    ()=>getThumbnailUrl,
    "getTreatmentAutocomplete",
    ()=>getTreatmentAutocomplete,
    "getTreatmentRankings",
    ()=>getTreatmentRankings,
    "loadAllData",
    ()=>loadAllData,
    "loadCategoryTreatTimeRecovery",
    ()=>loadCategoryTreatTimeRecovery,
    "loadConcernPosts",
    ()=>loadConcernPosts,
    "loadHospitalMaster",
    ()=>loadHospitalMaster,
    "loadHospitalReviews",
    ()=>loadHospitalReviews,
    "loadHospitalTreatments",
    ()=>loadHospitalTreatments,
    "loadHospitalsPaginated",
    ()=>loadHospitalsPaginated,
    "loadKeywordMonthlyTrends",
    ()=>loadKeywordMonthlyTrends,
    "loadProcedureReviews",
    ()=>loadProcedureReviews,
    "loadRelatedTreatments",
    ()=>loadRelatedTreatments,
    "loadTreatmentById",
    ()=>loadTreatmentById,
    "loadTreatments",
    ()=>loadTreatments,
    "loadTreatmentsPaginated",
    ()=>loadTreatmentsPaginated,
    "parseProcedureTime",
    ()=>parseProcedureTime,
    "parseRecoveryPeriod",
    ()=>parseRecoveryPeriod,
    "saveConcernPost",
    ()=>saveConcernPost,
    "saveHospitalReview",
    ()=>saveHospitalReview,
    "saveProcedureReview",
    ()=>saveProcedureReview,
    "sortHospitalsByPlatform",
    ()=>sortHospitalsByPlatform,
    "sortTreatmentsByPlatform",
    ()=>sortTreatmentsByPlatform
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-client] (ecmascript)");
;
// Supabase 테이블 이름
const TABLE_NAMES = {
    TREATMENT_MASTER: "treatment_master",
    CATEGORY_TREATTIME_RECOVERY: "category_treattime_recovery",
    HOSPITAL_MASTER: "hospital_master",
    KEYWORD_MONTHLY_TRENDS: "keyword_monthly_trends"
};
// Supabase 클라이언트 안전 접근 헬퍼
// 환경변수가 없어서 supabase가 초기화되지 않은 경우
// 런타임 TypeError 대신 빈 결과를 반환하도록 각 함수에서 사용합니다.
function getSupabaseOrNull() {
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"]) {
        if ("TURBOPACK compile-time truthy", 1) {
            console.warn("[beautripApi] Supabase 클라이언트가 초기화되지 않았습니다. 환경변수를 확인하세요.");
        }
        return null;
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"];
}
// ---------------------------
// 캐시 및 유틸
// ---------------------------
// category_mid -> 회복정보 캐시 (중복 호출/로그 폭주 방지)
const recoveryInfoCache = new Map();
// 이미 매칭 로그를 찍은 category_mid 모음 (콘솔 스팸 방지)
const recoveryLogPrinted = new Set();
// 공통 데이터 정리 함수 (NaN을 null로 변환)
function cleanData(data) {
    return data.map((item)=>{
        const cleaned = {};
        for(const key in item){
            const value = item[key];
            cleaned[key] = value === "NaN" || typeof value === "number" && isNaN(value) ? null : value;
        }
        return cleaned;
    });
}
async function loadTreatments() {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        const allData = [];
        const pageSize = 1000; // Supabase 기본 limit
        let from = 0;
        let hasMore = true;
        console.log("🔄 전체 데이터 로드 시작...");
        // 페이지네이션으로 모든 데이터 가져오기
        while(hasMore){
            const { data, error } = await client.from(TABLE_NAMES.TREATMENT_MASTER).select("*").range(from, from + pageSize - 1);
            if (error) {
                throw new Error(`Supabase 오류: ${error.message}`);
            }
            if (!data) {
                throw new Error("데이터를 가져올 수 없습니다.");
            }
            if (!Array.isArray(data)) {
                throw new Error("데이터 형식이 올바르지 않습니다. 배열이 아닙니다.");
            }
            // 데이터 추가
            const cleanedData = cleanData(data);
            allData.push(...cleanedData);
            console.log(`📥 ${from + 1}~${from + data.length}개 로드 완료 (총 ${allData.length}개)`);
            // 더 가져올 데이터가 있는지 확인
            if (data.length < pageSize) {
                hasMore = false;
            } else {
                from += pageSize;
            }
        }
        console.log(`✅ 전체 데이터 로드 완료: ${allData.length}개`);
        // 플랫폼 우선순위로 정렬 (gangnamunni → yeoti → babitalk)
        const sortedData = sortTreatmentsByPlatform(allData);
        console.log(`🔄 플랫폼 우선순위 정렬 완료`);
        return sortedData;
    } catch (error) {
        console.error("시술 데이터 로드 실패:", error);
        throw error;
    }
}
// Fisher-Yates 셔플 알고리즘 (랜덤 정렬)
function shuffleArray(array) {
    const shuffled = [
        ...array
    ];
    for(let i = shuffled.length - 1; i > 0; i--){
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [
            shuffled[j],
            shuffled[i]
        ];
    }
    return shuffled;
}
async function loadTreatmentsPaginated(page = 1, pageSize = 50, filters) {
    try {
        const client = getSupabaseOrNull();
        if (!client) {
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        let query = client.from(TABLE_NAMES.TREATMENT_MASTER).select("*", {
            count: "exact"
        });
        // 필터 적용 (최소 2글자 이상일 때만 검색)
        if (filters?.searchTerm && filters.searchTerm.trim().length >= 2) {
            const term = filters.searchTerm.toLowerCase().trim();
            query = query.or(`treatment_name.ilike.%${term}%,hospital_name.ilike.%${term}%,treatment_hashtags.ilike.%${term}%`);
        } else if (filters?.searchTerm && filters.searchTerm.trim().length === 1) {
            // 1글자일 때는 검색하지 않음 (빈 결과 반환)
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        if (filters?.categoryLarge) {
            // 카테고리 매핑을 사용하여 여러 카테고리를 OR 조건으로 검색
            const mappedCategories = CATEGORY_MAPPING[filters.categoryLarge] || [
                filters.categoryLarge
            ];
            if (mappedCategories.length === 0) {
            // "전체"인 경우 필터링하지 않음
            // (빈 배열이면 모든 데이터 반환)
            } else if (mappedCategories.length === 1) {
                // 단일 카테고리인 경우 정확한 일치 또는 부분 일치 검색
                query = query.ilike("category_large", `%${mappedCategories[0]}%`);
            } else {
                // 여러 카테고리인 경우 OR 조건으로 검색
                const orConditions = mappedCategories.map((cat)=>`category_large.ilike.%${cat}%`).join(",");
                query = query.or(orConditions);
            }
            console.log(`[loadTreatmentsPaginated] 대분류 필터: "${filters.categoryLarge}" -> 매핑된 카테고리:`, mappedCategories);
        }
        if (filters?.categoryMid) {
            query = query.eq("category_mid", filters.categoryMid);
        }
        let data, error, count;
        // 랜덤 정렬인 경우: Supabase에서 랜덤 정렬 후 페이지네이션
        // PostgreSQL의 RANDOM() 함수를 사용하여 서버에서 처리
        if (filters?.randomOrder) {
            try {
                // Supabase는 PostgreSQL 기반이므로 RPC 함수나 직접 쿼리로 랜덤 정렬 가능
                // 하지만 JS 클라이언트에서는 직접 지원하지 않으므로,
                // 전체 데이터를 로드하되 클라이언트(브라우저)에서 실행되므로 서버 메모리 사용 없음
                // 필터가 있으면 필터링된 결과만 로드
                const result = await query;
                data = result.data;
                error = result.error;
                count = result.count;
            } catch (fetchError) {
                // 네트워크 오류 처리
                if (fetchError instanceof TypeError && fetchError.message === "Failed to fetch") {
                    console.error("네트워크 오류: Supabase 서버에 연결할 수 없습니다.", fetchError);
                    return {
                        data: [],
                        total: 0,
                        hasMore: false
                    };
                }
                throw fetchError;
            }
            if (error) {
                console.error("Supabase 쿼리 오류:", error);
                throw new Error(`Supabase 오류: ${error.message}`);
            }
            if (!data) {
                return {
                    data: [],
                    total: 0,
                    hasMore: false
                };
            }
            const cleanedData = cleanData(data);
            // 전체 데이터 랜덤 정렬 (클라이언트에서 실행되므로 서버 메모리 사용 없음)
            const shuffledData = shuffleArray(cleanedData);
            // 클라이언트에서 페이지네이션
            const from = (page - 1) * pageSize;
            const to = from + pageSize;
            const paginatedData = shuffledData.slice(from, to);
            const total = count || shuffledData.length;
            const hasMore = to < shuffledData.length;
            return {
                data: paginatedData,
                total,
                hasMore
            };
        } else {
            // 일반 정렬: 서버에서 페이지네이션
            const from = (page - 1) * pageSize;
            const to = from + pageSize - 1;
            try {
                const result = await query.range(from, to);
                data = result.data;
                error = result.error;
                count = result.count;
            } catch (fetchError) {
                // 네트워크 오류 처리
                if (fetchError instanceof TypeError && fetchError.message === "Failed to fetch") {
                    console.error("네트워크 오류: Supabase 서버에 연결할 수 없습니다.", fetchError);
                    return {
                        data: [],
                        total: 0,
                        hasMore: false
                    };
                }
                throw fetchError;
            }
            if (error) {
                console.error("Supabase 쿼리 오류:", error);
                throw new Error(`Supabase 오류: ${error.message}`);
            }
            if (!data) {
                return {
                    data: [],
                    total: 0,
                    hasMore: false
                };
            }
            const cleanedData = cleanData(data);
            let sortedData;
            if (filters?.skipPlatformSort) {
                // 랭킹 페이지는 플랫폼 정렬을 건너뛰고 원본 순서 유지 (랭킹 알고리즘이 정렬함)
                sortedData = cleanedData;
            } else {
                // 플랫폼 우선순위 정렬
                sortedData = sortTreatmentsByPlatform(cleanedData);
            }
            const total = count || 0;
            const hasMore = to < total - 1;
            return {
                data: sortedData,
                total,
                hasMore
            };
        }
    } catch (error) {
        console.error("시술 데이터 페이지네이션 로드 실패:", error);
        throw error;
    }
}
async function getTreatmentAutocomplete(searchTerm, limit = 10) {
    try {
        if (!searchTerm || searchTerm.length < 1) {
            return {
                treatmentNames: [],
                hospitalNames: []
            };
        }
        const client = getSupabaseOrNull();
        if (!client) {
            return {
                treatmentNames: [],
                hospitalNames: []
            };
        }
        const term = searchTerm.toLowerCase();
        const { data, error } = await client.from(TABLE_NAMES.TREATMENT_MASTER).select("category_small, hospital_name").or(`category_small.ilike.%${term}%,hospital_name.ilike.%${term}%`).limit(limit * 2);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return {
                treatmentNames: [],
                hospitalNames: []
            };
        }
        // category_small만 반환 (소분류 기준)
        const treatmentNames = Array.from(new Set(data.map((t)=>t.category_small).filter((name)=>name !== null && name.toLowerCase().includes(term)))).slice(0, limit);
        const hospitalNames = Array.from(new Set(data.map((t)=>t.hospital_name).filter((name)=>name !== null && name.toLowerCase().includes(term)))).slice(0, limit);
        return {
            treatmentNames,
            hospitalNames
        };
    } catch (error) {
        console.error("자동완성 데이터 로드 실패:", error);
        return {
            treatmentNames: [],
            hospitalNames: []
        };
    }
}
async function loadCategoryTreatTimeRecovery() {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        const { data, error } = await client.from(TABLE_NAMES.CATEGORY_TREATTIME_RECOVERY).select("*");
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data || !Array.isArray(data)) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("카테고리 시술 시간/회복 기간 데이터 로드 실패:", error);
        throw error;
    }
}
async function getRecoveryInfoByCategoryMid(categoryMid) {
    try {
        if (!categoryMid) return null;
        const categoryMidTrimmed = categoryMid.trim();
        // 캐시 (중복 호출/로그 스팸 방지) - trim된 키 사용
        // ❗ null(매칭 실패)은 캐시하지 않고, 성공한 값만 캐시합니다.
        if (recoveryInfoCache.has(categoryMidTrimmed)) {
            const cached = recoveryInfoCache.get(categoryMidTrimmed);
            if (cached) return cached;
        }
        const recoveryData = await loadCategoryTreatTimeRecovery();
        // 키/샘플 확인 (디버깅용)
        console.log("🔑 recovery 첫 행 keys:", recoveryData?.[0] ? Object.keys(recoveryData[0]) : null);
        console.log("🔎 sample 중분류:", recoveryData?.slice(0, 5).map((x)=>x["중분류"] ?? x.중분류 ?? x.category_mid));
        const getMid = (item)=>String(item["중분류"] ?? item.중분류 ?? item["category_mid"] ?? item.category_mid ?? item["categoryMid"] ?? item.categoryMid ?? "");
        // 정규화 함수: NFC + zero-width 제거 + 공백 제거 + 소문자
        // (슬래시(`/`) 같은 구분 문자는 그대로 둬서 "유두/유륜성형" 등의 매칭을 보존)
        const normalize = (str)=>str.normalize("NFC").replace(/[\u200B-\u200D\uFEFF]/g, "").replace(/\s+/g, "").toLowerCase();
        // 정상화된 중분류 목록을 미리 만들어 정확/부분 일치에 사용
        const normalizedCategoryMid = normalize(categoryMidTrimmed);
        const normalizedRecoveryData = recoveryData.map((item)=>{
            const mid = getMid(item).trim();
            return {
                ...item,
                _mid: mid,
                _normalized: normalize(mid)
            };
        });
        // 디버깅: 매칭 시도 전 로그 (한번만 찍기)
        if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
            console.log(`🔍 [매칭 시도] category_mid: "${categoryMidTrimmed}"`);
            console.log(`🔍 [매칭 시도] 정규화된 값: "${normalizedCategoryMid}"`);
            console.log(`🔍 [전체 데이터] 총 ${recoveryData.length}개 항목`);
        }
        // "V라인" 또는 입력값이 포함된 모든 중분류 찾기 (디버깅용)
        const relatedItems = normalizedRecoveryData.filter((item)=>{
            if (!item._normalized) return false;
            return item._normalized.includes(normalizedCategoryMid) || normalizedCategoryMid.includes(item._normalized);
        });
        if (relatedItems.length > 0 && !recoveryLogPrinted.has(categoryMidTrimmed)) {
            console.log(`🔍 [관련 항목 발견] ${relatedItems.length}개 항목 발견:`, relatedItems.map((item)=>({
                    중분류: item.중분류,
                    정규화: normalize(item.중분류 || ""),
                    "권장체류일수(일)": item["권장체류일수(일)"] ?? item.권장체류일수
                })));
        }
        // 중분류 컬럼과 category_mid를 매칭 (더 강력한 매칭 로직)
        // 1) 정규화된 정확 일치 우선
        let matched = normalizedRecoveryData.find((item)=>item._normalized && item._normalized === normalizedCategoryMid);
        // 2) 원본 문자열 정확 일치
        if (!matched) {
            matched = normalizedRecoveryData.find((item)=>item._mid === categoryMidTrimmed);
        }
        // 3) 정규화된 부분 일치
        if (!matched) {
            matched = normalizedRecoveryData.find((item)=>{
                if (!item._normalized) return false;
                return item._normalized.includes(normalizedCategoryMid) || normalizedCategoryMid.includes(item._normalized);
            });
        }
        // 4) 원본 부분 일치
        if (!matched) {
            matched = normalizedRecoveryData.find((item)=>{
                const mid = item._mid;
                if (!mid) return false;
                return mid.includes(categoryMidTrimmed) || categoryMidTrimmed.includes(mid);
            });
        }
        if (!matched) {
            if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
                console.error(`❌ [매칭 실패] category_mid: "${categoryMidTrimmed}" (정규화: "${normalize(categoryMidTrimmed)}")`);
            }
            // "V라인"이 포함된 모든 항목 찾기
            const vlineItems = recoveryData.filter((item)=>{
                const 중분류 = (item.중분류 || "").trim();
                return 중분류 && (중분류.includes("V라인") || 중분류.includes("v라인") || 중분류.includes("V 라인"));
            });
            if (vlineItems.length > 0 && !recoveryLogPrinted.has(categoryMidTrimmed)) {
                console.log(`🔍 [V라인 관련 항목] ${vlineItems.length}개 발견:`, vlineItems.map((item)=>({
                        중분류: item.중분류,
                        정규화: normalize(item.중분류 || ""),
                        "권장체류일수(일)": item["권장체류일수(일)"] ?? item.권장체류일수
                    })));
            }
            recoveryLogPrinted.add(categoryMidTrimmed);
            return null;
        }
        // 실제 컬럼명: 회복기간_min(일), 회복기간_max(일), 시술시간_min(분), 시술시간_max(분)
        if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
            console.log("🔍 매칭된 객체의 모든 키:", Object.keys(matched));
            console.log("🔍 매칭된 객체에서 회복기간 값 확인:", {
                "회복기간_max(일)": matched["회복기간_max(일)"],
                "회복기간_min(일)": matched["회복기간_min(일)"],
                "시술시간_max(분)": matched["시술시간_max"],
                "시술시간_min(분)": matched["시술시간_min"],
                타입_max: typeof matched["회복기간_max(일)"],
                타입_min: typeof matched["회복기간_min(일)"]
            });
        }
        const m = matched;
        const recoveryMax = m["회복기간_max(일)"] || m["회복기간_min(일)"] || 0;
        const recoveryMin = m["회복기간_min(일)"] || 0;
        const procedureTimeMax = m["시술시간_max(분)"] || m["시술시간_min(분)"] || m["시술시간_max"] || m["시술시간_min"] || 0;
        const procedureTimeMin = m["시술시간_min(분)"] || m["시술시간_min"] || 0;
        console.log(`✅ 매칭 성공! category_mid: "${categoryMidTrimmed}", 회복기간_max: ${recoveryMax}, 회복기간_min: ${recoveryMin}`);
        if (recoveryMax === 0 && recoveryMin === 0) {
            console.warn(`⚠️ 회복 기간 값이 0입니다. category_mid: "${categoryMidTrimmed}", 매칭된 항목:`, matched);
            console.warn("🔍 사용 가능한 모든 키:", Object.keys(matched));
        }
        // 회복 기간 텍스트 가이드 (전체 범위 저장)
        const recoveryGuides = {
            "1~3": matched["1~3"] || null,
            "4~7": matched["4~7"] || null,
            "8~14": matched["8~14"] || null,
            "15~21": matched["15~21"] || null
        };
        // 회복 기간에 맞는 대표 텍스트 컬럼 선택 (회복기간_max 기준)
        let recoveryText = null;
        if (recoveryMax >= 1 && recoveryMax <= 3) {
            recoveryText = recoveryGuides["1~3"];
        } else if (recoveryMax >= 4 && recoveryMax <= 7) {
            recoveryText = recoveryGuides["4~7"];
        } else if (recoveryMax >= 8 && recoveryMax <= 14) {
            recoveryText = recoveryGuides["8~14"];
        } else if (recoveryMax >= 15 && recoveryMax <= 21) {
            recoveryText = recoveryGuides["15~21"];
        }
        // 권장체류일수(일) 가져오기 - 컬럼명 변형까지 대응
        const recommendedStayDays = (()=>{
            const direct = m["권장체류일수(일)"] ?? m["권장체류일수"] ?? m.권장체류일수;
            if (typeof direct === "number" && !isNaN(direct) && direct > 0) {
                if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
                    console.log(`✅ [권장체류일수] 직접 매칭: ${direct}일`);
                }
                return direct;
            }
            const dynamicKey = Object.keys(m).find((k)=>k.replace(/\s+/g, "").includes("권장체류"));
            if (dynamicKey) {
                const value = m[dynamicKey];
                if (typeof value === "number" && !isNaN(value) && value > 0) {
                    if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
                        console.log(`✅ [권장체류일수] 동적 키 매칭 (${dynamicKey}): ${value}일`);
                    }
                    return value;
                }
            }
            if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
                console.warn(`⚠️ [권장체류일수] 찾을 수 없음. category_mid: "${categoryMidTrimmed}"`);
                console.log("🔍 [매칭된 객체의 모든 키]:", Object.keys(matched));
            }
            return 0;
        })();
        // 권장체류일수가 있으면 recoveryMax로 사용 (회복 기간 표시용)
        const finalRecoveryMax = recommendedStayDays > 0 ? recommendedStayDays : recoveryMax;
        const finalRecoveryMin = recommendedStayDays > 0 ? recommendedStayDays : recoveryMin;
        if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
            console.log(`✅ [최종 회복 기간] category_mid: "${categoryMidTrimmed}", 권장체류일수: ${recommendedStayDays}일, 회복기간_max: ${recoveryMax}일, 최종 사용: ${finalRecoveryMax}일`);
        }
        const result = {
            recoveryMin: finalRecoveryMin,
            recoveryMax: finalRecoveryMax,
            recoveryText,
            procedureTimeMin,
            procedureTimeMax,
            recommendedStayDays,
            recoveryGuides
        };
        // 캐시 & 로그 기록 (성공한 경우에만 캐시)
        recoveryInfoCache.set(categoryMidTrimmed, result);
        recoveryLogPrinted.add(categoryMidTrimmed);
        return result;
    } catch (error) {
        console.error("회복 기간 정보 로드 실패:", error);
        return null;
    }
}
async function loadHospitalMaster() {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        const { data, error } = await client.from(TABLE_NAMES.HOSPITAL_MASTER).select("*");
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data || !Array.isArray(data)) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("병원 데이터 로드 실패:", error);
        throw error;
    }
}
async function loadTreatmentById(treatmentId) {
    try {
        const client = getSupabaseOrNull();
        if (!client) return null;
        const { data, error } = await client.from(TABLE_NAMES.TREATMENT_MASTER).select("*").eq("treatment_id", treatmentId).single();
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return null;
        }
        return cleanData([
            data
        ])[0];
    } catch (error) {
        console.error("시술 데이터 로드 실패:", error);
        return null;
    }
}
async function loadRelatedTreatments(treatmentName, excludeId) {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        let query = client.from(TABLE_NAMES.TREATMENT_MASTER).select("*").eq("treatment_name", treatmentName);
        if (excludeId) {
            query = query.neq("treatment_id", excludeId);
        }
        const { data, error } = await query.limit(50);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("관련 시술 데이터 로드 실패:", error);
        return [];
    }
}
async function loadHospitalTreatments(hospitalName, excludeId) {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        let query = client.from(TABLE_NAMES.TREATMENT_MASTER).select("*").eq("hospital_name", hospitalName);
        if (excludeId) {
            query = query.neq("treatment_id", excludeId);
        }
        const { data, error } = await query.limit(10);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("병원 시술 데이터 로드 실패:", error);
        return [];
    }
}
async function loadHospitalsPaginated(page = 1, pageSize = 50, filters) {
    try {
        const client = getSupabaseOrNull();
        if (!client) {
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        let query = client.from(TABLE_NAMES.HOSPITAL_MASTER).select("*", {
            count: "exact"
        });
        // 필터 적용 (최소 2글자 이상일 때만 검색)
        if (filters?.searchTerm && filters.searchTerm.trim().length >= 2) {
            const term = filters.searchTerm.toLowerCase().trim();
            query = query.ilike("hospital_name", `%${term}%`);
        } else if (filters?.searchTerm && filters.searchTerm.trim().length === 1) {
            // 1글자일 때는 검색하지 않음 (빈 결과 반환)
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        let data, error, count;
        // 랜덤 정렬인 경우: 전체 데이터를 로드한 후 클라이언트에서 페이지네이션
        // 클라이언트(브라우저)에서 실행되므로 서버 메모리 사용 없음
        if (filters?.randomOrder) {
            // 전체 데이터 로드 (페이지네이션 없이)
            // 필터가 있으면 필터링된 결과만 로드
            const result = await query;
            data = result.data;
            error = result.error;
            count = result.count;
            if (error) {
                throw new Error(`Supabase 오류: ${error.message}`);
            }
            if (!data) {
                return {
                    data: [],
                    total: 0,
                    hasMore: false
                };
            }
            const cleanedData = cleanData(data);
            // 전체 데이터 랜덤 정렬 (클라이언트에서 실행되므로 서버 메모리 사용 없음)
            const shuffledData = shuffleArray(cleanedData);
            // 클라이언트에서 페이지네이션
            const from = (page - 1) * pageSize;
            const to = from + pageSize;
            const paginatedData = shuffledData.slice(from, to);
            const total = count || shuffledData.length;
            const hasMore = to < shuffledData.length;
            return {
                data: paginatedData,
                total,
                hasMore
            };
        } else {
            // 일반 정렬: 서버에서 페이지네이션
            const from = (page - 1) * pageSize;
            const to = from + pageSize - 1;
            const result = await query.range(from, to);
            data = result.data;
            error = result.error;
            count = result.count;
            if (error) {
                throw new Error(`Supabase 오류: ${error.message}`);
            }
            if (!data) {
                return {
                    data: [],
                    total: 0,
                    hasMore: false
                };
            }
            const cleanedData = cleanData(data);
            // 플랫폼 우선순위 정렬
            const sortedData = sortHospitalsByPlatform(cleanedData);
            const total = count || 0;
            const hasMore = to < total - 1;
            return {
                data: sortedData,
                total,
                hasMore
            };
        }
    } catch (error) {
        console.error("병원 데이터 페이지네이션 로드 실패:", error);
        throw error;
    }
}
async function getHospitalAutocomplete(searchTerm, limit = 10) {
    try {
        if (!searchTerm || searchTerm.length < 1) {
            return [];
        }
        const client = getSupabaseOrNull();
        if (!client) return [];
        const term = searchTerm.toLowerCase();
        const { data, error } = await client.from(TABLE_NAMES.HOSPITAL_MASTER).select("hospital_name").ilike("hospital_name", `%${term}%`).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return Array.from(new Set(data.map((h)=>h.hospital_name).filter((name)=>!!name)));
    } catch (error) {
        console.error("병원 자동완성 데이터 로드 실패:", error);
        return [];
    }
}
async function loadKeywordMonthlyTrends() {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        const { data, error } = await client.from(TABLE_NAMES.KEYWORD_MONTHLY_TRENDS).select("*");
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data || !Array.isArray(data)) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("키워드 트렌드 데이터 로드 실패:", error);
        throw error;
    }
}
async function loadAllData() {
    try {
        const [treatments, categoryData, hospitals, trends] = await Promise.all([
            loadTreatments(),
            loadCategoryTreatTimeRecovery(),
            loadHospitalMaster(),
            loadKeywordMonthlyTrends()
        ]);
        return {
            treatments,
            categoryTreatTimeRecovery: categoryData,
            hospitals,
            keywordTrends: trends
        };
    } catch (error) {
        console.error("전체 데이터 로드 실패:", error);
        throw error;
    }
}
function extractHospitalInfo(treatments) {
    const hospitalMap = new Map();
    treatments.forEach((treatment)=>{
        if (!treatment.hospital_name) return;
        const hospitalName = treatment.hospital_name;
        if (!hospitalMap.has(hospitalName)) {
            hospitalMap.set(hospitalName, {
                hospital_name: hospitalName,
                treatments: [],
                averageRating: 0,
                totalReviews: 0,
                procedures: [],
                categories: new Set()
            });
        }
        const hospital = hospitalMap.get(hospitalName);
        hospital.treatments.push(treatment);
        if (treatment.treatment_name) {
            hospital.procedures.push(treatment.treatment_name);
        }
        if (treatment.category_large) {
            hospital.categories.add(treatment.category_large);
        }
        if (treatment.rating) {
            hospital.averageRating += treatment.rating;
        }
        if (treatment.review_count) {
            hospital.totalReviews += treatment.review_count;
        }
    });
    // 평균 평점 계산 및 데이터 정리
    const hospitals = Array.from(hospitalMap.values()).map((hospital)=>{
        const treatmentCount = hospital.treatments.length;
        const avgRating = treatmentCount > 0 && hospital.averageRating > 0 ? hospital.averageRating / treatmentCount : 0;
        // 중복 제거 및 정렬
        const uniqueProcedures = Array.from(new Set(hospital.procedures)).slice(0, 10);
        return {
            ...hospital,
            averageRating: Math.round(avgRating * 10) / 10,
            procedures: uniqueProcedures,
            categories: hospital.categories
        };
    });
    // 평점 순으로 정렬
    return hospitals.sort((a, b)=>b.averageRating - a.averageRating);
}
function getThumbnailUrl(treatment) {
    // API에서 제공하는 main_image_url이 있으면 우선 사용
    if (treatment.main_image_url && treatment.main_image_url.trim() !== "") {
        return treatment.main_image_url;
    }
    // main_image_url이 없을 경우 고유한 플레이스홀더 생성
    const categoryColors = {
        리프팅: "667eea",
        피부: "f093fb",
        눈: "4facfe",
        코: "43e97b",
        입술: "fa709a",
        볼: "fee140",
        쁘띠: "30cfd0",
        기타: "667eea"
    };
    const category = treatment.category_large || "기타";
    const color = categoryColors[category] || "667eea";
    // treatment_id를 기반으로 고유한 이미지 생성
    const treatmentId = treatment.treatment_id || Math.random() * 1000;
    const seed = treatmentId % 1000;
    // 시술명의 첫 글자
    const firstChar = treatment.treatment_name ? treatment.treatment_name.charAt(0) : category.charAt(0);
    // data URI로 플레이스홀더 생성 (외부 서비스 의존성 제거)
    return `data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="300"%3E%3Crect fill="%23${color}" width="400" height="300"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="white" font-size="48" font-weight="bold"%3E${encodeURIComponent(firstChar)}%3C/text%3E%3C/svg%3E`;
}
function calculateRecommendationScore(treatment) {
    const rating = treatment.rating || 0;
    const reviewCount = treatment.review_count || 0;
    const price = treatment.selling_price || 0;
    // 평점 가중치 (40%)
    const ratingScore = rating * 40;
    // 리뷰 수 가중치 (30%) - 리뷰가 많을수록 좋음 (로그 스케일 사용)
    const reviewScore = Math.log10(reviewCount + 1) * 10 * 3;
    // 가격 인기도 점수 (20%) - 합리적인 가격대일수록 높은 점수
    // 평균 가격대 근처일수록 높은 점수 (간단한 휴리스틱)
    const priceScore = price > 0 && price < 1000000 ? 20 : 10;
    // 할인율 보너스 (10%)
    const discountBonus = treatment.dis_rate ? treatment.dis_rate * 0.1 : 0;
    return ratingScore + reviewScore + priceScore + discountBonus;
}
function getCategoryRankings(treatments, category) {
    let filtered = treatments;
    if (category) {
        filtered = treatments.filter((t)=>t.category_large === category || t.category_mid === category);
    }
    // 추천 점수 계산 후 정렬
    return filtered.map((treatment)=>({
            ...treatment,
            recommendationScore: calculateRecommendationScore(treatment)
        })).sort((a, b)=>b.recommendationScore - a.recommendationScore);
}
function getTreatmentRankings(treatments) {
    const treatmentMap = new Map();
    // 시술명으로 그룹화
    treatments.forEach((treatment)=>{
        if (!treatment.treatment_name) return;
        const name = treatment.treatment_name;
        if (!treatmentMap.has(name)) {
            treatmentMap.set(name, []);
        }
        treatmentMap.get(name).push(treatment);
    });
    // 랭킹 데이터 생성
    const rankings = Array.from(treatmentMap.entries()).map(([treatmentName, treatmentList])=>{
        const ratings = treatmentList.map((t)=>t.rating || 0).filter((r)=>r > 0);
        const reviews = treatmentList.map((t)=>t.review_count || 0).reduce((sum, count)=>sum + count, 0);
        const prices = treatmentList.map((t)=>t.selling_price || 0).filter((p)=>p > 0);
        const averageRating = ratings.length > 0 ? ratings.reduce((sum, r)=>sum + r, 0) / ratings.length : 0;
        const averagePrice = prices.length > 0 ? prices.reduce((sum, p)=>sum + p, 0) / prices.length : 0;
        // 대표 시술 3개 선택 (평점 높은 순)
        const topTreatments = [
            ...treatmentList
        ].sort((a, b)=>(b.rating || 0) - (a.rating || 0)).slice(0, 3);
        // 추천 점수 계산
        const representativeTreatment = {
            ...topTreatments[0],
            rating: averageRating,
            review_count: reviews
        };
        const recommendationScore = calculateRecommendationScore(representativeTreatment);
        return {
            treatmentName,
            treatments: treatmentList,
            averageRating,
            totalReviews: reviews,
            averagePrice,
            recommendationScore,
            topTreatments
        };
    }).sort((a, b)=>b.recommendationScore - a.recommendationScore);
    return rankings;
}
// K-beauty 관련 시술 필터링 (키워드 기반)
const KBEAUTY_KEYWORDS = [
    "리쥬란",
    "인모드",
    "슈링크",
    "윤곽",
    "주사",
    "보톡스",
    "필러",
    "리프팅",
    "탄력",
    "미백",
    "백옥",
    "프락셀",
    "피코",
    "레이저"
];
function getKBeautyRankings(treatments) {
    return treatments.filter((treatment)=>{
        const name = (treatment.treatment_name || "").toLowerCase();
        const hashtags = (treatment.treatment_hashtags || "").toLowerCase();
        const category = (treatment.category_large || "").toLowerCase();
        return KBEAUTY_KEYWORDS.some((keyword)=>name.includes(keyword.toLowerCase()) || hashtags.includes(keyword.toLowerCase()) || category.includes(keyword.toLowerCase()));
    }).map((treatment)=>({
            ...treatment,
            recommendationScore: calculateRecommendationScore(treatment)
        })).sort((a, b)=>b.recommendationScore - a.recommendationScore);
}
function parseRecoveryPeriod(downtime) {
    if (!downtime) return 0;
    if (typeof downtime === "number") return downtime;
    // 문자열인 경우 "1일", "2일", "1-2일" 등의 형식 파싱
    const match = downtime.toString().match(/(\d+)/);
    return match ? parseInt(match[1]) : 0;
}
function parseProcedureTime(surgeryTime) {
    if (!surgeryTime) return 0;
    if (typeof surgeryTime === "number") return surgeryTime;
    // 문자열인 경우 "30분", "60분" 등의 형식 파싱
    const match = surgeryTime.toString().match(/(\d+)/);
    return match ? parseInt(match[1]) : 0;
}
const CATEGORY_MAPPING = {
    눈성형: [
        "눈",
        "눈성형"
    ],
    리프팅: [
        "리프팅",
        "윤곽",
        "볼륨"
    ],
    보톡스: [
        "보톡스",
        "주사"
    ],
    "안면윤곽/양악": [
        "안면",
        "윤곽",
        "양악",
        "턱"
    ],
    제모: [
        "제모",
        "레이저"
    ],
    지방성형: [
        "지방",
        "체형",
        "다이어트",
        "지방흡입"
    ],
    코성형: [
        "코",
        "코성형"
    ],
    피부: [
        "피부",
        "피부관리"
    ],
    필러: [
        "필러",
        "주사"
    ],
    가슴성형: [
        "가슴",
        "유방",
        "보형물"
    ],
    기타: [
        "기타"
    ],
    전체: []
};
async function getScheduleBasedRecommendations(treatments, categoryLarge, startDate, endDate) {
    // 여행 일수 계산
    const start = new Date(startDate);
    const end = new Date(endDate);
    const travelDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1; // n박 n일
    // 아주 짧은 일정(당일 or 1박 2일)일 때는,
    // 회복친화적인 3일짜리 시술까지는 보여주기 위해
    // 필터 기준을 최소 3일로 완화
    const effectiveTravelDays = travelDays <= 2 ? 3 : travelDays;
    // 대분류 카테고리로 필터링
    const mappedCategories = CATEGORY_MAPPING[categoryLarge] || [
        categoryLarge
    ];
    const categoryFiltered = treatments.filter((t)=>{
        if (!t.category_large) return false;
        // "전체"인 경우 모든 시술 포함
        if (categoryLarge === "전체") {
            return true;
        }
        // "기타"인 경우: 다른 카테고리에 속하지 않는 것만
        if (categoryLarge === "기타") {
            const allOtherCategories = [
                "눈",
                "눈성형",
                "리프팅",
                "윤곽",
                "볼륨",
                "보톡스",
                "주사",
                "안면",
                "양악",
                "턱",
                "제모",
                "레이저",
                "지방",
                "체형",
                "다이어트",
                "지방흡입",
                "코",
                "코성형",
                "피부",
                "피부관리",
                "필러",
                "가슴",
                "유방",
                "보형물"
            ];
            const categoryLower = t.category_large?.toLowerCase() || "";
            const midCategoryLower = t.category_mid?.toLowerCase() || "";
            // 다른 카테고리에 속하지 않는지 확인
            const isInOtherCategory = allOtherCategories.some((otherCat)=>categoryLower.includes(otherCat.toLowerCase()) || midCategoryLower.includes(otherCat.toLowerCase()));
            return !isInOtherCategory;
        }
        // 일반 카테고리: category_large를 우선적으로 확인
        // category_large가 매핑된 카테고리 중 하나와 일치하는지 확인
        const categoryLargeLower = (t.category_large || "").toLowerCase();
        const categoryMidLower = (t.category_mid || "").toLowerCase();
        // category_large가 매핑된 카테고리 중 하나와 일치하는 경우
        const matchesLarge = mappedCategories.some((mapped)=>{
            const mappedLower = mapped.toLowerCase();
            return categoryLargeLower.includes(mappedLower);
        });
        if (matchesLarge) {
            return true;
        }
        // category_large가 매칭되지 않으면, category_mid만으로는 선택하지 않음
        // (이렇게 하면 다른 대분류의 시술이 잘못 필터링되는 것을 방지)
        //
        // TODO: 데이터가 10,000개 이상일 때는 더 엄격한 필터링 필요
        // - category_large와 category_mid 모두 정확히 매칭되어야 함
        // - 키워드 포함 검사 대신 정확한 문자열 매칭 사용
        // - 예: category_large === mapped (정확히 일치) && category_mid가 매핑된 중분류와 일치
        return false;
    });
    console.log(`[일정 기반 추천] 선택 카테고리: ${categoryLarge}, 필터링된 데이터: ${categoryFiltered.length}개`);
    // 중분류별로 그룹화 (대분류 + 중분류 조합으로 키 생성하여 중복 방지)
    const midCategoryMap = new Map();
    // "정맥주사" 중복 확인을 위한 디버깅
    const jeongmaekjusaTreatments = [];
    categoryFiltered.forEach((treatment)=>{
        const categoryLarge = treatment.category_large || "";
        const midCategory = treatment.category_mid || "기타";
        // "정맥주사" 데이터 수집 (선택된 카테고리 정보 포함)
        if (midCategory === "정맥주사" || midCategory.includes("정맥주사")) {
            jeongmaekjusaTreatments.push({
                categoryLarge,
                categoryMid: midCategory,
                treatmentName: treatment.treatment_name || "이름 없음",
                treatmentId: treatment.treatment_id,
                selectedCategory: categoryLarge
            });
        }
        // 대분류와 중분류를 조합하여 고유 키 생성
        const uniqueKey = `${categoryLarge}::${midCategory}`;
        if (!midCategoryMap.has(uniqueKey)) {
            midCategoryMap.set(uniqueKey, []);
        }
        midCategoryMap.get(uniqueKey).push(treatment);
    });
    // "정맥주사" 중복 확인 로그 - 각 대분류별로 다른 시술인지 확인
    if (jeongmaekjusaTreatments.length > 0) {
        const categoryLargeSet = new Set(jeongmaekjusaTreatments.map((t)=>t.categoryLarge));
        console.log("🔍 [정맥주사 데이터 분석]");
        console.log(`- 선택된 카테고리: ${categoryLarge}`);
        console.log(`- 총 ${jeongmaekjusaTreatments.length}개의 정맥주사 시술 발견`);
        console.log(`- 속한 대분류(category_large): ${Array.from(categoryLargeSet).join(", ")}`);
        console.log(`- 대분류 개수: ${categoryLargeSet.size}개`);
        // 대분류별로 그룹화하여 상세 정보 출력
        const byCategory = new Map();
        jeongmaekjusaTreatments.forEach((t)=>{
            const existing = byCategory.get(t.categoryLarge) || {
                count: 0,
                treatments: []
            };
            existing.count += 1;
            existing.treatments.push({
                name: t.treatmentName,
                id: t.treatmentId
            });
            byCategory.set(t.categoryLarge, existing);
        });
        // 각 대분류별 시술 목록 출력
        byCategory.forEach((data, cat)=>{
            console.log(`\n📋 [${cat}] 대분류의 정맥주사 시술 (${data.count}개):`);
            const treatmentNames = data.treatments.map((t)=>t.name);
            const treatmentIds = data.treatments.map((t)=>t.id).filter((id)=>id !== undefined);
            console.log(`  시술명: ${treatmentNames.slice(0, 5).join(", ")}${treatmentNames.length > 5 ? ` ... 외 ${treatmentNames.length - 5}개` : ""}`);
            console.log(`  시술 ID: ${treatmentIds.slice(0, 5).join(", ")}${treatmentIds.length > 5 ? ` ... 외 ${treatmentIds.length - 5}개` : ""}`);
        });
        // 중복 시술 확인 (같은 시술 ID가 여러 대분류에 있는지)
        const allTreatmentIds = new Map();
        jeongmaekjusaTreatments.forEach((t)=>{
            if (t.treatmentId !== undefined) {
                const existing = allTreatmentIds.get(t.treatmentId) || [];
                if (!existing.includes(t.categoryLarge)) {
                    existing.push(t.categoryLarge);
                }
                allTreatmentIds.set(t.treatmentId, existing);
            }
        });
        const duplicateTreatments = [];
        allTreatmentIds.forEach((categories, id)=>{
            if (categories.length > 1) {
                const treatment = jeongmaekjusaTreatments.find((t)=>t.treatmentId === id);
                if (treatment) {
                    duplicateTreatments.push({
                        id,
                        name: treatment.treatmentName,
                        categories
                    });
                }
            }
        });
        if (duplicateTreatments.length > 0) {
            console.error("❌ [문제 발견] 같은 시술이 여러 대분류에 중복되어 있습니다:");
            duplicateTreatments.forEach((d)=>{
                console.error(`  - 시술 ID ${d.id} (${d.name}): ${d.categories.join(", ")} 대분류에 중복`);
            });
            console.error("💡 이는 필터링 로직 문제로 인해 발생할 수 있습니다. 각 대분류별로 다른 시술이 표시되어야 합니다.");
        } else {
            console.log("✅ 각 대분류별로 다른 시술이 표시되고 있습니다.");
        }
        if (categoryLargeSet.size > 1) {
            console.warn("⚠️ 정맥주사가 여러 대분류에 속해있습니다:", Array.from(categoryLargeSet));
            console.log("💡 이는 데이터 상에서 '정맥주사' 중분류가 실제로 여러 대분류에 속해있기 때문입니다.");
        }
    }
    // 중분류별로 추천 데이터 생성
    const recommendationsPromises = Array.from(midCategoryMap.entries()).map(async ([uniqueKey, treatmentList])=>{
        // uniqueKey에서 중분류 이름만 추출 (대분류::중분류 형식)
        const categoryMid = uniqueKey.split("::")[1] || "기타";
        // 먼저 category_treattime_recovery 테이블에서 권장체류일수 및 회복기간 범위 가져오기
        let recommendedStayDays = 0;
        let recoveryMin = 0;
        let recoveryMax = 0;
        let procedureTimeMin = 0;
        let procedureTimeMax = 0;
        try {
            const recoveryInfo = await getRecoveryInfoByCategoryMid(categoryMid);
            if (recoveryInfo) {
                recoveryMin = recoveryInfo.recoveryMin;
                recoveryMax = recoveryInfo.recoveryMax;
                procedureTimeMin = recoveryInfo.procedureTimeMin;
                procedureTimeMax = recoveryInfo.procedureTimeMax;
                recommendedStayDays = recoveryInfo.recommendedStayDays;
            }
        } catch (error) {
            console.warn(`회복 기간 정보 로드 실패 (category_mid: ${categoryMid}):`, error);
        }
        // 권장체류일수(일)만 사용하여 여행 기간에 맞는 시술만 필터링
        // - 결정 기준은 category_treattime_recovery 테이블의 "권장체류일수(일)" 컬럼
        // - 이 값이 없을 때만 기존 로직(downtime)으로 fallback
        const groupStayDays = recommendedStayDays;
        // 권장체류일수가 여행 일수보다 크면, 이 중분류 전체를 추천에서 제외
        // 단, 당일/1박 2일은 effectiveTravelDays=3으로 간주하여 3일짜리 시술까지 허용
        if (groupStayDays > 0 && groupStayDays > effectiveTravelDays) {
            return null;
        }
        let suitableTreatments;
        if (groupStayDays > 0) {
            // 권장체류일수가 여행 일수 이내면 해당 중분류 전체를 포함
            suitableTreatments = treatmentList;
        } else {
            // 권장체류일수가 없으면 기존 로직 사용 (downtime 기반)
            suitableTreatments = treatmentList.filter((treatment)=>{
                const recoveryPeriod = parseRecoveryPeriod(treatment.downtime);
                // 회복기간 정보가 없으면 포함 (기본적으로 표시)
                if (recoveryPeriod === 0) return true;
                // 여행 일수에서 최소 1일은 여유를 둠 (시술 당일 제외)
                // 당일/1박 2일의 경우 effectiveTravelDays=3이므로 2일까지 허용
                return recoveryPeriod <= effectiveTravelDays - 1;
            });
        }
        // 필터링 결과가 없거나 회복기간 정보가 없으면 전체 시술 표시 (최대 20개)
        // 권장체류일수 또는 개별 downtime 정보가 있는 경우에만 필터링 적용
        const hasRecoveryData = recommendedStayDays > 0 || treatmentList.some((t)=>parseRecoveryPeriod(t.downtime) > 0);
        const finalTreatments = hasRecoveryData && suitableTreatments.length > 0 ? suitableTreatments : [
            ...treatmentList
        ].sort((a, b)=>{
            // 추천 점수로 정렬
            const scoreA = calculateRecommendationScore(a);
            const scoreB = calculateRecommendationScore(b);
            return scoreB - scoreA;
        }).slice(0, 20); // 최대 20개
        // 회복 기간 정보가 없으면 downtime에서 계산
        if (recoveryMin === 0 && recoveryMax === 0) {
            const recoveryPeriods = finalTreatments.map((t)=>parseRecoveryPeriod(t.downtime)).filter((r)=>r > 0);
            if (recoveryPeriods.length > 0) {
                recoveryMin = Math.min(...recoveryPeriods);
                recoveryMax = Math.max(...recoveryPeriods);
            }
        }
        // 시술 시간 정보가 없으면 surgery_time에서 계산
        if (procedureTimeMin === 0 && procedureTimeMax === 0) {
            const procedureTimes = finalTreatments.map((t)=>parseProcedureTime(t.surgery_time)).filter((t)=>t > 0);
            if (procedureTimes.length > 0) {
                procedureTimeMin = Math.min(...procedureTimes);
                procedureTimeMax = Math.max(...procedureTimes);
            }
        }
        // 평균 회복 기간 계산 (표시용)
        const recoveryPeriods = finalTreatments.map((t)=>parseRecoveryPeriod(t.downtime)).filter((r)=>r > 0);
        const averageRecoveryPeriod = recoveryPeriods.length > 0 ? recoveryPeriods.reduce((sum, r)=>sum + r, 0) / recoveryPeriods.length : recoveryMax > 0 ? (recoveryMin + recoveryMax) / 2 : 0;
        // 평균 시술 시간 계산 (표시용)
        const procedureTimes = finalTreatments.map((t)=>parseProcedureTime(t.surgery_time)).filter((t)=>t > 0);
        const averageProcedureTime = procedureTimes.length > 0 ? procedureTimes.reduce((sum, t)=>sum + t, 0) / procedureTimes.length : procedureTimeMax > 0 ? (procedureTimeMin + procedureTimeMax) / 2 : 0;
        // 추천 점수로 정렬
        const sortedTreatments = finalTreatments.map((treatment)=>({
                ...treatment,
                recommendationScore: calculateRecommendationScore(treatment)
            })).sort((a, b)=>b.recommendationScore - a.recommendationScore);
        return {
            categoryMid,
            treatments: sortedTreatments,
            averageRecoveryPeriod: Math.round(averageRecoveryPeriod * 10) / 10,
            averageRecoveryPeriodMin: recoveryMin,
            averageRecoveryPeriodMax: recoveryMax,
            averageProcedureTime: Math.round(averageProcedureTime),
            averageProcedureTimeMin: procedureTimeMin,
            averageProcedureTimeMax: procedureTimeMax
        };
    });
    const recommendations = (await Promise.all(recommendationsPromises)).filter((rec)=>rec !== null);
    return recommendations.filter((rec)=>rec.treatments.length > 0) // 시술이 있는 중분류만
    .sort((a, b)=>{
        // 1순위: 인기 점수(가장 상위 시술의 recommendationScore) 높은 순
        const scoreA = a.treatments[0]?.recommendationScore || 0;
        const scoreB = b.treatments[0]?.recommendationScore || 0;
        if (scoreA !== scoreB) {
            return scoreB - scoreA;
        }
        // 2순위: 평균 회복 기간이 짧은 순 (동점일 때 여행 친화적인 순서)
        if (a.averageRecoveryPeriod !== b.averageRecoveryPeriod) {
            return a.averageRecoveryPeriod - b.averageRecoveryPeriod;
        }
        return 0;
    });
}
// 플랫폼 우선순위 (높을수록 우선)
const PLATFORM_PRIORITY = {
    gangnamunni: 3,
    yeoti: 2,
    babitalk: 1
};
function sortTreatmentsByPlatform(treatments) {
    return [
        ...treatments
    ].sort((a, b)=>{
        const platformA = (a.platform || "").toLowerCase();
        const platformB = (b.platform || "").toLowerCase();
        const priorityA = PLATFORM_PRIORITY[platformA] || 0;
        const priorityB = PLATFORM_PRIORITY[platformB] || 0;
        // 우선순위가 높은 것이 앞에 오도록 (내림차순)
        return priorityB - priorityA;
    });
}
function sortHospitalsByPlatform(hospitals) {
    return [
        ...hospitals
    ].sort((a, b)=>{
        const platformA = (a.platform || "").toLowerCase();
        const platformB = (b.platform || "").toLowerCase();
        const priorityA = PLATFORM_PRIORITY[platformA] || 0;
        const priorityB = PLATFORM_PRIORITY[platformB] || 0;
        // 우선순위가 높은 것이 앞에 오도록 (내림차순)
        return priorityB - priorityA;
    });
}
async function saveProcedureReview(data) {
    try {
        const reviewData = {
            user_id: data.user_id ?? 0,
            category: data.category,
            procedure_name: data.procedure_name,
            hospital_name: data.hospital_name || null,
            cost: data.cost,
            procedure_rating: data.procedure_rating,
            hospital_rating: data.hospital_rating,
            gender: data.gender,
            age_group: data.age_group,
            surgery_date: data.surgery_date || null,
            content: data.content,
            images: data.images && data.images.length > 0 ? data.images : null
        };
        const { data: insertedData, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("procedure_reviews").insert([
            reviewData
        ]).select("id").single();
        if (error) {
            console.error("시술후기 저장 실패:", error);
            return {
                success: false,
                error: error.message
            };
        }
        return {
            success: true,
            id: insertedData?.id
        };
    } catch (error) {
        console.error("시술후기 저장 중 오류:", error);
        return {
            success: false,
            error: error?.message || "시술후기 저장에 실패했습니다."
        };
    }
}
async function saveHospitalReview(data) {
    try {
        const reviewData = {
            user_id: data.user_id ?? 0,
            hospital_name: data.hospital_name,
            category_large: data.category_large,
            procedure_name: data.procedure_name || null,
            visit_date: data.visit_date || null,
            overall_satisfaction: data.overall_satisfaction || null,
            hospital_kindness: data.hospital_kindness || null,
            has_translation: data.has_translation ?? false,
            translation_satisfaction: data.has_translation && data.translation_satisfaction ? data.translation_satisfaction : null,
            content: data.content,
            images: data.images && data.images.length > 0 ? data.images : null
        };
        const { data: insertedData, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("hospital_reviews").insert([
            reviewData
        ]).select("id").single();
        if (error) {
            console.error("병원후기 저장 실패:", error);
            return {
                success: false,
                error: error.message
            };
        }
        return {
            success: true,
            id: insertedData?.id
        };
    } catch (error) {
        console.error("병원후기 저장 중 오류:", error);
        return {
            success: false,
            error: error?.message || "병원후기 저장에 실패했습니다."
        };
    }
}
async function saveConcernPost(data) {
    try {
        const postData = {
            user_id: data.user_id ?? 0,
            title: data.title,
            concern_category: data.concern_category,
            content: data.content
        };
        const { data: insertedData, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("concern_posts").insert([
            postData
        ]).select("id").single();
        if (error) {
            console.error("고민글 저장 실패:", error);
            return {
                success: false,
                error: error.message
            };
        }
        return {
            success: true,
            id: insertedData?.id
        };
    } catch (error) {
        console.error("고민글 저장 중 오류:", error);
        return {
            success: false,
            error: error?.message || "고민글 저장에 실패했습니다."
        };
    }
}
async function loadProcedureReviews(limit = 50) {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("procedure_reviews").select("*").order("created_at", {
            ascending: false
        }).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return data;
    } catch (error) {
        console.error("시술 후기 로드 실패:", error);
        return [];
    }
}
async function loadHospitalReviews(limit = 50) {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("hospital_reviews").select("*").order("created_at", {
            ascending: false
        }).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return data;
    } catch (error) {
        console.error("병원 후기 로드 실패:", error);
        return [];
    }
}
async function loadConcernPosts(limit = 50) {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("concern_posts").select("*").order("created_at", {
            ascending: false
        }).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return data;
    } catch (error) {
        console.error("고민글 로드 실패:", error);
        return [];
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/AutocompleteInput.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AutocompleteInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function AutocompleteInput({ value, onChange, placeholder = "검색...", suggestions, onSuggestionSelect, onEnter, className = "" }) {
    _s();
    const [showSuggestions, setShowSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [focusedIndex, setFocusedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const [isComposing, setIsComposing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // 한글 입력 조합 중인지 추적
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const suggestionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // 외부 클릭 시 자동완성 닫기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AutocompleteInput.useEffect": ()=>{
            const handleClickOutside = {
                "AutocompleteInput.useEffect.handleClickOutside": (event)=>{
                    if (inputRef.current && !inputRef.current.contains(event.target) && suggestionsRef.current && !suggestionsRef.current.contains(event.target)) {
                        setShowSuggestions(false);
                    }
                }
            }["AutocompleteInput.useEffect.handleClickOutside"];
            document.addEventListener("mousedown", handleClickOutside);
            return ({
                "AutocompleteInput.useEffect": ()=>document.removeEventListener("mousedown", handleClickOutside)
            })["AutocompleteInput.useEffect"];
        }
    }["AutocompleteInput.useEffect"], []);
    // 자동완성 선택으로 인한 value 변경인지 추적
    const isSuggestionSelectedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    // 검색어가 변경되면 자동완성 표시
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AutocompleteInput.useEffect": ()=>{
            // 자동완성 선택으로 인한 value 변경이면 자동완성을 다시 열지 않음
            if (isSuggestionSelectedRef.current) {
                isSuggestionSelectedRef.current = false;
                return;
            }
            setShowSuggestions(value.length > 0 && suggestions.length > 0);
            setFocusedIndex(-1);
        }
    }["AutocompleteInput.useEffect"], [
        value,
        suggestions
    ]);
    const handleInputChange = (e)=>{
        // 항상 onChange 호출 (입력 필드가 업데이트되도록)
        onChange(e.target.value);
    };
    // 한글 입력 조합 시작
    const handleCompositionStart = ()=>{
        setIsComposing(true);
    };
    // 한글 입력 조합 종료
    const handleCompositionEnd = (e)=>{
        setIsComposing(false);
        // 조합이 완료되면 최종 값을 onChange로 전달 (이미 handleInputChange에서 호출되지만 확실히 하기 위해)
        onChange(e.currentTarget.value);
    };
    const handleSuggestionClick = (suggestion)=>{
        // 자동완성 선택 플래그 설정 (value 변경으로 인해 자동완성이 다시 열리지 않도록)
        isSuggestionSelectedRef.current = true;
        // 먼저 자동완성을 닫고, 그 다음에 onChange 호출
        setShowSuggestions(false);
        onChange(suggestion);
        if (onSuggestionSelect) {
            onSuggestionSelect(suggestion);
        }
        inputRef.current?.blur();
    };
    const handleKeyDown = (e)=>{
        if (e.key === "Enter") {
            if (showSuggestions && suggestions.length > 0 && focusedIndex >= 0) {
                // 자동완성 항목이 선택된 경우
                e.preventDefault();
                handleSuggestionClick(suggestions[focusedIndex]);
            } else if (onEnter && value.trim().length >= 2) {
                // 자동완성 항목이 선택되지 않은 경우 Enter 키 처리 (2글자 이상일 때만)
                e.preventDefault();
                onEnter();
            }
            return;
        }
        if (!showSuggestions || suggestions.length === 0) return;
        if (e.key === "ArrowDown") {
            e.preventDefault();
            setFocusedIndex((prev)=>prev < suggestions.length - 1 ? prev + 1 : prev);
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setFocusedIndex((prev)=>prev > 0 ? prev - 1 : -1);
        } else if (e.key === "Escape") {
            setShowSuggestions(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-3 top-1/2 transform -translate-y-1/2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSearch"], {
                            className: "text-gray-400 text-sm"
                        }, void 0, false, {
                            fileName: "[project]/components/AutocompleteInput.tsx",
                            lineNumber: 124,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 123,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: inputRef,
                        type: "text",
                        value: value,
                        onChange: handleInputChange,
                        onCompositionStart: handleCompositionStart,
                        onCompositionEnd: handleCompositionEnd,
                        onKeyDown: handleKeyDown,
                        onFocus: ()=>{
                            if (value.length > 0 && suggestions.length > 0) {
                                setShowSuggestions(true);
                            }
                        },
                        placeholder: placeholder,
                        className: `w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-main ${className}`
                    }, void 0, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/AutocompleteInput.tsx",
                lineNumber: 122,
                columnNumber: 7
            }, this),
            showSuggestions && suggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: suggestionsRef,
                className: "absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto",
                children: suggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>handleSuggestionClick(suggestion),
                        onMouseEnter: ()=>setFocusedIndex(index),
                        className: `w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${index === focusedIndex ? "bg-gray-50" : ""}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSearch"], {
                                    className: "text-gray-400 text-xs"
                                }, void 0, false, {
                                    fileName: "[project]/components/AutocompleteInput.tsx",
                                    lineNumber: 161,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: suggestion
                                }, void 0, false, {
                                    fileName: "[project]/components/AutocompleteInput.tsx",
                                    lineNumber: 162,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AutocompleteInput.tsx",
                            lineNumber: 160,
                            columnNumber: 15
                        }, this)
                    }, index, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 151,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/AutocompleteInput.tsx",
                lineNumber: 146,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/AutocompleteInput.tsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
_s(AutocompleteInput, "+C4g0DflqOSlovvKMUTWVOQq8lc=");
_c = AutocompleteInput;
var _c;
__turbopack_context__.k.register(_c, "AutocompleteInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/SearchModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SearchModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AutocompleteInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AutocompleteInput.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const MAX_RECENT_SEARCHES = 10; // 최대 최근 검색어 개수
const recommendedSearches = [
    {
        id: 1,
        name: "리쥬란힐러",
        badge: "BEST"
    },
    {
        id: 2,
        name: "써마지",
        badge: "BEST"
    },
    {
        id: 3,
        name: "쥬베룩",
        badge: "BEST"
    },
    {
        id: 4,
        name: "울쎄라",
        badge: "up"
    },
    {
        id: 5,
        name: "LDM",
        badge: "up"
    },
    {
        id: 6,
        name: "스킨부"
    },
    {
        id: 7,
        name: "올리지"
    },
    {
        id: 8,
        name: "튠페"
    },
    {
        id: 9,
        name: "쎄라플"
    },
    {
        id: 10,
        name: "리프터"
    }
];
const quickIcons = [
    {
        id: 1,
        label: "블프 세일 대축제",
        icon: "🛍️"
    },
    {
        id: 2,
        label: "요즘인기시술",
        icon: "⭐"
    },
    {
        id: 3,
        label: "혜택 플러스",
        icon: "💎"
    },
    {
        id: 4,
        label: "포인트 적립백서",
        icon: "📝"
    },
    {
        id: 5,
        label: "부작용 안심케어",
        icon: "🛡️"
    }
];
const recentEvents = [
    {
        id: 1,
        title: "Shurink Universe",
        clinic: "본연_슈링크 유니버스",
        location: "서울 강남역·본연성...",
        price: "120,000원",
        image: ""
    },
    {
        id: 2,
        title: "Eight longtime #인모드 #슈링크",
        clinic: "지방소멸 롱타임 인모드리프팅 슈링...",
        location: "서울 압구정역·에이...",
        price: "₩108,900",
        image: ""
    },
    {
        id: 3,
        title: "시술 시간 걱정 없이 인모드는 롱~모드로!",
        clinic: "롱모드 인모드 풀페이스 10분 FX...",
        location: "서울 홍대입구역·리...",
        price: "99,000원",
        image: ""
    },
    {
        id: 4,
        title: "후기 6,000+ 디에이 자려한 코성형",
        clinic: "예쁘면DA야_자려한 코성형_비순각코수...",
        location: "서울 역삼역·디에이...",
        price: "1,088,000원",
        image: ""
    }
];
const interestProcedures = [
    "인모드리프팅",
    "슈링크리프팅",
    "슈링크유니버스",
    "코재수술",
    "아이슈링크"
];
const categories = [
    {
        icon: "👁️",
        label: "눈성형"
    },
    {
        icon: "👃",
        label: "코성형"
    },
    {
        icon: "😊",
        label: "안면윤곽/양악"
    },
    {
        icon: "💪",
        label: "가슴성형"
    },
    {
        icon: "🏃",
        label: "지방성형"
    },
    {
        icon: "💉",
        label: "필러"
    },
    {
        icon: "💉",
        label: "보톡스"
    },
    {
        icon: "✨",
        label: "리프팅"
    },
    {
        icon: "🌟",
        label: "피부"
    },
    {
        icon: "✂️",
        label: "제모"
    },
    {
        icon: "💇",
        label: "모발이식"
    },
    {
        icon: "🦷",
        label: "치아"
    },
    {
        icon: "🍵",
        label: "한방"
    },
    {
        icon: "📦",
        label: "기타"
    }
];
function SearchModal({ isOpen, onClose }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedRegion, setSelectedRegion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("지역");
    const [recentSearches, setRecentSearches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [autocompleteSuggestions, setAutocompleteSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // localStorage에서 최근 검색어 불러오기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SearchModal.useEffect": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                const saved = localStorage.getItem("recentSearches");
                if (saved) {
                    try {
                        setRecentSearches(JSON.parse(saved));
                    } catch (e) {
                        console.error("Failed to parse recent searches", e);
                    }
                }
            }
        }
    }["SearchModal.useEffect"], []);
    // 자동완성 데이터 로드
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SearchModal.useEffect": ()=>{
            const loadAutocomplete = {
                "SearchModal.useEffect.loadAutocomplete": async ()=>{
                    if (searchQuery.length < 1) {
                        setAutocompleteSuggestions([]);
                        return;
                    }
                    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTreatmentAutocomplete"])(searchQuery, 10);
                    const allSuggestions = [
                        ...result.treatmentNames,
                        ...result.hospitalNames
                    ];
                    setAutocompleteSuggestions(allSuggestions);
                }
            }["SearchModal.useEffect.loadAutocomplete"];
            const debounceTimer = setTimeout({
                "SearchModal.useEffect.debounceTimer": ()=>{
                    loadAutocomplete();
                }
            }["SearchModal.useEffect.debounceTimer"], 300);
            return ({
                "SearchModal.useEffect": ()=>clearTimeout(debounceTimer)
            })["SearchModal.useEffect"];
        }
    }["SearchModal.useEffect"], [
        searchQuery
    ]);
    // 최근 검색어에 추가하는 함수
    const addToRecentSearches = (query)=>{
        const trimmedQuery = query.trim();
        if (!trimmedQuery) return;
        setRecentSearches((prev)=>{
            // 중복 제거 (기존 항목 제거 후 맨 앞에 추가)
            const filtered = prev.filter((item)=>item !== trimmedQuery);
            const updated = [
                trimmedQuery,
                ...filtered
            ].slice(0, MAX_RECENT_SEARCHES);
            // localStorage에 저장
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("recentSearches", JSON.stringify(updated));
            }
            return updated;
        });
    };
    // 개별 검색어 삭제
    const removeRecentSearch = (query, e)=>{
        e.stopPropagation(); // 버튼 클릭 이벤트 전파 방지
        setRecentSearches((prev)=>{
            const updated = prev.filter((item)=>item !== query);
            // localStorage에 저장
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("recentSearches", JSON.stringify(updated));
            }
            return updated;
        });
    };
    // 전체 검색어 삭제
    const clearAllRecentSearches = ()=>{
        setRecentSearches([]);
        if ("TURBOPACK compile-time truthy", 1) {
            localStorage.removeItem("recentSearches");
        }
    };
    const handleSearch = ()=>{
        if (searchQuery.trim()) {
            // 최근 검색어에 추가
            addToRecentSearches(searchQuery.trim());
            // 탐색 페이지로 이동하면서 검색어와 섹션 정보 전달
            router.push(`/explore?search=${encodeURIComponent(searchQuery.trim())}&section=procedure`);
            onClose();
        }
    };
    const handleKeyPress = (e)=>{
        if (e.key === "Enter") {
            handleSearch();
        }
    };
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[100] bg-white overflow-y-auto max-w-md mx-auto left-1/2 transform -translate-x-1/2 pb-20 w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sticky top-0 z-50 bg-white border-b border-gray-100 px-4 py-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClose,
                                className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                                    className: "text-gray-700 text-xl"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 218,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 214,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 relative",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AutocompleteInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    value: searchQuery,
                                    onChange: setSearchQuery,
                                    placeholder: "시술명/수술명을 입력해 주세요.",
                                    suggestions: autocompleteSuggestions,
                                    onSuggestionSelect: (suggestion)=>{
                                        setSearchQuery(suggestion);
                                        // 자동완성 선택 시 바로 검색 실행
                                        setTimeout(()=>{
                                            handleSearch();
                                        }, 100);
                                    },
                                    onEnter: handleSearch,
                                    className: "bg-gray-50 border border-gray-200"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 221,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 220,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleSearch,
                                className: "px-3 py-2 text-primary-main text-sm font-medium hover:bg-primary-main/10 rounded-lg transition-colors",
                                children: "검색"
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 237,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 213,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "flex items-center gap-1 text-gray-700 text-sm hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: selectedRegion
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 248,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronDown"], {
                                    className: "text-gray-500 text-sm"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 249,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/SearchModal.tsx",
                            lineNumber: 247,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 246,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SearchModal.tsx",
                lineNumber: 212,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 py-6 space-y-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative bg-black rounded-2xl overflow-hidden p-6 min-h-[160px] flex items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute inset-0 opacity-5",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-0",
                                    style: {
                                        backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.1) 10px, rgba(255,255,255,0.1) 20px)"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 259,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 258,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative w-full",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start justify-between mb-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-white text-xs",
                                                children: "K-피부시술 세일 페스타, 모든 시술이 한자리에!"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 269,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-primary-main text-white px-3 py-1 rounded-full text-xs font-bold flex-shrink-0 ml-2",
                                                children: "~49% off"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 272,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 268,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-4xl font-black mb-3 leading-tight",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white",
                                                children: "BLACK"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 277,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-primary-light relative",
                                                children: [
                                                    "BEAUTY",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "absolute -top-1 -right-3 text-primary-main text-xs",
                                                        children: "★"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 280,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 278,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white",
                                                children: "FRIDAY"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 284,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 276,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-white text-sm",
                                        children: "11.11 — 12.10"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 286,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 267,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 257,
                        columnNumber: 9
                    }, this),
                    recentSearches.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-base font-bold text-gray-900",
                                        children: "최근 검색어"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 294,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: clearAllRecentSearches,
                                        className: "text-sm text-gray-500 hover:text-gray-700",
                                        children: "전체삭제"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 295,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 293,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 flex-wrap",
                                children: recentSearches.map((search, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setSearchQuery(search);
                                            addToRecentSearches(search); // 클릭 시에도 최근 검색어에 추가 (순서 업데이트)
                                            router.push(`/explore?search=${encodeURIComponent(search)}&section=procedure`);
                                            onClose();
                                        },
                                        className: "flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-full text-sm transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: search
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 318,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                onClick: (e)=>{
                                                    e.stopPropagation();
                                                    removeRecentSearch(search, e);
                                                },
                                                className: "hover:bg-gray-300 rounded-full p-0.5 transition-colors cursor-pointer",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoClose"], {
                                                    className: "text-gray-500 text-sm"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/SearchModal.tsx",
                                                    lineNumber: 326,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 319,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, index, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 304,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 302,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 292,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-5 gap-4",
                        children: quickIcons.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "flex flex-col items-center gap-2 p-3 hover:bg-gray-50 rounded-xl transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-12 h-12 bg-gradient-to-br from-primary-light/20 to-primary-main/30 rounded-full flex items-center justify-center text-xl",
                                        children: item.icon
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 341,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-700 text-center leading-tight",
                                        children: item.label
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 344,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, item.id, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 337,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 335,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-base font-bold text-gray-900 mb-4",
                                children: "추천 검색어"
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 353,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-4",
                                children: recommendedSearches.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setSearchQuery(item.name);
                                            addToRecentSearches(item.name); // 추천 검색어 클릭 시에도 최근 검색어에 추가
                                            router.push(`/explore?search=${encodeURIComponent(item.name)}&section=procedure`);
                                            onClose();
                                        },
                                        className: "flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors text-left",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-primary-main font-bold text-sm min-w-[20px]",
                                                        children: item.id
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 373,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-gray-900 text-sm",
                                                        children: item.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 376,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 372,
                                                columnNumber: 17
                                            }, this),
                                            item.badge === "BEST" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "bg-primary-light/20 text-primary-main px-2 py-0.5 rounded text-xs font-semibold",
                                                children: "BEST"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 379,
                                                columnNumber: 19
                                            }, this),
                                            item.badge === "up" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-3 h-3 text-primary-main",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    fillRule: "evenodd",
                                                    d: "M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z",
                                                    clipRule: "evenodd"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/SearchModal.tsx",
                                                    lineNumber: 389,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 384,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, item.id, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 358,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 356,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 352,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SearchModal.tsx",
                lineNumber: 255,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/SearchModal.tsx",
        lineNumber: 210,
        columnNumber: 5
    }, this);
}
_s(SearchModal, "RfQBDmNVGE2WOvqHX2rzPVGKT74=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = SearchModal;
var _c;
__turbopack_context__.k.register(_c, "SearchModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Header.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/bs/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SearchModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SearchModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function Header({ hasRankingBanner = false }) {
    _s();
    const [isSearchOpen, setIsSearchOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLanguageOpen, setIsLanguageOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [logoError, setLogoError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const globeButtonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { language, setLanguage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [dropdownPosition, setDropdownPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        top: 0,
        right: 0
    });
    const languages = [
        {
            code: "KR",
            name: "한국어",
            flag: "🇰🇷"
        },
        {
            code: "EN",
            name: "English",
            flag: "🇺🇸"
        },
        {
            code: "JP",
            name: "日本語",
            flag: "🇯🇵"
        },
        {
            code: "CN",
            name: "中文",
            flag: "🇨🇳"
        }
    ];
    const selectedLanguage = languages.find((lang)=>lang.code === language) || languages[0];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Header.useEffect": ()=>{
            if (isLanguageOpen && globeButtonRef.current) {
                const rect = globeButtonRef.current.getBoundingClientRect();
                setDropdownPosition({
                    top: rect.bottom + 8,
                    right: window.innerWidth - rect.right
                });
            }
        }
    }["Header.useEffect"], [
        isLanguageOpen
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: `sticky ${hasRankingBanner ? "top-[41px]" : "top-0"} z-40 bg-white border-b border-gray-100 px-4 py-3`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>router.push("/"),
                            className: "flex items-center gap-2 hover:opacity-80 transition-opacity cursor-pointer",
                            children: !logoError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/beautrip-logo.png",
                                alt: "BeauTrip",
                                className: "h-6 w-auto object-contain",
                                onError: ()=>setLogoError(true)
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 63,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BsCloud"], {
                                className: "text-primary-main text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 70,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4 relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setIsSearchOpen(true),
                                    className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSearch"], {
                                        className: "text-gray-700 text-xl"
                                    }, void 0, false, {
                                        fileName: "[project]/components/Header.tsx",
                                        lineNumber: 81,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            ref: globeButtonRef,
                                            onClick: ()=>setIsLanguageOpen(!isLanguageOpen),
                                            className: "p-2 hover:bg-gray-50 rounded-full transition-colors relative z-[100]",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiGlobe"], {
                                                className: "text-gray-700 text-xl"
                                            }, void 0, false, {
                                                fileName: "[project]/components/Header.tsx",
                                                lineNumber: 89,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this),
                                        isLanguageOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "fixed inset-0 z-[99]",
                                                    onClick: ()=>setIsLanguageOpen(false)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Header.tsx",
                                                    lineNumber: 93,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "fixed bg-white border border-gray-200 rounded-lg shadow-lg z-[100] min-w-[150px]",
                                                    style: {
                                                        top: `${dropdownPosition.top}px`,
                                                        right: `${dropdownPosition.right}px`
                                                    },
                                                    children: languages.map((lang)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>{
                                                                setLanguage(lang.code);
                                                                setIsLanguageOpen(false);
                                                            },
                                                            className: `w-full text-left px-4 py-2 hover:bg-gray-50 transition-colors flex items-center gap-2 ${selectedLanguage.code === lang.code ? "bg-primary-main/10" : ""}`,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: lang.flag
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 117,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-gray-700",
                                                                    children: lang.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 118,
                                                                    columnNumber: 25
                                                                }, this),
                                                                selectedLanguage.code === lang.code && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "ml-auto text-primary-main",
                                                                    children: "✓"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 122,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, lang.code, true, {
                                                            fileName: "[project]/components/Header.tsx",
                                                            lineNumber: 105,
                                                            columnNumber: 23
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Header.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 83,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "p-2 hover:bg-gray-50 rounded-full transition-colors relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiBell"], {
                                            className: "text-gray-700 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 131,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/Header.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/Header.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SearchModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isSearchOpen,
                onClose: ()=>setIsSearchOpen(false)
            }, void 0, false, {
                fileName: "[project]/components/Header.tsx",
                lineNumber: 137,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(Header, "wHAZrX0YKQ6dHEhrD591unZdiTg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/TravelScheduleCalendarModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TravelScheduleCalendarModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function TravelScheduleCalendarModal({ isOpen, onClose, onDateSelect, selectedStartDate, selectedEndDate, onModalStateChange }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [currentDate, setCurrentDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Date());
    const [tempStartDate, setTempStartDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(selectedStartDate || null);
    const [tempEndDate, setTempEndDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(selectedEndDate || null);
    // 모달 상태 변경 알림 (렌더링 후 실행) - hooks는 항상 같은 순서로 실행되어야 함
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TravelScheduleCalendarModal.useEffect": ()=>{
            if (!isOpen) return;
            if (onModalStateChange) {
                onModalStateChange(true);
            }
            return ({
                "TravelScheduleCalendarModal.useEffect": ()=>{
                    if (onModalStateChange) {
                        onModalStateChange(false);
                    }
                }
            })["TravelScheduleCalendarModal.useEffect"];
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["TravelScheduleCalendarModal.useEffect"], [
        isOpen
    ]); // onModalStateChange는 의존성에서 제외 (무한 루프 방지)
    if (!isOpen) return null;
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    // 달력의 첫 번째 날짜와 마지막 날짜 계산
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    const daysInMonth = lastDayOfMonth.getDate();
    const startingDayOfWeek = firstDayOfMonth.getDay();
    // 이전 달로 이동
    const goToPreviousMonth = ()=>{
        setCurrentDate(new Date(year, month - 1, 1));
    };
    // 다음 달로 이동
    const goToNextMonth = ()=>{
        setCurrentDate(new Date(year, month + 1, 1));
    };
    // 날짜 포맷팅 (YYYY-MM-DD)
    const formatDate = (date)=>{
        const y = date.getFullYear();
        const m = String(date.getMonth() + 1).padStart(2, "0");
        const d = String(date.getDate()).padStart(2, "0");
        return `${y}-${m}-${d}`;
    };
    // 오늘 날짜인지 확인
    const isToday = (date)=>{
        const today = new Date();
        return date.getDate() === today.getDate() && date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear();
    };
    // 선택된 날짜 범위인지 확인
    const isInRange = (date)=>{
        if (!tempStartDate) return false;
        const dateStr = formatDate(date);
        const start = new Date(tempStartDate);
        const end = tempEndDate ? new Date(tempEndDate) : null;
        const current = new Date(dateStr);
        if (end) {
            return current >= start && current <= end;
        }
        return dateStr === tempStartDate;
    };
    // 시작일인지 확인
    const isStartDate = (date)=>{
        if (!tempStartDate) return false;
        return formatDate(date) === tempStartDate;
    };
    // 종료일인지 확인
    const isEndDate = (date)=>{
        if (!tempEndDate) return false;
        return formatDate(date) === tempEndDate;
    };
    // 날짜 클릭 핸들러
    const handleDateClick = (date)=>{
        const dateStr = formatDate(date);
        const clickedDate = new Date(dateStr);
        // 과거 날짜는 선택 불가
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (clickedDate < today) return;
        if (!tempStartDate || tempStartDate && tempEndDate) {
            // 시작일 선택 또는 재선택
            setTempStartDate(dateStr);
            setTempEndDate(null);
        } else if (tempStartDate && !tempEndDate) {
            // 종료일 선택
            const start = new Date(tempStartDate);
            if (clickedDate < start) {
                // 종료일이 시작일보다 이전이면 시작일로 변경
                setTempStartDate(dateStr);
                setTempEndDate(null);
            } else {
                setTempEndDate(dateStr);
            }
        }
    };
    // 확인 버튼 클릭
    const handleConfirm = ()=>{
        if (tempStartDate && tempEndDate) {
            onDateSelect(tempStartDate, tempEndDate, null);
            if (onModalStateChange) {
                onModalStateChange(false);
            }
            onClose();
        }
    };
    // 모달 닫기 시 상태 업데이트
    const handleClose = ()=>{
        if (onModalStateChange) {
            onModalStateChange(false);
        }
        onClose();
    };
    // 달력 날짜 배열 생성
    const calendarDays = [];
    // 이전 달의 마지막 날들 추가
    const prevMonthLastDay = new Date(year, month, 0).getDate();
    for(let i = startingDayOfWeek - 1; i >= 0; i--){
        calendarDays.push(new Date(year, month - 1, prevMonthLastDay - i));
    }
    // 현재 달의 날들 추가
    for(let day = 1; day <= daysInMonth; day++){
        calendarDays.push(new Date(year, month, day));
    }
    // 다음 달의 첫 날들 추가 (총 42개 셀을 채우기 위해)
    const remainingDays = 42 - calendarDays.length;
    for(let day = 1; day <= remainingDays; day++){
        calendarDays.push(new Date(year, month + 1, day));
    }
    const monthNames = [
        "1월",
        "2월",
        "3월",
        "4월",
        "5월",
        "6월",
        "7월",
        "8월",
        "9월",
        "10월",
        "11월",
        "12월"
    ];
    const dayNames = [
        "일",
        "월",
        "화",
        "수",
        "목",
        "금",
        "토"
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl w-full max-w-xs mx-4 max-h-[85vh] overflow-y-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sticky top-0 bg-white border-b border-gray-200 px-3 py-3 flex items-center justify-between z-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-lg font-bold text-gray-900",
                            children: t("calendar.title")
                        }, void 0, false, {
                            fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                            lineNumber: 206,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleClose,
                            className: "p-2 hover:bg-gray-100 rounded-full transition-colors",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                className: "text-gray-700 text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                lineNumber: 213,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                            lineNumber: 209,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                    lineNumber: 205,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-2.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between mb-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: goToPreviousMonth,
                                    className: "p-2 hover:bg-gray-100 rounded-full transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronLeft"], {
                                        className: "text-gray-700 text-xl"
                                    }, void 0, false, {
                                        fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                        lineNumber: 225,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                    lineNumber: 221,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-sm font-semibold text-gray-900",
                                    children: [
                                        year,
                                        "년 ",
                                        monthNames[month]
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                    lineNumber: 227,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: goToNextMonth,
                                    className: "p-2 hover:bg-gray-100 rounded-full transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                                        className: "text-gray-700 text-xl"
                                    }, void 0, false, {
                                        fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                        lineNumber: 234,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                    lineNumber: 230,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                            lineNumber: 220,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-white rounded-xl border border-gray-200 overflow-hidden",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-7 bg-gray-50 border-b border-gray-200",
                                    children: dayNames.map((day)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "py-1 text-center text-[9px] font-semibold text-gray-600",
                                            children: day
                                        }, day, false, {
                                            fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                            lineNumber: 243,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                    lineNumber: 241,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-7",
                                    children: calendarDays.map((date, index)=>{
                                        if (!date) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "aspect-square"
                                        }, index, false, {
                                            fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                            lineNumber: 256,
                                            columnNumber: 26
                                        }, this);
                                        const isCurrentMonth = date.getMonth() === month;
                                        const isTodayDate = isToday(date);
                                        const inRange = isInRange(date);
                                        const isStart = isStartDate(date);
                                        const isEnd = isEndDate(date);
                                        // 과거 날짜는 비활성화
                                        const today = new Date();
                                        today.setHours(0, 0, 0, 0);
                                        const isPast = date < today;
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>!isPast && handleDateClick(date),
                                            disabled: isPast,
                                            className: `aspect-square border-r border-b border-gray-100 p-0.5 transition-colors relative ${!isCurrentMonth ? "text-gray-300 bg-gray-50" : isPast ? "text-gray-300 bg-gray-50 cursor-not-allowed" : isStart || isEnd ? "bg-primary-main text-white font-semibold" : inRange ? "bg-primary-main/20 text-primary-main font-semibold" : isTodayDate ? "bg-primary-light/20 text-primary-main font-semibold" : "text-gray-700 hover:bg-gray-50"}`,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-center h-full",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs",
                                                    children: date.getDate()
                                                }, void 0, false, {
                                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                                    lineNumber: 289,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                                lineNumber: 288,
                                                columnNumber: 21
                                            }, this)
                                        }, index, false, {
                                            fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                            lineNumber: 270,
                                            columnNumber: 19
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                    lineNumber: 253,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-2.5 space-y-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1 p-2 bg-primary-light/10 rounded-lg",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[10px] text-gray-600 mb-0.5",
                                                    children: t("calendar.startDate")
                                                }, void 0, false, {
                                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                                    lineNumber: 301,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs font-semibold text-primary-main",
                                                    children: tempStartDate || t("calendar.notSelected")
                                                }, void 0, false, {
                                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                                    lineNumber: 304,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                            lineNumber: 300,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1 p-2 bg-primary-light/10 rounded-lg",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[10px] text-gray-600 mb-0.5",
                                                    children: t("calendar.endDate")
                                                }, void 0, false, {
                                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                                    lineNumber: 309,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs font-semibold text-primary-main",
                                                    children: tempEndDate || t("calendar.notSelected")
                                                }, void 0, false, {
                                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                                    lineNumber: 312,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                            lineNumber: 308,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                    lineNumber: 299,
                                    columnNumber: 13
                                }, this),
                                tempStartDate && tempEndDate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleConfirm,
                                    className: "w-full bg-primary-main hover:bg-[#2DB8A0] text-white py-2 rounded-lg text-xs font-semibold transition-colors",
                                    children: t("common.confirm")
                                }, void 0, false, {
                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                    lineNumber: 320,
                                    columnNumber: 15
                                }, this),
                                tempStartDate && !tempEndDate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{},
                                    disabled: true,
                                    className: "w-full bg-gray-200 text-gray-500 py-2 rounded-lg text-xs font-semibold transition-colors cursor-not-allowed",
                                    children: t("calendar.selectEndDate")
                                }, void 0, false, {
                                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                                    lineNumber: 329,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                            lineNumber: 298,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
                    lineNumber: 218,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
            lineNumber: 203,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/TravelScheduleCalendarModal.tsx",
        lineNumber: 202,
        columnNumber: 5
    }, this);
}
_s(TravelScheduleCalendarModal, "AFfWo2j8CWDmJTppiavAuETqp1A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = TravelScheduleCalendarModal;
var _c;
__turbopack_context__.k.register(_c, "TravelScheduleCalendarModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/TravelScheduleBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TravelScheduleBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$TravelScheduleCalendarModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/TravelScheduleCalendarModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function TravelScheduleBar({ onScheduleChange, onModalStateChange }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [isModalOpen, setIsModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedStartDate, setSelectedStartDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedEndDate, setSelectedEndDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // localStorage에서 기존 여행 기간 로드하지 않음 (홈 화면에서는 항상 초기 상태로 시작)
    // useEffect 제거 - 홈 화면에서는 날짜를 선택하라는 버튼으로 표시
    const handleModalOpen = ()=>{
        setIsModalOpen(true);
        if (onModalStateChange) {
            onModalStateChange(true);
        }
    };
    const handleModalClose = ()=>{
        setIsModalOpen(false);
        if (onModalStateChange) {
            onModalStateChange(false);
        }
    };
    const handleDateSelect = (startDate, endDate, categoryId)=>{
        setSelectedStartDate(startDate);
        setSelectedEndDate(endDate);
        // 여행 기간을 localStorage에 저장 (MySchedulePage와 연동)
        if (startDate && endDate) {
            const travelPeriod = {
                start: startDate,
                end: endDate
            };
            localStorage.setItem("travelPeriod", JSON.stringify(travelPeriod));
            // 여행 기간 업데이트 이벤트 발생
            window.dispatchEvent(new Event("travelPeriodUpdated"));
        }
        if (onScheduleChange) {
            onScheduleChange(startDate, endDate, categoryId);
        }
    };
    const formatDisplayDate = (dateStr)=>{
        const date = new Date(dateStr);
        const month = date.getMonth() + 1;
        const day = date.getDate();
        const dayNames = [
            "일",
            "월",
            "화",
            "수",
            "목",
            "금",
            "토"
        ];
        const dayName = dayNames[date.getDay()];
        return `${month}월 ${day}일 (${dayName})`;
    };
    const getDisplayText = ()=>{
        if (selectedStartDate && selectedEndDate) {
            return `${formatDisplayDate(selectedStartDate)} ~ ${formatDisplayDate(selectedEndDate)}`;
        } else if (selectedStartDate) {
            return `${formatDisplayDate(selectedStartDate)} ~ 종료일 선택`;
        }
        return "";
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative mb-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-3 top-1/2 transform -translate-y-1/2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCalendar"], {
                            className: "text-primary-main text-lg"
                        }, void 0, false, {
                            fileName: "[project]/components/TravelScheduleBar.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/TravelScheduleBar.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: getDisplayText(),
                        placeholder: t("home.selectSchedule"),
                        onClick: handleModalOpen,
                        readOnly: true,
                        className: "w-full pl-10 pr-10 py-3 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-light focus:border-transparent cursor-pointer"
                    }, void 0, false, {
                        fileName: "[project]/components/TravelScheduleBar.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronDown"], {
                            className: "text-gray-400 text-lg"
                        }, void 0, false, {
                            fileName: "[project]/components/TravelScheduleBar.tsx",
                            lineNumber: 104,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/TravelScheduleBar.tsx",
                        lineNumber: 103,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/TravelScheduleBar.tsx",
                lineNumber: 91,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$TravelScheduleCalendarModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isModalOpen,
                onClose: handleModalClose,
                onDateSelect: handleDateSelect,
                selectedStartDate: selectedStartDate,
                selectedEndDate: selectedEndDate,
                onModalStateChange: (isOpen)=>{
                    setIsModalOpen(isOpen);
                    if (onModalStateChange) {
                        onModalStateChange(isOpen);
                    }
                }
            }, void 0, false, {
                fileName: "[project]/components/TravelScheduleBar.tsx",
                lineNumber: 108,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(TravelScheduleBar, "XL4XPZs4iQ8bqNfvqItipsgA1jQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = TravelScheduleBar;
var _c;
__turbopack_context__.k.register(_c, "TravelScheduleBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/AddToScheduleModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AddToScheduleModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function AddToScheduleModal({ isOpen, onClose, onDateSelect, treatmentName, selectedStartDate, selectedEndDate, categoryMid }) {
    _s();
    const [currentDate, setCurrentDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Date());
    const [selectedDate, setSelectedDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // localStorage에서 여행 기간 로드
    const [travelStartDate, setTravelStartDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [travelEndDate, setTravelEndDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // 회복 기간 정보
    const [recoveryDays, setRecoveryDays] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    // 여행 기간 로드 함수
    const loadTravelPeriod = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AddToScheduleModal.useCallback[loadTravelPeriod]": ()=>{
            // props로 전달된 기간이 있으면 우선 사용, 없으면 localStorage에서 로드
            if (selectedStartDate && selectedEndDate) {
                setTravelStartDate(selectedStartDate);
                setTravelEndDate(selectedEndDate);
            } else {
                const travelPeriod = localStorage.getItem("travelPeriod");
                if (travelPeriod) {
                    try {
                        const period = JSON.parse(travelPeriod);
                        if (period.start && period.end) {
                            setTravelStartDate(period.start);
                            setTravelEndDate(period.end);
                            // 선택된 기간의 시작일로 달력 이동
                            const startDate = new Date(period.start);
                            setCurrentDate(startDate);
                        }
                    } catch (e) {
                        console.error("Failed to parse travelPeriod:", e);
                    }
                }
            }
        }
    }["AddToScheduleModal.useCallback[loadTravelPeriod]"], [
        selectedStartDate,
        selectedEndDate
    ]);
    // 회복 기간 정보 로드
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AddToScheduleModal.useEffect": ()=>{
            const loadRecoveryInfo = {
                "AddToScheduleModal.useEffect.loadRecoveryInfo": async ()=>{
                    if (categoryMid) {
                        try {
                            const recoveryInfo = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRecoveryInfoByCategoryMid"])(categoryMid);
                            if (recoveryInfo) {
                                // 권장체류일수가 있으면 그것을 사용, 없으면 recoveryMax 사용
                                const days = recoveryInfo.recommendedStayDays > 0 ? recoveryInfo.recommendedStayDays : recoveryInfo.recoveryMax;
                                setRecoveryDays(days);
                            }
                        } catch (error) {
                            console.error("Failed to load recovery info:", error);
                            setRecoveryDays(0);
                        }
                    } else {
                        setRecoveryDays(0);
                    }
                }
            }["AddToScheduleModal.useEffect.loadRecoveryInfo"];
            if (isOpen && categoryMid) {
                loadRecoveryInfo();
            }
        }
    }["AddToScheduleModal.useEffect"], [
        isOpen,
        categoryMid
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AddToScheduleModal.useEffect": ()=>{
            if (isOpen) {
                loadTravelPeriod();
            }
        }
    }["AddToScheduleModal.useEffect"], [
        isOpen,
        loadTravelPeriod
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AddToScheduleModal.useEffect": ()=>{
            // travelPeriodUpdated 이벤트 리스너
            const handleTravelPeriodUpdate = {
                "AddToScheduleModal.useEffect.handleTravelPeriodUpdate": ()=>{
                    loadTravelPeriod();
                }
            }["AddToScheduleModal.useEffect.handleTravelPeriodUpdate"];
            window.addEventListener("travelPeriodUpdated", handleTravelPeriodUpdate);
            return ({
                "AddToScheduleModal.useEffect": ()=>{
                    window.removeEventListener("travelPeriodUpdated", handleTravelPeriodUpdate);
                }
            })["AddToScheduleModal.useEffect"];
        }
    }["AddToScheduleModal.useEffect"], [
        loadTravelPeriod
    ]);
    if (!isOpen) return null;
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    // 달력의 첫 번째 날짜와 마지막 날짜 계산
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    const daysInMonth = lastDayOfMonth.getDate();
    const startingDayOfWeek = firstDayOfMonth.getDay();
    // 이전 달로 이동
    const goToPreviousMonth = ()=>{
        setCurrentDate(new Date(year, month - 1, 1));
    };
    // 다음 달로 이동
    const goToNextMonth = ()=>{
        setCurrentDate(new Date(year, month + 1, 1));
    };
    // 날짜 포맷팅 (YYYY-MM-DD)
    const formatDate = (date)=>{
        const y = date.getFullYear();
        const m = String(date.getMonth() + 1).padStart(2, "0");
        const d = String(date.getDate()).padStart(2, "0");
        return `${y}-${m}-${d}`;
    };
    // 오늘 날짜인지 확인
    const isToday = (date)=>{
        const today = new Date();
        return date.getDate() === today.getDate() && date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear();
    };
    // 선택된 여행 기간 범위인지 확인
    const isInTravelRange = (date)=>{
        if (!travelStartDate || !travelEndDate) return false;
        const dateStr = formatDate(date);
        const start = new Date(travelStartDate);
        const end = new Date(travelEndDate);
        const current = new Date(dateStr);
        return current >= start && current <= end;
    };
    // 여행 시작일인지 확인
    const isTravelStartDate = (date)=>{
        if (!travelStartDate) return false;
        return formatDate(date) === travelStartDate;
    };
    // 여행 종료일인지 확인
    const isTravelEndDate = (date)=>{
        if (!travelEndDate) return false;
        return formatDate(date) === travelEndDate;
    };
    // 회복 기간 범위인지 확인
    const isInRecoveryRange = (date)=>{
        if (!selectedDate || recoveryDays === 0) return false;
        const dateStr = formatDate(date);
        const procedureDate = new Date(selectedDate);
        const current = new Date(dateStr);
        // 시술 날짜 다음 날부터 회복 기간 시작 (MySchedulePage와 동일한 로직)
        // recoveryDays가 3이면: 다음날(1), 그다음날(2), 마지막날(3) = 총 3일
        const recoveryStartDate = new Date(procedureDate);
        recoveryStartDate.setDate(recoveryStartDate.getDate() + 1);
        // 회복 기간 종료일 계산 (시술일 + recoveryDays)
        const recoveryEndDate = new Date(procedureDate);
        recoveryEndDate.setDate(recoveryEndDate.getDate() + recoveryDays);
        // 날짜 비교 시 시간 제거
        recoveryStartDate.setHours(0, 0, 0, 0);
        recoveryEndDate.setHours(0, 0, 0, 0);
        current.setHours(0, 0, 0, 0);
        return current >= recoveryStartDate && current <= recoveryEndDate;
    };
    // 회복 기간이 여행 기간 밖에 있는지 확인
    const isRecoveryOutsideTravel = (date)=>{
        if (!selectedDate || recoveryDays === 0 || !travelEndDate) return false;
        if (!isInRecoveryRange(date)) return false;
        const dateStr = formatDate(date);
        const travelEnd = new Date(travelEndDate);
        const current = new Date(dateStr);
        travelEnd.setHours(0, 0, 0, 0);
        current.setHours(0, 0, 0, 0);
        // 회복 기간이 여행 종료일보다 늦으면 경고
        return current > travelEnd;
    };
    // 회복 기간이 여행 기간을 벗어나는지 확인 (전체적으로)
    const isRecoveryPeriodOutsideTravel = ()=>{
        if (!selectedDate || recoveryDays === 0 || !travelEndDate) return false;
        const procedureDate = new Date(selectedDate);
        const recoveryEndDate = new Date(procedureDate);
        recoveryEndDate.setDate(recoveryEndDate.getDate() + recoveryDays);
        const travelEnd = new Date(travelEndDate);
        recoveryEndDate.setHours(0, 0, 0, 0);
        travelEnd.setHours(0, 0, 0, 0);
        // 회복 기간 종료일이 여행 종료일보다 늦으면 경고
        return recoveryEndDate > travelEnd;
    };
    // 날짜 클릭 핸들러
    const handleDateClick = (date)=>{
        const dateStr = formatDate(date);
        const clickedDate = new Date(dateStr);
        // 과거 날짜는 선택 불가
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        clickedDate.setHours(0, 0, 0, 0);
        if (clickedDate < today) {
            return;
        }
        setSelectedDate(dateStr);
    };
    // 확인 버튼 클릭
    const handleConfirm = ()=>{
        if (selectedDate) {
            onDateSelect(selectedDate);
            onClose();
            setSelectedDate(null);
        }
    };
    // 달력 날짜 배열 생성
    const calendarDays = [];
    // 빈 칸 추가 (첫 주 시작일 전)
    for(let i = 0; i < startingDayOfWeek; i++){
        calendarDays.push(null);
    }
    // 날짜 추가
    for(let day = 1; day <= daysInMonth; day++){
        calendarDays.push(new Date(year, month, day));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 bg-black/50 z-[100]",
                onClick: onClose
            }, void 0, false, {
                fileName: "[project]/components/AddToScheduleModal.tsx",
                lineNumber: 270,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-[101] flex items-center justify-center p-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white rounded-2xl w-full max-w-md shadow-xl",
                    onClick: (e)=>e.stopPropagation(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between p-4 border-b border-gray-200",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-bold text-gray-900",
                                    children: "일정에 추가"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                    lineNumber: 280,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onClose,
                                    className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                        className: "text-gray-700 text-xl"
                                    }, void 0, false, {
                                        fileName: "[project]/components/AddToScheduleModal.tsx",
                                        lineNumber: 285,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                    lineNumber: 281,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddToScheduleModal.tsx",
                            lineNumber: 279,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-4 py-3 bg-gray-50 border-b border-gray-200",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-600",
                                    children: "시술명"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                    lineNumber: 291,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-base font-semibold text-gray-900 mt-1",
                                    children: treatmentName
                                }, void 0, false, {
                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                    lineNumber: 292,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddToScheduleModal.tsx",
                            lineNumber: 290,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-between mb-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: goToPreviousMonth,
                                            className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronLeft"], {
                                                className: "text-gray-700"
                                            }, void 0, false, {
                                                fileName: "[project]/components/AddToScheduleModal.tsx",
                                                lineNumber: 305,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/AddToScheduleModal.tsx",
                                            lineNumber: 301,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-lg font-semibold text-gray-900",
                                            children: [
                                                year,
                                                "년 ",
                                                month + 1,
                                                "월"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddToScheduleModal.tsx",
                                            lineNumber: 307,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: goToNextMonth,
                                            className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                                                className: "text-gray-700"
                                            }, void 0, false, {
                                                fileName: "[project]/components/AddToScheduleModal.tsx",
                                                lineNumber: 314,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/AddToScheduleModal.tsx",
                                            lineNumber: 310,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                    lineNumber: 300,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-7 gap-1 mb-2",
                                    children: [
                                        "일",
                                        "월",
                                        "화",
                                        "수",
                                        "목",
                                        "금",
                                        "토"
                                    ].map((day, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `text-center text-sm font-medium py-2 ${index === 0 ? "text-red-500" : index === 6 ? "text-blue-500" : "text-gray-600"}`,
                                            children: day
                                        }, day, false, {
                                            fileName: "[project]/components/AddToScheduleModal.tsx",
                                            lineNumber: 321,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                    lineNumber: 319,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid grid-cols-7 gap-1",
                                    children: calendarDays.map((date, index)=>{
                                        if (!date) {
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "aspect-square"
                                            }, index, false, {
                                                fileName: "[project]/components/AddToScheduleModal.tsx",
                                                lineNumber: 340,
                                                columnNumber: 26
                                            }, this);
                                        }
                                        const dateStr = formatDate(date);
                                        const isSelected = selectedDate === dateStr;
                                        const isPast = date < new Date(new Date().setHours(0, 0, 0, 0));
                                        const dayOfWeek = date.getDay();
                                        const inTravelRange = isInTravelRange(date);
                                        const isTravelStart = isTravelStartDate(date);
                                        const isTravelEnd = isTravelEndDate(date);
                                        const isTodayDate = isToday(date);
                                        const inRecoveryRange = isInRecoveryRange(date);
                                        const recoveryOutsideTravel = isRecoveryOutsideTravel(date);
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>handleDateClick(date),
                                            disabled: isPast,
                                            className: `aspect-square flex items-center justify-center text-sm rounded-lg transition-colors relative ${isPast ? "text-gray-300 cursor-not-allowed bg-gray-50" : isSelected ? "bg-pink-500 text-white font-semibold z-10 shadow-md" : recoveryOutsideTravel ? "bg-orange-100 text-orange-700 border-2 border-orange-400" : inRecoveryRange ? "bg-purple-100 text-purple-700" : isTravelStart || isTravelEnd ? "bg-sky-100 text-sky-700 font-semibold" : inTravelRange ? "bg-sky-100 text-sky-700" : isTodayDate ? "text-primary-main font-semibold" : dayOfWeek === 0 ? "text-red-500 hover:bg-red-50" : dayOfWeek === 6 ? "text-blue-500 hover:bg-blue-50" : "text-gray-700 hover:bg-gray-100"}`,
                                            children: date.getDate()
                                        }, index, false, {
                                            fileName: "[project]/components/AddToScheduleModal.tsx",
                                            lineNumber: 355,
                                            columnNumber: 19
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                    lineNumber: 337,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddToScheduleModal.tsx",
                            lineNumber: 298,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-4 pb-3 h-[100px] flex items-start",
                            children: selectedDate && isRecoveryPeriodOutsideTravel() ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-orange-50 border border-orange-200 rounded-lg p-3 w-full",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-start gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-orange-600 text-lg",
                                            children: "⚠️"
                                        }, void 0, false, {
                                            fileName: "[project]/components/AddToScheduleModal.tsx",
                                            lineNumber: 393,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm font-semibold text-orange-800 mb-1",
                                                    children: "회복 기간이 여행 기간을 벗어납니다"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                                    lineNumber: 395,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-orange-700 leading-relaxed",
                                                    children: "선택한 시술의 회복 기간이 여행 종료일 이후까지 이어집니다. 여행 기간 내에 회복을 완료할 수 있도록 일정을 조정해주세요."
                                                }, void 0, false, {
                                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                                    lineNumber: 398,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/AddToScheduleModal.tsx",
                                            lineNumber: 394,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                    lineNumber: 392,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/AddToScheduleModal.tsx",
                                lineNumber: 391,
                                columnNumber: 15
                            }, this) : null
                        }, void 0, false, {
                            fileName: "[project]/components/AddToScheduleModal.tsx",
                            lineNumber: 389,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-4 border-t border-gray-200 flex gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onClose,
                                    className: "flex-1 py-3 px-4 bg-gray-100 text-gray-700 rounded-lg font-semibold hover:bg-gray-200 transition-colors",
                                    children: "취소"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                    lineNumber: 411,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleConfirm,
                                    disabled: !selectedDate,
                                    className: `flex-1 py-3 px-4 rounded-lg font-semibold transition-colors ${selectedDate ? "bg-primary-main text-white hover:bg-primary-main/90" : "bg-gray-200 text-gray-400 cursor-not-allowed"}`,
                                    children: "추가하기"
                                }, void 0, false, {
                                    fileName: "[project]/components/AddToScheduleModal.tsx",
                                    lineNumber: 417,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AddToScheduleModal.tsx",
                            lineNumber: 410,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/AddToScheduleModal.tsx",
                    lineNumber: 274,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/AddToScheduleModal.tsx",
                lineNumber: 273,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(AddToScheduleModal, "Mljhz82KaKsJG5D7K+8Xx49ykDI=");
_c = AddToScheduleModal;
var _c;
__turbopack_context__.k.register(_c, "AddToScheduleModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/HotConcernsSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HotConcernsSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AddToScheduleModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AddToScheduleModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function HotConcernsSection() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [treatments, setTreatments] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [favorites, setFavorites] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [selectedTreatment, setSelectedTreatment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isScheduleModalOpen, setIsScheduleModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HotConcernsSection.useEffect": ()=>{
            async function fetchData() {
                try {
                    setLoading(true);
                    // 필요한 만큼만 로드 (50개)
                    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadTreatmentsPaginated"])(1, 50);
                    const allTreatments = result.data;
                    // 추천 점수로 정렬하고 랜덤으로 10개 선택
                    const sortedTreatments = allTreatments.map({
                        "HotConcernsSection.useEffect.fetchData.sortedTreatments": (treatment)=>({
                                ...treatment,
                                recommendationScore: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateRecommendationScore"])(treatment)
                            })
                    }["HotConcernsSection.useEffect.fetchData.sortedTreatments"]).sort({
                        "HotConcernsSection.useEffect.fetchData.sortedTreatments": (a, b)=>b.recommendationScore - a.recommendationScore
                    }["HotConcernsSection.useEffect.fetchData.sortedTreatments"]);
                    // 상위 50개 중에서 랜덤으로 10개 선택
                    const top50 = sortedTreatments.slice(0, 50);
                    const shuffled = [
                        ...top50
                    ].sort({
                        "HotConcernsSection.useEffect.fetchData.shuffled": ()=>Math.random() - 0.5
                    }["HotConcernsSection.useEffect.fetchData.shuffled"]);
                    const random10 = shuffled.slice(0, 10);
                    setTreatments(random10);
                } catch (error) {
                    console.error("데이터 로드 실패:", error);
                } finally{
                    setLoading(false);
                }
            }
            fetchData();
        }
    }["HotConcernsSection.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HotConcernsSection.useEffect": ()=>{
            const savedFavorites = JSON.parse(localStorage.getItem("favorites") || "[]");
            const procedureFavorites = savedFavorites.filter({
                "HotConcernsSection.useEffect.procedureFavorites": (f)=>f.type === "procedure"
            }["HotConcernsSection.useEffect.procedureFavorites"]).map({
                "HotConcernsSection.useEffect.procedureFavorites": (f)=>f.id
            }["HotConcernsSection.useEffect.procedureFavorites"]);
            setFavorites(new Set(procedureFavorites));
        }
    }["HotConcernsSection.useEffect"], []);
    const handleFavoriteClick = (treatment, e)=>{
        e.stopPropagation();
        if (!treatment.treatment_id) return;
        setFavorites((prev)=>{
            const newSet = new Set(prev);
            if (newSet.has(treatment.treatment_id)) {
                newSet.delete(treatment.treatment_id);
            } else {
                newSet.add(treatment.treatment_id);
            }
            // 로컬 스토리지에 저장
            const savedFavorites = JSON.parse(localStorage.getItem("favorites") || "[]");
            const updatedFavorites = Array.from(newSet).map((id)=>({
                    id,
                    type: "procedure"
                }));
            localStorage.setItem("favorites", JSON.stringify(updatedFavorites));
            return newSet;
        });
    };
    const handleScheduleClick = (treatment, e)=>{
        e.stopPropagation();
        setSelectedTreatment(treatment);
        setIsScheduleModalOpen(true);
    };
    const handleDateSelect = async (date)=>{
        if (!selectedTreatment) return;
        // 해당 날짜의 기존 일정 개수 확인 (시술 + 회복 기간 합쳐서)
        const schedules = JSON.parse(localStorage.getItem("schedules") || "[]");
        const formatDate = (dateStr)=>{
            return dateStr;
        };
        let countOnDate = 0;
        schedules.forEach((s)=>{
            const procDate = new Date(s.procedureDate);
            const procDateStr = formatDate(s.procedureDate);
            if (procDateStr === date) {
                countOnDate++;
            }
            for(let i = 1; i <= (s.recoveryDays || 0); i++){
                const recoveryDate = new Date(procDate);
                recoveryDate.setDate(recoveryDate.getDate() + i);
                const recoveryDateStr = formatDate(`${recoveryDate.getFullYear()}-${String(recoveryDate.getMonth() + 1).padStart(2, "0")}-${String(recoveryDate.getDate()).padStart(2, "0")}`);
                if (recoveryDateStr === date) {
                    countOnDate++;
                }
            }
        });
        if (countOnDate >= 3) {
            alert("일정이 꽉 찼습니다! 3개 이하로 정리 후 다시 시도해 주세요.");
            setIsScheduleModalOpen(false);
            setSelectedTreatment(null);
            return;
        }
        // category_mid로 회복 기간 정보 가져오기 (소분류_리스트와 매칭)
        let recoveryDays = 0;
        let recoveryText = null;
        if (selectedTreatment.category_mid) {
            const recoveryInfo = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRecoveryInfoByCategoryMid"])(selectedTreatment.category_mid);
            if (recoveryInfo) {
                recoveryDays = recoveryInfo.recoveryMax; // 회복기간_max 기준
                recoveryText = recoveryInfo.recoveryText;
            }
        }
        // recoveryInfo가 없으면 기존 downtime 사용 (fallback)
        if (recoveryDays === 0) {
            recoveryDays = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseRecoveryPeriod"])(selectedTreatment.downtime) || 0;
        }
        const newSchedule = {
            id: Date.now(),
            treatmentId: selectedTreatment.treatment_id,
            procedureDate: date,
            procedureName: selectedTreatment.treatment_name || "시술명 없음",
            hospital: selectedTreatment.hospital_name || "병원명 없음",
            category: selectedTreatment.category_mid || selectedTreatment.category_large || "기타",
            categoryMid: selectedTreatment.category_mid || null,
            recoveryDays,
            recoveryText,
            procedureTime: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseProcedureTime"])(selectedTreatment.surgery_time) || 0,
            price: selectedTreatment.selling_price || null,
            rating: selectedTreatment.rating || 0,
            reviewCount: selectedTreatment.review_count || 0
        };
        schedules.push(newSchedule);
        localStorage.setItem("schedules", JSON.stringify(schedules));
        window.dispatchEvent(new Event("scheduleAdded"));
        alert(`${date}에 일정이 추가되었습니다!`);
        setIsScheduleModalOpen(false);
        setSelectedTreatment(null);
    };
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mb-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2 mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiTrendingUp"], {
                            className: "text-primary-main"
                        }, void 0, false, {
                            fileName: "[project]/components/HotConcernsSection.tsx",
                            lineNumber: 196,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-lg font-bold text-gray-900",
                            children: t("home.hotConcerns")
                        }, void 0, false, {
                            fileName: "[project]/components/HotConcernsSection.tsx",
                            lineNumber: 197,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/HotConcernsSection.tsx",
                    lineNumber: 195,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4",
                    children: [
                        ...Array(3)
                    ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-shrink-0 w-[150px] bg-gray-100 rounded-xl animate-pulse",
                            style: {
                                height: "200px"
                            }
                        }, i, false, {
                            fileName: "[project]/components/HotConcernsSection.tsx",
                            lineNumber: 203,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/HotConcernsSection.tsx",
                    lineNumber: 201,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/HotConcernsSection.tsx",
            lineNumber: 194,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2 mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiTrendingUp"], {
                        className: "text-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/HotConcernsSection.tsx",
                        lineNumber: 217,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: t("home.hotConcerns")
                    }, void 0, false, {
                        fileName: "[project]/components/HotConcernsSection.tsx",
                        lineNumber: 218,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HotConcernsSection.tsx",
                lineNumber: 216,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4",
                children: treatments.map((treatment)=>{
                    const isFavorite = favorites.has(treatment.treatment_id || 0);
                    const thumbnailUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getThumbnailUrl"])(treatment);
                    const price = treatment.selling_price ? `${Math.round(treatment.selling_price / 10000)}만원` : "가격 문의";
                    const rating = treatment.rating || 0;
                    const reviewCount = treatment.review_count || 0;
                    const discountRate = treatment.dis_rate ? `${treatment.dis_rate}%` : "";
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-shrink-0 w-[150px] bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer",
                        onClick: ()=>{
                            if (treatment.treatment_id) {
                                router.push(`/treatment/${treatment.treatment_id}`);
                            }
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative w-full aspect-[2/1] bg-gray-100 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: thumbnailUrl,
                                        alt: treatment.treatment_name || "시술 이미지",
                                        className: "w-full h-full object-cover",
                                        onError: (e)=>{
                                            const target = e.target;
                                            if (target.dataset.fallback === "true") {
                                                target.style.display = "none";
                                                return;
                                            }
                                            target.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="300"%3E%3Crect fill="%23f3f4f6" width="400" height="300"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="%239ca3af" font-size="24"%3E🏥%3C/text%3E%3C/svg%3E';
                                            target.dataset.fallback = "true";
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/components/HotConcernsSection.tsx",
                                        lineNumber: 249,
                                        columnNumber: 17
                                    }, this),
                                    discountRate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-bold z-10",
                                        children: discountRate
                                    }, void 0, false, {
                                        fileName: "[project]/components/HotConcernsSection.tsx",
                                        lineNumber: 266,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            handleFavoriteClick(treatment, e);
                                        },
                                        className: "absolute top-2 right-2 bg-white/90 hover:bg-white rounded-full p-1.5 transition-colors shadow-sm z-10",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHeart"], {
                                            className: `text-sm ${isFavorite ? "text-red-500 fill-red-500" : "text-gray-600"}`
                                        }, void 0, false, {
                                            fileName: "[project]/components/HotConcernsSection.tsx",
                                            lineNumber: 278,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/HotConcernsSection.tsx",
                                        lineNumber: 271,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            handleScheduleClick(treatment, e);
                                        },
                                        className: "absolute top-11 right-2 bg-white/90 hover:bg-white rounded-full p-1.5 transition-colors shadow-sm z-10",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCalendar"], {
                                            className: "text-sm text-primary-main"
                                        }, void 0, false, {
                                            fileName: "[project]/components/HotConcernsSection.tsx",
                                            lineNumber: 292,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/HotConcernsSection.tsx",
                                        lineNumber: 285,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/HotConcernsSection.tsx",
                                lineNumber: 248,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-3",
                                children: [
                                    treatment.hospital_name && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-500 mb-1 truncate",
                                        children: treatment.hospital_name
                                    }, void 0, false, {
                                        fileName: "[project]/components/HotConcernsSection.tsx",
                                        lineNumber: 300,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "font-semibold text-gray-900 mb-2 text-sm line-clamp-2 min-h-[2.5rem]",
                                        children: treatment.treatment_name
                                    }, void 0, false, {
                                        fileName: "[project]/components/HotConcernsSection.tsx",
                                        lineNumber: 306,
                                        columnNumber: 17
                                    }, this),
                                    rating > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-1 mb-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiStar"], {
                                                className: "text-yellow-400 fill-yellow-400 text-xs"
                                            }, void 0, false, {
                                                fileName: "[project]/components/HotConcernsSection.tsx",
                                                lineNumber: 313,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-semibold",
                                                children: rating.toFixed(1)
                                            }, void 0, false, {
                                                fileName: "[project]/components/HotConcernsSection.tsx",
                                                lineNumber: 314,
                                                columnNumber: 21
                                            }, this),
                                            reviewCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-gray-400",
                                                children: [
                                                    "(",
                                                    reviewCount.toLocaleString(),
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/HotConcernsSection.tsx",
                                                lineNumber: 318,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/HotConcernsSection.tsx",
                                        lineNumber: 312,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm font-bold text-primary-main",
                                        children: price
                                    }, void 0, false, {
                                        fileName: "[project]/components/HotConcernsSection.tsx",
                                        lineNumber: 326,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/HotConcernsSection.tsx",
                                lineNumber: 297,
                                columnNumber: 15
                            }, this)
                        ]
                    }, treatment.treatment_id, true, {
                        fileName: "[project]/components/HotConcernsSection.tsx",
                        lineNumber: 238,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/components/HotConcernsSection.tsx",
                lineNumber: 224,
                columnNumber: 7
            }, this),
            selectedTreatment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AddToScheduleModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isScheduleModalOpen,
                onClose: ()=>{
                    setIsScheduleModalOpen(false);
                    setSelectedTreatment(null);
                },
                onDateSelect: handleDateSelect,
                treatmentName: selectedTreatment.treatment_name || "시술명 없음",
                categoryMid: selectedTreatment.category_mid || null
            }, void 0, false, {
                fileName: "[project]/components/HotConcernsSection.tsx",
                lineNumber: 335,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/HotConcernsSection.tsx",
        lineNumber: 215,
        columnNumber: 5
    }, this);
}
_s(HotConcernsSection, "C4B7DjD8gu342cEsdieht6wXA+U=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = HotConcernsSection;
var _c;
__turbopack_context__.k.register(_c, "HotConcernsSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/AISkinAnalysisConsentModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AISkinAnalysisConsentModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function AISkinAnalysisConsentModal({ isOpen, onClose, onAgree }) {
    _s();
    const [isAgreed, setIsAgreed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    if (!isOpen) return null;
    const handleAgree = ()=>{
        setIsAgreed(true);
        onAgree();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[100] bg-black bg-opacity-40 flex items-center justify-center p-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-xl max-w-md w-full mx-auto max-h-[90vh] overflow-y-auto pb-20",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sticky top-0 bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-lg font-semibold text-gray-900",
                            children: "AI 피부 분석 테스트"
                        }, void 0, false, {
                            fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                            lineNumber: 31,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                className: "text-gray-700 text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                lineNumber: 36,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                            lineNumber: 32,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                    lineNumber: 30,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-4 py-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-center text-sm text-gray-600 mb-4",
                            children: [
                                "테스트의 총 소요시간은 ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    className: "text-gray-900",
                                    children: "3분"
                                }, void 0, false, {
                                    fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                    lineNumber: 43,
                                    columnNumber: 26
                                }, this),
                                "입니다."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center text-xs text-gray-700 mb-4 leading-relaxed",
                            children: [
                                "여러분의 얼굴을 촬영한 후 AI 기능을 통해 분석을 시작합니다.",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                    fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                    lineNumber: 47,
                                    columnNumber: 48
                                }, this),
                                "얼굴 사진 촬영에 동의하신다면 아래 '동의'를 클릭해 주세요.",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                    fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                    lineNumber: 48,
                                    columnNumber: 47
                                }, this),
                                "세부 내용은 아래에서 확인하시기 바랍니다."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gray-100 rounded-lg p-4 mb-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-800 leading-relaxed",
                                children: [
                                    "당사는 고객의 AI 피부 분석을 위한 내부 연구 목적으로 여러분의 얼굴 사진을 수집·분석합니다.",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                        lineNumber: 55,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                        lineNumber: 55,
                                        columnNumber: 21
                                    }, this),
                                    "촬영된 얼굴 사진은 AI 기능을 통해 특징 및 패턴을 분석하는 데 사용되며, 분석 과정에서 수집된 정보는 통계 및 알고리즘 개선에만 활용됩니다.",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                        lineNumber: 57,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                        lineNumber: 57,
                                        columnNumber: 21
                                    }, this),
                                    "수집된 개인정보는 연구 목적 달성 후 지체 없이 파기되며, 법령에 따라 보관이 필요한 경우 해당 기간 동안 안전하게 보관됩니다.",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                        lineNumber: 59,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                        lineNumber: 59,
                                        columnNumber: 21
                                    }, this),
                                    "해당 정보는 제3자에게 제공되지 않으며, 분석 업무 수행을 위해 필요한 경우에 한해 기술 협력업체에 위탁할 수 있습니다.",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                        lineNumber: 61,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                        lineNumber: 61,
                                        columnNumber: 21
                                    }, this),
                                    "개인정보 수집 및 이용에 동의하지 않으실 수 있으나, 동의하지 않을 경우 AI 분석 관련 서비스 참여가 제한될 수 있습니다."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                lineNumber: 53,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                            lineNumber: 52,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-center text-xs text-gray-700 mb-4",
                            children: "위 사항을 모두 확인했으며, 동의한다면 동의 버튼을 눌러주세요."
                        }, void 0, false, {
                            fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                            lineNumber: 66,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleAgree,
                            className: "w-full bg-primary-main hover:bg-[#2DB8A0] text-white py-3 rounded-lg font-semibold transition-colors mb-2 flex items-center justify-center gap-2",
                            children: [
                                "동의",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowRight"], {
                                    className: "text-lg"
                                }, void 0, false, {
                                    fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                                    lineNumber: 75,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                            lineNumber: 70,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "w-full text-xs text-gray-600 underline py-2",
                            children: "동의하지 않겠습니다"
                        }, void 0, false, {
                            fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                            lineNumber: 78,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/AISkinAnalysisConsentModal.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_s(AISkinAnalysisConsentModal, "EmMVXcdoT9yDOcbPtnp97OT8b88=");
_c = AISkinAnalysisConsentModal;
var _c;
__turbopack_context__.k.register(_c, "AISkinAnalysisConsentModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/AISkinAnalysisCameraModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AISkinAnalysisCameraModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function AISkinAnalysisCameraModal({ isOpen, onClose, onCapture }) {
    _s();
    const [stream, setStream] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isCaptured, setIsCaptured] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [capturedImage, setCapturedImage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const videoRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AISkinAnalysisCameraModal.useEffect": ()=>{
            if (isOpen && !isCaptured) {
                startCamera();
            } else if (!isOpen) {
                stopCamera();
                setIsCaptured(false);
                setCapturedImage(null);
            }
            return ({
                "AISkinAnalysisCameraModal.useEffect": ()=>{
                    stopCamera();
                }
            })["AISkinAnalysisCameraModal.useEffect"];
        }
    }["AISkinAnalysisCameraModal.useEffect"], [
        isOpen,
        isCaptured
    ]);
    const startCamera = async ()=>{
        try {
            const mediaStream = await navigator.mediaDevices.getUserMedia({
                video: {
                    facingMode: 'user',
                    width: {
                        ideal: 400
                    },
                    height: {
                        ideal: 400
                    }
                }
            });
            setStream(mediaStream);
            if (videoRef.current) {
                videoRef.current.srcObject = mediaStream;
            }
        } catch (err) {
            console.error('카메라 접근 오류:', err);
            alert('카메라 접근에 실패했습니다. 브라우저 권한을 확인해주세요.');
        }
    };
    const stopCamera = ()=>{
        if (stream) {
            stream.getTracks().forEach((track)=>track.stop());
            setStream(null);
        }
    };
    const capturePhoto = ()=>{
        if (!videoRef.current || !canvasRef.current) return;
        const video = videoRef.current;
        const canvas = canvasRef.current;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        // 비디오를 미러링하므로 다시 뒤집어서 그리기
        ctx.translate(canvas.width, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(video, 0, 0);
        // Canvas를 이미지 데이터로 변환
        const imageData = canvas.toDataURL('image/png');
        setCapturedImage(imageData);
        setIsCaptured(true);
        stopCamera();
    };
    const handleConfirm = ()=>{
        if (capturedImage) {
            onCapture(capturedImage);
            onClose();
        }
    };
    const handleRetake = ()=>{
        setIsCaptured(false);
        setCapturedImage(null);
        startCamera();
    };
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[100] bg-white overflow-y-auto max-w-md mx-auto left-1/2 transform -translate-x-1/2 pb-20",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sticky top-0 bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between z-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-10"
                    }, void 0, false, {
                        fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-lg font-bold text-gray-900",
                        children: "얼굴 촬영"
                    }, void 0, false, {
                        fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onClose,
                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                            className: "text-gray-700 text-xl"
                        }, void 0, false, {
                            fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                            lineNumber: 112,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                        lineNumber: 108,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center px-4 py-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-center text-lg font-semibold text-gray-900 mb-8",
                        children: "얼굴을 화면에 맞춰주세요"
                    }, void 0, false, {
                        fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                        lineNumber: 118,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative w-64 h-96 border-2 border-gray-400 rounded-full overflow-hidden bg-gray-100 mb-8",
                        children: [
                            !isCaptured ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("video", {
                                ref: videoRef,
                                autoPlay: true,
                                playsInline: true,
                                className: "w-full h-full object-cover scale-x-[-1]"
                            }, void 0, false, {
                                fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                                lineNumber: 124,
                                columnNumber: 13
                            }, this) : capturedImage ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: capturedImage,
                                alt: "촬영된 사진",
                                className: "w-full h-full object-cover"
                            }, void 0, false, {
                                fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                                lineNumber: 131,
                                columnNumber: 13
                            }, this) : null,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                                ref: canvasRef,
                                className: "hidden"
                            }, void 0, false, {
                                fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                                lineNumber: 137,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                        lineNumber: 122,
                        columnNumber: 9
                    }, this),
                    !isCaptured ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: capturePhoto,
                        className: "w-full max-w-sm bg-primary-main hover:bg-[#2DB8A0] text-white py-3 rounded-lg font-semibold transition-colors flex items-center justify-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"], {
                                className: "text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                                lineNumber: 145,
                                columnNumber: 13
                            }, this),
                            "촬영"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                        lineNumber: 141,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-full max-w-sm flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleRetake,
                                className: "flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 rounded-lg font-semibold transition-colors",
                                children: "다시 촬영"
                            }, void 0, false, {
                                fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                                lineNumber: 150,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleConfirm,
                                className: "flex-1 bg-primary-main hover:bg-[#2DB8A0] text-white py-3 rounded-lg font-semibold transition-colors",
                                children: "확인"
                            }, void 0, false, {
                                fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                                lineNumber: 156,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                        lineNumber: 149,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/AISkinAnalysisCameraModal.tsx",
        lineNumber: 103,
        columnNumber: 5
    }, this);
}
_s(AISkinAnalysisCameraModal, "E52fenhe2RfysgFIZRiGrVCXVRM=");
_c = AISkinAnalysisCameraModal;
var _c;
__turbopack_context__.k.register(_c, "AISkinAnalysisCameraModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/AIAnalysisBanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AIAnalysisBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisConsentModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AISkinAnalysisConsentModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisCameraModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AISkinAnalysisCameraModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function AIAnalysisBanner() {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [isConsentModalOpen, setIsConsentModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCameraModalOpen, setIsCameraModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const handleStartAnalysis = ()=>{
        setIsConsentModalOpen(true);
    };
    const handleConsentAgree = ()=>{
        setIsConsentModalOpen(false);
        setIsCameraModalOpen(true);
    };
    const handleCapture = (imageData)=>{
        // 이미지를 localStorage에 저장
        localStorage.setItem("capturedFaceImage", imageData);
        // 결과 페이지로 이동 (나중에 구현)
        // router.push("/ai-skin-analysis-result");
        alert("AI 피부 분석이 완료되었습니다! (결과 페이지는 추후 구현 예정)");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6 border border-gray-200 rounded-xl p-4 bg-gradient-to-r from-primary-light/20 to-primary-main/20 relative overflow-hidden shadow-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative z-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiZap"], {
                                        className: "text-primary-main text-xl"
                                    }, void 0, false, {
                                        fileName: "[project]/components/AIAnalysisBanner.tsx",
                                        lineNumber: 38,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-bold text-gray-900",
                                        children: t("banner.ai.title")
                                    }, void 0, false, {
                                        fileName: "[project]/components/AIAnalysisBanner.tsx",
                                        lineNumber: 39,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/AIAnalysisBanner.tsx",
                                lineNumber: 37,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-gray-700 mb-3",
                                children: t("banner.ai.desc")
                            }, void 0, false, {
                                fileName: "[project]/components/AIAnalysisBanner.tsx",
                                lineNumber: 43,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleStartAnalysis,
                                        className: "bg-primary-main hover:bg-[#2DB8A0] text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors",
                                        children: t("banner.ai.start")
                                    }, void 0, false, {
                                        fileName: "[project]/components/AIAnalysisBanner.tsx",
                                        lineNumber: 45,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold transition-colors",
                                        children: t("banner.ai.reviews")
                                    }, void 0, false, {
                                        fileName: "[project]/components/AIAnalysisBanner.tsx",
                                        lineNumber: 51,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/AIAnalysisBanner.tsx",
                                lineNumber: 44,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/AIAnalysisBanner.tsx",
                        lineNumber: 36,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute right-4 top-1/2 transform -translate-y-1/2 opacity-10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-24 h-24 bg-primary-main rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/components/AIAnalysisBanner.tsx",
                            lineNumber: 57,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/AIAnalysisBanner.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/AIAnalysisBanner.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisConsentModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isConsentModalOpen,
                onClose: ()=>setIsConsentModalOpen(false),
                onAgree: handleConsentAgree
            }, void 0, false, {
                fileName: "[project]/components/AIAnalysisBanner.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisCameraModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isCameraModalOpen,
                onClose: ()=>setIsCameraModalOpen(false),
                onCapture: handleCapture
            }, void 0, false, {
                fileName: "[project]/components/AIAnalysisBanner.tsx",
                lineNumber: 67,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(AIAnalysisBanner, "pnh4djzJwCZYM+tRqdEEZtmP3Q8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = AIAnalysisBanner;
var _c;
__turbopack_context__.k.register(_c, "AIAnalysisBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/PromotionBanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PromotionBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisConsentModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AISkinAnalysisConsentModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisCameraModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AISkinAnalysisCameraModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function PromotionBanner() {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [currentSlide, setCurrentSlide] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isConsentModalOpen, setIsConsentModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCameraModalOpen, setIsCameraModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const bannerSlides = [
        {
            id: 1,
            image: "/banners/banner-1.png"
        },
        {
            id: 2,
            image: "/banners/banner-2.png"
        },
        {
            id: 3,
            image: "/banners/banner-3.png"
        },
        {
            id: 4,
            image: "/banners/banner-4.png"
        },
        {
            id: 5,
            image: "/banners/banner-5.png"
        },
        {
            id: 6,
            image: "/banners/banner-6.png"
        },
        {
            id: 7,
            image: "/banners/banner-7.png"
        },
        {
            id: 8,
            image: "/banners/banner-8.png"
        }
    ];
    const totalSlides = bannerSlides.length;
    // Auto slide
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PromotionBanner.useEffect": ()=>{
            const interval = setInterval({
                "PromotionBanner.useEffect.interval": ()=>{
                    setCurrentSlide({
                        "PromotionBanner.useEffect.interval": (prev)=>(prev + 1) % totalSlides
                    }["PromotionBanner.useEffect.interval"]);
                }
            }["PromotionBanner.useEffect.interval"], 5000); // 5초마다 자동 슬라이드
            return ({
                "PromotionBanner.useEffect": ()=>clearInterval(interval)
            })["PromotionBanner.useEffect"];
        }
    }["PromotionBanner.useEffect"], [
        totalSlides
    ]);
    const goToPrevious = ()=>{
        setCurrentSlide((prev)=>(prev - 1 + totalSlides) % totalSlides);
    };
    const goToNext = ()=>{
        setCurrentSlide((prev)=>(prev + 1) % totalSlides);
    };
    const goToSlide = (index)=>{
        setCurrentSlide(index);
    };
    const handleAIBannerClick = ()=>{
        setIsConsentModalOpen(true);
    };
    const handleConsentAgree = ()=>{
        setIsConsentModalOpen(false);
        setIsCameraModalOpen(true);
    };
    const handleCapture = (imageData)=>{
        localStorage.setItem("capturedFaceImage", imageData);
        alert("AI 피부 분석이 완료되었습니다! (결과 페이지는 추후 구현 예정)");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6 relative rounded-xl overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative h-48",
                    children: [
                        bannerSlides.map((slide, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `absolute inset-0 transition-opacity duration-500 cursor-pointer ${index === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"}`,
                                onClick: slide.isAIBanner ? handleAIBannerClick : slide.onClick,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: slide.image,
                                    alt: `배너 ${slide.id}`,
                                    fill: true,
                                    className: "object-cover rounded-xl",
                                    priority: index === 0,
                                    unoptimized: true
                                }, void 0, false, {
                                    fileName: "[project]/components/PromotionBanner.tsx",
                                    lineNumber: 107,
                                    columnNumber: 15
                                }, this)
                            }, slide.id, false, {
                                fileName: "[project]/components/PromotionBanner.tsx",
                                lineNumber: 100,
                                columnNumber: 13
                            }, this)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute bottom-4 right-4 bg-black bg-opacity-30 px-3 py-1 rounded-full text-xs z-20",
                            children: [
                                currentSlide + 1,
                                "/",
                                totalSlides
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PromotionBanner.tsx",
                            lineNumber: 119,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: goToPrevious,
                            className: "absolute left-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-20 p-2 rounded-full hover:bg-opacity-30 transition-colors z-20",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoChevronBack"], {
                                className: "text-white text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/PromotionBanner.tsx",
                                lineNumber: 128,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/PromotionBanner.tsx",
                            lineNumber: 124,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: goToNext,
                            className: "absolute right-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-20 p-2 rounded-full hover:bg-opacity-30 transition-colors z-20",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoChevronForward"], {
                                className: "text-white text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/PromotionBanner.tsx",
                                lineNumber: 134,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/PromotionBanner.tsx",
                            lineNumber: 130,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2 z-20",
                            children: bannerSlides.map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>goToSlide(index),
                                    className: `w-2 h-2 rounded-full transition-all ${index === currentSlide ? "bg-white w-6" : "bg-white bg-opacity-50"}`
                                }, index, false, {
                                    fileName: "[project]/components/PromotionBanner.tsx",
                                    lineNumber: 140,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/PromotionBanner.tsx",
                            lineNumber: 138,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/PromotionBanner.tsx",
                    lineNumber: 98,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/PromotionBanner.tsx",
                lineNumber: 97,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisConsentModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isConsentModalOpen,
                onClose: ()=>setIsConsentModalOpen(false),
                onAgree: handleConsentAgree
            }, void 0, false, {
                fileName: "[project]/components/PromotionBanner.tsx",
                lineNumber: 154,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisCameraModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isCameraModalOpen,
                onClose: ()=>setIsCameraModalOpen(false),
                onCapture: handleCapture
            }, void 0, false, {
                fileName: "[project]/components/PromotionBanner.tsx",
                lineNumber: 160,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(PromotionBanner, "LnNva8V0weG1AagxODNBN3Tfnx4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = PromotionBanner;
var _c;
__turbopack_context__.k.register(_c, "PromotionBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/AISkinAnalysisButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AISkinAnalysisButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisConsentModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AISkinAnalysisConsentModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisCameraModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AISkinAnalysisCameraModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function AISkinAnalysisButton() {
    _s();
    const [isConsentModalOpen, setIsConsentModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCameraModalOpen, setIsCameraModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isHovered, setIsHovered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [imageError, setImageError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleStartAnalysis = ()=>{
        setIsConsentModalOpen(true);
    };
    const handleConsentAgree = ()=>{
        setIsConsentModalOpen(false);
        setIsCameraModalOpen(true);
    };
    const handleCapture = (imageData)=>{
        // 이미지를 localStorage에 저장
        localStorage.setItem("capturedFaceImage", imageData);
        // 결과 페이지로 이동 (나중에 구현)
        alert("AI 피부 분석이 완료되었습니다! (결과 페이지는 추후 구현 예정)");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed bottom-20 right-0 left-0 z-40 pointer-events-none max-w-md mx-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: handleStartAnalysis,
                    onMouseEnter: ()=>setIsHovered(true),
                    onMouseLeave: ()=>setIsHovered(false),
                    className: "pointer-events-auto absolute bottom-0 right-4 transition-all duration-300 hover:scale-110 active:scale-95 touch-manipulation",
                    style: {
                        // 터치 영역 확보 (최소 44x44px)
                        minWidth: "56px",
                        minHeight: "56px",
                        background: "transparent",
                        border: "none",
                        padding: 0
                    },
                    "aria-label": "AI 피부 분석 시작",
                    children: !imageError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: isHovered ? "/ai-skin-analysis-button-hover.png" : "/ai-skin-analysis-button.png",
                        alt: "AI 피부 분석",
                        className: "w-14 h-14 sm:w-16 sm:h-16 object-contain drop-shadow-lg",
                        onError: ()=>setImageError(true)
                    }, void 0, false, {
                        fileName: "[project]/components/AISkinAnalysisButton.tsx",
                        lineNumber: 50,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-14 h-14 sm:w-16 sm:h-16 bg-pink-200 hover:bg-pink-300 active:bg-pink-400 rounded-full flex items-center justify-center shadow-lg",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSearch"], {
                            className: "text-xl sm:text-2xl text-pink-700"
                        }, void 0, false, {
                            fileName: "[project]/components/AISkinAnalysisButton.tsx",
                            lineNumber: 62,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/AISkinAnalysisButton.tsx",
                        lineNumber: 61,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/AISkinAnalysisButton.tsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/AISkinAnalysisButton.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisConsentModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isConsentModalOpen,
                onClose: ()=>setIsConsentModalOpen(false),
                onAgree: handleConsentAgree
            }, void 0, false, {
                fileName: "[project]/components/AISkinAnalysisButton.tsx",
                lineNumber: 68,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisCameraModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isCameraModalOpen,
                onClose: ()=>setIsCameraModalOpen(false),
                onCapture: handleCapture
            }, void 0, false, {
                fileName: "[project]/components/AISkinAnalysisButton.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(AISkinAnalysisButton, "iCfrchbVJ0OF3mKVCXUFXks8TBI=");
_c = AISkinAnalysisButton;
var _c;
__turbopack_context__.k.register(_c, "AISkinAnalysisButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/PopularReviewsSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PopularReviewsSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
// 인기 리뷰 데이터 (조회수/좋아요 기준 상위)
const popularReviews = [
    {
        id: 1,
        category: "후기",
        username: "베소통리소",
        avatar: "🐹",
        content: "원래 눈 라인이 마음에 들지 않아서 재수술을 고민하게 되었어요 첫 수술로 잡았던 라인이 너무 낮기도 하고 여전히 눈매가 흐릿해...",
        images: [
            "eye1",
            "eye2"
        ],
        timestamp: "18시간 전",
        upvotes: 62,
        comments: 198,
        views: 5722
    },
    {
        id: 5,
        category: "후기",
        username: "뷰티러버",
        avatar: "✨",
        content: "강남역 근처 클리닉에서 리쥬란 힐러 받고 왔어요! 처음 받아보는 거라 조금 걱정됐는데 원장님이 친절하게 설명해주셔서...",
        images: [
            "skin1"
        ],
        timestamp: "2일 전",
        upvotes: 45,
        comments: 72,
        views: 3200,
        likes: 120
    },
    {
        id: 2,
        category: "후기",
        username: "홀짝댄스",
        avatar: "🐱",
        content: "비티에서 윤곽3종이랑 무보형물로 코수술 하고 왔당 ㅎㅎㅎㅎ 코는 이승호원장님, 윤곽...",
        images: [
            "face1",
            "face2"
        ],
        timestamp: "1일 전",
        upvotes: 29,
        comments: 58,
        views: 2648
    },
    {
        id: 4,
        category: "후기",
        username: "춤추는아미고",
        avatar: "🦊",
        content: "와.. 티타늄 맛집은 테이아였네?? ;; 나 요즘 턱선이랑 볼살이 너무 축 처져서 테이아의원에서 티타늄리프팅 받아봤거...",
        images: [
            "before",
            "after"
        ],
        timestamp: "1일 전",
        upvotes: 29,
        comments: 50,
        views: 2604
    }
];
function PopularReviewsSection() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const handleReviewClick = ()=>{
        router.push("/community?tab=review");
    };
    const handleMoreClick = (e)=>{
        e.stopPropagation();
        router.push("/community?tab=review");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: t("home.trendingReviews")
                    }, void 0, false, {
                        fileName: "[project]/components/PopularReviewsSection.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleMoreClick,
                        className: "text-sm text-primary-main font-medium flex items-center gap-1 hover:text-primary-dark transition-colors",
                        children: [
                            t("home.reviewMore"),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                                className: "text-xs"
                            }, void 0, false, {
                                fileName: "[project]/components/PopularReviewsSection.tsx",
                                lineNumber: 96,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/PopularReviewsSection.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/PopularReviewsSection.tsx",
                lineNumber: 89,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-4 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4",
                children: popularReviews.map((review)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleReviewClick,
                        className: "flex-shrink-0 w-80 bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all text-left",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full h-40 bg-gradient-to-br from-gray-100 to-gray-200 relative",
                                children: [
                                    review.images && review.images.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-full h-full flex items-center justify-center text-gray-400 text-xs",
                                        children: "이미지"
                                    }, void 0, false, {
                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                        lineNumber: 110,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-full h-full flex items-center justify-center text-gray-300 text-xs",
                                        children: "이미지 없음"
                                    }, void 0, false, {
                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                        lineNumber: 114,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute top-3 left-3",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "bg-primary-main text-white px-2 py-1 rounded-full text-xs font-medium",
                                            children: review.category
                                        }, void 0, false, {
                                            fileName: "[project]/components/PopularReviewsSection.tsx",
                                            lineNumber: 120,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                        lineNumber: 119,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/PopularReviewsSection.tsx",
                                lineNumber: 108,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 mb-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-lg",
                                                children: review.avatar
                                            }, void 0, false, {
                                                fileName: "[project]/components/PopularReviewsSection.tsx",
                                                lineNumber: 130,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-semibold text-gray-900",
                                                children: review.username
                                            }, void 0, false, {
                                                fileName: "[project]/components/PopularReviewsSection.tsx",
                                                lineNumber: 133,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-gray-500",
                                                children: review.timestamp
                                            }, void 0, false, {
                                                fileName: "[project]/components/PopularReviewsSection.tsx",
                                                lineNumber: 136,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                        lineNumber: 129,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-gray-800 mb-3 line-clamp-2 leading-relaxed",
                                        children: review.content
                                    }, void 0, false, {
                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                        lineNumber: 140,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3 pt-2 border-t border-gray-100",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-1 text-gray-600",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowUp"], {
                                                        className: "text-primary-main text-sm"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                                        lineNumber: 147,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs",
                                                        children: review.upvotes
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                                        lineNumber: 148,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/PopularReviewsSection.tsx",
                                                lineNumber: 146,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-1 text-gray-600",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiMessageCircle"], {
                                                        className: "text-primary-main text-sm"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                                        lineNumber: 151,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs",
                                                        children: review.comments
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                                        lineNumber: 152,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/PopularReviewsSection.tsx",
                                                lineNumber: 150,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-1 text-gray-600",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiEye"], {
                                                        className: "text-gray-400 text-sm"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                                        lineNumber: 155,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs text-gray-400",
                                                        children: review.views.toLocaleString()
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                                        lineNumber: 156,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/PopularReviewsSection.tsx",
                                                lineNumber: 154,
                                                columnNumber: 17
                                            }, this),
                                            review.likes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-1 text-gray-600 ml-auto",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHeart"], {
                                                        className: "text-primary-main fill-primary-main text-sm"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                                        lineNumber: 162,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs",
                                                        children: review.likes
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                                        lineNumber: 163,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/PopularReviewsSection.tsx",
                                                lineNumber: 161,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/PopularReviewsSection.tsx",
                                        lineNumber: 145,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/PopularReviewsSection.tsx",
                                lineNumber: 127,
                                columnNumber: 13
                            }, this)
                        ]
                    }, review.id, true, {
                        fileName: "[project]/components/PopularReviewsSection.tsx",
                        lineNumber: 102,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/PopularReviewsSection.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/PopularReviewsSection.tsx",
        lineNumber: 88,
        columnNumber: 5
    }, this);
}
_s(PopularReviewsSection, "e/Js9Umc9/cISp9Ww2MTCpYgglc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = PopularReviewsSection;
var _c;
__turbopack_context__.k.register(_c, "PopularReviewsSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/OverlayBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OverlayBar
]);
"use client";
function OverlayBar() {
    return null;
}
_c = OverlayBar;
var _c;
__turbopack_context__.k.register(_c, "OverlayBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/BottomNavigation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BottomNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const navItems = [
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHome"],
        labelKey: "nav.home",
        path: "/"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCompass"],
        labelKey: "nav.explore",
        path: "/explore"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiUsers"],
        labelKey: "nav.community",
        path: "/community"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCalendar"],
        labelKey: "nav.schedule",
        path: "/schedule"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiUser"],
        labelKey: "nav.mypage",
        path: "/mypage"
    }
];
function BottomNavigation({ disabled = false }) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: `fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 z-50 ${disabled ? "pointer-events-none" : ""}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-around items-center py-2",
            children: navItems.map((item)=>{
                const Icon = item.icon;
                const isActive = pathname === item.path;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: item.path,
                    className: `flex flex-col items-center justify-center gap-1 py-1 px-2 min-w-0 flex-1 transition-colors ${disabled ? "text-gray-300 cursor-not-allowed" : isActive ? "text-primary-main" : "text-gray-500"}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                            className: `text-xl ${disabled ? "text-gray-300" : isActive ? "text-primary-main" : "text-gray-500"}`
                        }, void 0, false, {
                            fileName: "[project]/components/BottomNavigation.tsx",
                            lineNumber: 43,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: `text-xs whitespace-nowrap ${disabled ? "text-gray-300" : isActive ? "text-primary-main font-medium" : "text-gray-500"}`,
                            children: t(item.labelKey)
                        }, void 0, false, {
                            fileName: "[project]/components/BottomNavigation.tsx",
                            lineNumber: 52,
                            columnNumber: 15
                        }, this)
                    ]
                }, item.path, true, {
                    fileName: "[project]/components/BottomNavigation.tsx",
                    lineNumber: 32,
                    columnNumber: 13
                }, this);
            })
        }, void 0, false, {
            fileName: "[project]/components/BottomNavigation.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/BottomNavigation.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_s(BottomNavigation, "xidiIFVahZXU1vxN+08Jg/l1pJo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = BottomNavigation;
var _c;
__turbopack_context__.k.register(_c, "BottomNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ProcedureFilterModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProcedureFilterModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const DURATION_OPTIONS = [
    {
        value: "same-day",
        label: "당일"
    },
    {
        value: "half-day",
        label: "반나절"
    },
    {
        value: "1-day",
        label: "1일"
    },
    {
        value: "2-3-days",
        label: "2~3일"
    },
    {
        value: "surgery",
        label: "수술 포함"
    }
];
const RECOVERY_OPTIONS = [
    {
        value: "same-day",
        label: "당일 생활 가능"
    },
    {
        value: "1-3-days",
        label: "1~3일"
    },
    {
        value: "4-7-days",
        label: "4~7일"
    },
    {
        value: "1-week-plus",
        label: "1주 이상"
    }
];
const BUDGET_OPTIONS = [
    {
        value: "under-50",
        label: "~50만원"
    },
    {
        value: "50-100",
        label: "50~100만원"
    },
    {
        value: "100-200",
        label: "100~200만원"
    },
    {
        value: "200-plus",
        label: "200만원+"
    }
];
function ProcedureFilterModal({ isOpen, onClose, onApply, currentFilter }) {
    _s();
    const [filter, setFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(currentFilter);
    const handleOptionClick = (type, value)=>{
        setFilter((prev)=>({
                ...prev,
                [type]: prev[type] === value ? null : value
            }));
    };
    const handleApply = ()=>{
        onApply(filter);
        onClose();
    };
    const handleReset = ()=>{
        const resetFilter = {
            duration: null,
            recovery: null,
            budget: null
        };
        setFilter(resetFilter);
    // 초기화만 하고 모달은 열어둠
    };
    const hasActiveFilters = filter.duration !== null || filter.recovery !== null || filter.budget !== null;
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                onClick: onClose,
                className: "jsx-c94ef0859b828328" + " " + "fixed inset-0 bg-black/50 z-40"
            }, void 0, false, {
                fileName: "[project]/components/ProcedureFilterModal.tsx",
                lineNumber: 84,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-c94ef0859b828328" + " " + "fixed bottom-0 left-0 right-0 bg-white rounded-t-3xl z-50 max-w-md mx-auto shadow-2xl animate-slide-up pb-20",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-c94ef0859b828328" + " " + "flex items-center justify-between p-4 border-b border-gray-200",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-c94ef0859b828328" + " " + "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiFilter"], {
                                        className: "text-primary-main"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureFilterModal.tsx",
                                        lineNumber: 94,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "jsx-c94ef0859b828328" + " " + "text-lg font-bold text-gray-900",
                                        children: "필터"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureFilterModal.tsx",
                                        lineNumber: 95,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ProcedureFilterModal.tsx",
                                lineNumber: 93,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClose,
                                className: "jsx-c94ef0859b828328" + " " + "p-2 hover:bg-gray-100 rounded-full transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                    className: "text-gray-600"
                                }, void 0, false, {
                                    fileName: "[project]/components/ProcedureFilterModal.tsx",
                                    lineNumber: 101,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureFilterModal.tsx",
                                lineNumber: 97,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureFilterModal.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-c94ef0859b828328" + " " + "px-4 py-6 max-h-[60vh] overflow-y-auto",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-c94ef0859b828328" + " " + "mb-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "jsx-c94ef0859b828328" + " " + "text-sm font-semibold text-gray-900 mb-3",
                                        children: "소요시간 기반 일정표"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureFilterModal.tsx",
                                        lineNumber: 109,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-c94ef0859b828328" + " " + "flex flex-wrap gap-2",
                                        children: DURATION_OPTIONS.map((option)=>{
                                            const isSelected = filter.duration === option.value;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>handleOptionClick("duration", option.value),
                                                className: "jsx-c94ef0859b828328" + " " + `px-4 py-2 rounded-full text-sm font-medium transition-colors ${isSelected ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                                                children: option.label
                                            }, option.value, false, {
                                                fileName: "[project]/components/ProcedureFilterModal.tsx",
                                                lineNumber: 116,
                                                columnNumber: 19
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureFilterModal.tsx",
                                        lineNumber: 112,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ProcedureFilterModal.tsx",
                                lineNumber: 108,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-c94ef0859b828328" + " " + "mb-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "jsx-c94ef0859b828328" + " " + "text-sm font-semibold text-gray-900 mb-3",
                                        children: "회복기간"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureFilterModal.tsx",
                                        lineNumber: 134,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-c94ef0859b828328" + " " + "flex flex-wrap gap-2",
                                        children: RECOVERY_OPTIONS.map((option)=>{
                                            const isSelected = filter.recovery === option.value;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>handleOptionClick("recovery", option.value),
                                                className: "jsx-c94ef0859b828328" + " " + `px-4 py-2 rounded-full text-sm font-medium transition-colors ${isSelected ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                                                children: option.label
                                            }, option.value, false, {
                                                fileName: "[project]/components/ProcedureFilterModal.tsx",
                                                lineNumber: 141,
                                                columnNumber: 19
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureFilterModal.tsx",
                                        lineNumber: 137,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ProcedureFilterModal.tsx",
                                lineNumber: 133,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-c94ef0859b828328" + " " + "mb-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "jsx-c94ef0859b828328" + " " + "text-sm font-semibold text-gray-900 mb-3",
                                        children: "예산 비용"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureFilterModal.tsx",
                                        lineNumber: 159,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-c94ef0859b828328" + " " + "flex flex-wrap gap-2",
                                        children: BUDGET_OPTIONS.map((option)=>{
                                            const isSelected = filter.budget === option.value;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>handleOptionClick("budget", option.value),
                                                className: "jsx-c94ef0859b828328" + " " + `px-4 py-2 rounded-full text-sm font-medium transition-colors ${isSelected ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                                                children: option.label
                                            }, option.value, false, {
                                                fileName: "[project]/components/ProcedureFilterModal.tsx",
                                                lineNumber: 166,
                                                columnNumber: 19
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureFilterModal.tsx",
                                        lineNumber: 162,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ProcedureFilterModal.tsx",
                                lineNumber: 158,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureFilterModal.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-c94ef0859b828328" + " " + "sticky bottom-0 bg-white px-4 py-4 border-t border-gray-200 flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleReset,
                                className: "jsx-c94ef0859b828328" + " " + "flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 rounded-lg text-sm font-semibold transition-colors",
                                children: "초기화"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureFilterModal.tsx",
                                lineNumber: 185,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleApply,
                                disabled: !hasActiveFilters,
                                className: "jsx-c94ef0859b828328" + " " + `flex-1 py-3 rounded-lg text-sm font-semibold transition-colors ${hasActiveFilters ? "bg-primary-main hover:bg-[#2DB8A0] text-white" : "bg-gray-200 text-gray-400 cursor-not-allowed"}`,
                                children: "찾기"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureFilterModal.tsx",
                                lineNumber: 191,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureFilterModal.tsx",
                        lineNumber: 184,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureFilterModal.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "c94ef0859b828328",
                children: "@keyframes slide-up{0%{transform:translateY(100%)}to{transform:translateY(0)}}.animate-slide-up.jsx-c94ef0859b828328{animation:.3s ease-out slide-up}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true);
}
_s(ProcedureFilterModal, "EQRPV/04Oqax3SOZe6h2rpuFIxI=");
_c = ProcedureFilterModal;
var _c;
__turbopack_context__.k.register(_c, "ProcedureFilterModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ProcedureRecommendation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProcedureRecommendation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProcedureFilterModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ProcedureFilterModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AddToScheduleModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AddToScheduleModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
// 필터 옵션 상수 (ProcedureFilterModal과 동일)
const DURATION_OPTIONS = [
    {
        value: "same-day",
        label: "당일"
    },
    {
        value: "half-day",
        label: "반나절"
    },
    {
        value: "1-day",
        label: "1일"
    },
    {
        value: "2-3-days",
        label: "2~3일"
    },
    {
        value: "surgery",
        label: "수술 포함"
    }
];
const RECOVERY_OPTIONS = [
    {
        value: "same-day",
        label: "당일 생활 가능"
    },
    {
        value: "1-3-days",
        label: "1~3일"
    },
    {
        value: "4-7-days",
        label: "4~7일"
    },
    {
        value: "1-week-plus",
        label: "1주 이상"
    }
];
const BUDGET_OPTIONS = [
    {
        value: "under-50",
        label: "~50만원"
    },
    {
        value: "50-100",
        label: "50~100만원"
    },
    {
        value: "100-200",
        label: "100~200만원"
    },
    {
        value: "200-plus",
        label: "200만원+"
    }
];
// 카테고리별 시술 데이터
const PROCEDURES_BY_CATEGORY = {
    피부관리: [
        {
            id: 1,
            procedure: "리쥬란 힐러",
            hospital: "강남비비의원",
            price: "12만원",
            rating: "9.8",
            procedureTime: "30분",
            recoveryPeriod: "1일",
            matchesBudget: true,
            category: "피부관리",
            subCategory: "필러"
        },
        {
            id: 2,
            procedure: "써마지",
            hospital: "압구정 클리닉",
            price: "35만원",
            rating: "9.7",
            procedureTime: "90분",
            recoveryPeriod: "0일",
            matchesBudget: true,
            category: "피부관리",
            subCategory: "리프팅"
        },
        {
            id: 3,
            procedure: "울쎄라",
            hospital: "신사역 메디컬",
            price: "45만원",
            rating: "9.9",
            procedureTime: "60분",
            recoveryPeriod: "1일",
            matchesBudget: true,
            category: "피부관리",
            subCategory: "리프팅"
        },
        {
            id: 4,
            procedure: "프락셀",
            hospital: "홍대 의원",
            price: "15만원",
            rating: "9.6",
            procedureTime: "30분",
            recoveryPeriod: "2일",
            matchesBudget: true,
            category: "피부관리",
            subCategory: "레이저"
        },
        {
            id: 5,
            procedure: "아쿠아필",
            hospital: "강남 피부과",
            price: "8만원",
            rating: "9.5",
            procedureTime: "20분",
            recoveryPeriod: "0일",
            matchesBudget: true,
            category: "피부관리",
            subCategory: "관리"
        }
    ],
    "흉터/자국": [
        {
            id: 6,
            procedure: "프락셀 스카",
            hospital: "강남비비의원",
            price: "20만원",
            rating: "9.8",
            procedureTime: "40분",
            recoveryPeriod: "3일",
            matchesBudget: true,
            category: "흉터/자국",
            subCategory: "레이저"
        },
        {
            id: 7,
            procedure: "마이크로 니들링",
            hospital: "압구정 클리닉",
            price: "12만원",
            rating: "9.6",
            procedureTime: "30분",
            recoveryPeriod: "2일",
            matchesBudget: true,
            category: "흉터/자국",
            subCategory: "시술"
        },
        {
            id: 8,
            procedure: "CO2 레이저",
            hospital: "신사역 메디컬",
            price: "25만원",
            rating: "9.7",
            procedureTime: "45분",
            recoveryPeriod: "5일",
            matchesBudget: true,
            category: "흉터/자국",
            subCategory: "레이저"
        }
    ],
    "윤곽/리프팅": [
        {
            id: 9,
            procedure: "인모드 리프팅",
            hospital: "신사역 메디컬",
            price: "25만원",
            rating: "9.9",
            procedureTime: "60분",
            recoveryPeriod: "2일",
            matchesBudget: true,
            category: "윤곽/리프팅",
            subCategory: "리프팅"
        },
        {
            id: 10,
            procedure: "슈링크 유니버스",
            hospital: "홍대 의원",
            price: "18만원",
            rating: "9.7",
            procedureTime: "45분",
            recoveryPeriod: "1일",
            matchesBudget: true,
            category: "윤곽/리프팅",
            subCategory: "리프팅"
        },
        {
            id: 11,
            procedure: "울쎄라 더블",
            hospital: "강남비비의원",
            price: "50만원",
            rating: "9.8",
            procedureTime: "90분",
            recoveryPeriod: "2일",
            matchesBudget: true,
            category: "윤곽/리프팅",
            subCategory: "리프팅"
        },
        {
            id: 12,
            procedure: "실리프팅",
            hospital: "압구정 클리닉",
            price: "30만원",
            rating: "9.6",
            procedureTime: "30분",
            recoveryPeriod: "1일",
            matchesBudget: true,
            category: "윤곽/리프팅",
            subCategory: "실"
        }
    ],
    코성형: [
        {
            id: 13,
            procedure: "코필러",
            hospital: "강남비비의원",
            price: "15만원",
            rating: "9.7",
            procedureTime: "20분",
            recoveryPeriod: "1일",
            matchesBudget: true,
            category: "코성형",
            subCategory: "필러"
        },
        {
            id: 14,
            procedure: "코 리프팅",
            hospital: "압구정 클리닉",
            price: "22만원",
            rating: "9.8",
            procedureTime: "30분",
            recoveryPeriod: "2일",
            matchesBudget: true,
            category: "코성형",
            subCategory: "리프팅"
        }
    ],
    눈성형: [
        {
            id: 15,
            procedure: "눈밑 필러",
            hospital: "신사역 메디컬",
            price: "18만원",
            rating: "9.7",
            procedureTime: "25분",
            recoveryPeriod: "1일",
            matchesBudget: true,
            category: "눈성형",
            subCategory: "필러"
        },
        {
            id: 16,
            procedure: "눈밑 지방재배치",
            hospital: "강남비비의원",
            price: "35만원",
            rating: "9.9",
            procedureTime: "60분",
            recoveryPeriod: "3일",
            matchesBudget: true,
            category: "눈성형",
            subCategory: "수술"
        }
    ],
    "보톡스/필러": [
        {
            id: 17,
            procedure: "보톡스",
            hospital: "압구정 클리닉",
            price: "8만원",
            rating: "9.6",
            procedureTime: "15분",
            recoveryPeriod: "0일",
            matchesBudget: true,
            category: "보톡스/필러",
            subCategory: "보톡스"
        },
        {
            id: 18,
            procedure: "쥬베룩",
            hospital: "강남비비의원",
            price: "12만원",
            rating: "9.8",
            procedureTime: "20분",
            recoveryPeriod: "0일",
            matchesBudget: true,
            category: "보톡스/필러",
            subCategory: "보톡스"
        },
        {
            id: 19,
            procedure: "볼륨 필러",
            hospital: "신사역 메디컬",
            price: "25만원",
            rating: "9.7",
            procedureTime: "30분",
            recoveryPeriod: "1일",
            matchesBudget: true,
            category: "보톡스/필러",
            subCategory: "필러"
        },
        {
            id: 20,
            procedure: "리쥬란",
            hospital: "홍대 의원",
            price: "15만원",
            rating: "9.6",
            procedureTime: "25분",
            recoveryPeriod: "1일",
            matchesBudget: true,
            category: "보톡스/필러",
            subCategory: "필러"
        }
    ],
    "체형/지방": [
        {
            id: 21,
            procedure: "지방분해 주사",
            hospital: "강남비비의원",
            price: "20만원",
            rating: "9.7",
            procedureTime: "30분",
            recoveryPeriod: "1일",
            matchesBudget: true,
            category: "체형/지방",
            subCategory: "주사"
        },
        {
            id: 22,
            procedure: "쿨스컬핑",
            hospital: "압구정 클리닉",
            price: "35만원",
            rating: "9.8",
            procedureTime: "60분",
            recoveryPeriod: "2일",
            matchesBudget: true,
            category: "체형/지방",
            subCategory: "시술"
        }
    ],
    기타: [
        {
            id: 23,
            procedure: "제모 레이저",
            hospital: "신사역 메디컬",
            price: "10만원",
            rating: "9.5",
            procedureTime: "20분",
            recoveryPeriod: "0일",
            matchesBudget: true,
            category: "기타",
            subCategory: "레이저"
        },
        {
            id: 24,
            procedure: "문신 제거",
            hospital: "홍대 의원",
            price: "15만원",
            rating: "9.6",
            procedureTime: "30분",
            recoveryPeriod: "3일",
            matchesBudget: true,
            category: "기타",
            subCategory: "레이저"
        }
    ]
};
// 간단한 알고리즘: 시술 기간과 회복 기간을 고려한 추천
function calculateRecommendations(data) {
    const daysDiff = data.travelPeriod.start && data.travelPeriod.end ? Math.ceil((new Date(data.travelPeriod.end).getTime() - new Date(data.travelPeriod.start).getTime()) / (1000 * 60 * 60 * 24)) : 7;
    // 선택된 카테고리에 맞는 시술 가져오기
    const categoryProcedures = PROCEDURES_BY_CATEGORY[data.procedureCategory] || [];
    // 카테고리에 시술이 없으면 전체 시술 중에서 선택
    const allProcedures = Object.values(PROCEDURES_BY_CATEGORY).flat();
    const recommendations = categoryProcedures.length > 0 ? categoryProcedures : allProcedures;
    // 여행 기간에 맞는 시술만 필터링 (최소 2개 이상은 항상 표시)
    const filtered = recommendations.filter((rec)=>{
        const totalDays = parseInt(rec.recoveryPeriod) + 1;
        return daysDiff >= totalDays;
    });
    // 필터링 결과가 1개 이하이면 최소 2개는 표시 (회복 기간이 짧은 것 우선)
    if (filtered.length <= 1) {
        return recommendations.sort((a, b)=>parseInt(a.recoveryPeriod) - parseInt(b.recoveryPeriod)).slice(0, Math.max(2, filtered.length));
    }
    return filtered;
}
function ProcedureRecommendation({ scheduleData, selectedCategoryId, onCategoryChange, mainCategories = [] }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [isFilterOpen, setIsFilterOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [filter, setFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        duration: null,
        recovery: null,
        budget: null
    });
    const [allTreatments, setAllTreatments] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [recommendations, setRecommendations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [scrollPositions, setScrollPositions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [favorites, setFavorites] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [selectedTreatment, setSelectedTreatment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isScheduleModalOpen, setIsScheduleModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const scrollRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    // 중분류 카테고리 표시 개수 (초기 5개)
    const [visibleCategoriesCount, setVisibleCategoriesCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(5);
    // 중분류 중복 확인을 위한 로그 (개발용)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProcedureRecommendation.useEffect": ()=>{
            if (recommendations.length > 0 && scheduleData.procedureCategory === "전체") {
                const categoryMidCounts = new Map();
                recommendations.forEach({
                    "ProcedureRecommendation.useEffect": (rec)=>{
                        if (!categoryMidCounts.has(rec.categoryMid)) {
                            categoryMidCounts.set(rec.categoryMid, new Set());
                        }
                        // 해당 중분류가 속한 대분류 확인
                        rec.treatments.forEach({
                            "ProcedureRecommendation.useEffect": (treatment)=>{
                                if (treatment.category_large) {
                                    categoryMidCounts.get(rec.categoryMid).add(treatment.category_large);
                                }
                            }
                        }["ProcedureRecommendation.useEffect"]);
                    }
                }["ProcedureRecommendation.useEffect"]);
                // 중복된 중분류 확인 (같은 중분류가 여러 대분류에 속한 경우)
                const duplicates = [];
                categoryMidCounts.forEach({
                    "ProcedureRecommendation.useEffect": (categoryLarges, categoryMid)=>{
                        if (categoryLarges.size > 1) {
                            duplicates.push(`${categoryMid} (대분류: ${Array.from(categoryLarges).join(", ")})`);
                        }
                    }
                }["ProcedureRecommendation.useEffect"]);
                if (duplicates.length > 0) {
                    console.warn("⚠️ 데이터 상 중분류 중복 발견 (다른 대분류에 같은 중분류 이름 존재):", duplicates);
                }
            }
        }
    }["ProcedureRecommendation.useEffect"], [
        recommendations,
        scheduleData.procedureCategory
    ]);
    // 각 중분류별 시술 표시 개수 (초기 3개)
    const [visibleTreatmentsCount, setVisibleTreatmentsCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProcedureRecommendation.useEffect": ()=>{
            async function fetchData() {
                try {
                    setLoading(true);
                    // selectedCategoryId를 한국어 카테고리 이름으로 변환
                    let categoryForLoad;
                    if (selectedCategoryId !== null && selectedCategoryId !== undefined) {
                        const selectedCategory = mainCategories.find({
                            "ProcedureRecommendation.useEffect.fetchData.selectedCategory": (cat)=>cat.id === selectedCategoryId
                        }["ProcedureRecommendation.useEffect.fetchData.selectedCategory"]);
                        categoryForLoad = selectedCategory?.name || selectedCategoryId;
                    } else if (scheduleData.procedureCategory !== "전체") {
                        categoryForLoad = scheduleData.procedureCategory;
                    }
                    // 필요한 만큼만 로드 (200개 - 일정 기반 추천에 충분)
                    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadTreatmentsPaginated"])(1, 200, {
                        categoryLarge: categoryForLoad
                    });
                    const treatments = result.data;
                    setAllTreatments(treatments);
                    // 일정 기반 추천 데이터 생성
                    if (scheduleData.travelPeriod.start && scheduleData.travelPeriod.end) {
                        // selectedCategoryId를 한국어 카테고리 이름으로 변환
                        let categoryToUse;
                        if (selectedCategoryId !== null && selectedCategoryId !== undefined) {
                            // mainCategories에서 선택된 카테고리의 name을 찾기
                            const selectedCategory = mainCategories.find({
                                "ProcedureRecommendation.useEffect.fetchData.selectedCategory": (cat)=>cat.id === selectedCategoryId
                            }["ProcedureRecommendation.useEffect.fetchData.selectedCategory"]);
                            categoryToUse = selectedCategory?.name || selectedCategoryId;
                        } else {
                            categoryToUse = scheduleData.procedureCategory || "전체";
                        }
                        const scheduleBasedRecs = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getScheduleBasedRecommendations"])(treatments, categoryToUse, scheduleData.travelPeriod.start, scheduleData.travelPeriod.end);
                        setRecommendations(scheduleBasedRecs);
                    }
                } catch (error) {
                    console.error("데이터 로드 실패:", error);
                } finally{
                    setLoading(false);
                }
            }
            fetchData();
        }
    }["ProcedureRecommendation.useEffect"], [
        scheduleData,
        selectedCategoryId
    ]);
    // 일정 추가 핸들러
    const handleDateSelect = async (date)=>{
        if (!selectedTreatment) return;
        // category_mid로 회복 기간 정보 가져오기 (소분류_리스트와 매칭)
        let recoveryDays = 0;
        let recoveryText = null;
        let recommendedStayDays = 0;
        let recoveryGuides = undefined;
        if (selectedTreatment.category_mid) {
            const recoveryInfo = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRecoveryInfoByCategoryMid"])(selectedTreatment.category_mid);
            if (recoveryInfo) {
                recommendedStayDays = recoveryInfo.recommendedStayDays || 0;
                recoveryDays = recoveryInfo.recoveryMax; // 회복기간_max 기준 (fallback)
                recoveryText = recoveryInfo.recoveryText;
                recoveryGuides = recoveryInfo.recoveryGuides;
            }
        }
        // 권장체류일수가 있으면 우선 사용
        if (recommendedStayDays > 0) {
            recoveryDays = recommendedStayDays;
        } else if (recoveryDays === 0) {
            // recoveryInfo가 없으면 기존 downtime 사용 (fallback)
            recoveryDays = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseRecoveryPeriod"])(selectedTreatment.downtime) || 0;
        }
        const schedules = JSON.parse(localStorage.getItem("schedules") || "[]");
        const newSchedule = {
            id: Date.now(),
            treatmentId: selectedTreatment.treatment_id,
            procedureDate: date,
            procedureName: selectedTreatment.treatment_name || "시술명 없음",
            hospital: selectedTreatment.hospital_name || "병원명 없음",
            category: selectedTreatment.category_mid || selectedTreatment.category_large || "기타",
            categoryMid: selectedTreatment.category_mid || null,
            recoveryDays,
            recoveryText,
            recoveryGuides,
            procedureTime: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseProcedureTime"])(selectedTreatment.surgery_time) || 0,
            price: selectedTreatment.selling_price || null,
            rating: selectedTreatment.rating || 0,
            reviewCount: selectedTreatment.review_count || 0
        };
        schedules.push(newSchedule);
        localStorage.setItem("schedules", JSON.stringify(schedules));
        window.dispatchEvent(new Event("scheduleAdded"));
        alert(`${date}에 일정이 추가되었습니다!`);
        setIsScheduleModalOpen(false);
        setSelectedTreatment(null);
    };
    // 여행 일수 계산
    const travelDays = scheduleData.travelPeriod.start && scheduleData.travelPeriod.end ? Math.ceil((new Date(scheduleData.travelPeriod.end).getTime() - new Date(scheduleData.travelPeriod.start).getTime()) / (1000 * 60 * 60 * 24)) + 1 : 0;
    // 필터링된 추천 데이터
    const filteredRecommendations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProcedureRecommendation.useMemo[filteredRecommendations]": ()=>{
            let filtered = recommendations;
            // 필터 적용
            if (filter.duration) {
                filtered = filtered.map({
                    "ProcedureRecommendation.useMemo[filteredRecommendations]": (rec)=>{
                        const filteredTreatments = rec.treatments.filter({
                            "ProcedureRecommendation.useMemo[filteredRecommendations].filteredTreatments": (treatment)=>{
                                const procedureTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseProcedureTime"])(treatment.surgery_time);
                                switch(filter.duration){
                                    case "same-day":
                                        return procedureTime <= 30; // 30분 이하
                                    case "half-day":
                                        return procedureTime > 30 && procedureTime <= 120; // 30분~2시간
                                    case "1-day":
                                        return procedureTime > 120 && procedureTime <= 480; // 2시간~8시간
                                    case "2-3-days":
                                        return procedureTime > 480; // 8시간 이상
                                    case "surgery":
                                        return procedureTime >= 60; // 1시간 이상 (수술 포함)
                                    default:
                                        return true;
                                }
                            }
                        }["ProcedureRecommendation.useMemo[filteredRecommendations].filteredTreatments"]);
                        return {
                            ...rec,
                            treatments: filteredTreatments
                        };
                    }
                }["ProcedureRecommendation.useMemo[filteredRecommendations]"]).filter({
                    "ProcedureRecommendation.useMemo[filteredRecommendations]": (rec)=>rec.treatments.length > 0
                }["ProcedureRecommendation.useMemo[filteredRecommendations]"]);
            }
            if (filter.recovery) {
                filtered = filtered.map({
                    "ProcedureRecommendation.useMemo[filteredRecommendations]": (rec)=>{
                        const filteredTreatments = rec.treatments.filter({
                            "ProcedureRecommendation.useMemo[filteredRecommendations].filteredTreatments": (treatment)=>{
                                const recoveryPeriod = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseRecoveryPeriod"])(treatment.downtime);
                                switch(filter.recovery){
                                    case "same-day":
                                        return recoveryPeriod === 0 || recoveryPeriod <= 1;
                                    case "1-3-days":
                                        return recoveryPeriod >= 1 && recoveryPeriod <= 3;
                                    case "4-7-days":
                                        return recoveryPeriod >= 4 && recoveryPeriod <= 7;
                                    case "1-week-plus":
                                        return recoveryPeriod >= 8;
                                    default:
                                        return true;
                                }
                            }
                        }["ProcedureRecommendation.useMemo[filteredRecommendations].filteredTreatments"]);
                        return {
                            ...rec,
                            treatments: filteredTreatments
                        };
                    }
                }["ProcedureRecommendation.useMemo[filteredRecommendations]"]).filter({
                    "ProcedureRecommendation.useMemo[filteredRecommendations]": (rec)=>rec.treatments.length > 0
                }["ProcedureRecommendation.useMemo[filteredRecommendations]"]);
            }
            if (filter.budget) {
                filtered = filtered.map({
                    "ProcedureRecommendation.useMemo[filteredRecommendations]": (rec)=>{
                        const filteredTreatments = rec.treatments.filter({
                            "ProcedureRecommendation.useMemo[filteredRecommendations].filteredTreatments": (treatment)=>{
                                const price = treatment.selling_price || 0;
                                switch(filter.budget){
                                    case "under-50":
                                        return price < 500000; // 50만원 미만
                                    case "50-100":
                                        return price >= 500000 && price < 1000000; // 50~100만원
                                    case "100-200":
                                        return price >= 1000000 && price < 2000000; // 100~200만원
                                    case "200-plus":
                                        return price >= 2000000; // 200만원 이상
                                    default:
                                        return true;
                                }
                            }
                        }["ProcedureRecommendation.useMemo[filteredRecommendations].filteredTreatments"]);
                        return {
                            ...rec,
                            treatments: filteredTreatments
                        };
                    }
                }["ProcedureRecommendation.useMemo[filteredRecommendations]"]).filter({
                    "ProcedureRecommendation.useMemo[filteredRecommendations]": (rec)=>rec.treatments.length > 0
                }["ProcedureRecommendation.useMemo[filteredRecommendations]"]);
            }
            return filtered;
        }
    }["ProcedureRecommendation.useMemo[filteredRecommendations]"], [
        recommendations,
        filter
    ]);
    const handleFilterApply = (newFilter)=>{
        setFilter(newFilter);
    };
    const hasActiveFilters = filter.duration !== null || filter.recovery !== null || filter.budget !== null;
    // 스크롤 핸들러
    const handleScroll = (categoryMid)=>{
        const element = scrollRefs.current[categoryMid];
        if (!element) return;
        const scrollLeft = element.scrollLeft;
        const scrollWidth = element.scrollWidth;
        const clientWidth = element.clientWidth;
        const canScrollLeft = scrollLeft > 0;
        const canScrollRight = scrollLeft < scrollWidth - clientWidth - 10;
        setScrollPositions((prev)=>({
                ...prev,
                [categoryMid]: {
                    left: scrollLeft,
                    canScrollLeft,
                    canScrollRight
                }
            }));
    };
    // 초기 스크롤 상태 확인
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProcedureRecommendation.useEffect": ()=>{
            if (recommendations.length > 0) {
                const timer = setTimeout({
                    "ProcedureRecommendation.useEffect.timer": ()=>{
                        recommendations.forEach({
                            "ProcedureRecommendation.useEffect.timer": (rec)=>{
                                const element = scrollRefs.current[rec.categoryMid];
                                if (element) {
                                    const scrollLeft = element.scrollLeft;
                                    const scrollWidth = element.scrollWidth;
                                    const clientWidth = element.clientWidth;
                                    const canScrollLeft = scrollLeft > 0;
                                    const canScrollRight = scrollLeft < scrollWidth - clientWidth - 10;
                                    setScrollPositions({
                                        "ProcedureRecommendation.useEffect.timer": (prev)=>({
                                                ...prev,
                                                [rec.categoryMid]: {
                                                    left: scrollLeft,
                                                    canScrollLeft,
                                                    canScrollRight
                                                }
                                            })
                                    }["ProcedureRecommendation.useEffect.timer"]);
                                }
                            }
                        }["ProcedureRecommendation.useEffect.timer"]);
                    }
                }["ProcedureRecommendation.useEffect.timer"], 200);
                return ({
                    "ProcedureRecommendation.useEffect": ()=>clearTimeout(timer)
                })["ProcedureRecommendation.useEffect"];
            }
        }
    }["ProcedureRecommendation.useEffect"], [
        recommendations
    ]);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "px-4 py-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-center text-gray-500",
                children: t("procedure.loading")
            }, void 0, false, {
                fileName: "[project]/components/ProcedureRecommendation.tsx",
                lineNumber: 760,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/ProcedureRecommendation.tsx",
            lineNumber: 759,
            columnNumber: 7
        }, this);
    }
    // 카테고리 변경 핸들러
    const handleCategoryClick = (categoryId)=>{
        if (onCategoryChange) {
            onCategoryChange(categoryId);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "px-4 py-6 space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: t("procedure.customRecommendations")
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                        lineNumber: 776,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setIsFilterOpen(true),
                        className: `flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${hasActiveFilters ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiFilter"], {
                                className: "text-xs"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureRecommendation.tsx",
                                lineNumber: 787,
                                columnNumber: 11
                            }, this),
                            t("procedure.filter"),
                            hasActiveFilters && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "bg-white/30 text-white text-xs px-1.5 py-0.5 rounded-full",
                                children: [
                                    filter.duration,
                                    filter.recovery,
                                    filter.budget
                                ].filter((f)=>f !== null).length
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureRecommendation.tsx",
                                lineNumber: 790,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                        lineNumber: 779,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureRecommendation.tsx",
                lineNumber: 775,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCalendar"], {
                            className: "text-primary-main"
                        }, void 0, false, {
                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                            lineNumber: 804,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-sm text-gray-700",
                            children: [
                                t("procedure.travelPeriod"),
                                ": ",
                                travelDays - 1,
                                "박 ",
                                travelDays,
                                "일"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                            lineNumber: 805,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                    lineNumber: 803,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ProcedureRecommendation.tsx",
                lineNumber: 802,
                columnNumber: 7
            }, this),
            mainCategories.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>handleCategoryClick(null),
                            className: `px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${selectedCategoryId === null ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-bold",
                                    children: "ALL"
                                }, void 0, false, {
                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                    lineNumber: 824,
                                    columnNumber: 15
                                }, this),
                                " 전체"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                            lineNumber: 816,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                        lineNumber: 815,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-5 gap-2",
                        children: mainCategories.map((category)=>{
                            const isActive = selectedCategoryId === category.id;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleCategoryClick(category.id),
                                className: `flex flex-col items-center justify-center gap-1 py-1.5 px-1 rounded-xl text-[11px] font-medium transition-colors aspect-[5/3] ${isActive ? "bg-primary-main/10 text-primary-main font-bold border border-primary-main shadow-[0_0_0_1px_rgba(45,184,160,0.3)]" : "bg-white text-gray-600 hover:text-gray-900 hover:bg-gray-50 border border-gray-100"}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-lg leading-none",
                                        children: category.icon
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                                        lineNumber: 842,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "leading-tight whitespace-nowrap",
                                        children: category.name
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                                        lineNumber: 843,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, category.id, true, {
                                fileName: "[project]/components/ProcedureRecommendation.tsx",
                                lineNumber: 833,
                                columnNumber: 17
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                        lineNumber: 829,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureRecommendation.tsx",
                lineNumber: 813,
                columnNumber: 9
            }, this),
            hasActiveFilters && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-wrap gap-1.5",
                    children: [
                        filter.duration && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs text-gray-600 bg-white px-2 py-1 rounded-full border border-gray-200",
                            children: DURATION_OPTIONS.find((opt)=>opt.value === filter.duration)?.label || filter.duration
                        }, void 0, false, {
                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                            lineNumber: 858,
                            columnNumber: 15
                        }, this),
                        filter.recovery && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs text-gray-600 bg-white px-2 py-1 rounded-full border border-gray-200",
                            children: RECOVERY_OPTIONS.find((opt)=>opt.value === filter.recovery)?.label || filter.recovery
                        }, void 0, false, {
                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                            lineNumber: 864,
                            columnNumber: 15
                        }, this),
                        filter.budget && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs text-gray-600 bg-white px-2 py-1 rounded-full border border-gray-200",
                            children: BUDGET_OPTIONS.find((opt)=>opt.value === filter.budget)?.label || filter.budget
                        }, void 0, false, {
                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                            lineNumber: 870,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                    lineNumber: 856,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ProcedureRecommendation.tsx",
                lineNumber: 855,
                columnNumber: 9
            }, this),
            filteredRecommendations.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-center text-gray-500 text-sm",
                children: t("procedure.noResults")
            }, void 0, false, {
                fileName: "[project]/components/ProcedureRecommendation.tsx",
                lineNumber: 881,
                columnNumber: 9
            }, this),
            filteredRecommendations.slice(0, visibleCategoriesCount).map((rec)=>{
                const scrollState = scrollPositions[rec.categoryMid] || {
                    left: 0,
                    canScrollLeft: false,
                    canScrollRight: true
                };
                const handleScrollLeft = ()=>{
                    const element = scrollRefs.current[rec.categoryMid];
                    if (element) {
                        element.scrollBy({
                            left: -300,
                            behavior: "smooth"
                        });
                    }
                };
                const handleScrollRight = ()=>{
                    const element = scrollRefs.current[rec.categoryMid];
                    if (element) {
                        element.scrollBy({
                            left: 300,
                            behavior: "smooth"
                        });
                    }
                };
                // 더보기 기능 (10개 카드 추가)
                const handleShowMore = ()=>{
                    setVisibleTreatmentsCount((prev)=>({
                            ...prev,
                            [rec.categoryMid]: (prev[rec.categoryMid] || 3) + 10
                        }));
                };
                // 현재 표시된 카드 수
                const currentVisibleCount = visibleTreatmentsCount[rec.categoryMid] || 3;
                const hasMoreTreatments = rec.treatments.length > currentVisibleCount;
                // 우측 버튼 표시 조건: 스크롤 가능하거나 더보기 가능할 때
                const shouldShowRightButton = scrollState.canScrollRight || hasMoreTreatments;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "text-base font-bold text-gray-900",
                                        children: rec.categoryMid
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                                        lineNumber: 928,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-500 mt-0.5",
                                        children: [
                                            "평균 시술시간",
                                            " ",
                                            rec.averageProcedureTimeMin > 0 || rec.averageProcedureTimeMax > 0 ? rec.averageProcedureTimeMin === rec.averageProcedureTimeMax ? `${rec.averageProcedureTimeMax}분` : `${rec.averageProcedureTimeMin}~${rec.averageProcedureTimeMax}분` : rec.averageProcedureTime > 0 ? `${rec.averageProcedureTime}분` : "정보 없음",
                                            " ",
                                            "· 회복기간",
                                            " ",
                                            rec.averageRecoveryPeriodMin > 0 || rec.averageRecoveryPeriodMax > 0 ? rec.averageRecoveryPeriodMin === rec.averageRecoveryPeriodMax ? `${rec.averageRecoveryPeriodMax}일` : `${rec.averageRecoveryPeriodMin}~${rec.averageRecoveryPeriodMax}일` : rec.averageRecoveryPeriod > 0 ? `${rec.averageRecoveryPeriod}일` : "정보 없음"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                                        lineNumber: 931,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ProcedureRecommendation.tsx",
                                lineNumber: 927,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                            lineNumber: 926,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative",
                            children: [
                                scrollState.canScrollLeft && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleScrollLeft,
                                    className: "absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white/90 hover:bg-white shadow-lg rounded-full p-2 transition-all",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronLeft"], {
                                        className: "text-gray-700 text-lg"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                                        lineNumber: 964,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                    lineNumber: 960,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    ref: (el)=>{
                                        scrollRefs.current[rec.categoryMid] = el;
                                    },
                                    className: "flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4",
                                    onScroll: ()=>handleScroll(rec.categoryMid),
                                    children: rec.treatments.slice(0, visibleTreatmentsCount[rec.categoryMid] || 3).map((treatment)=>{
                                        const recoveryPeriod = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseRecoveryPeriod"])(treatment.downtime);
                                        const procedureTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseProcedureTime"])(treatment.surgery_time);
                                        const price = treatment.selling_price ? `${Math.round(treatment.selling_price / 10000)}만원` : "가격 문의";
                                        const isFavorited = treatment.treatment_id ? favorites.has(treatment.treatment_id) : false;
                                        const handleFavoriteClick = (e)=>{
                                            e.stopPropagation();
                                            if (treatment.treatment_id) {
                                                setFavorites((prev)=>{
                                                    const newSet = new Set(prev);
                                                    if (newSet.has(treatment.treatment_id)) {
                                                        newSet.delete(treatment.treatment_id);
                                                    } else {
                                                        newSet.add(treatment.treatment_id);
                                                    }
                                                    return newSet;
                                                });
                                            // TODO: 로컬 스토리지 또는 API에 저장
                                            }
                                        };
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-shrink-0 w-[150px] cursor-pointer",
                                            onClick: ()=>{
                                                if (treatment.treatment_id) {
                                                    router.push(`/treatment/${treatment.treatment_id}`);
                                                }
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "w-full aspect-[2/1] bg-gray-100 rounded-lg mb-3 overflow-hidden relative",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                            src: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getThumbnailUrl"])(treatment),
                                                            alt: treatment.treatment_name,
                                                            className: "w-full h-full object-cover"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                            lineNumber: 1020,
                                                            columnNumber: 27
                                                        }, this),
                                                        treatment.dis_rate && treatment.dis_rate > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded z-20",
                                                            children: [
                                                                treatment.dis_rate,
                                                                "%"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                            lineNumber: 1027,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: handleFavoriteClick,
                                                            className: "absolute top-2 right-2 bg-white/90 hover:bg-white rounded-full p-1.5 transition-colors shadow-sm z-20",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHeart"], {
                                                                className: `text-sm ${isFavorited ? "text-red-500 fill-red-500" : "text-gray-600"}`
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                lineNumber: 1036,
                                                                columnNumber: 29
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                            lineNumber: 1032,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: (e)=>{
                                                                e.stopPropagation();
                                                                setSelectedTreatment(treatment);
                                                                setIsScheduleModalOpen(true);
                                                            },
                                                            className: "absolute bottom-2 right-2 bg-white/90 hover:bg-white rounded-full p-1.5 transition-colors shadow-sm z-20",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCalendar"], {
                                                                className: "text-sm text-primary-main"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                lineNumber: 1053,
                                                                columnNumber: 29
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                            lineNumber: 1045,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                    lineNumber: 1019,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: treatment.hospital_name
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                    lineNumber: 1058,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                                    className: "font-semibold text-gray-900 mb-2 text-sm line-clamp-2",
                                                    children: treatment.treatment_name
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                    lineNumber: 1063,
                                                    columnNumber: 25
                                                }, this),
                                                treatment.rating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-1 mb-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiStar"], {
                                                            className: "text-yellow-400 fill-yellow-400 text-xs"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                            lineNumber: 1070,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs font-semibold",
                                                            children: treatment.rating.toFixed(1)
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                            lineNumber: 1071,
                                                            columnNumber: 29
                                                        }, this),
                                                        treatment.review_count && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs text-gray-400",
                                                            children: [
                                                                "(",
                                                                treatment.review_count.toLocaleString(),
                                                                ")"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                            lineNumber: 1075,
                                                            columnNumber: 31
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                    lineNumber: 1069,
                                                    columnNumber: 27
                                                }, this),
                                                (procedureTime > 0 || recoveryPeriod > 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-3 text-xs text-gray-600 mb-3",
                                                    children: [
                                                        procedureTime > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiClock"], {
                                                                    className: "text-primary-main text-xs"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                    lineNumber: 1087,
                                                                    columnNumber: 33
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: [
                                                                        procedureTime,
                                                                        t("procedure.procedureTime")
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                    lineNumber: 1088,
                                                                    columnNumber: 33
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                            lineNumber: 1086,
                                                            columnNumber: 31
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiClock"], {
                                                                    className: "text-gray-300 text-xs"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                    lineNumber: 1095,
                                                                    columnNumber: 33
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-gray-400",
                                                                    children: "시간 정보 없음"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                    lineNumber: 1096,
                                                                    columnNumber: 33
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                            lineNumber: 1094,
                                                            columnNumber: 31
                                                        }, this),
                                                        recoveryPeriod > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCalendar"], {
                                                                    className: "text-primary-main text-xs"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                    lineNumber: 1103,
                                                                    columnNumber: 33
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: [
                                                                        t("procedure.recoveryPeriod"),
                                                                        " ",
                                                                        recoveryPeriod,
                                                                        t("procedure.recoveryDays")
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                    lineNumber: 1104,
                                                                    columnNumber: 33
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                            lineNumber: 1102,
                                                            columnNumber: 31
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCalendar"], {
                                                                    className: "text-gray-300 text-xs"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                    lineNumber: 1112,
                                                                    columnNumber: 33
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-gray-400",
                                                                    children: "회복기간 정보 없음"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                    lineNumber: 1113,
                                                                    columnNumber: 33
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                            lineNumber: 1111,
                                                            columnNumber: 31
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                    lineNumber: 1084,
                                                    columnNumber: 27
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-2",
                                                        children: [
                                                            treatment.original_price && treatment.selling_price && treatment.original_price > treatment.selling_price && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-xs text-gray-400 line-through",
                                                                children: [
                                                                    Math.round(treatment.original_price / 10000),
                                                                    "만원"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                lineNumber: 1128,
                                                                columnNumber: 33
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-base font-bold text-primary-main",
                                                                children: price
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                                lineNumber: 1133,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                        lineNumber: 1123,
                                                        columnNumber: 27
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                                    lineNumber: 1122,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, treatment.treatment_id, true, {
                                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                                            lineNumber: 1009,
                                            columnNumber: 23
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                    lineNumber: 969,
                                    columnNumber: 15
                                }, this),
                                shouldShowRightButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        // 더보기 가능하면 더보기 우선 실행, 그 외에는 스크롤
                                        if (hasMoreTreatments) {
                                            handleShowMore();
                                        } else if (scrollState.canScrollRight) {
                                            handleScrollRight();
                                        }
                                    },
                                    className: "absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white hover:bg-gray-50 shadow-lg rounded-full p-2.5 transition-all",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                                        className: "text-gray-700 text-xl"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                                        lineNumber: 1156,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                                    lineNumber: 1145,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ProcedureRecommendation.tsx",
                            lineNumber: 957,
                            columnNumber: 13
                        }, this)
                    ]
                }, rec.categoryMid, true, {
                    fileName: "[project]/components/ProcedureRecommendation.tsx",
                    lineNumber: 924,
                    columnNumber: 11
                }, this);
            }),
            recommendations.length > visibleCategoriesCount && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setVisibleCategoriesCount((prev)=>prev + 10),
                className: "w-full py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-semibold transition-colors",
                children: [
                    "더보기 (",
                    recommendations.length - visibleCategoriesCount,
                    "개 카테고리 더)"
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureRecommendation.tsx",
                lineNumber: 1166,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-primary-light/10 rounded-xl p-4 mt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        className: "font-semibold text-gray-900 mb-2",
                        children: t("procedure.matchingHospital")
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                        lineNumber: 1177,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-gray-700 mb-3",
                        children: t("procedure.hospitalRecommendation")
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                        lineNumber: 1180,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "w-full bg-primary-main hover:bg-[#2DB8A0] text-white py-2.5 rounded-lg text-sm font-semibold transition-colors",
                        children: t("procedure.viewHospitalInfo")
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureRecommendation.tsx",
                        lineNumber: 1183,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureRecommendation.tsx",
                lineNumber: 1176,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProcedureFilterModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isFilterOpen,
                onClose: ()=>setIsFilterOpen(false),
                onApply: handleFilterApply,
                currentFilter: filter
            }, void 0, false, {
                fileName: "[project]/components/ProcedureRecommendation.tsx",
                lineNumber: 1189,
                columnNumber: 7
            }, this),
            selectedTreatment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AddToScheduleModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isScheduleModalOpen,
                onClose: ()=>{
                    setIsScheduleModalOpen(false);
                    setSelectedTreatment(null);
                },
                onDateSelect: handleDateSelect,
                treatmentName: selectedTreatment.treatment_name || "시술명 없음",
                categoryMid: selectedTreatment.category_mid || null
            }, void 0, false, {
                fileName: "[project]/components/ProcedureRecommendation.tsx",
                lineNumber: 1198,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ProcedureRecommendation.tsx",
        lineNumber: 773,
        columnNumber: 5
    }, this);
}
_s(ProcedureRecommendation, "VJffcB60I8reQbhI03LUtZtRti8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = ProcedureRecommendation;
var _c;
__turbopack_context__.k.register(_c, "ProcedureRecommendation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/CountryPainPointSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CountryPainPointSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
// 고민 키워드와 시술 매핑
const CONCERN_KEYWORDS = {
    주름: [
        "보톡스",
        "리쥬란",
        "리프팅",
        "인모드",
        "슈링크",
        "주름"
    ],
    다크서클: [
        "필러",
        "지방재배치",
        "리쥬란",
        "다크서클",
        "눈밑"
    ],
    모공: [
        "프락셀",
        "레이저",
        "모공",
        "피코",
        "아쿠아필"
    ],
    피부톤: [
        "미백",
        "레이저",
        "프락셀",
        "피부톤",
        "백옥"
    ],
    트러블: [
        "레이저",
        "프락셀",
        "트러블",
        "피코",
        "아쿠아필"
    ],
    탄력: [
        "리프팅",
        "인모드",
        "슈링크",
        "울쎄라",
        "탄력"
    ]
};
function CountryPainPointSection() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [selectedCountry, setSelectedCountry] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    const [selectedConcern, setSelectedConcern] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [recommendedTreatments, setRecommendedTreatments] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [favorites, setFavorites] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const countries = [
        {
            id: "all",
            key: "home.country.all"
        },
        {
            id: "korea",
            key: "home.country.korea"
        },
        {
            id: "china",
            key: "home.country.china"
        },
        {
            id: "japan",
            key: "home.country.japan"
        },
        {
            id: "usa",
            key: "home.country.usa"
        }
    ];
    const painPoints = {
        all: [
            "주름",
            "다크서클",
            "모공",
            "피부톤",
            "트러블"
        ],
        korea: [
            "주름",
            "탄력",
            "모공",
            "피부톤",
            "다크서클"
        ],
        china: [
            "주름",
            "다크서클",
            "모공",
            "피부톤",
            "트러블"
        ],
        japan: [
            "모공",
            "주름",
            "다크서클",
            "피부톤",
            "트러블"
        ],
        usa: [
            "주름",
            "다크서클",
            "피부톤",
            "모공",
            "트러블"
        ]
    };
    const currentPainPoints = painPoints[selectedCountry] || painPoints.all;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CountryPainPointSection.useEffect": ()=>{
            const savedFavorites = JSON.parse(localStorage.getItem("favorites") || "[]");
            const procedureFavorites = savedFavorites.filter({
                "CountryPainPointSection.useEffect.procedureFavorites": (f)=>f.type === "procedure"
            }["CountryPainPointSection.useEffect.procedureFavorites"]).map({
                "CountryPainPointSection.useEffect.procedureFavorites": (f)=>f.id
            }["CountryPainPointSection.useEffect.procedureFavorites"]);
            setFavorites(new Set(procedureFavorites));
        }
    }["CountryPainPointSection.useEffect"], []);
    const handleConcernClick = async (concern)=>{
        if (selectedConcern === concern) {
            // 같은 해시태그를 다시 클릭하면 닫기
            setSelectedConcern(null);
            setRecommendedTreatments([]);
            return;
        }
        setSelectedConcern(concern);
        setLoading(true);
        try {
            // 필요한 만큼만 로드 (100개)
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadTreatmentsPaginated"])(1, 100);
            const allTreatments = result.data;
            const keywords = CONCERN_KEYWORDS[concern] || [
                concern
            ];
            // 키워드로 필터링
            const filtered = allTreatments.filter((treatment)=>{
                const name = (treatment.treatment_name || "").toLowerCase();
                const hashtags = (treatment.treatment_hashtags || "").toLowerCase();
                const categoryLarge = (treatment.category_large || "").toLowerCase();
                const categoryMid = (treatment.category_mid || "").toLowerCase();
                return keywords.some((keyword)=>{
                    const keywordLower = keyword.toLowerCase();
                    return name.includes(keywordLower) || hashtags.includes(keywordLower) || categoryLarge.includes(keywordLower) || categoryMid.includes(keywordLower);
                });
            });
            // 추천 점수로 정렬하고 상위 10개 선택
            const sorted = filtered.map((treatment)=>({
                    ...treatment,
                    recommendationScore: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateRecommendationScore"])(treatment)
                })).sort((a, b)=>b.recommendationScore - a.recommendationScore).slice(0, 10);
            setRecommendedTreatments(sorted);
        } catch (error) {
            console.error("시술 추천 로드 실패:", error);
        } finally{
            setLoading(false);
        }
    };
    const handleFavoriteClick = (treatment, e)=>{
        e.stopPropagation();
        if (!treatment.treatment_id) return;
        setFavorites((prev)=>{
            const newSet = new Set(prev);
            if (newSet.has(treatment.treatment_id)) {
                newSet.delete(treatment.treatment_id);
            } else {
                newSet.add(treatment.treatment_id);
            }
            // 로컬 스토리지에 저장
            const savedFavorites = JSON.parse(localStorage.getItem("favorites") || "[]");
            const updatedFavorites = Array.from(newSet).map((id)=>({
                    id,
                    type: "procedure"
                }));
            localStorage.setItem("favorites", JSON.stringify(updatedFavorites));
            return newSet;
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-3",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-lg font-bold text-gray-900",
                    children: t("home.countrySearch")
                }, void 0, false, {
                    fileName: "[project]/components/CountryPainPointSection.tsx",
                    lineNumber: 146,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/CountryPainPointSection.tsx",
                lineNumber: 145,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4 mb-3",
                children: countries.map((country)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setSelectedCountry(country.id);
                            setSelectedConcern(null);
                            setRecommendedTreatments([]);
                        },
                        className: `px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${selectedCountry === country.id ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                        children: t(country.key)
                    }, country.id, false, {
                        fileName: "[project]/components/CountryPainPointSection.tsx",
                        lineNumber: 154,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/CountryPainPointSection.tsx",
                lineNumber: 152,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-2 mb-4",
                children: currentPainPoints.map((point, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: (e)=>{
                            // Ctrl/Cmd 키를 누르지 않은 경우에만 탐색 페이지로 이동
                            if (!e.ctrlKey && !e.metaKey) {
                                // 탐색 페이지로 이동하고 검색어와 section 파라미터 전달
                                router.push(`/explore?section=procedure&search=${encodeURIComponent(point)}`);
                            } else {
                                // Ctrl/Cmd 키를 누른 경우 기존 동작 (현재 페이지에서 추천 표시)
                                handleConcernClick(point);
                            }
                        },
                        className: `px-4 py-2 rounded-full text-sm font-medium transition-colors ${selectedConcern === point ? "bg-primary-main text-white border-primary-main" : "bg-white border border-gray-200 text-gray-700 hover:border-primary-main hover:text-primary-main"}`,
                        children: [
                            "#",
                            point
                        ]
                    }, index, true, {
                        fileName: "[project]/components/CountryPainPointSection.tsx",
                        lineNumber: 175,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/CountryPainPointSection.tsx",
                lineNumber: 173,
                columnNumber: 7
            }, this),
            selectedConcern && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 p-4 bg-gray-50 rounded-xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                className: "text-base font-bold text-gray-900",
                                children: [
                                    "#",
                                    selectedConcern,
                                    " 추천 시술"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/CountryPainPointSection.tsx",
                                lineNumber: 206,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    setSelectedConcern(null);
                                    setRecommendedTreatments([]);
                                },
                                className: "p-1 hover:bg-gray-200 rounded-full transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                    className: "text-gray-600 text-lg"
                                }, void 0, false, {
                                    fileName: "[project]/components/CountryPainPointSection.tsx",
                                    lineNumber: 216,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/CountryPainPointSection.tsx",
                                lineNumber: 209,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/CountryPainPointSection.tsx",
                        lineNumber: 205,
                        columnNumber: 11
                    }, this),
                    loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4",
                        children: [
                            ...Array(3)
                        ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-shrink-0 w-[150px] bg-gray-200 rounded-xl animate-pulse",
                                style: {
                                    height: "200px"
                                }
                            }, i, false, {
                                fileName: "[project]/components/CountryPainPointSection.tsx",
                                lineNumber: 223,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/CountryPainPointSection.tsx",
                        lineNumber: 221,
                        columnNumber: 13
                    }, this) : recommendedTreatments.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4",
                        children: recommendedTreatments.map((treatment)=>{
                            const isFavorite = favorites.has(treatment.treatment_id || 0);
                            const thumbnailUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getThumbnailUrl"])(treatment);
                            const price = treatment.selling_price ? `${Math.round(treatment.selling_price / 10000)}만원` : "가격 문의";
                            const rating = treatment.rating || 0;
                            const reviewCount = treatment.review_count || 0;
                            const discountRate = treatment.dis_rate ? `${treatment.dis_rate}%` : "";
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-shrink-0 w-[150px] bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer",
                                onClick: ()=>{
                                    if (treatment.treatment_id) {
                                        router.push(`/treatment/${treatment.treatment_id}`);
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative w-full aspect-[2/1] bg-gray-100 overflow-hidden",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: thumbnailUrl,
                                                alt: treatment.treatment_name || "시술 이미지",
                                                className: "w-full h-full object-cover",
                                                onError: (e)=>{
                                                    const target = e.target;
                                                    if (target.dataset.fallback === "true") {
                                                        target.style.display = "none";
                                                        return;
                                                    }
                                                    target.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="300"%3E%3Crect fill="%23f3f4f6" width="400" height="300"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="%239ca3af" font-size="24"%3E🏥%3C/text%3E%3C/svg%3E';
                                                    target.dataset.fallback = "true";
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/components/CountryPainPointSection.tsx",
                                                lineNumber: 256,
                                                columnNumber: 23
                                            }, this),
                                            discountRate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-bold z-10",
                                                children: discountRate
                                            }, void 0, false, {
                                                fileName: "[project]/components/CountryPainPointSection.tsx",
                                                lineNumber: 273,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: (e)=>{
                                                    e.stopPropagation();
                                                    handleFavoriteClick(treatment, e);
                                                },
                                                className: "absolute top-2 right-2 bg-white/90 hover:bg-white rounded-full p-1.5 transition-colors shadow-sm z-10",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHeart"], {
                                                    className: `text-sm ${isFavorite ? "text-red-500 fill-red-500" : "text-gray-600"}`
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CountryPainPointSection.tsx",
                                                    lineNumber: 285,
                                                    columnNumber: 25
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/CountryPainPointSection.tsx",
                                                lineNumber: 278,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/CountryPainPointSection.tsx",
                                        lineNumber: 255,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-3",
                                        children: [
                                            treatment.hospital_name && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-gray-500 mb-1 truncate",
                                                children: treatment.hospital_name
                                            }, void 0, false, {
                                                fileName: "[project]/components/CountryPainPointSection.tsx",
                                                lineNumber: 299,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                className: "font-semibold text-gray-900 mb-2 text-sm line-clamp-2 min-h-[2.5rem]",
                                                children: treatment.treatment_name
                                            }, void 0, false, {
                                                fileName: "[project]/components/CountryPainPointSection.tsx",
                                                lineNumber: 305,
                                                columnNumber: 23
                                            }, this),
                                            rating > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-1 mb-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiStar"], {
                                                        className: "text-yellow-400 fill-yellow-400 text-xs"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/CountryPainPointSection.tsx",
                                                        lineNumber: 312,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs font-semibold",
                                                        children: rating.toFixed(1)
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/CountryPainPointSection.tsx",
                                                        lineNumber: 313,
                                                        columnNumber: 27
                                                    }, this),
                                                    reviewCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs text-gray-400",
                                                        children: [
                                                            "(",
                                                            reviewCount.toLocaleString(),
                                                            ")"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/CountryPainPointSection.tsx",
                                                        lineNumber: 317,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/CountryPainPointSection.tsx",
                                                lineNumber: 311,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm font-bold text-primary-main",
                                                children: price
                                            }, void 0, false, {
                                                fileName: "[project]/components/CountryPainPointSection.tsx",
                                                lineNumber: 325,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/CountryPainPointSection.tsx",
                                        lineNumber: 296,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, treatment.treatment_id, true, {
                                fileName: "[project]/components/CountryPainPointSection.tsx",
                                lineNumber: 245,
                                columnNumber: 19
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/components/CountryPainPointSection.tsx",
                        lineNumber: 231,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-center text-gray-500 text-sm py-4",
                        children: [
                            selectedConcern,
                            "에 대한 추천 시술을 찾을 수 없습니다."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/CountryPainPointSection.tsx",
                        lineNumber: 334,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/CountryPainPointSection.tsx",
                lineNumber: 204,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/CountryPainPointSection.tsx",
        lineNumber: 144,
        columnNumber: 5
    }, this);
}
_s(CountryPainPointSection, "D8ZLKu7xh2jsMtBNDmUQGCDp04c=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = CountryPainPointSection;
var _c;
__turbopack_context__.k.register(_c, "CountryPainPointSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ProcedureReviewForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProcedureReviewForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ProcedureReviewForm({ onBack, onSubmit }) {
    _s();
    const [surgeryDate, setSurgeryDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [category, setCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [hospitalName, setHospitalName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureName, setProcedureName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureSearchTerm, setProcedureSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [showProcedureSuggestions, setShowProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [procedureSuggestions, setProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [cost, setCost] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureRating, setProcedureRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [hospitalRating, setHospitalRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [gender, setGender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [ageGroup, setAgeGroup] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [images, setImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // 대분류 카테고리 10개 (고정)
    const categories = [
        "눈성형",
        "리프팅",
        "보톡스",
        "안면윤곽/양악",
        "제모",
        "지방성형",
        "코성형",
        "피부",
        "필러",
        "가슴성형"
    ];
    const ageGroups = [
        "20대",
        "30대",
        "40대",
        "50대"
    ];
    // 한국어 완성형 글자 체크 (자음만 입력 방지)
    const hasCompleteCharacter = (text)=>{
        // 완성형 한글(가-힣), 영문, 숫자가 1자 이상 포함되어 있는지 확인
        return /[가-힣a-zA-Z0-9]/.test(text);
    };
    // 시술명 자동완성 데이터 로드 (서버 사이드 검색)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProcedureReviewForm.useEffect": ()=>{
            const loadAutocomplete = {
                "ProcedureReviewForm.useEffect.loadAutocomplete": async ()=>{
                    if (!procedureSearchTerm || procedureSearchTerm.trim().length < 1) {
                        setProcedureSuggestions([]);
                        setShowProcedureSuggestions(false);
                        return;
                    }
                    // 완성형 글자가 1자 이상 있어야 자동완성 표시 (자음만 입력 방지)
                    if (!hasCompleteCharacter(procedureSearchTerm)) {
                        setProcedureSuggestions([]);
                        setShowProcedureSuggestions(false);
                        return;
                    }
                    try {
                        // 카테고리가 선택되었으면 해당 카테고리의 시술 데이터를 로드해서 category_small 추출
                        if (category) {
                            // category_small 검색을 위해 직접 Supabase 쿼리 사용
                            let query = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("treatment_master").select("category_small").eq("category_large", category).not("category_small", "is", null);
                            const { data, error } = await query.limit(1000);
                            if (error) {
                                throw new Error(`Supabase 오류: ${error.message}`);
                            }
                            // category_small 추출 및 중복 제거
                            const allCategorySmall = Array.from(new Set((data || []).map({
                                "ProcedureReviewForm.useEffect.loadAutocomplete.allCategorySmall": (t)=>t.category_small
                            }["ProcedureReviewForm.useEffect.loadAutocomplete.allCategorySmall"]).filter({
                                "ProcedureReviewForm.useEffect.loadAutocomplete.allCategorySmall": (small)=>typeof small === "string" && small.trim() !== ""
                            }["ProcedureReviewForm.useEffect.loadAutocomplete.allCategorySmall"])));
                            // 검색어로 필터링
                            const searchTermLower = procedureSearchTerm.toLowerCase();
                            const suggestions = allCategorySmall.filter({
                                "ProcedureReviewForm.useEffect.loadAutocomplete.suggestions": (small)=>small.toLowerCase().includes(searchTermLower)
                            }["ProcedureReviewForm.useEffect.loadAutocomplete.suggestions"]).slice(0, 10);
                            setProcedureSuggestions(suggestions);
                            // 검색 결과가 있으면 자동완성 표시
                            if (suggestions.length > 0) {
                                setShowProcedureSuggestions(true);
                            }
                            console.log("🔍 검색어:", procedureSearchTerm);
                            console.log("🔍 선택된 카테고리:", category);
                            console.log("🔍 전체 데이터 개수:", allCategorySmall.length);
                            console.log("🔍 검색 결과 개수:", suggestions.length);
                            if (suggestions.length > 0) {
                                console.log("🔍 검색 결과:", suggestions);
                            } else {
                                console.log("🔍 해당 카테고리의 모든 category_small:", allCategorySmall);
                            }
                        } else {
                            // 카테고리가 선택되지 않았으면 기존 함수 사용
                            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTreatmentAutocomplete"])(procedureSearchTerm, 10);
                            setProcedureSuggestions(result.treatmentNames);
                            // 검색 결과가 있으면 자동완성 표시
                            if (result.treatmentNames.length > 0) {
                                setShowProcedureSuggestions(true);
                            }
                            console.log("🔍 검색어:", procedureSearchTerm);
                            console.log("🔍 선택된 카테고리: 전체");
                            console.log("🔍 검색 결과 개수:", result.treatmentNames.length);
                            if (result.treatmentNames.length > 0) {
                                console.log("🔍 검색 결과:", result.treatmentNames);
                            }
                        }
                    } catch (error) {
                        console.error("자동완성 데이터 로드 실패:", error);
                        setProcedureSuggestions([]);
                    }
                }
            }["ProcedureReviewForm.useEffect.loadAutocomplete"];
            const debounceTimer = setTimeout({
                "ProcedureReviewForm.useEffect.debounceTimer": ()=>{
                    loadAutocomplete();
                }
            }["ProcedureReviewForm.useEffect.debounceTimer"], 300);
            return ({
                "ProcedureReviewForm.useEffect": ()=>clearTimeout(debounceTimer)
            })["ProcedureReviewForm.useEffect"];
        }
    }["ProcedureReviewForm.useEffect"], [
        procedureSearchTerm,
        category
    ]);
    const handleImageUpload = (e)=>{
        if (e.target.files) {
            const files = Array.from(e.target.files);
            const newImages = files.map((file)=>URL.createObjectURL(file));
            setImages([
                ...images,
                ...newImages
            ].slice(0, 4));
        }
    };
    const removeImage = (index)=>{
        setImages(images.filter((_, i)=>i !== index));
    };
    const handleSubmit = async ()=>{
        // 필수 항목 검증
        // procedureName은 procedureSearchTerm에서 가져오거나 직접 입력된 값 사용
        const finalProcedureName = procedureName || procedureSearchTerm;
        if (!category || !finalProcedureName || !cost || content.length < 10) {
            alert("필수 항목을 모두 입력하고 글을 10자 이상 작성해주세요.");
            return;
        }
        // 성별, 연령대 검증
        if (!gender || !ageGroup) {
            alert("성별과 연령대를 선택해주세요.");
            return;
        }
        // 만족도 검증
        if (procedureRating === 0 || hospitalRating === 0) {
            alert("시술 만족도와 병원 만족도를 모두 선택해주세요.");
            return;
        }
        try {
            // 이미지 URL 배열 생성 (현재는 로컬 URL이므로 추후 Supabase Storage 업로드 필요)
            const imageUrls = images.length > 0 ? images : undefined;
            // 데이터 저장
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveProcedureReview"])({
                category,
                procedure_name: finalProcedureName,
                hospital_name: hospitalName || undefined,
                cost: parseInt(cost),
                procedure_rating: procedureRating,
                hospital_rating: hospitalRating,
                gender,
                age_group: ageGroup,
                surgery_date: surgeryDate || undefined,
                content,
                images: imageUrls,
                user_id: 0
            });
            if (result.success) {
                alert("시술후기가 성공적으로 작성되었습니다!");
                onSubmit();
            } else {
                alert(`시술후기 작성에 실패했습니다: ${result.error}`);
            }
        } catch (error) {
            console.error("시술후기 저장 오류:", error);
            alert(`시술후기 작성 중 오류가 발생했습니다: ${error.message}`);
        }
    };
    const StarRating = ({ rating, onRatingChange, label })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "block text-sm font-semibold text-gray-900 mb-2",
                    children: [
                        label,
                        " ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-red-500",
                            children: "*"
                        }, void 0, false, {
                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                            lineNumber: 241,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                    lineNumber: 240,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2",
                    children: [
                        1,
                        2,
                        3,
                        4,
                        5
                    ].map((star)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>onRatingChange(star),
                            className: "p-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiStar"], {
                                className: `text-2xl ${star <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 251,
                                columnNumber: 13
                            }, this)
                        }, star, false, {
                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                            lineNumber: 245,
                            columnNumber: 11
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                    lineNumber: 243,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/ProcedureReviewForm.tsx",
            lineNumber: 239,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onBack,
                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                            className: "text-gray-700 text-xl"
                        }, void 0, false, {
                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                            lineNumber: 272,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 268,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: "시술 후기 작성"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 274,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 267,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "시술 카테고리 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 280,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 279,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: category,
                        onChange: (e)=>{
                            setCategory(e.target.value);
                            setProcedureSearchTerm(""); // 카테고리 변경 시 검색어 초기화
                            setProcedureName("");
                            setShowProcedureSuggestions(false); // 자동완성 닫기
                            setProcedureSuggestions([]); // 자동완성 목록 초기화
                        },
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "카테고리를 선택하세요"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 293,
                                columnNumber: 11
                            }, this),
                            categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: cat,
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                                    lineNumber: 295,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 282,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 278,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "시술명(수술명) ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 305,
                                columnNumber: 20
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 304,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: procedureSearchTerm,
                        onChange: (e)=>{
                            const value = e.target.value;
                            setProcedureSearchTerm(value);
                            // 완성형 글자가 있을 때만 자동완성 표시
                            if (hasCompleteCharacter(value)) {
                                setShowProcedureSuggestions(true);
                            } else {
                                setShowProcedureSuggestions(false);
                            }
                            // 자동완성에서 선택되지 않은 값이면 procedureName도 업데이트 (직접 입력 허용)
                            if (value && !procedureSuggestions.includes(value)) {
                                setProcedureName(value);
                            }
                        },
                        onFocus: ()=>{
                            if (procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm)) {
                                setShowProcedureSuggestions(true);
                            }
                        },
                        onBlur: ()=>{
                            // 약간의 지연을 두어 클릭 이벤트가 먼저 발생하도록
                            setTimeout(()=>{
                                setShowProcedureSuggestions(false);
                                // blur 시 현재 입력값을 procedureName에 저장 (선택된 값이 없을 때)
                                if (procedureSearchTerm && !procedureName) {
                                    setProcedureName(procedureSearchTerm);
                                }
                            }, 200);
                        },
                        placeholder: "시술명을 입력해 주세요.",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 307,
                        columnNumber: 9
                    }, this),
                    showProcedureSuggestions && procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm) && procedureSuggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-xl shadow-lg max-h-60 overflow-y-auto",
                        children: procedureSuggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    setProcedureName(suggestion);
                                    setProcedureSearchTerm(suggestion);
                                    setShowProcedureSuggestions(false);
                                },
                                className: "w-full px-4 py-2 text-left hover:bg-gray-50 first:rounded-t-xl last:rounded-b-xl",
                                children: suggestion
                            }, index, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 351,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 349,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 303,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "비용 (만원) ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 371,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 370,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-gray-700",
                                children: "₩"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 374,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: cost,
                                onChange: (e)=>setCost(e.target.value),
                                placeholder: "수술 비용",
                                className: "flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 375,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-gray-700",
                                children: "만원"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 382,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 373,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 369,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: procedureRating,
                onRatingChange: setProcedureRating,
                label: "전체적인 시술 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 387,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: hospitalRating,
                onRatingChange: setHospitalRating,
                label: "병원 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 394,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "병원명(선택사항)"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 402,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: hospitalName,
                        onChange: (e)=>setHospitalName(e.target.value),
                        placeholder: "병원명을 입력하세요",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 405,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 401,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "시술 날짜(선택사항)"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 416,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "date",
                        value: surgeryDate,
                        onChange: (e)=>setSurgeryDate(e.target.value),
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 419,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 415,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "성별 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 430,
                                columnNumber: 14
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 429,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setGender("여"),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${gender === "여" ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "여"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 433,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setGender("남"),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${gender === "남" ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "남"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 444,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 432,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 428,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "연령 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 461,
                                columnNumber: 14
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 460,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: ageGroups.map((age)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setAgeGroup(age),
                                className: `py-3 rounded-xl border-2 transition-colors ${ageGroup === age ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: age
                            }, age, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 465,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 463,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 459,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "글 작성 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 484,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 483,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: content,
                        onChange: (e)=>setContent(e.target.value),
                        placeholder: "시술 경험을 자세히 작성해주세요 (10자 이상)",
                        rows: 8,
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main resize-none"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 486,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-1",
                        children: [
                            content.length,
                            "자 / 최소 10자 이상 작성해주세요"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 493,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 482,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"], {
                                className: "text-primary-main"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 501,
                                columnNumber: 11
                            }, this),
                            "사진첨부 (최대 4장)"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 500,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: [
                            images.map((img, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative aspect-square rounded-xl overflow-hidden border border-gray-300",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: img,
                                            alt: `Uploaded ${index + 1}`,
                                            fill: true,
                                            className: "object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                                            lineNumber: 510,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>removeImage(index),
                                            className: "absolute top-2 right-2 p-1 bg-black/50 rounded-full text-white hover:bg-black/70",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                                className: "text-sm"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                                lineNumber: 521,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                                            lineNumber: 516,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, index, true, {
                                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                                    lineNumber: 506,
                                    columnNumber: 13
                                }, this)),
                            images.length < 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "aspect-square border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center cursor-pointer hover:border-primary-main transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "file",
                                        accept: "image/*",
                                        multiple: true,
                                        onChange: handleImageUpload,
                                        className: "hidden"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                                        lineNumber: 527,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"], {
                                                className: "text-2xl text-gray-400 mx-auto mb-2"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                                lineNumber: 535,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-gray-500",
                                                children: "사진 추가"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                                lineNumber: 536,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                                        lineNumber: 534,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 526,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 504,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 499,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 pt-4 pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onBack,
                        className: "flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-colors",
                        children: "취소"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 545,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleSubmit,
                        className: "flex-1 py-3 bg-primary-main hover:bg-primary-light text-white rounded-xl font-semibold transition-colors",
                        children: "작성완료"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 552,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 544,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ProcedureReviewForm.tsx",
        lineNumber: 265,
        columnNumber: 5
    }, this);
}
_s(ProcedureReviewForm, "UwTr4J4mNL64hEppkMCkVQDDRIc=");
_c = ProcedureReviewForm;
var _c;
__turbopack_context__.k.register(_c, "ProcedureReviewForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/HospitalReviewForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HospitalReviewForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function HospitalReviewForm({ onBack, onSubmit }) {
    _s();
    const [hospitalName, setHospitalName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [visitDate, setVisitDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [categoryLarge, setCategoryLarge] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureSearchTerm, setProcedureSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [showProcedureSuggestions, setShowProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [procedureSuggestions, setProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedProcedure, setSelectedProcedure] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [overallSatisfaction, setOverallSatisfaction] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [hospitalKindness, setHospitalKindness] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [hasTranslation, setHasTranslation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [translationSatisfaction, setTranslationSatisfaction] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [images, setImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // 대분류 카테고리 10개 (고정)
    const categories = [
        "눈성형",
        "리프팅",
        "보톡스",
        "안면윤곽/양악",
        "제모",
        "지방성형",
        "코성형",
        "피부",
        "필러",
        "가슴성형"
    ];
    // 한국어 완성형 글자 체크 (자음만 입력 방지)
    const hasCompleteCharacter = (text)=>{
        // 완성형 한글(가-힣), 영문, 숫자가 1자 이상 포함되어 있는지 확인
        return /[가-힣a-zA-Z0-9]/.test(text);
    };
    // 시술명 자동완성 데이터 로드 (서버 사이드 검색)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HospitalReviewForm.useEffect": ()=>{
            const loadAutocomplete = {
                "HospitalReviewForm.useEffect.loadAutocomplete": async ()=>{
                    if (!procedureSearchTerm || procedureSearchTerm.trim().length < 1) {
                        setProcedureSuggestions([]);
                        setShowProcedureSuggestions(false);
                        return;
                    }
                    // 완성형 글자가 1자 이상 있어야 자동완성 표시 (자음만 입력 방지)
                    if (!hasCompleteCharacter(procedureSearchTerm)) {
                        setProcedureSuggestions([]);
                        setShowProcedureSuggestions(false);
                        return;
                    }
                    try {
                        // 카테고리가 선택되었으면 해당 카테고리의 시술 데이터를 로드해서 category_small 추출
                        if (categoryLarge) {
                            // category_small 검색을 위해 직접 Supabase 쿼리 사용
                            let query = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("treatment_master").select("category_small").eq("category_large", categoryLarge).not("category_small", "is", null);
                            const { data, error } = await query.limit(1000);
                            if (error) {
                                throw new Error(`Supabase 오류: ${error.message}`);
                            }
                            // category_small 추출 및 중복 제거
                            const allCategorySmall = Array.from(new Set((data || []).map({
                                "HospitalReviewForm.useEffect.loadAutocomplete.allCategorySmall": (t)=>t.category_small
                            }["HospitalReviewForm.useEffect.loadAutocomplete.allCategorySmall"]).filter({
                                "HospitalReviewForm.useEffect.loadAutocomplete.allCategorySmall": (small)=>typeof small === "string" && small.trim() !== ""
                            }["HospitalReviewForm.useEffect.loadAutocomplete.allCategorySmall"])));
                            // 검색어로 필터링
                            const searchTermLower = procedureSearchTerm.toLowerCase();
                            const suggestions = allCategorySmall.filter({
                                "HospitalReviewForm.useEffect.loadAutocomplete.suggestions": (small)=>small.toLowerCase().includes(searchTermLower)
                            }["HospitalReviewForm.useEffect.loadAutocomplete.suggestions"]).slice(0, 10);
                            setProcedureSuggestions(suggestions);
                            // 검색 결과가 있으면 자동완성 표시
                            if (suggestions.length > 0) {
                                setShowProcedureSuggestions(true);
                            }
                        } else {
                            // 카테고리가 선택되지 않았으면 기존 함수 사용
                            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTreatmentAutocomplete"])(procedureSearchTerm, 10);
                            setProcedureSuggestions(result.treatmentNames);
                            // 검색 결과가 있으면 자동완성 표시
                            if (result.treatmentNames.length > 0) {
                                setShowProcedureSuggestions(true);
                            }
                        }
                    } catch (error) {
                        console.error("자동완성 데이터 로드 실패:", error);
                        setProcedureSuggestions([]);
                    }
                }
            }["HospitalReviewForm.useEffect.loadAutocomplete"];
            const debounceTimer = setTimeout({
                "HospitalReviewForm.useEffect.debounceTimer": ()=>{
                    loadAutocomplete();
                }
            }["HospitalReviewForm.useEffect.debounceTimer"], 300);
            return ({
                "HospitalReviewForm.useEffect": ()=>clearTimeout(debounceTimer)
            })["HospitalReviewForm.useEffect"];
        }
    }["HospitalReviewForm.useEffect"], [
        procedureSearchTerm,
        categoryLarge
    ]);
    const handleImageUpload = (e)=>{
        if (e.target.files) {
            const files = Array.from(e.target.files);
            const newImages = files.map((file)=>URL.createObjectURL(file));
            setImages([
                ...images,
                ...newImages
            ].slice(0, 4));
        }
    };
    const removeImage = (index)=>{
        setImages(images.filter((_, i)=>i !== index));
    };
    const StarRating = ({ rating, onRatingChange, label })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "block text-sm font-semibold text-gray-900 mb-2",
                    children: label
                }, void 0, false, {
                    fileName: "[project]/components/HospitalReviewForm.tsx",
                    lineNumber: 165,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2",
                    children: [
                        1,
                        2,
                        3,
                        4,
                        5
                    ].map((star)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>onRatingChange(star),
                            className: "p-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiStar"], {
                                className: `text-2xl ${star <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 176,
                                columnNumber: 13
                            }, this)
                        }, star, false, {
                            fileName: "[project]/components/HospitalReviewForm.tsx",
                            lineNumber: 170,
                            columnNumber: 11
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/HospitalReviewForm.tsx",
                    lineNumber: 168,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/HospitalReviewForm.tsx",
            lineNumber: 164,
            columnNumber: 5
        }, this);
    const handleSubmit = async ()=>{
        // 필수 항목 검증
        if (!hospitalName || !categoryLarge || content.length < 10) {
            alert("필수 항목을 모두 입력하고 글을 10자 이상 작성해주세요.");
            return;
        }
        try {
            // 이미지 URL 배열 생성 (현재는 로컬 URL이므로 추후 Supabase Storage 업로드 필요)
            const imageUrls = images.length > 0 ? images : undefined;
            // 데이터 저장
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveHospitalReview"])({
                hospital_name: hospitalName,
                category_large: categoryLarge,
                procedure_name: selectedProcedure || undefined,
                visit_date: visitDate || undefined,
                overall_satisfaction: overallSatisfaction > 0 ? overallSatisfaction : undefined,
                hospital_kindness: hospitalKindness > 0 ? hospitalKindness : undefined,
                has_translation: hasTranslation,
                translation_satisfaction: hasTranslation && translationSatisfaction > 0 ? translationSatisfaction : undefined,
                content,
                images: imageUrls,
                user_id: 0
            });
            if (result.success) {
                alert("병원후기가 성공적으로 작성되었습니다!");
                onSubmit();
            } else {
                alert(`병원후기 작성에 실패했습니다: ${result.error}`);
            }
        } catch (error) {
            console.error("병원후기 저장 오류:", error);
            alert(`병원후기 작성 중 오류가 발생했습니다: ${error.message}`);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onBack,
                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                            className: "text-gray-700 text-xl"
                        }, void 0, false, {
                            fileName: "[project]/components/HospitalReviewForm.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 235,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: "병원 후기 작성"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 241,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 234,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "병원명 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 247,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 246,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: hospitalName,
                        onChange: (e)=>setHospitalName(e.target.value),
                        placeholder: "병원명을 입력하세요",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 249,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 245,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "시술 카테고리 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 261,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 260,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: categoryLarge,
                        onChange: (e)=>{
                            setCategoryLarge(e.target.value);
                            setProcedureSearchTerm(""); // 카테고리 변경 시 검색어 초기화
                            setSelectedProcedure("");
                            setShowProcedureSuggestions(false); // 자동완성 닫기
                            setProcedureSuggestions([]); // 자동완성 목록 초기화
                        },
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "대분류 선택"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 274,
                                columnNumber: 11
                            }, this),
                            categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: cat,
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/components/HospitalReviewForm.tsx",
                                    lineNumber: 276,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 263,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 259,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "시술명(수술명) (선택사항)"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 285,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: procedureSearchTerm,
                        onChange: (e)=>{
                            const value = e.target.value;
                            setProcedureSearchTerm(value);
                            // 완성형 글자가 있을 때만 자동완성 표시
                            if (hasCompleteCharacter(value)) {
                                setShowProcedureSuggestions(true);
                            } else {
                                setShowProcedureSuggestions(false);
                            }
                            // 자동완성에서 선택되지 않은 값이면 selectedProcedure도 업데이트 (직접 입력 허용)
                            if (value && !procedureSuggestions.includes(value)) {
                                setSelectedProcedure(value);
                            }
                        },
                        onFocus: ()=>{
                            if (procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm)) {
                                setShowProcedureSuggestions(true);
                            }
                        },
                        onBlur: ()=>{
                            // 약간의 지연을 두어 클릭 이벤트가 먼저 발생하도록
                            setTimeout(()=>{
                                setShowProcedureSuggestions(false);
                                // blur 시 현재 입력값을 selectedProcedure에 저장 (선택된 값이 없을 때)
                                if (procedureSearchTerm && !selectedProcedure) {
                                    setSelectedProcedure(procedureSearchTerm);
                                }
                            }, 200);
                        },
                        placeholder: "시술명을 입력해 주세요.",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 288,
                        columnNumber: 9
                    }, this),
                    showProcedureSuggestions && procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm) && procedureSuggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-xl shadow-lg max-h-60 overflow-y-auto",
                        children: procedureSuggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    setSelectedProcedure(suggestion);
                                    setProcedureSearchTerm(suggestion);
                                    setShowProcedureSuggestions(false);
                                },
                                className: "w-full px-4 py-2 text-left hover:bg-gray-50 first:rounded-t-xl last:rounded-b-xl",
                                children: suggestion
                            }, index, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 332,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 330,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 284,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: overallSatisfaction,
                onRatingChange: setOverallSatisfaction,
                label: "전체적인 시술 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 350,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: hospitalKindness,
                onRatingChange: setHospitalKindness,
                label: "병원 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 357,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "통역 여부"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 365,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setHasTranslation(true),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${hasTranslation ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "있음"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 369,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setHasTranslation(false),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${!hasTranslation ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "없음"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 380,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 368,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 364,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "병원 방문일"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 396,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "date",
                        value: visitDate,
                        onChange: (e)=>setVisitDate(e.target.value),
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 399,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 395,
                columnNumber: 7
            }, this),
            hasTranslation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: translationSatisfaction,
                onRatingChange: setTranslationSatisfaction,
                label: "통역 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 409,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "글 작성 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 419,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 418,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: content,
                        onChange: (e)=>setContent(e.target.value),
                        placeholder: "병원 방문 경험을 자세히 작성해주세요 (10자 이상)",
                        rows: 8,
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main resize-none"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 421,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-1",
                        children: [
                            content.length,
                            "자 / 최소 10자 이상 작성해주세요"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 428,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 417,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"], {
                                className: "text-primary-main"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 436,
                                columnNumber: 11
                            }, this),
                            "사진첨부 (최대 4장)"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 435,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: [
                            images.map((img, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative aspect-square rounded-xl overflow-hidden border border-gray-300",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: img,
                                            alt: `Uploaded ${index + 1}`,
                                            fill: true,
                                            className: "object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/components/HospitalReviewForm.tsx",
                                            lineNumber: 445,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>removeImage(index),
                                            className: "absolute top-2 right-2 p-1 bg-black/50 rounded-full text-white hover:bg-black/70",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                                className: "text-sm"
                                            }, void 0, false, {
                                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                                lineNumber: 456,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/HospitalReviewForm.tsx",
                                            lineNumber: 451,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, index, true, {
                                    fileName: "[project]/components/HospitalReviewForm.tsx",
                                    lineNumber: 441,
                                    columnNumber: 13
                                }, this)),
                            images.length < 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "aspect-square border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center cursor-pointer hover:border-primary-main transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "file",
                                        accept: "image/*",
                                        multiple: true,
                                        onChange: handleImageUpload,
                                        className: "hidden"
                                    }, void 0, false, {
                                        fileName: "[project]/components/HospitalReviewForm.tsx",
                                        lineNumber: 462,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"], {
                                                className: "text-2xl text-gray-400 mx-auto mb-2"
                                            }, void 0, false, {
                                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                                lineNumber: 470,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-gray-500",
                                                children: "사진 추가"
                                            }, void 0, false, {
                                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                                lineNumber: 471,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/HospitalReviewForm.tsx",
                                        lineNumber: 469,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 461,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 439,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 434,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 pt-4 pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onBack,
                        className: "flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-colors",
                        children: "취소"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 480,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleSubmit,
                        className: "flex-1 py-3 bg-primary-main hover:bg-primary-light text-white rounded-xl font-semibold transition-colors",
                        children: "작성완료"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 487,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 479,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/HospitalReviewForm.tsx",
        lineNumber: 232,
        columnNumber: 5
    }, this);
}
_s(HospitalReviewForm, "y55aBcHDxMgjeXqHl6Hnq6PSd0Q=");
_c = HospitalReviewForm;
var _c;
__turbopack_context__.k.register(_c, "HospitalReviewForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ConcernPostForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConcernPostForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ConcernPostForm({ onBack, onSubmit }) {
    _s();
    const [title, setTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [concernCategory, setConcernCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // 커뮤니티 - 고민상담소 카테고리 (현재 선택 가능한 카테고리대로)
    const concernCategories = [
        "피부 고민",
        "시술 고민",
        "병원 선택",
        "가격 문의",
        "회복 기간",
        "부작용",
        "기타"
    ];
    const handleSubmit = async ()=>{
        // 필수 항목 검증
        if (!title || !concernCategory || content.length < 10) {
            alert("필수 항목을 모두 입력하고 글을 10자 이상 작성해주세요.");
            return;
        }
        try {
            // 데이터 저장
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveConcernPost"])({
                title,
                concern_category: concernCategory,
                content,
                user_id: 0
            });
            if (result.success) {
                alert("고민글이 성공적으로 작성되었습니다!");
                onSubmit();
            } else {
                alert(`고민글 작성에 실패했습니다: ${result.error}`);
            }
        } catch (error) {
            console.error("고민글 저장 오류:", error);
            alert(`고민글 작성 중 오류가 발생했습니다: ${error.message}`);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onBack,
                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                            className: "text-gray-700 text-xl"
                        }, void 0, false, {
                            fileName: "[project]/components/ConcernPostForm.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: "고민글 작성"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 69,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "제목 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 75,
                                columnNumber: 14
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: title,
                        onChange: (e)=>setTitle(e.target.value),
                        placeholder: "고민글 제목을 입력하세요",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 77,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "고민 카테고리 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 89,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 88,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: concernCategory,
                        onChange: (e)=>setConcernCategory(e.target.value),
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "고민 카테고리를 선택하세요"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 96,
                                columnNumber: 11
                            }, this),
                            concernCategories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: cat,
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/components/ConcernPostForm.tsx",
                                    lineNumber: 98,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "고민 글 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 108,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: content,
                        onChange: (e)=>setContent(e.target.value),
                        placeholder: "고민이나 질문을 자세히 작성해주세요 (10자 이상)",
                        rows: 10,
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main resize-none"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-1",
                        children: [
                            content.length,
                            "자 / 최소 10자 이상 작성해주세요"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 117,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 pt-4 pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onBack,
                        className: "flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-colors",
                        children: "취소"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 124,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleSubmit,
                        className: "flex-1 py-3 bg-primary-main hover:bg-primary-light text-white rounded-xl font-semibold transition-colors",
                        children: "작성완료"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 123,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ConcernPostForm.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
_s(ConcernPostForm, "ojOAOHULwMDRAGNvV9kVTY5rtio=");
_c = ConcernPostForm;
var _c;
__turbopack_context__.k.register(_c, "ConcernPostForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/CommunityWriteModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommunityWriteModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProcedureReviewForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ProcedureReviewForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HospitalReviewForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/HospitalReviewForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ConcernPostForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ConcernPostForm.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const writeOptions = [
    {
        id: "procedure-review",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"],
        title: "시술 후기",
        description: "시술 경험을 공유해보세요",
        color: "from-pink-500 to-rose-500"
    },
    {
        id: "hospital-review",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHome"],
        title: "병원 후기",
        description: "병원 방문 경험을 공유해보세요",
        color: "from-blue-500 to-cyan-500"
    },
    {
        id: "concern-post",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiFileText"],
        title: "고민글",
        description: "고민이나 질문을 올려보세요",
        color: "from-purple-500 to-pink-500"
    }
];
function CommunityWriteModal({ isOpen, onClose }) {
    _s();
    const [selectedOption, setSelectedOption] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    if (!isOpen) return null;
    const handleOptionClick = (optionId)=>{
        setSelectedOption(optionId);
    };
    const handleBack = ()=>{
        setSelectedOption(null);
    };
    const handleSubmit = ()=>{
        // 각 폼에서 이미 성공 메시지를 표시하므로 여기서는 alert 제거
        setSelectedOption(null);
        onClose();
        // 후기 목록 새로고침을 위한 이벤트 발생
        window.dispatchEvent(new CustomEvent("reviewAdded"));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 bg-black/50 z-[100] transition-opacity",
                onClick: onClose
            }, void 0, false, {
                fileName: "[project]/components/CommunityWriteModal.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-x-0 bottom-0 bg-white rounded-t-3xl z-[100] max-w-md mx-auto shadow-2xl animate-slide-up",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center pt-3 pb-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-12 h-1 bg-gray-300 rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/components/CommunityWriteModal.tsx",
                            lineNumber: 74,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/CommunityWriteModal.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-6 py-4 border-b border-gray-100",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-xl font-bold text-gray-900",
                                        children: "글 작성하기"
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 80,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: onClose,
                                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                            className: "text-gray-600 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                            lineNumber: 85,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 81,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/CommunityWriteModal.tsx",
                                lineNumber: 79,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-gray-500 mt-1",
                                children: "어떤 이야기를 공유하고 싶으신가요?"
                            }, void 0, false, {
                                fileName: "[project]/components/CommunityWriteModal.tsx",
                                lineNumber: 88,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/CommunityWriteModal.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-6 py-4 max-h-[70vh] overflow-y-auto",
                        children: !selectedOption ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-3",
                            children: [
                                writeOptions.map((option)=>{
                                    const Icon = option.icon;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>handleOptionClick(option.id),
                                        className: "w-full p-4 bg-gradient-to-r rounded-xl border-2 border-gray-100 hover:border-primary-main/30 hover:shadow-lg transition-all text-left group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: `bg-gradient-to-br ${option.color} p-3 rounded-xl shadow-md group-hover:scale-110 transition-transform`,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                                        className: "text-white text-xl"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                                        lineNumber: 109,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 106,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-base font-bold text-gray-900 mb-1",
                                                            children: option.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 112,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm text-gray-600",
                                                            children: option.description
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 115,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 111,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-400 group-hover:text-primary-main transition-colors",
                                                    children: "→"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 119,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                            lineNumber: 105,
                                            columnNumber: 21
                                        }, this)
                                    }, option.id, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 100,
                                        columnNumber: 19
                                    }, this);
                                }),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-t border-gray-200 pt-3 mt-3",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            // TODO: 내 글 관리 페이지로 이동
                                            alert("내 글 관리 기능은 추후 구현 예정입니다.");
                                            onClose();
                                        },
                                        className: "w-full p-4 bg-gray-50 hover:bg-gray-100 rounded-xl border-2 border-gray-200 hover:border-primary-main/30 transition-all text-left group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "bg-gradient-to-br from-gray-400 to-gray-500 p-3 rounded-xl shadow-md group-hover:scale-110 transition-transform",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiUser"], {
                                                        className: "text-white text-xl"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                                        lineNumber: 139,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 138,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-base font-bold text-gray-900 mb-1",
                                                            children: "내 글 관리"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 142,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm text-gray-600",
                                                            children: "작성한 글을 관리해보세요"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 145,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 141,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-400 group-hover:text-primary-main transition-colors",
                                                    children: "→"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 149,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                            lineNumber: 137,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 129,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 128,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/CommunityWriteModal.tsx",
                            lineNumber: 96,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                selectedOption === "procedure-review" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProcedureReviewForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onBack: handleBack,
                                    onSubmit: handleSubmit
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 159,
                                    columnNumber: 17
                                }, this),
                                selectedOption === "hospital-review" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HospitalReviewForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onBack: handleBack,
                                    onSubmit: handleSubmit
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 165,
                                    columnNumber: 17
                                }, this),
                                selectedOption === "concern-post" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ConcernPostForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onBack: handleBack,
                                    onSubmit: handleSubmit
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 171,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/CommunityWriteModal.tsx",
                            lineNumber: 157,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/CommunityWriteModal.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/CommunityWriteModal.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(CommunityWriteModal, "JA8CxE9ZrczvRffCFoauEAbBIYg=");
_c = CommunityWriteModal;
var _c;
__turbopack_context__.k.register(_c, "CommunityWriteModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/InformationalContentSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InformationalContentSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
// 정보성 컨텐츠 데이터 (임시 - 추후 API 연동)
const informationalContents = [
    {
        id: 1,
        title: "한국 성형수술 가이드: 초보자를 위한 완벽 가이드",
        description: "한국에서 성형수술을 받기 전 알아야 할 모든 것",
        category: "가이드",
        readTime: "5분",
        views: 1234
    },
    {
        id: 2,
        title: "시술별 회복기간과 주의사항",
        description: "각 시술의 다운타임과 회복 과정을 상세히 안내합니다",
        category: "정보",
        readTime: "7분",
        views: 2345
    },
    {
        id: 3,
        title: "병원 선택 시 체크리스트",
        description: "안전하고 만족스러운 병원 선택을 위한 필수 체크리스트",
        category: "가이드",
        readTime: "3분",
        views: 3456
    },
    {
        id: 4,
        title: "통역 서비스 이용 가이드",
        description: "한국어가 서툰 외국인을 위한 통역 서비스 안내",
        category: "정보",
        readTime: "4분",
        views: 1567
    },
    {
        id: 5,
        title: "비자와 여행 일정 계획하기",
        description: "성형수술 여행을 위한 비자 및 일정 계획 팁",
        category: "가이드",
        readTime: "6분",
        views: 2789
    }
];
function InformationalContentSection() {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [selectedCategory, setSelectedCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    const categories = [
        "all",
        "가이드",
        "정보"
    ];
    const filteredContents = selectedCategory === "all" ? informationalContents : informationalContents.filter((item)=>item.category === selectedCategory);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiBook"], {
                                className: "text-primary-main"
                            }, void 0, false, {
                                fileName: "[project]/components/InformationalContentSection.tsx",
                                lineNumber: 77,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-bold text-gray-900",
                                children: "정보성 컨텐츠"
                            }, void 0, false, {
                                fileName: "[project]/components/InformationalContentSection.tsx",
                                lineNumber: 78,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/InformationalContentSection.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "text-sm text-primary-main font-medium flex items-center gap-1 hover:text-primary-dark transition-colors",
                        children: [
                            "전체보기",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                                className: "text-xs"
                            }, void 0, false, {
                                fileName: "[project]/components/InformationalContentSection.tsx",
                                lineNumber: 82,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/InformationalContentSection.tsx",
                        lineNumber: 80,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/InformationalContentSection.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4 mb-4",
                children: categories.map((category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setSelectedCategory(category),
                        className: `px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${selectedCategory === category ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                        children: category === "all" ? "전체" : category
                    }, category, false, {
                        fileName: "[project]/components/InformationalContentSection.tsx",
                        lineNumber: 89,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/InformationalContentSection.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: filteredContents.map((content)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            if (content.id === 2) {
                                router.push("/community/info/recovery-guide");
                            }
                        },
                        className: "w-full bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-all text-left",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-start gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-shrink-0 w-20 h-20 bg-gradient-to-br from-primary-light/20 to-primary-main/30 rounded-lg overflow-hidden",
                                    children: content.thumbnail ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: content.thumbnail,
                                        alt: content.title,
                                        className: "w-full h-full object-cover"
                                    }, void 0, false, {
                                        fileName: "[project]/components/InformationalContentSection.tsx",
                                        lineNumber: 119,
                                        columnNumber: 19
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-full h-full flex items-center justify-center",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiBook"], {
                                            className: "text-primary-main text-2xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 126,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/InformationalContentSection.tsx",
                                        lineNumber: 125,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                    lineNumber: 117,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 min-w-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2 mb-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs bg-primary-light/20 text-primary-main px-2 py-0.5 rounded-full font-medium",
                                                    children: content.category
                                                }, void 0, false, {
                                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                                    lineNumber: 134,
                                                    columnNumber: 19
                                                }, this),
                                                content.readTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs text-gray-500",
                                                    children: [
                                                        content.readTime,
                                                        " 읽기"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                                    lineNumber: 138,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 133,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                            className: "font-semibold text-gray-900 mb-1 text-sm line-clamp-2",
                                            children: content.title
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 141,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-600 line-clamp-1 mb-2",
                                            children: content.description
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 144,
                                            columnNumber: 17
                                        }, this),
                                        content.views && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-3 text-xs text-gray-400",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: [
                                                    "조회 ",
                                                    content.views.toLocaleString()
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/InformationalContentSection.tsx",
                                                lineNumber: 149,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 148,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                    lineNumber: 132,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-shrink-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                                        className: "text-gray-400"
                                    }, void 0, false, {
                                        fileName: "[project]/components/InformationalContentSection.tsx",
                                        lineNumber: 156,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                    lineNumber: 155,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/InformationalContentSection.tsx",
                            lineNumber: 115,
                            columnNumber: 13
                        }, this)
                    }, content.id, false, {
                        fileName: "[project]/components/InformationalContentSection.tsx",
                        lineNumber: 106,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/InformationalContentSection.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/InformationalContentSection.tsx",
        lineNumber: 74,
        columnNumber: 5
    }, this);
}
_s(InformationalContentSection, "w4mrPfbRNTB+0PtKmqTkKSrAEjI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = InformationalContentSection;
var _c;
__turbopack_context__.k.register(_c, "InformationalContentSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/HomePage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HomePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$RankingBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/RankingBanner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Header.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$TravelScheduleBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/TravelScheduleBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HotConcernsSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/HotConcernsSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AIAnalysisBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AIAnalysisBanner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PromotionBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/PromotionBanner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AISkinAnalysisButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PopularReviewsSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/PopularReviewsSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$OverlayBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/OverlayBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/BottomNavigation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProcedureRecommendation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ProcedureRecommendation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CountryPainPointSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CountryPainPointSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityWriteModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CommunityWriteModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InformationalContentSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/InformationalContentSection.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function HomePage() {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    // 실제 데이터의 대분류 카테고리 10개
    const MAIN_CATEGORIES = [
        {
            id: "eyes",
            name: "눈성형",
            icon: "👀"
        },
        {
            id: "lifting",
            name: "리프팅",
            icon: "✨"
        },
        {
            id: "botox",
            name: "보톡스",
            icon: "💉"
        },
        {
            id: "facial",
            name: "안면윤곽/양악",
            icon: "😊"
        },
        {
            id: "hair-removal",
            name: "제모",
            icon: "🧴"
        },
        {
            id: "liposuction",
            name: "지방성형",
            icon: "💪"
        },
        {
            id: "nose",
            name: "코성형",
            icon: "👃"
        },
        {
            id: "skin",
            name: "피부",
            icon: "🌟"
        },
        {
            id: "filler",
            name: "필러",
            icon: "💊"
        },
        {
            id: "breast",
            name: "가슴성형",
            icon: "💕"
        }
    ];
    const [schedule, setSchedule] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        start: null,
        end: null
    });
    const [selectedCategoryId, setSelectedCategoryId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isCalendarModalOpen, setIsCalendarModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isWriteModalOpen, setIsWriteModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleScheduleChange = (start, end, categoryId)=>{
        setSchedule({
            start,
            end
        });
        // 일정 선택 시 전체 카테고리를 디폴트로 설정
        if (start && end && !categoryId) {
            setSelectedCategoryId(null); // null = 전체
        } else if (categoryId) {
            setSelectedCategoryId(categoryId);
        }
    };
    const handleCategoryClick = (id)=>{
        setSelectedCategoryId((prev)=>prev === id ? null : id);
    };
    const scheduleData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "HomePage.useMemo[scheduleData]": ()=>{
            if (!schedule.start || !schedule.end) return null;
            // selectedCategoryId가 null이면 "전체"로 설정
            const categoryLabel = selectedCategoryId ? MAIN_CATEGORIES.find({
                "HomePage.useMemo[scheduleData]": (c)=>c.id === selectedCategoryId
            }["HomePage.useMemo[scheduleData]"]) ? MAIN_CATEGORIES.find({
                "HomePage.useMemo[scheduleData]": (c)=>c.id === selectedCategoryId
            }["HomePage.useMemo[scheduleData]"]).name : "전체" : "전체";
            return {
                travelPeriod: {
                    start: schedule.start,
                    end: schedule.end
                },
                travelRegion: "서울",
                procedureCategory: categoryLabel,
                estimatedBudget: "100만원 미만"
            };
        }
    }["HomePage.useMemo[scheduleData]"], [
        schedule.start,
        schedule.end,
        selectedCategoryId,
        t
    ]);
    const hasFullSchedule = !!(schedule.start && schedule.end);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white max-w-md mx-auto w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$RankingBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/HomePage.tsx",
                lineNumber: 91,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                hasRankingBanner: true
            }, void 0, false, {
                fileName: "[project]/components/HomePage.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pt-[41px] px-4 pb-20",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$TravelScheduleBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            onScheduleChange: handleScheduleChange,
                            onModalStateChange: setIsCalendarModalOpen
                        }, void 0, false, {
                            fileName: "[project]/components/HomePage.tsx",
                            lineNumber: 99,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/HomePage.tsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, this),
                    scheduleData ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-6 -mx-4 bg-gray-50",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProcedureRecommendation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            scheduleData: scheduleData,
                            selectedCategoryId: selectedCategoryId,
                            onCategoryChange: setSelectedCategoryId,
                            mainCategories: MAIN_CATEGORIES
                        }, void 0, false, {
                            fileName: "[project]/components/HomePage.tsx",
                            lineNumber: 108,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/HomePage.tsx",
                        lineNumber: 107,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HotConcernsSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/components/HomePage.tsx",
                        lineNumber: 116,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PromotionBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/components/HomePage.tsx",
                        lineNumber: 120,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InformationalContentSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/components/HomePage.tsx",
                        lineNumber: 123,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CountryPainPointSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/components/HomePage.tsx",
                        lineNumber: 129,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AIAnalysisBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/components/HomePage.tsx",
                        lineNumber: 135,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PopularReviewsSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/components/HomePage.tsx",
                        lineNumber: 138,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setIsWriteModalOpen(true),
                            className: "w-full bg-primary-main hover:bg-[#2DB8A0] text-white rounded-xl px-4 py-3 flex items-center justify-center gap-2 font-semibold transition-colors shadow-md",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: t("home.reviewButton")
                                }, void 0, false, {
                                    fileName: "[project]/components/HomePage.tsx",
                                    lineNumber: 149,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: ">"
                                }, void 0, false, {
                                    fileName: "[project]/components/HomePage.tsx",
                                    lineNumber: 150,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/HomePage.tsx",
                            lineNumber: 145,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/HomePage.tsx",
                        lineNumber: 144,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HomePage.tsx",
                lineNumber: 95,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AISkinAnalysisButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/HomePage.tsx",
                lineNumber: 159,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$OverlayBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/HomePage.tsx",
                lineNumber: 164,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityWriteModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isWriteModalOpen,
                onClose: ()=>setIsWriteModalOpen(false)
            }, void 0, false, {
                fileName: "[project]/components/HomePage.tsx",
                lineNumber: 167,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pb-20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    disabled: isCalendarModalOpen
                }, void 0, false, {
                    fileName: "[project]/components/HomePage.tsx",
                    lineNumber: 173,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/HomePage.tsx",
                lineNumber: 172,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/HomePage.tsx",
        lineNumber: 89,
        columnNumber: 5
    }, this);
}
_s(HomePage, "2EItLQY6YU/LZriIoqDS/3fhaD4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = HomePage;
var _c;
__turbopack_context__.k.register(_c, "HomePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HomePage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/HomePage.tsx [app-client] (ecmascript)");
"use client";
;
;
function Home() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HomePage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 6,
        columnNumber: 10
    }, this);
}
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_d5b49a11._.js.map