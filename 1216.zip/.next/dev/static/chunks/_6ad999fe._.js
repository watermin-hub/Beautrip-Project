(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/AutocompleteInput.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AutocompleteInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function AutocompleteInput({ value, onChange, placeholder = "검색...", suggestions, onSuggestionSelect, onEnter, className = "" }) {
    _s();
    const [showSuggestions, setShowSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [focusedIndex, setFocusedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const [isComposing, setIsComposing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // 한글 입력 조합 중인지 추적
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const suggestionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // 외부 클릭 시 자동완성 닫기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AutocompleteInput.useEffect": ()=>{
            const handleClickOutside = {
                "AutocompleteInput.useEffect.handleClickOutside": (event)=>{
                    if (inputRef.current && !inputRef.current.contains(event.target) && suggestionsRef.current && !suggestionsRef.current.contains(event.target)) {
                        setShowSuggestions(false);
                    }
                }
            }["AutocompleteInput.useEffect.handleClickOutside"];
            document.addEventListener("mousedown", handleClickOutside);
            return ({
                "AutocompleteInput.useEffect": ()=>document.removeEventListener("mousedown", handleClickOutside)
            })["AutocompleteInput.useEffect"];
        }
    }["AutocompleteInput.useEffect"], []);
    // 자동완성 선택으로 인한 value 변경인지 추적
    const isSuggestionSelectedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    // 검색어가 변경되면 자동완성 표시
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AutocompleteInput.useEffect": ()=>{
            // 자동완성 선택으로 인한 value 변경이면 자동완성을 다시 열지 않음
            if (isSuggestionSelectedRef.current) {
                isSuggestionSelectedRef.current = false;
                return;
            }
            setShowSuggestions(value.length > 0 && suggestions.length > 0);
            setFocusedIndex(-1);
        }
    }["AutocompleteInput.useEffect"], [
        value,
        suggestions
    ]);
    const handleInputChange = (e)=>{
        // 항상 onChange 호출 (입력 필드가 업데이트되도록)
        onChange(e.target.value);
    };
    // 한글 입력 조합 시작
    const handleCompositionStart = ()=>{
        setIsComposing(true);
    };
    // 한글 입력 조합 종료
    const handleCompositionEnd = (e)=>{
        setIsComposing(false);
        // 조합이 완료되면 최종 값을 onChange로 전달 (이미 handleInputChange에서 호출되지만 확실히 하기 위해)
        onChange(e.currentTarget.value);
    };
    const handleSuggestionClick = (suggestion)=>{
        // 자동완성 선택 플래그 설정 (value 변경으로 인해 자동완성이 다시 열리지 않도록)
        isSuggestionSelectedRef.current = true;
        // 먼저 자동완성을 닫고, 그 다음에 onChange 호출
        setShowSuggestions(false);
        onChange(suggestion);
        if (onSuggestionSelect) {
            onSuggestionSelect(suggestion);
        }
        inputRef.current?.blur();
    };
    const handleKeyDown = (e)=>{
        if (e.key === "Enter") {
            if (showSuggestions && suggestions.length > 0 && focusedIndex >= 0) {
                // 자동완성 항목이 선택된 경우
                e.preventDefault();
                handleSuggestionClick(suggestions[focusedIndex]);
            } else if (onEnter && value.trim().length >= 2) {
                // 자동완성 항목이 선택되지 않은 경우 Enter 키 처리 (2글자 이상일 때만)
                e.preventDefault();
                onEnter();
            }
            return;
        }
        if (!showSuggestions || suggestions.length === 0) return;
        if (e.key === "ArrowDown") {
            e.preventDefault();
            setFocusedIndex((prev)=>prev < suggestions.length - 1 ? prev + 1 : prev);
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setFocusedIndex((prev)=>prev > 0 ? prev - 1 : -1);
        } else if (e.key === "Escape") {
            setShowSuggestions(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-3 top-1/2 transform -translate-y-1/2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSearch"], {
                            className: "text-gray-400 text-sm"
                        }, void 0, false, {
                            fileName: "[project]/components/AutocompleteInput.tsx",
                            lineNumber: 124,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 123,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: inputRef,
                        type: "text",
                        value: value,
                        onChange: handleInputChange,
                        onCompositionStart: handleCompositionStart,
                        onCompositionEnd: handleCompositionEnd,
                        onKeyDown: handleKeyDown,
                        onFocus: ()=>{
                            if (value.length > 0 && suggestions.length > 0) {
                                setShowSuggestions(true);
                            }
                        },
                        placeholder: placeholder,
                        className: `w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-main ${className}`
                    }, void 0, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/AutocompleteInput.tsx",
                lineNumber: 122,
                columnNumber: 7
            }, this),
            showSuggestions && suggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: suggestionsRef,
                className: "absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto",
                children: suggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>handleSuggestionClick(suggestion),
                        onMouseEnter: ()=>setFocusedIndex(index),
                        className: `w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${index === focusedIndex ? "bg-gray-50" : ""}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSearch"], {
                                    className: "text-gray-400 text-xs"
                                }, void 0, false, {
                                    fileName: "[project]/components/AutocompleteInput.tsx",
                                    lineNumber: 161,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: suggestion
                                }, void 0, false, {
                                    fileName: "[project]/components/AutocompleteInput.tsx",
                                    lineNumber: 162,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AutocompleteInput.tsx",
                            lineNumber: 160,
                            columnNumber: 15
                        }, this)
                    }, index, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 151,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/AutocompleteInput.tsx",
                lineNumber: 146,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/AutocompleteInput.tsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
_s(AutocompleteInput, "+C4g0DflqOSlovvKMUTWVOQq8lc=");
_c = AutocompleteInput;
var _c;
__turbopack_context__.k.register(_c, "AutocompleteInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/SearchModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SearchModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AutocompleteInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AutocompleteInput.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const MAX_RECENT_SEARCHES = 10; // 최대 최근 검색어 개수
const recommendedSearches = [
    {
        id: 1,
        name: "리쥬란힐러",
        badge: "BEST"
    },
    {
        id: 2,
        name: "써마지",
        badge: "BEST"
    },
    {
        id: 3,
        name: "쥬베룩",
        badge: "BEST"
    },
    {
        id: 4,
        name: "울쎄라",
        badge: "up"
    },
    {
        id: 5,
        name: "LDM",
        badge: "up"
    },
    {
        id: 6,
        name: "스킨부"
    },
    {
        id: 7,
        name: "올리지"
    },
    {
        id: 8,
        name: "튠페"
    },
    {
        id: 9,
        name: "쎄라플"
    },
    {
        id: 10,
        name: "리프터"
    }
];
const quickIcons = [
    {
        id: 1,
        label: "블프 세일 대축제",
        icon: "🛍️"
    },
    {
        id: 2,
        label: "요즘인기시술",
        icon: "⭐"
    },
    {
        id: 3,
        label: "혜택 플러스",
        icon: "💎"
    },
    {
        id: 4,
        label: "포인트 적립백서",
        icon: "📝"
    },
    {
        id: 5,
        label: "부작용 안심케어",
        icon: "🛡️"
    }
];
const recentEvents = [
    {
        id: 1,
        title: "Shurink Universe",
        clinic: "본연_슈링크 유니버스",
        location: "서울 강남역·본연성...",
        price: "120,000원",
        image: ""
    },
    {
        id: 2,
        title: "Eight longtime #인모드 #슈링크",
        clinic: "지방소멸 롱타임 인모드리프팅 슈링...",
        location: "서울 압구정역·에이...",
        price: "₩108,900",
        image: ""
    },
    {
        id: 3,
        title: "시술 시간 걱정 없이 인모드는 롱~모드로!",
        clinic: "롱모드 인모드 풀페이스 10분 FX...",
        location: "서울 홍대입구역·리...",
        price: "99,000원",
        image: ""
    },
    {
        id: 4,
        title: "후기 6,000+ 디에이 자려한 코성형",
        clinic: "예쁘면DA야_자려한 코성형_비순각코수...",
        location: "서울 역삼역·디에이...",
        price: "1,088,000원",
        image: ""
    }
];
const interestProcedures = [
    "인모드리프팅",
    "슈링크리프팅",
    "슈링크유니버스",
    "코재수술",
    "아이슈링크"
];
const categories = [
    {
        icon: "👁️",
        label: "눈성형"
    },
    {
        icon: "👃",
        label: "코성형"
    },
    {
        icon: "😊",
        label: "안면윤곽/양악"
    },
    {
        icon: "💪",
        label: "가슴성형"
    },
    {
        icon: "🏃",
        label: "지방성형"
    },
    {
        icon: "💉",
        label: "필러"
    },
    {
        icon: "💉",
        label: "보톡스"
    },
    {
        icon: "✨",
        label: "리프팅"
    },
    {
        icon: "🌟",
        label: "피부"
    },
    {
        icon: "✂️",
        label: "제모"
    },
    {
        icon: "💇",
        label: "모발이식"
    },
    {
        icon: "🦷",
        label: "치아"
    },
    {
        icon: "🍵",
        label: "한방"
    },
    {
        icon: "📦",
        label: "기타"
    }
];
function SearchModal({ isOpen, onClose }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedRegion, setSelectedRegion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("지역");
    const [recentSearches, setRecentSearches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [autocompleteSuggestions, setAutocompleteSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // localStorage에서 최근 검색어 불러오기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SearchModal.useEffect": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                const saved = localStorage.getItem("recentSearches");
                if (saved) {
                    try {
                        setRecentSearches(JSON.parse(saved));
                    } catch (e) {
                        console.error("Failed to parse recent searches", e);
                    }
                }
            }
        }
    }["SearchModal.useEffect"], []);
    // 자동완성 데이터 로드
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SearchModal.useEffect": ()=>{
            const loadAutocomplete = {
                "SearchModal.useEffect.loadAutocomplete": async ()=>{
                    if (searchQuery.length < 1) {
                        setAutocompleteSuggestions([]);
                        return;
                    }
                    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTreatmentAutocomplete"])(searchQuery, 10);
                    const allSuggestions = [
                        ...result.treatmentNames,
                        ...result.hospitalNames
                    ];
                    setAutocompleteSuggestions(allSuggestions);
                }
            }["SearchModal.useEffect.loadAutocomplete"];
            const debounceTimer = setTimeout({
                "SearchModal.useEffect.debounceTimer": ()=>{
                    loadAutocomplete();
                }
            }["SearchModal.useEffect.debounceTimer"], 300);
            return ({
                "SearchModal.useEffect": ()=>clearTimeout(debounceTimer)
            })["SearchModal.useEffect"];
        }
    }["SearchModal.useEffect"], [
        searchQuery
    ]);
    // 최근 검색어에 추가하는 함수
    const addToRecentSearches = (query)=>{
        const trimmedQuery = query.trim();
        if (!trimmedQuery) return;
        setRecentSearches((prev)=>{
            // 중복 제거 (기존 항목 제거 후 맨 앞에 추가)
            const filtered = prev.filter((item)=>item !== trimmedQuery);
            const updated = [
                trimmedQuery,
                ...filtered
            ].slice(0, MAX_RECENT_SEARCHES);
            // localStorage에 저장
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("recentSearches", JSON.stringify(updated));
            }
            return updated;
        });
    };
    // 개별 검색어 삭제
    const removeRecentSearch = (query, e)=>{
        e.stopPropagation(); // 버튼 클릭 이벤트 전파 방지
        setRecentSearches((prev)=>{
            const updated = prev.filter((item)=>item !== query);
            // localStorage에 저장
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("recentSearches", JSON.stringify(updated));
            }
            return updated;
        });
    };
    // 전체 검색어 삭제
    const clearAllRecentSearches = ()=>{
        setRecentSearches([]);
        if ("TURBOPACK compile-time truthy", 1) {
            localStorage.removeItem("recentSearches");
        }
    };
    const handleSearch = ()=>{
        if (searchQuery.trim()) {
            // 최근 검색어에 추가
            addToRecentSearches(searchQuery.trim());
            // 탐색 페이지로 이동하면서 검색어와 섹션 정보 전달
            router.push(`/explore?search=${encodeURIComponent(searchQuery.trim())}&section=procedure`);
            onClose();
        }
    };
    const handleKeyPress = (e)=>{
        if (e.key === "Enter") {
            handleSearch();
        }
    };
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[100] bg-white overflow-y-auto max-w-md mx-auto left-1/2 transform -translate-x-1/2 pb-20 w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sticky top-0 z-50 bg-white border-b border-gray-100 px-4 py-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClose,
                                className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                                    className: "text-gray-700 text-xl"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 218,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 214,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 relative",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AutocompleteInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    value: searchQuery,
                                    onChange: setSearchQuery,
                                    placeholder: "시술명/수술명을 입력해 주세요.",
                                    suggestions: autocompleteSuggestions,
                                    onSuggestionSelect: (suggestion)=>{
                                        setSearchQuery(suggestion);
                                        // 자동완성 선택 시 바로 검색 실행
                                        setTimeout(()=>{
                                            handleSearch();
                                        }, 100);
                                    },
                                    onEnter: handleSearch,
                                    className: "bg-gray-50 border border-gray-200"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 221,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 220,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleSearch,
                                className: "px-3 py-2 text-primary-main text-sm font-medium hover:bg-primary-main/10 rounded-lg transition-colors",
                                children: "검색"
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 237,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 213,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "flex items-center gap-1 text-gray-700 text-sm hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: selectedRegion
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 248,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronDown"], {
                                    className: "text-gray-500 text-sm"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 249,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/SearchModal.tsx",
                            lineNumber: 247,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 246,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SearchModal.tsx",
                lineNumber: 212,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 py-6 space-y-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative bg-black rounded-2xl overflow-hidden p-6 min-h-[160px] flex items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute inset-0 opacity-5",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-0",
                                    style: {
                                        backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.1) 10px, rgba(255,255,255,0.1) 20px)"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 259,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 258,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative w-full",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start justify-between mb-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-white text-xs",
                                                children: "K-피부시술 세일 페스타, 모든 시술이 한자리에!"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 269,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-primary-main text-white px-3 py-1 rounded-full text-xs font-bold flex-shrink-0 ml-2",
                                                children: "~49% off"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 272,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 268,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-4xl font-black mb-3 leading-tight",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white",
                                                children: "BLACK"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 277,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-primary-light relative",
                                                children: [
                                                    "BEAUTY",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "absolute -top-1 -right-3 text-primary-main text-xs",
                                                        children: "★"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 280,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 278,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white",
                                                children: "FRIDAY"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 284,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 276,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-white text-sm",
                                        children: "11.11 — 12.10"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 286,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 267,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 257,
                        columnNumber: 9
                    }, this),
                    recentSearches.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-base font-bold text-gray-900",
                                        children: "최근 검색어"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 294,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: clearAllRecentSearches,
                                        className: "text-sm text-gray-500 hover:text-gray-700",
                                        children: "전체삭제"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 295,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 293,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 flex-wrap",
                                children: recentSearches.map((search, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setSearchQuery(search);
                                            addToRecentSearches(search); // 클릭 시에도 최근 검색어에 추가 (순서 업데이트)
                                            router.push(`/explore?search=${encodeURIComponent(search)}&section=procedure`);
                                            onClose();
                                        },
                                        className: "flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-full text-sm transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: search
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 318,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                onClick: (e)=>{
                                                    e.stopPropagation();
                                                    removeRecentSearch(search, e);
                                                },
                                                className: "hover:bg-gray-300 rounded-full p-0.5 transition-colors cursor-pointer",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoClose"], {
                                                    className: "text-gray-500 text-sm"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/SearchModal.tsx",
                                                    lineNumber: 326,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 319,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, index, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 304,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 302,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 292,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-5 gap-4",
                        children: quickIcons.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "flex flex-col items-center gap-2 p-3 hover:bg-gray-50 rounded-xl transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-12 h-12 bg-gradient-to-br from-primary-light/20 to-primary-main/30 rounded-full flex items-center justify-center text-xl",
                                        children: item.icon
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 341,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-700 text-center leading-tight",
                                        children: item.label
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 344,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, item.id, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 337,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 335,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-base font-bold text-gray-900 mb-4",
                                children: "추천 검색어"
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 353,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-4",
                                children: recommendedSearches.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setSearchQuery(item.name);
                                            addToRecentSearches(item.name); // 추천 검색어 클릭 시에도 최근 검색어에 추가
                                            router.push(`/explore?search=${encodeURIComponent(item.name)}&section=procedure`);
                                            onClose();
                                        },
                                        className: "flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors text-left",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-primary-main font-bold text-sm min-w-[20px]",
                                                        children: item.id
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 373,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-gray-900 text-sm",
                                                        children: item.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 376,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 372,
                                                columnNumber: 17
                                            }, this),
                                            item.badge === "BEST" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "bg-primary-light/20 text-primary-main px-2 py-0.5 rounded text-xs font-semibold",
                                                children: "BEST"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 379,
                                                columnNumber: 19
                                            }, this),
                                            item.badge === "up" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-3 h-3 text-primary-main",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    fillRule: "evenodd",
                                                    d: "M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z",
                                                    clipRule: "evenodd"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/SearchModal.tsx",
                                                    lineNumber: 389,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 384,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, item.id, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 358,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 356,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 352,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SearchModal.tsx",
                lineNumber: 255,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/SearchModal.tsx",
        lineNumber: 210,
        columnNumber: 5
    }, this);
}
_s(SearchModal, "RfQBDmNVGE2WOvqHX2rzPVGKT74=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = SearchModal;
var _c;
__turbopack_context__.k.register(_c, "SearchModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Header.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/bs/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SearchModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SearchModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function Header({ hasRankingBanner = false }) {
    _s();
    const [isSearchOpen, setIsSearchOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLanguageOpen, setIsLanguageOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [logoError, setLogoError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const globeButtonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { language, setLanguage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [dropdownPosition, setDropdownPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        top: 0,
        right: 0
    });
    const languages = [
        {
            code: "KR",
            name: "한국어",
            flag: "🇰🇷"
        },
        {
            code: "EN",
            name: "English",
            flag: "🇺🇸"
        },
        {
            code: "JP",
            name: "日本語",
            flag: "🇯🇵"
        },
        {
            code: "CN",
            name: "中文",
            flag: "🇨🇳"
        }
    ];
    const selectedLanguage = languages.find((lang)=>lang.code === language) || languages[0];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Header.useEffect": ()=>{
            if (isLanguageOpen && globeButtonRef.current) {
                const rect = globeButtonRef.current.getBoundingClientRect();
                setDropdownPosition({
                    top: rect.bottom + 8,
                    right: window.innerWidth - rect.right
                });
            }
        }
    }["Header.useEffect"], [
        isLanguageOpen
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: `sticky ${hasRankingBanner ? "top-[41px]" : "top-0"} z-40 bg-white border-b border-gray-100 px-4 py-3`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>router.push("/"),
                            className: "flex items-center gap-2 hover:opacity-80 transition-opacity cursor-pointer",
                            children: !logoError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/beautrip-logo.png",
                                alt: "BeauTrip",
                                className: "h-6 w-auto object-contain",
                                onError: ()=>setLogoError(true)
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 63,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BsCloud"], {
                                className: "text-primary-main text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 70,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4 relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setIsSearchOpen(true),
                                    className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSearch"], {
                                        className: "text-gray-700 text-xl"
                                    }, void 0, false, {
                                        fileName: "[project]/components/Header.tsx",
                                        lineNumber: 81,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            ref: globeButtonRef,
                                            onClick: ()=>setIsLanguageOpen(!isLanguageOpen),
                                            className: "p-2 hover:bg-gray-50 rounded-full transition-colors relative z-[100]",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiGlobe"], {
                                                className: "text-gray-700 text-xl"
                                            }, void 0, false, {
                                                fileName: "[project]/components/Header.tsx",
                                                lineNumber: 89,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this),
                                        isLanguageOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "fixed inset-0 z-[99]",
                                                    onClick: ()=>setIsLanguageOpen(false)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Header.tsx",
                                                    lineNumber: 93,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "fixed bg-white border border-gray-200 rounded-lg shadow-lg z-[100] min-w-[150px]",
                                                    style: {
                                                        top: `${dropdownPosition.top}px`,
                                                        right: `${dropdownPosition.right}px`
                                                    },
                                                    children: languages.map((lang)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>{
                                                                setLanguage(lang.code);
                                                                setIsLanguageOpen(false);
                                                            },
                                                            className: `w-full text-left px-4 py-2 hover:bg-gray-50 transition-colors flex items-center gap-2 ${selectedLanguage.code === lang.code ? "bg-primary-main/10" : ""}`,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: lang.flag
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 117,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-gray-700",
                                                                    children: lang.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 118,
                                                                    columnNumber: 25
                                                                }, this),
                                                                selectedLanguage.code === lang.code && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "ml-auto text-primary-main",
                                                                    children: "✓"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 122,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, lang.code, true, {
                                                            fileName: "[project]/components/Header.tsx",
                                                            lineNumber: 105,
                                                            columnNumber: 23
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Header.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 83,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "p-2 hover:bg-gray-50 rounded-full transition-colors relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiBell"], {
                                            className: "text-gray-700 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 131,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/Header.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/Header.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SearchModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isSearchOpen,
                onClose: ()=>setIsSearchOpen(false)
            }, void 0, false, {
                fileName: "[project]/components/Header.tsx",
                lineNumber: 137,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(Header, "wHAZrX0YKQ6dHEhrD591unZdiTg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/BottomNavigation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BottomNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const navItems = [
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHome"],
        labelKey: "nav.home",
        path: "/"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCompass"],
        labelKey: "nav.explore",
        path: "/explore"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiUsers"],
        labelKey: "nav.community",
        path: "/community"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCalendar"],
        labelKey: "nav.schedule",
        path: "/schedule"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiUser"],
        labelKey: "nav.mypage",
        path: "/mypage"
    }
];
function BottomNavigation({ disabled = false }) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: `fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 z-50 ${disabled ? "pointer-events-none" : ""}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-around items-center py-2",
            children: navItems.map((item)=>{
                const Icon = item.icon;
                const isActive = pathname === item.path;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: item.path,
                    className: `flex flex-col items-center justify-center gap-1 py-1 px-2 min-w-0 flex-1 transition-colors ${disabled ? "text-gray-300 cursor-not-allowed" : isActive ? "text-primary-main" : "text-gray-500"}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                            className: `text-xl ${disabled ? "text-gray-300" : isActive ? "text-primary-main" : "text-gray-500"}`
                        }, void 0, false, {
                            fileName: "[project]/components/BottomNavigation.tsx",
                            lineNumber: 43,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: `text-xs whitespace-nowrap ${disabled ? "text-gray-300" : isActive ? "text-primary-main font-medium" : "text-gray-500"}`,
                            children: t(item.labelKey)
                        }, void 0, false, {
                            fileName: "[project]/components/BottomNavigation.tsx",
                            lineNumber: 52,
                            columnNumber: 15
                        }, this)
                    ]
                }, item.path, true, {
                    fileName: "[project]/components/BottomNavigation.tsx",
                    lineNumber: 32,
                    columnNumber: 13
                }, this);
            })
        }, void 0, false, {
            fileName: "[project]/components/BottomNavigation.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/BottomNavigation.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_s(BottomNavigation, "xidiIFVahZXU1vxN+08Jg/l1pJo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = BottomNavigation;
var _c;
__turbopack_context__.k.register(_c, "BottomNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ReviewWriteModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ReviewWriteModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function ReviewWriteModal({ isOpen, onClose, filterData }) {
    _s();
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [rating, setRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [procedure, setProcedure] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [clinic, setClinic] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [images, setImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ReviewWriteModal.useEffect": ()=>{
            if (filterData?.category && filterData.category !== 'All') {
                setProcedure(filterData.category);
            }
            if (filterData?.rating && filterData.rating !== 'All') {
                setRating(parseInt(filterData.rating));
            }
        }
    }["ReviewWriteModal.useEffect"], [
        filterData
    ]);
    if (!isOpen) return null;
    const handleImageUpload = (e)=>{
        if (e.target.files) {
            const files = Array.from(e.target.files);
            const newImages = files.map((file)=>URL.createObjectURL(file));
            setImages([
                ...images,
                ...newImages
            ].slice(0, 5));
        }
    };
    const handleSubmit = ()=>{
        if (!content.trim()) {
            alert('리뷰 내용을 입력해주세요.');
            return;
        }
        const newReview = {
            id: Date.now(),
            category: '후기',
            username: '사용자',
            avatar: '👤',
            content: content,
            images: images.length > 0 ? images : undefined,
            timestamp: '방금 전',
            upvotes: 0,
            comments: 0,
            views: 0,
            rating: rating > 0 ? rating : undefined,
            procedure: procedure || undefined,
            clinic: clinic || undefined
        };
        // 로컬 스토리지에 저장
        const existingReviews = JSON.parse(localStorage.getItem('reviews') || '[]');
        existingReviews.unshift(newReview);
        localStorage.setItem('reviews', JSON.stringify(existingReviews));
        // 이벤트 발생하여 최신글 업데이트
        window.dispatchEvent(new Event('reviewAdded'));
        alert('리뷰가 작성되었습니다!');
        setContent('');
        setRating(0);
        setProcedure('');
        setClinic('');
        setImages([]);
        onClose();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[100] bg-black/50 flex items-center justify-center p-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-md mx-auto bg-white rounded-2xl max-h-[90vh] overflow-y-auto pb-20",
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sticky top-0 bg-white border-b border-gray-200 px-4 py-4 flex items-center justify-between z-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-lg font-bold text-gray-900",
                            children: "리뷰 작성"
                        }, void 0, false, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 106,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "p-2 hover:bg-gray-100 rounded-full transition-colors",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                className: "text-xl text-gray-700"
                            }, void 0, false, {
                                fileName: "[project]/components/ReviewWriteModal.tsx",
                                lineNumber: 111,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 107,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ReviewWriteModal.tsx",
                    lineNumber: 105,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-4 py-6 space-y-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-semibold text-gray-900 mb-2 block",
                                    children: "시술 종류"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 119,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    value: procedure,
                                    onChange: (e)=>setProcedure(e.target.value),
                                    placeholder: "받으신 시술을 입력해주세요",
                                    className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-main"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 120,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 118,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-semibold text-gray-900 mb-2 block",
                                    children: "병원/클리닉"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 131,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    value: clinic,
                                    onChange: (e)=>setClinic(e.target.value),
                                    placeholder: "병원 또는 클리닉 이름을 입력해주세요",
                                    className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-main"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 132,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 130,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-semibold text-gray-900 mb-2 block",
                                    children: "평점"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 143,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-2",
                                    children: [
                                        1,
                                        2,
                                        3,
                                        4,
                                        5
                                    ].map((star)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>setRating(star),
                                            className: "p-2",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiStar"], {
                                                className: `text-2xl ${star <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`
                                            }, void 0, false, {
                                                fileName: "[project]/components/ReviewWriteModal.tsx",
                                                lineNumber: 151,
                                                columnNumber: 19
                                            }, this)
                                        }, star, false, {
                                            fileName: "[project]/components/ReviewWriteModal.tsx",
                                            lineNumber: 146,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 144,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 142,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-semibold text-gray-900 mb-2 block",
                                    children: "리뷰 내용"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 165,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                    value: content,
                                    onChange: (e)=>setContent(e.target.value),
                                    placeholder: "시술 경험을 자세히 작성해주세요...",
                                    rows: 8,
                                    className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-main resize-none"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 166,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 164,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-semibold text-gray-900 mb-2 block",
                                    children: "사진 첨부 (최대 5장)"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 177,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-2 flex-wrap",
                                    children: [
                                        images.map((img, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative w-24 h-24 rounded-lg overflow-hidden",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: img,
                                                        alt: `Upload ${idx + 1}`,
                                                        className: "w-full h-full object-cover"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ReviewWriteModal.tsx",
                                                        lineNumber: 181,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>setImages(images.filter((_, i)=>i !== idx)),
                                                        className: "absolute top-1 right-1 bg-black/50 text-white rounded-full p-1",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                                            className: "text-xs"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ReviewWriteModal.tsx",
                                                            lineNumber: 186,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ReviewWriteModal.tsx",
                                                        lineNumber: 182,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, idx, true, {
                                                fileName: "[project]/components/ReviewWriteModal.tsx",
                                                lineNumber: 180,
                                                columnNumber: 17
                                            }, this)),
                                        images.length < 5 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "w-24 h-24 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center cursor-pointer hover:border-primary-main transition-colors",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "file",
                                                    accept: "image/*",
                                                    multiple: true,
                                                    onChange: handleImageUpload,
                                                    className: "hidden"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                                    lineNumber: 192,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiImage"], {
                                                    className: "text-2xl text-gray-400"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                                    lineNumber: 199,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/ReviewWriteModal.tsx",
                                            lineNumber: 191,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 178,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 176,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ReviewWriteModal.tsx",
                    lineNumber: 116,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sticky bottom-0 bg-white border-t border-gray-200 px-4 py-4 flex gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-semibold transition-colors hover:bg-gray-200",
                            children: "취소"
                        }, void 0, false, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 208,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleSubmit,
                            className: "flex-1 bg-primary-main text-white py-3 rounded-lg font-semibold transition-colors hover:bg-[#2DB8A0]",
                            children: "작성 완료"
                        }, void 0, false, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 214,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ReviewWriteModal.tsx",
                    lineNumber: 207,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/ReviewWriteModal.tsx",
            lineNumber: 100,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ReviewWriteModal.tsx",
        lineNumber: 99,
        columnNumber: 5
    }, this);
}
_s(ReviewWriteModal, "Iu9HMalle8SqCXWOKx9NWFHI9IM=");
_c = ReviewWriteModal;
var _c;
__turbopack_context__.k.register(_c, "ReviewWriteModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ReviewFilterModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ReviewFilterModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ReviewWriteModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ReviewWriteModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function ReviewFilterModal({ isOpen, onClose }) {
    _s();
    const [selectedGender, setSelectedGender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('All');
    const [selectedCategory, setSelectedCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('All');
    const [selectedRating, setSelectedRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('All');
    const [selectedDistance, setSelectedDistance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('All');
    const [showWriteModal, setShowWriteModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    if (!isOpen) return null;
    const handleApplyFilter = ()=>{
        setShowWriteModal(true);
    };
    const handleReset = ()=>{
        setSelectedGender('All');
        setSelectedCategory('All');
        setSelectedRating('All');
        setSelectedDistance('All');
    };
    const handleCloseWriteModal = ()=>{
        setShowWriteModal(false);
        onClose();
    };
    const genders = [
        'All',
        'Male',
        'Female',
        'Others'
    ];
    const categories = [
        'All',
        '눈성형',
        '코성형',
        '리프팅',
        '피부',
        '보톡스/필러'
    ];
    const ratings = [
        'All',
        '5',
        '4',
        '3',
        '2',
        '1'
    ];
    const distances = [
        'All',
        '1 Km',
        '1-3 Km',
        '3-5 Km',
        '5 Km 이상'
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-[100] bg-black/50 flex items-end justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full max-w-md bg-white rounded-t-3xl max-h-[85vh] overflow-y-auto animate-slide-up pb-20",
                    onClick: (e)=>e.stopPropagation(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "sticky top-0 bg-white border-b border-gray-200 px-4 py-4 flex items-center justify-between z-10",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-bold text-gray-900",
                                    children: "Filter your Need"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onClose,
                                    className: "p-2 hover:bg-gray-100 rounded-full transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                        className: "text-xl text-gray-700"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ReviewFilterModal.tsx",
                                        lineNumber: 56,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 52,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewFilterModal.tsx",
                            lineNumber: 50,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-4 py-6 space-y-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-semibold text-gray-900 mb-3 block",
                                            children: "성별"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 64,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2 flex-wrap",
                                            children: genders.map((gender)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>setSelectedGender(gender),
                                                    className: `px-4 py-2 rounded-full text-sm font-medium transition-colors ${selectedGender === gender ? 'bg-primary-main text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`,
                                                    children: gender === 'All' ? '전체' : gender === 'Male' ? '남성' : gender === 'Female' ? '여성' : '기타'
                                                }, gender, false, {
                                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                                    lineNumber: 67,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 63,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-semibold text-gray-900 mb-3 block",
                                            children: "시술 카테고리"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2 flex-wrap",
                                            children: categories.map((category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>setSelectedCategory(category),
                                                    className: `px-4 py-2 rounded-full text-sm font-medium transition-colors ${selectedCategory === category ? 'bg-primary-main text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`,
                                                    children: category
                                                }, category, false, {
                                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                                    lineNumber: 87,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 85,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 83,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-semibold text-gray-900 mb-3 block",
                                            children: "평점"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 104,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2 flex-wrap",
                                            children: ratings.map((rating)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>setSelectedRating(rating),
                                                    className: `px-4 py-2 rounded-full text-sm font-medium transition-colors flex items-center gap-1 ${selectedRating === rating ? 'bg-primary-main text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`,
                                                    children: [
                                                        rating !== 'All' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: "⭐"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                                            lineNumber: 116,
                                                            columnNumber: 42
                                                        }, this),
                                                        rating === 'All' ? '전체' : rating
                                                    ]
                                                }, rating, true, {
                                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                                    lineNumber: 107,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 105,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 103,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-semibold text-gray-900 mb-3 block",
                                            children: "거리"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 125,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2 flex-wrap",
                                            children: distances.map((distance)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>setSelectedDistance(distance),
                                                    className: `px-4 py-2 rounded-full text-sm font-medium transition-colors ${selectedDistance === distance ? 'bg-primary-main text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`,
                                                    children: distance === 'All' ? '전체' : distance
                                                }, distance, false, {
                                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                                    lineNumber: 128,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 126,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 124,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewFilterModal.tsx",
                            lineNumber: 61,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "sticky bottom-0 bg-white border-t border-gray-200 px-4 py-4 flex gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleReset,
                                    className: "flex-1 bg-white border border-gray-300 text-gray-700 py-3 rounded-lg font-semibold transition-colors hover:bg-gray-50",
                                    children: "Reset"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 146,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleApplyFilter,
                                    className: "flex-1 bg-primary-main text-white py-3 rounded-lg font-semibold transition-colors hover:bg-[#2DB8A0]",
                                    children: "Apply Filter"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 152,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewFilterModal.tsx",
                            lineNumber: 145,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ReviewFilterModal.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ReviewFilterModal.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            showWriteModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ReviewWriteModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showWriteModal,
                onClose: handleCloseWriteModal,
                filterData: {
                    gender: selectedGender,
                    category: selectedCategory,
                    rating: selectedRating,
                    distance: selectedDistance
                }
            }, void 0, false, {
                fileName: "[project]/components/ReviewFilterModal.tsx",
                lineNumber: 163,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(ReviewFilterModal, "k2s0bQOCOjGH+Tasc+kpZKmMveo=");
_c = ReviewFilterModal;
var _c;
__turbopack_context__.k.register(_c, "ReviewFilterModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/CommunityHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommunityHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ReviewFilterModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ReviewFilterModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function CommunityHeader({ activeTab, onTabChange }) {
    _s();
    const [isFilterOpen, setIsFilterOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const tabs = [
        {
            id: "popular",
            label: "인기글"
        },
        {
            id: "latest",
            label: "최신글"
        },
        {
            id: "info",
            label: "정보컨텐츠"
        },
        {
            id: "consultation",
            label: "고민상담소"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sticky top-[48px] z-20 bg-white border-b border-gray-100",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between px-4 py-4 border-b border-gray-100",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-xl font-bold text-gray-900",
                                children: "커뮤니티"
                            }, void 0, false, {
                                fileName: "[project]/components/CommunityHeader.tsx",
                                lineNumber: 31,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSend"], {
                                            className: "text-gray-700 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/CommunityHeader.tsx",
                                            lineNumber: 34,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityHeader.tsx",
                                        lineNumber: 33,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setIsFilterOpen(true),
                                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiEdit3"], {
                                            className: "text-gray-700 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/CommunityHeader.tsx",
                                            lineNumber: 40,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityHeader.tsx",
                                        lineNumber: 36,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/CommunityHeader.tsx",
                                lineNumber: 32,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/CommunityHeader.tsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-6 px-4 py-3",
                        children: tabs.map((tab)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>onTabChange(tab.id),
                                className: `text-sm font-medium transition-colors pb-2 relative ${activeTab === tab.id ? "text-gray-900" : "text-gray-500"}`,
                                children: [
                                    tab.label,
                                    activeTab === tab.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute bottom-0 left-0 right-0 h-0.5 bg-primary-main"
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityHeader.tsx",
                                        lineNumber: 57,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, tab.id, true, {
                                fileName: "[project]/components/CommunityHeader.tsx",
                                lineNumber: 48,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/CommunityHeader.tsx",
                        lineNumber: 46,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/CommunityHeader.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ReviewFilterModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isFilterOpen,
                onClose: ()=>setIsFilterOpen(false)
            }, void 0, false, {
                fileName: "[project]/components/CommunityHeader.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(CommunityHeader, "Ck5YPSyGZjEl44uePWCVg1w6nLw=");
_c = CommunityHeader;
var _c;
__turbopack_context__.k.register(_c, "CommunityHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/content/recoveryGuideContent.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "recoveryGuideContent",
    ()=>recoveryGuideContent
]);
const recoveryGuideContent = {
    KR: {
        jaw: {
            title: "턱·윤곽·양악 수술",
            badge: "뼈 수술",
            summary: "턱·윤곽·양악 등 얼굴 뼈 구조가 크게 변하는 수술군",
            recommended: "권장 회복 기간: 4주 이상",
            procedures: "V라인축소술, 사각턱수술, 턱끝수술, 턱끝축소, 피질절골, 교근축소술, 비절개턱성형, 이중턱근육묶기, 하악수술, 상악수술, 양악수술, 턱끝보형물, 턱끝보형물제거, 턱끝이물질제거",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "몸이 ‘수술을 인지하고 가장 강하게 반응하는 시기’",
                    description: [
                        "수술 부위와 주변 조직이 ‘얼굴 구조에 큰 변화가 생겼다’는 사실을 인지하며 붓기, 멍, 당김, 압박감을 가장 강하게 만들어내는 단계입니다.",
                        "뼈의 위치가 바뀌고, 그 위를 덮고 있던 근육·피부·신경이 아직 새로운 위치에 적응하지 못해 얼굴은 실제 결과보다 더 부어 있고, 더 넓고, 더 둔탁해 보이는 것이 정상입니다.",
                        "이 시기의 외형은 수술 결과를 판단할 수 있는 기준이 아니며, 의학적으로도 ‘회복 전 단계의 임시 모습’에 해당합니다.",
                        "몸의 입장에서는 아직 회복이 본격적으로 진행되기보다는 ‘회복을 시작하기 위한 준비 단계’라고 이해하시면 됩니다."
                    ],
                    tips: [
                        "가능한 한 일정은 최소화하고, 회복을 최우선으로 두기",
                        "수면 시 머리를 살짝 높여 붓기 압력 줄이기",
                        "하루 여러 번, 방 안이나 복도에서 3–5분 정도 짧게 걷기 (혈액순환과 붓기 관리에 도움이 됩니다)"
                    ],
                    cautions: [
                        "거울을 자주 보며 결과를 평가하지 않기",
                        "무리한 외출, 장시간 이동 피하기",
                        "통증·붓기가 있다고 해서 ‘문제가 생겼다’고 단정하지 않기"
                    ],
                    quote: "이 시기의 목표는 ‘얼굴이 예뻐 보이게 만드는 것’이 아니라 ‘붓기를 키우지 않고, 몸이 회복을 시작하도록 돕는 것’입니다."
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "강한 붓기는 줄고, ‘변화의 방향’이 보이기 시작하는 시기",
                    description: [
                        "2주차부터는 수술 직후의 강한 염증 반응이 조금씩 가라앉으면서 얼굴 전체 부피감이 서서히 줄어듭니다.",
                        "아직은 큰 붓기와 잔붓기가 섞여 있는 과도기이기 때문에 아침에는 둔탁하고, 오후에는 조금 가벼워지는 ‘아침–저녁 컨디션 차이’를 느낄 수 있습니다.",
                        "이 패턴은 턱·윤곽·양악 수술에서 매우 흔한 회복 양상이며, 회복이 잘못되고 있다는 신호가 아닙니다.",
                        "이 시점에서는 ‘윤곽이 이런 방향으로 바뀌는구나’ 정도의 큰 흐름만 가볍게 확인하시면 충분합니다."
                    ],
                    tips: [
                        "카페·쇼핑몰처럼 앉아서 쉬는 시간이 포함된 일정 위주로 외출하기",
                        "사진은 조명·각도를 고정해서 기록용으로만 남기기",
                        "가벼운 산책은 붓기 순환에 도움이 됩니다."
                    ],
                    cautions: [
                        "수술 전 사진이나 타인의 후기와 과도하게 비교하지 않기",
                        "과음·밤샘 일정은 붓기 회복을 늦출 수 있으므로 피하기",
                        "‘왜 아직도 부어 있지?’라는 조급한 판단 줄이기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "겉으로는 자연스러워 보이고, 몸은 적응을 마무리하는 시기",
                    description: [
                        "3주차에는 외관상 붓기가 많이 정리되어 주변 사람들은 이미 자연스럽다고 느끼는 경우가 많습니다.",
                        "하지만 턱 주변 근육·관절·저작 근육은 여전히 새로운 위치와 사용 패턴에 적응을 마무리하는 단계에 있습니다.",
                        "하루 일정을 많이 소화했거나 말을 많이 한 날에는 턱이 뻐근하거나 피로감이 다시 느껴질 수 있는데, 이는 적응 과정에서 나타나는 정상적인 신호입니다."
                    ],
                    tips: [
                        "사진 촬영, 가벼운 여행 일정은 가능합니다.",
                        "일정 중간중간 의도적으로 쉬는 시간을 넣어주기",
                        "피곤한 날은 일정을 줄이는 것도 회복의 일부라고 생각하기"
                    ],
                    cautions: [
                        "격한 운동이나 턱을 과하게 쓰는 활동은 아직 피하기",
                        "‘이제 다 끝났다’는 생각으로 무리하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "일상은 정상, 회복은 아직 진행 중인 시기",
                    description: [
                        "4주차가 되면 일상생활·출근·일반적인 여행은 대부분 가능합니다.",
                        "하지만 턱·윤곽·양악 수술의 진짜 안정화는 3–6개월에 걸쳐 진행되기 때문에, 지금 모습은 ‘최종 결과’라기보다 안정적으로 회복되고 있는 중간 단계입니다.",
                        "이 시점에서 너무 엄격하게 결과를 평가하면 불필요한 불안만 커질 수 있습니다."
                    ],
                    tips: [
                        "가벼운 운동은 의료진이 허용한 범위 내에서 천천히 시작",
                        "1·2주차 기록 사진과 비교하며 변화 확인하기",
                        "피로 신호가 오면 휴식을 최우선으로 두기"
                    ],
                    cautions: [
                        "4주차에 결과를 단정 짓지 않기",
                        "‘아직 불편하다 = 실패’로 연결하지 않기"
                    ],
                    quote: "지금 얼굴은 이미 충분히 회복이 잘 진행되고 있고, 앞으로 더 편안해질 여지가 남아 있는 상태입니다."
                }
            ],
            summaryTitle: "이 그룹의 핵심 정리",
            summaryBody: [
                "턱·윤곽·양악 수술의 회복은 속도가 아니라 순서입니다.",
                "지금 주차에 맞는 관리만 꾸준히 해주고 있다면, 결과는 대부분 그 다음에 자연스럽게 따라옵니다."
            ]
        },
        // 나머지 그룹들은 우선 간단한 요약 버전만 구성 (필요 시 점진적으로 세부 문구 보강)
        breast: {
            title: "가슴 + 유두·유륜 + 여유증 + 부유방",
            badge: "가슴 수술",
            summary: "보형물·지방이식·거상·축소 및 유두·유륜·여유증·부유방 수술군의 회복 흐름",
            procedures: "가슴보형물 / 가슴보형물+지방이식 / 가슴거상술 / 가슴거상술+확대 / 가슴축소 / 가슴보형물제거 / 가슴이물질제거 / 가슴재수술 / 가슴지방이식 / 부유방흡입 / 부유방제거수술 / 몽고메리결절제거 / 유두축소 / 유륜미백 / 유륜축소 / 유륜문신 / 함몰유두교정 / 여유증(시술) / 여유증수술",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "몸이 '상체 구조 변화'를 강하게 인지하는 시기",
                    description: [
                        "가슴뿐 아니라 흉곽·겨드랑이·등·어깨까지 상체 전체가 무게 중심과 구조가 바뀌었다는 사실을 인지하며 통증, 압박감, 묵직함, 당김을 강하게 느끼는 단계입니다.",
                        "겉으로 보이는 모양은 실제 결과보다 더 위로 올라가 있고 단단하며 부자연스럽게 보일 수 있지만, 이 시기의 외형은 최종 결과와 직접적인 연관이 없습니다."
                    ],
                    tips: [
                        "상체를 완전히 눕히지 말고 베개를 이용해 살짝 세운 자세로 휴식",
                        "압박 브라·붕대는 불편해도 지시된 기간 동안 유지",
                        "팔 사용을 최소화하고 모든 동작은 천천히 하기"
                    ],
                    cautions: [
                        "팔을 머리 위로 드는 동작, 갑작스러운 상체 회전 금지",
                        "무거운 가방이나 캐리어 들지 않기",
                        "거울을 자주 보며 모양을 평가하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "통증은 줄고, 묵직함이 중심이 되는 시기",
                    description: [
                        "날카로운 통증보다는 묵직함·당김·뻐근함이 중심이 되는 시기입니다.",
                        "보형물·거상 수술은 아직 윗가슴이 높고 단단하게 느껴질 수 있고, 축소·여유증 수술은 어깨와 목이 가벼워지면서 절개 부위가 예민해질 수 있습니다."
                    ],
                    tips: [
                        "앉아서 쉴 수 있는 짧은 일정 위주로 구성",
                        "앞에서 여미는 옷, 부드러운 면 소재 착용",
                        "흉터 부위는 문지르지 말고 처방된 연고만 사용"
                    ],
                    cautions: [
                        "와이어 브라, 타이트한 상의 착용 금지",
                        "쇼핑처럼 팔을 반복적으로 많이 쓰는 일정 자제",
                        "흉터 색·가슴 위치를 하루 단위로 비교하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "일상 동작은 가능하지만, 상체 보호는 계속 필요한 시기",
                    description: [
                        "카페·쇼핑·가벼운 외출 등 대부분의 일상 동작이 가능해집니다.",
                        "사진상으로는 자연스러워 보이지만 촉감·움직임에서는 아직 완전히 내 몸 같은 느낌까지는 아닐 수 있습니다."
                    ],
                    tips: [
                        "실내 위주 일정, 짧은 근교 이동 추천",
                        "앉아서 쉴 수 있는 동선을 우선 선택",
                        "쿠션 있는 의자를 사용해 상체 부담 줄이기"
                    ],
                    cautions: [
                        "점프, 상체 근력 운동, 격한 팔 동작은 아직 금지",
                        "‘이제 다 괜찮다’는 생각으로 관리를 갑자기 줄이지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "겉보기엔 안정적이지만, 조직은 계속 자리 잡는 중",
                    description: [
                        "외출·출근·여행이 대부분 가능해지고 타인이 보기엔 수술 티가 거의 나지 않을 수 있습니다.",
                        "다만 안쪽 조직의 안정은 3–6개월에 걸쳐 진행되므로 지금 모습은 완성이 아니라 중간 단계에 해당합니다."
                    ],
                    tips: [
                        "일상 복귀는 가능하되 피로 누적 시 휴식 우선",
                        "담당의 허용 시 가벼운 유산소 운동부터 시작",
                        "흉터 관리 루틴을 생활화하기"
                    ],
                    cautions: [
                        "고강도 운동·수영·웨이트는 반드시 의료진 상담 후 진행",
                        "1개월 차 모습을 최종 결과로 확정 짓지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "가슴 수술은 짧은 시간에 완성되는 수술이 아니라 시간을 두고 점점 자연스러워지는 수술입니다.",
                "지금의 모습은 이미 회복이 안정적으로 진행되고 있는 상태이며, 앞으로 더 편안하고 자연스러운 형태로 이어질 가능성이 충분합니다."
            ]
        },
        body: {
            title: "바디 지방흡입 · 거상 · 재수술 + 힙업 · 골반지방이식",
            badge: "바디 라인",
            summary: "몸 전체 실루엣과 힙업·골반 볼륨을 다루는 수술·시술군",
            procedures: "등지방흡입 / 러브핸들지방흡입 / 복부지방흡입 / 복부피부지방절제술 / 허벅지지방흡입 / 종아리지방흡입 / 발목지방흡입 / 무릎지방흡입 / 팔지방흡입 / 전신지방흡입 / 지방흡입재수술 / 복부거상술 / 팔거상술 / 목주름거상술 / 엉덩이지방이식 / 힙업성형 / 골반지방이식 / 손등지방이식",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "몸이 '바디 실루엣 변화'를 강하게 인지하는 시기",
                    description: [
                        "지방이 제거되거나 이동된 부위뿐 아니라 압박복이 닿는 범위 전체를 하나의 수술 부위로 인식하는 단계입니다.",
                        "겉으로 보기엔 라인이 더 울퉁불퉁해 보이거나 부은 살 때문에 오히려 더 커 보일 수 있지만, 이 시기의 외형은 결과를 판단할 수 있는 단계가 아닙니다."
                    ],
                    tips: [
                        "압박복은 답답해도 의료진 지시에 맞춰 착용 유지",
                        "침대에서 일어날 때는 옆으로 돌아누운 뒤 천천히 움직이기",
                        "방 안이나 복도에서 짧게, 자주 걷기"
                    ],
                    cautions: [
                        "‘지방이 빠졌는데 왜 더 부어 보이지?’라고 걱정하지 않기",
                        "하루 만보 걷기, 무리한 산책은 금지",
                        "압박복을 임의로 더 조이거나 마음대로 벗지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "붓기가 이동하며 실루엣이 오락가락하는 시기",
                    description: [
                        "아침에는 비교적 가벼운데 오후로 갈수록 다리·복부가 무거워지는 붓기 리듬을 느낄 수 있습니다.",
                        "압박복을 벗었을 때 라인이 정리된 듯하다가도 울퉁불퉁해 보이는 과도기적인 모습이 나타날 수 있습니다."
                    ],
                    tips: [
                        "일정은 평지 위주, 엘리베이터 필수 동선으로 선택",
                        "장시간 앉아 있을 땐 30–40분마다 자세 바꾸기",
                        "수분 섭취를 늘려 림프 순환을 돕기"
                    ],
                    cautions: [
                        "압박복을 벗은 상태로 장시간 외출하지 않기",
                        "거울로 허벅지·복부를 확대해서 평가하지 않기",
                        "하체 근력 운동·요가 스트레치는 아직 금지"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "몸이 '가벼워졌다'는 체감을 하기 시작하는 시기",
                    description: [
                        "바지·치마·원피스를 입었을 때 실루엣 변화가 눈에 띄게 느껴지기 시작합니다.",
                        "촉감상 딱딱함이나 뭉침이 남아 있을 수 있지만 대부분 정상적인 회복 과정에 포함됩니다."
                    ],
                    tips: [
                        "근교 이동, 카페 투어 등 사진 위주 일정 가능",
                        "쿠션 있는 의자·카페 좌석을 적극 활용",
                        "가벼운 산책은 회복에 도움"
                    ],
                    cautions: [
                        "달리기·점프·격한 하체 운동은 여전히 금지",
                        "‘라인이 완성된 것 같다’는 생각으로 관리 중단하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "라인은 정리되기 시작하지만, 아직은 중간 단계",
                    description: [
                        "외관상으로는 이미 충분히 달라진 몸처럼 느껴질 수 있습니다.",
                        "하지만 바디 지방흡입·거상·지방이식의 진짜 완성은 3–6개월에 걸쳐 라인이 더 매끈해지면서 이루어집니다."
                    ],
                    tips: [
                        "가벼운 유산소·스트레칭은 단계적으로 시작",
                        "피곤한 날엔 압박복 착용 시간을 다시 늘리기",
                        "장시간 서 있는 일정 뒤에는 휴식을 우선하기"
                    ],
                    cautions: [
                        "고강도 운동·헬스·러닝은 의료진 상담 후 시작",
                        "1개월 차 몸을 최종 결과로 규정하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "바디 수술은 눈에 보이는 변화보다 몸 안에서의 회복이 더 오래 걸리는 수술입니다.",
                "지금의 몸은 이미 회복이 안정 궤도에 올라 있으며, 시간이 지날수록 라인은 더 부드럽고 자연스럽게 이어질 가능성이 충분합니다."
            ]
        },
        upperFace: {
            title: "광대 · 관자 · 이마 · 뒤통수 · 눈썹뼈 · 안면윤곽 재수술",
            badge: "상안면 윤곽",
            summary: "얼굴 윗구조와 안면윤곽 재수술에 해당하는 수술군",
            procedures: "광대보형물 / 광대축소(앞광대·옆광대·전체) / 퀵광대 / 앞광대보형물 / 관자놀이보형물 / 관자놀이축소술 / 이마보형물 / 이마축소 / 눈썹뼈축소술 / 뒤통수보형물 / 광대이물질제거 / 관자놀이이물질제거 / 이마이물질제거 / 심부볼제거 / 안면윤곽재수술",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "얼굴 '윗구조 전체가 바뀌었다'고 인식하는 시기",
                    description: [
                        "광대·관자·이마·눈썹뼈·뒤통수 중 한 부위만 수술했더라도 몸은 상·중안면 전체를 하나의 수술 부위로 인식합니다.",
                        "얼굴 윗부분이 헬멧을 쓴 것처럼 단단하고 무겁게 느껴질 수 있으며, 정면에서 폭이 넓어 보이고 윤곽이 둔탁해 보이는 것이 정상입니다."
                    ],
                    tips: [
                        "머리는 너무 높이지 말고 살짝만 올린 상태로 휴식",
                        "얼굴을 손으로 만지거나 문지르지 않기",
                        "실내 위주로 조용히 지내며 자극 최소화"
                    ],
                    cautions: [
                        "거울을 자주 보며 얼굴 폭·광대 크기 평가하지 않기",
                        "모자를 깊게 눌러 쓰거나 얼굴을 압박하지 않기",
                        "웃음·표정을 과도하게 사용하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "붓기 속에서 윤곽이 보이기 시작하는 시기",
                    description: [
                        "붓기가 한 번에 빠지기보다 부위별로 다르게 움직이며 윤곽이 오락가락하는 느낌을 줄 수 있습니다.",
                        "정면에서는 여전히 넓어 보일 수 있지만, 측면이나 45도 각도에서 이전과 다른 입체감이 보이기 시작합니다."
                    ],
                    tips: [
                        "오전보다 오후 컨디션 기준으로 일정 잡기",
                        "머리카락·앞머리·모자를 활용해 윤곽을 자연스럽게 정리",
                        "카페·전시 등 앉아서 쉬는 일정 위주로 구성"
                    ],
                    cautions: [
                        "조명 강한 장소에서 얼굴 클로즈업 촬영 피하기",
                        "광대·관자 부위를 누르거나 마사지하지 않기",
                        "하루 단위로 얼굴 윤곽을 비교 분석하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "주변에서 변화가 먼저 보이는 시기",
                    description: [
                        "본인보다 주변에서 ‘얼굴 작아졌다’, ‘입체감이 생겼다’는 말을 먼저 듣는 경우가 많아지는 시기입니다.",
                        "사진에서 변화가 특히 잘 드러나며, 여행·촬영 일정도 비교적 자유로워집니다."
                    ],
                    tips: [
                        "한복 스냅, 카페 촬영 등 사진 일정 가능",
                        "장시간 촬영 시 중간중간 휴식 시간 넣기",
                        "머리카락 스타일로 윤곽을 부드럽게 보완"
                    ],
                    cautions: [
                        "격한 표정 연기, 장시간 웃음 유지는 피하기",
                        "밤샘·과음으로 붓기 재발 유발하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "겉보기엔 자연스럽지만, 안쪽 구조는 계속 적응 중",
                    description: [
                        "타인이 보기엔 수술 여부를 알아채기 어려울 정도로 윤곽이 자연스러워질 수 있습니다.",
                        "하지만 뼈·근막·연부조직이 함께 움직인 수술이기 때문에 3–6개월 동안 미세한 변화가 계속됩니다."
                    ],
                    tips: [
                        "일상 복귀는 가능하되 피로 누적 시 즉시 휴식",
                        "가벼운 스트레칭·산책은 회복에 도움",
                        "3개월 차를 기준으로 변화 관찰하기"
                    ],
                    cautions: [
                        "경락·윤곽 마사지·강한 압박은 아직 금지",
                        "미세한 비대칭을 과도하게 확대 해석하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "상안면 윤곽 수술은 짧은 시간에 완성되는 수술이 아니라 시간이 지나면서 자연스럽게 자리 잡는 수술입니다.",
                "지금의 모습은 회복이 매우 정상적으로 진행되고 있는 상태이며, 앞으로 더 부드럽고 안정적인 윤곽으로 이어질 가능성이 충분합니다."
            ]
        },
        nose: {
            title: "코끝 · 콧볼 · 복코 · 비공 라인 개선",
            badge: "코 성형",
            summary: "코끝·콧볼·복코·비공 및 콧대 라인을 다루는 수술·시술군",
            procedures: "복코교정(수술) / 복코교정(시술) / 콧볼축소 / 비절개콧볼축소 / 코끝보형물 / 코끝자가연골 / 코끝기증연골 / 코끝기증진피 / 비공내리기 / 비절개코끝시술 / 미스코 / 하이코 / 고양이수술 / 콧대보형물 / 콧대인공조직 / 콧대자가조직 / 비주연장술 / 코길이연장술 / 비절개코교정",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "코가 '호흡·표정·중심 구조 변화'를 동시에 인지하는 시기",
                    description: [
                        "코끝·콧볼·비공·콧대 중 한 부위만 시술했더라도 얼굴의 중심 구조가 바뀌었다고 인지하며 붓기·압박감·당김·이물감이 가장 강하게 나타나는 단계입니다.",
                        "겉으로 보이는 코는 실제 결과보다 더 크고 뭉툭하거나 더 들려 보일 수 있으며, 콧볼이 넓어 보이거나 코끝이 둔해 보이는 착시가 생기기 쉽습니다."
                    ],
                    tips: [
                        "얼굴을 베개·손에 파묻지 않고 정면을 향한 자세 유지",
                        "물을 자주 마셔 비강·점막 건조를 방지",
                        "병원에서 안내한 세척·연고·찜질 루틴만 정확히 지키기"
                    ],
                    cautions: [
                        "코를 비비거나 만지는 행동 금지",
                        "마스크를 코끝에 강하게 눌러 쓰지 않기",
                        "뜨거운 음식·과음으로 붓기를 유발하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "붓기 속에서 '코 라인의 방향성'이 보이기 시작하는 시기",
                    description: [
                        "코끝과 콧볼의 붓기가 조금씩 정리되며 ‘방향은 이렇게 잡혔구나’라는 느낌이 들기 시작합니다.",
                        "수술 계열은 여전히 단단함과 당김이 남아 있지만, 정면·측면에서 이전과 다른 실루엣이 서서히 보이기 시작합니다."
                    ],
                    tips: [
                        "마스크는 사람 많은 곳에서만 착용하고 압박은 최소화",
                        "카페·쇼핑 등 가벼운 외출 가능",
                        "사진은 자연광에서 정면·45도 각도로 기록"
                    ],
                    cautions: [
                        "콧볼·코끝을 눌러 모양 확인하지 않기",
                        "‘아직 뭔가 어색하다’는 감정을 과도하게 키우지 않기",
                        "강한 햇빛·사우나·찜질방 피하기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "사진과 일상에서 코 변화가 자연스럽게 드러나는 시기",
                    description: [
                        "코가 얼굴 전체에 자연스럽게 섞여 보이기 시작합니다.",
                        "수술 계열도 일반적인 사진·영상에서는 수술 티가 크게 느껴지지 않을 수 있으며, 시술 계열은 가장 예쁘게 라인이 유지되는 시기입니다."
                    ],
                    tips: [
                        "포토부스·카페 촬영·스냅 사진 가능",
                        "살짝 위에서 아래로 찍는 각도가 안정적",
                        "피부톤 위주의 가벼운 메이크업부터 시작"
                    ],
                    cautions: [
                        "사람 많은 곳에서 부딪히지 않도록 주의",
                        "과음·밤샘 일정으로 붓기 재발 유발하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "남에게는 완성처럼 보이지만, 코는 계속 변하는 중",
                    description: [
                        "4주차 코는 주변 사람이 보기에 이미 충분히 자연스럽고 안정적으로 보일 수 있습니다.",
                        "하지만 코끝·콧볼·복코·비공 라인은 연골·연부조직·피부가 함께 적응하는 구조라 3–6개월까지도 미세한 변화가 이어집니다."
                    ],
                    tips: [
                        "일상·여행·비행 대부분 무리 없이 가능",
                        "3개월 차 사진을 기준으로 변화 비교 계획 세우기",
                        "코 주변 자극 없는 생활 습관 유지"
                    ],
                    cautions: [
                        "코 마사지·경락·강한 압박은 아직 금지",
                        "미세한 높이·각도 차이에 집착하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "코 성형과 코 라인 시술은 얼굴 중심에 위치한 만큼 회복 과정에서 심리적 흔들림이 큰 편입니다.",
                "지금의 변화는 정상적인 회복 흐름 안에 있으며, 시간이 지날수록 표정과 조화롭게 어우러진 코로 이어질 가능성이 충분합니다."
            ]
        },
        eyeSurgery: {
            title: "눈 성형 · 트임 · 눈밑 지방 · 재수술",
            badge: "눈 성형",
            summary: "쌍꺼풀·트임·눈밑 수술 및 재수술 전반",
            procedures: "쌍꺼풀(매몰/부분절개/자연유착/절개), 눈매교정, 돌출눈수술, 상안검성형, 아이링, 하안검성형, 앞트임, 뒤트임, 밑트임, 윗트임, 레이저트임성형, 몽고트임, 트임복원, 눈꺼풀지방제거, 눈밑지방재배치, 눈밑지방제거, 눈재수술, 트임재수술",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "눈이 '시야·표정·피로'를 동시에 인지하는 시기",
                    description: [
                        "눈꺼풀·눈꼬리·눈밑 중 어느 한 부위만 수술했더라도 눈 주변 전체가 시야와 표정 구조가 바뀌었다고 인지하며 붓기·압박감·이물감·당김이 가장 강하게 나타나는 단계입니다.",
                        "겉으로 보이는 눈은 실제 결과보다 라인이 높고 두껍게 보이거나, 트임 부위가 과장돼 보이고, 눈밑이 울퉁불퉁하거나 부풀어 보이는 것이 정상입니다."
                    ],
                    tips: [
                        "화면 사용은 최소화하고 눈 감고 쉬는 시간을 자주 갖기",
                        "처방된 냉찜질·안약·인공눈물 루틴을 정확히 지키기",
                        "실내 조명은 부드럽게, 직사광선은 피하기"
                    ],
                    cautions: [
                        "눈 비비기, 세게 깜빡이기 금지",
                        "렌즈 착용, 아이메이크업은 아직 금지",
                        "거울로 라인 높이·대칭을 반복 평가하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "붓기 속에서 '눈 라인의 방향'이 보이기 시작하는 시기",
                    description: [
                        "눈꺼풀과 눈밑 붓기가 조금씩 내려가며 라인이 이렇게 잡히는구나 하는 방향성이 느껴지기 시작합니다.",
                        "쌍꺼풀·눈매교정 수술은 여전히 원하는 라인보다 조금 더 진하고 과장돼 보일 수 있지만, 이는 붓기와 아직 풀리지 않은 근육 반응 때문입니다."
                    ],
                    tips: [
                        "가벼운 외출·카페 일정은 가능",
                        "마스크·선글라스로 눈 주변 자극 최소화",
                        "사진은 정면보다는 45도 각도 위주로 기록"
                    ],
                    cautions: [
                        "진한 아이메이크업·마스카라 사용은 자제",
                        "눈꼬리·눈밑을 손으로 눌러 확인하지 않기",
                        "하루 단위로 라인 변화를 집요하게 비교하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "사진과 표정에서 눈 변화가 자연스럽게 드러나는 시기",
                    description: [
                        "사진·영상·대화 중 표정에서 눈의 변화가 비교적 자연스럽게 드러나는 시기입니다.",
                        "쌍꺼풀·트임·눈밑 수술은 사진상으로 수술 티가 거의 느껴지지 않을 수 있으며, 눈매 인상이 전반적으로 또렷해집니다."
                    ],
                    tips: [
                        "포토부스·셀프사진관·한복 스냅 촬영 가능",
                        "가벼운 아이메이크업은 단계적으로 시작",
                        "자연광에서 찍은 사진으로 변화 기록"
                    ],
                    cautions: [
                        "밤샘·과음으로 눈 붓기 재발 유발하지 않기",
                        "장시간 촬영으로 눈 피로를 누적시키지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "남에게는 자연스럽지만, 눈은 계속 안정되는 중",
                    description: [
                        "4주차가 되면 주변에서 ‘눈이 훨씬 또렷해졌다’는 말을 듣기 쉬운 시기입니다.",
                        "하지만 눈 성형은 라인·흉터·근육 움직임이 3–6개월에 걸쳐 서서히 더 부드러워지는 수술입니다."
                    ],
                    tips: [
                        "일상생활 대부분 무리 없이 가능",
                        "렌즈 착용은 반드시 의료진 허용 후 시작",
                        "눈가 보습·자외선 차단에 신경 쓰기"
                    ],
                    cautions: [
                        "눈가 마사지·경락은 아직 금지",
                        "미세한 라인 차이에 과도하게 집착하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "눈 성형은 얼굴 인상을 크게 바꾸는 수술인 만큼 회복 과정에서 심리적인 기복이 생기기 쉽습니다.",
                "지금의 변화는 정상적인 회복 흐름 안에 있으며, 시간이 지날수록 표정과 자연스럽게 어우러진 눈으로 이어질 가능성이 충분합니다."
            ]
        },
        eyeVolume: {
            title: "눈 지방이식 · 눈물골 · 애교살 · 눈 주변 지방",
            badge: "눈 볼륨 시술",
            summary: "눈밑·눈물골·애교살 지방이식·필러 등 볼륨 교정 시술군",
            procedures: "눈지방이식 / 눈밑지방이식 / 눈물골지방이식 / 애교살지방이식 / 눈주변지방이식 / 눈밑꺼짐교정 / 눈밑꺼짐재수술 / 눈물골필러 / 애교살필러 / 눈밑필러 / 눈지방재배치(보완) / 눈밑지방이식재수술",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "눈 주변이 '볼륨 변화와 압박'을 동시에 인지하는 시기",
                    description: [
                        "피부가 얇고 혈관이 많은 눈밑·눈물골·애교살 부위에 볼륨이 새로 들어오면서 몸이 이를 강하게 인지하는 단계입니다.",
                        "조금만 부어도 다크서클처럼 어둡게 보이거나 눈이 더 부어 보이는 착시가 생기기 쉽습니다."
                    ],
                    tips: [
                        "고개를 너무 숙이지 않고 정면을 향한 자세 유지",
                        "엎드려 자지 말고, 베개를 살짝 높여 수면",
                        "눈 주변을 만지거나 눌러보지 않기"
                    ],
                    cautions: [
                        "눈밑 볼륨을 손으로 만져 확인하지 않기",
                        "거울을 가까이 대고 확대해서 보지 않기",
                        "과한 메이크업으로 억지로 가리려 하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "볼륨이 퍼지며 자연스러움을 찾아가는 시기",
                    description: [
                        "눈밑과 눈물골의 붓기가 서서히 빠지면서 볼륨이 한 지점에 몰려 보이던 느낌이 조금씩 퍼지기 시작합니다.",
                        "지방이식은 자리 잡는 볼륨과 흡수될 볼륨이 섞여 있어 다소 오락가락해 보일 수 있습니다."
                    ],
                    tips: [
                        "자연광에서 정면·45도 각도로 변화 기록",
                        "가벼운 아이메이크업 가능",
                        "눈 밑이 건조하면 보습을 충분히 해주기"
                    ],
                    cautions: [
                        "눈 주변 마사지·경락·지압 금지",
                        "‘빠지는 것 같아 불안하다’는 감정에 휘둘리지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "눈 인상이 부드럽게 바뀌는 시기",
                    description: [
                        "눈밑 꺼짐·눈물골 음영이 완화되면서 피곤해 보이던 인상이 전반적으로 부드러워집니다.",
                        "사진에서 다크서클이 옅어 보이거나 애교살이 자연스럽게 살아나는 변화를 체감하는 경우가 많습니다."
                    ],
                    tips: [
                        "촬영·데이트·약속 일정 무리 없이 가능",
                        "자연스러운 웃는 표정 연습 가능",
                        "충분한 수분 섭취 유지"
                    ],
                    cautions: [
                        "강한 눈 화장으로 볼륨을 과하게 강조하지 않기",
                        "눈 주변을 세게 문지르는 습관을 재개하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "볼륨은 안정되고, 미세 조정만 남은 시기",
                    description: [
                        "눈밑과 애교살 볼륨은 외관상 상당히 안정돼 보이지만 지방이식의 경우 최종 생착률은 아직 확정되지 않은 상태입니다.",
                        "눈 주변 볼륨 시술은 1개월은 안정 단계, 3개월이 진짜 판단 시점에 가깝습니다."
                    ],
                    tips: [
                        "일상·여행·촬영 대부분 무리 없이 가능",
                        "눈가 보습과 자외선 차단을 생활화",
                        "3개월 차를 기준으로 리터치 여부 판단 계획 세우기"
                    ],
                    cautions: [
                        "눈가 마사지·경락은 아직 금지",
                        "미세한 볼륨 차이에 집착하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "눈 주변 볼륨 시술은 눈에 띄는 변화를 주지만 동시에 심리적인 예민함도 커질 수 있는 시술입니다.",
                "지금의 변화는 정상적인 회복 흐름 안에 있으며, 시간이 지날수록 더 자연스럽고 안정된 눈 인상으로 이어질 가능성이 충분합니다."
            ]
        },
        faceFat: {
            title: "얼굴 지방이식 · 팔자 · 풀페이스 볼륨",
            badge: "얼굴 볼륨",
            summary: "얼굴 지방이식·팔자·풀페이스 볼륨 교정 시술군",
            procedures: "얼굴지방이식 / 풀페이스지방이식 / 이마지방이식 / 관자지방이식 / 앞광대지방이식 / 볼지방이식 / 팔자지방이식 / 인디언주름지방이식 / 마리오넷라인지방이식 / 입가주름지방이식 / 얼굴지방이식재수술 / 볼꺼짐교정 / 얼굴볼륨교정",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "얼굴이 '전체 볼륨 변화'를 강하게 인지하는 시기",
                    description: [
                        "특정 부위만 시술했더라도 얼굴 전체가 볼륨 중심이 바뀌었다고 인식하며 붓기·묵직함·당김·압박감을 강하게 느끼는 단계입니다.",
                        "지방이 들어간 부위뿐 아니라 주변 조직까지 함께 반응해 얼굴이 전반적으로 커 보이거나 과하게 통통해 보일 수 있습니다."
                    ],
                    tips: [
                        "얼굴을 아래로 오래 숙이지 않고 정면 자세 유지",
                        "베개를 살짝 높여 붓기 압력을 줄이기",
                        "외출은 최소화하고 숙소에서 충분히 휴식"
                    ],
                    cautions: [
                        "얼굴을 누르거나 만져서 볼륨 확인하지 않기",
                        "‘너무 과한 것 같다’는 생각으로 조급해하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "볼륨이 퍼지며 얼굴 비율이 정리되기 시작하는 시기",
                    description: [
                        "얼굴에 몰려 있던 붓기가 조금씩 퍼지면서 볼륨이 부위별로 정리되기 시작합니다.",
                        "이마·관자·앞광대는 먼저 안정되는 편이고, 팔자·입가·마리오넷 라인은 상대적으로 붓기가 늦게 빠질 수 있습니다."
                    ],
                    tips: [
                        "자연광에서 정면·45도 사진으로 변화 기록",
                        "가벼운 메이크업 가능",
                        "수분 섭취를 늘려 순환을 돕기"
                    ],
                    cautions: [
                        "얼굴 마사지·경락·롤러 사용 금지",
                        "거울을 가까이 대고 확대해서 비교하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "인상이 부드러워지고, 볼륨감이 자연스럽게 느껴지는 시기",
                    description: [
                        "얼굴이 과하게 통통해 보이던 느낌이 줄고 전체 인상이 한결 부드러워집니다.",
                        "사진에서 광대·팔자·입가 라인이 자연스럽게 이어져 보이며 피곤해 보이던 인상이 완화됩니다."
                    ],
                    tips: [
                        "촬영·약속·데이트 일정 무리 없이 가능",
                        "평소 스타일 메이크업으로 점진적 복귀",
                        "충분한 수면으로 생착 환경 유지"
                    ],
                    cautions: [
                        "강한 경락·압박 마사지는 금지",
                        "급격한 체중 감량 시도 피하기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "볼륨은 안정되지만, 최종 판단은 아직 이른 시기",
                    description: [
                        "외관상 얼굴 볼륨이 상당히 자연스럽게 느껴질 수 있습니다.",
                        "하지만 얼굴 지방이식은 1개월은 안정 단계, 3개월이 최종 생착 판단 시점입니다."
                    ],
                    tips: [
                        "일상·여행·촬영 대부분 가능",
                        "자외선 차단과 보습 관리 지속",
                        "체중 변화 없이 생활 리듬 유지"
                    ],
                    cautions: [
                        "얼굴 마사지·고주파 시술은 의료진 상담 후 진행",
                        "1개월 차 얼굴을 최종 결과로 단정하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "얼굴 지방이식과 볼륨 교정은 시간을 두고 자연스럽게 완성되는 시술입니다.",
                "지금의 인상은 회복이 안정적으로 진행되고 있는 상태이며, 시간이 지날수록 표정과 더 조화롭게 어우러진 얼굴로 이어질 가능성이 충분합니다."
            ]
        },
        lifting: {
            title: "안면거상 · 이마거상 · 팔자박리 · 주름 개선 수술",
            badge: "거상 수술",
            summary: "안면거상·이마거상·팔자박리 등 주름 개선 수술군",
            procedures: "안면거상술 / 미니거상 / SMAS거상 / 목거상술 / 이마거상술 / 눈썹거상술 / 팔자박리술 / 마리오넷라인박리 / 중안면거상 / 하안면거상 / 주름개선수술 / 거상재수술",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "얼굴이 '당겨지고 재배치되었다'고 강하게 인지하는 시기",
                    description: [
                        "피부뿐 아니라 그 아래 근막(SMAS)과 연부조직이 함께 이동하면서 얼굴 전체가 강한 당김과 압박 변화를 인지하는 단계입니다.",
                        "겉으로는 더 당겨져 보이거나 귀 주변·두피·턱선이 어색해 보일 수 있지만, 아직 결과 판단 단계는 아닙니다."
                    ],
                    tips: [
                        "얼굴을 과하게 움직이지 않고 표정 사용 최소화",
                        "수면 시 머리를 살짝 높여 당김·부종 완화",
                        "병원에서 안내한 압박 밴드·거즈 관리를 철저히 하기"
                    ],
                    cautions: [
                        "입을 크게 벌리는 동작, 과한 하품은 피하기",
                        "귀 주변·두피를 손으로 만지거나 문지르지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "당김은 줄고, 붓기와 뻣뻣함이 남는 시기",
                    description: [
                        "초기의 강한 당김은 서서히 완화되고 뻣뻣함·묵직함·감각 둔함이 중심이 되는 시기입니다.",
                        "신경과 조직이 새로운 위치에 적응하면서 위화감이 생길 수 있으나 대부분 정상적인 반응입니다."
                    ],
                    tips: [
                        "짧은 외출·카페 일정 가능",
                        "부드러운 음식 위주로 천천히 식사",
                        "얼굴을 아래로 오래 숙이지 않기"
                    ],
                    cautions: [
                        "경락·마사지·롤러 사용 금지",
                        "귀 뒤·두피 절개 부위를 눌러 확인하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "얼굴 윤곽과 주름 개선 효과가 보이기 시작하는 시기",
                    description: [
                        "팔자·마리오넷·턱선이 전보다 정돈돼 보인다는 느낌을 받기 시작합니다.",
                        "주변에서는 ‘피부가 정리됐다’, ‘인상이 단정해졌다’는 말을 먼저 듣는 경우도 많아집니다."
                    ],
                    tips: [
                        "촬영·약속·가벼운 여행 일정 가능",
                        "웃는 표정은 자연스럽게, 과하지 않게",
                        "자외선 차단과 보습 관리에 신경 쓰기"
                    ],
                    cautions: [
                        "장시간 웃거나 말해야 하는 일정은 무리하지 않기",
                        "밤샘·과음으로 붓기 재발 유발하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "겉보기엔 정리됐지만, 안쪽은 계속 안정 중",
                    description: [
                        "타인이 보기엔 주름 개선과 윤곽 변화가 자연스럽게 느껴질 수 있습니다.",
                        "하지만 근막과 조직의 위치를 바꾸는 수술이기 때문에 최종 안정까지 3–6개월이 필요합니다."
                    ],
                    tips: [
                        "일상·출근·외출 대부분 무리 없이 가능",
                        "가벼운 산책·스트레칭부터 단계적으로 운동 재개",
                        "흉터 관리 루틴을 생활화"
                    ],
                    cautions: [
                        "강한 얼굴 마사지·고주파 시술은 의료진 상담 후",
                        "1개월 차 얼굴을 최종 결과로 규정하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "안면거상과 주름 개선 수술은 시간이 지나면서 ‘잘 당긴 얼굴’이 아니라 ‘정돈된 인상’으로 완성되는 수술입니다.",
                "지금의 변화는 정상적인 회복 흐름 안에 있으며, 앞으로 더 부드럽고 자연스러운 인상으로 이어질 가능성이 충분합니다."
            ]
        },
        procedures: {
            title: "시술 (필러 · 보톡스 · 지방분해 · 리프팅 · 레이저)",
            badge: "시술",
            summary: "필러·보톡스·지방분해·리프팅·레이저 전반",
            procedures: "이마필러 / 관자필러 / 앞광대필러 / 볼필러 / 팔자필러 / 마리오넷필러 / 입술필러 / 턱끝필러 / 코필러 / 애교필러 / 눈밑필러 / 필러제거주사 / 필러제거수술 / 보톡스(사각턱·이마·미간·눈가·턱끝·스킨보톡스) / 지방분해주사 / 윤곽주사 / 인모드 / 슈링크 / 울쎄라 / 써마지 / 온다 / 튠페이스 / IPL / 토닝 / 피코레이저 / 프락셀 / 제네시스 / 잡티·홍조·모공 레이저 전반",
            weeks: [
                {
                    label: "🕐 1주차 (Day 0–7)",
                    subtitle: "몸이 '자극과 변화'를 동시에 인지하는 시기",
                    description: [
                        "수술이 아닌 시술이라도 피부·지방층·근육·혈관이 외부 자극과 볼륨 변화를 인지하며 붓기·열감·뻐근함·이물감을 보이는 단계입니다.",
                        "필러·보톡스는 주입 직후 모양보다 조직 반응이 먼저 나타나기 때문에 더 부어 보이거나 뭉쳐 보이거나 어색해 보일 수 있습니다."
                    ],
                    tips: [
                        "시술 부위는 만지지 않고 자극을 최소화",
                        "충분한 수분 섭취로 순환 돕기",
                        "세안·메이크업은 병원 안내 시점 이후부터 시작"
                    ],
                    cautions: [
                        "시술 부위를 눌러 모양 확인하지 않기",
                        "사우나·찜질방·격한 운동 피하기",
                        "시술 다음 날 얼굴로 결과 판단하지 않기"
                    ]
                },
                {
                    label: "🕑 2주차 (Day 8–14)",
                    subtitle: "자극은 가라앉고, 효과의 방향이 보이기 시작하는 시기",
                    description: [
                        "초기 붓기와 열감이 줄어들며 필러 볼륨·윤곽 변화·피부결 개선의 방향성이 서서히 느껴지기 시작합니다.",
                        "보톡스는 이 시점부터 근육 힘이 약해지거나 표정이 부드러워졌다는 체감이 생깁니다."
                    ],
                    tips: [
                        "가벼운 외출·촬영 가능",
                        "자외선 차단을 철저히 유지",
                        "피부 보습 루틴을 평소보다 강화"
                    ],
                    cautions: [
                        "필러·보톡스 효과를 거울로 집요하게 분석하지 않기",
                        "추가 시술을 즉흥적으로 결정하지 않기"
                    ]
                },
                {
                    label: "🕒 3주차 (Day 15–21)",
                    subtitle: "시술 효과가 얼굴에 자연스럽게 섞이는 시기",
                    description: [
                        "필러·보톡스·리프팅 효과가 얼굴 전체 인상에 자연스럽게 녹아들기 시작하는 시기입니다.",
                        "주변에서 ‘뭔가 달라 보인다’는 말을 먼저 듣는 경우가 많아지고, 사진에서도 피부결·윤곽·볼륨 변화가 안정적으로 보입니다."
                    ],
                    tips: [
                        "데이트·여행·촬영 일정 무리 없이 가능",
                        "평소 메이크업 루틴으로 복귀",
                        "충분한 수면과 수분 섭취 유지"
                    ],
                    cautions: [
                        "과음·밤샘으로 시술 효과를 소모시키지 않기",
                        "피부가 안정됐다고 자극적인 관리 재개하지 않기"
                    ]
                },
                {
                    label: "🕓 4주차 (Day 22–28)",
                    subtitle: "효과는 유지되고, 다음 관리 시점을 판단하는 시기",
                    description: [
                        "시술 효과는 외관상 충분히 안정돼 보이며, 대부분의 일상·여행·비행 일정에 무리가 없습니다.",
                        "다만 필러·보톡스·리프팅·레이저는 유지 관리가 중요한 시술이므로, 이 시점은 완성이라기보다 다음 관리 시점을 계획하는 단계입니다."
                    ],
                    tips: [
                        "현재 상태를 기준으로 다음 시술 시점을 메모",
                        "자외선 차단·보습·클렌징 루틴 유지",
                        "과한 욕심보다 ‘지금 상태 유지’를 목표로 설정"
                    ],
                    cautions: [
                        "효과가 좋다고 시술 주기를 무리하게 당기지 않기",
                        "미세한 변화에 과도하게 집착하지 않기"
                    ]
                }
            ],
            closingTitle: "의사·간호사 공통 안내",
            closingBody: [
                "시술은 짧은 시간에 인상을 바꿀 수 있지만, 가장 중요한 것은 지금 상태를 어떻게 유지하느냐입니다.",
                "지금의 변화는 정상적인 반응과 효과가 잘 나타난 상태이며, 생활 습관과 관리에 따라 훨씬 더 안정적으로 이어질 수 있습니다."
            ]
        }
    },
    EN: {},
    JP: {},
    CN: {}
};
// EN 버전: 한국어 내용을 간결하게 영어로 정리 (여기서는 jaw 그룹만 예시로 자세히, 나머지는 요약)
const enBase = {
    jaw: {
        title: "Jaw · Contouring · Orthognathic Surgery",
        badge: "Jaw & facial contouring surgery",
        summary: "Procedures that significantly change the jaw and facial bone structure, such as V-line and orthognathic surgery.",
        recommended: "Recommended recovery period: 4+ weeks",
        procedures: "V-line reduction, square jaw reduction, chin surgery, chin reduction, cortical osteotomy, masseter reduction, non-incisional chin contouring, double-chin muscle tie, mandibular surgery, maxillary surgery, bimaxillary surgery, chin implant, chin implant removal, chin foreign-body removal",
        weeks: [
            {
                label: "🕐 Week 1 (Day 0–7)",
                subtitle: "The body reacts most strongly as it recognizes a major structural change",
                description: [
                    "Tissues around the operated area recognize that the facial structure has changed, so swelling, bruising, tightness and pressure are at their peak.",
                    "Because the bone position has changed and muscles, skin and nerves are not yet adapted, it is normal for your face to look more swollen, wider and duller than the final result.",
                    "This is a temporary early‑stage appearance and not a valid basis for judging the outcome.",
                    "Think of this phase as a preparation stage before recovery fully kicks in."
                ],
                tips: [
                    "Keep your schedule to a minimum and make recovery your top priority.",
                    "Sleep with your head slightly elevated to reduce swelling pressure.",
                    "Take short 3–5 minute indoor walks several times a day to support circulation and swelling control."
                ],
                cautions: [
                    "Avoid repeatedly checking the mirror and judging the result.",
                    "Avoid strenuous outings and long travel.",
                    "Don’t jump to conclusions that something is wrong just because you have pain or swelling."
                ],
                quote: "The goal this week is not to “look pretty” but to avoid increasing swelling and to help your body start the healing process."
            },
            {
                label: "🕑 Week 2 (Day 8–14)",
                subtitle: "Strong swelling eases and the overall direction of change becomes visible",
                description: [
                    "Inflammation from surgery gradually settles and total facial volume slowly begins to decrease.",
                    "This is a transition phase where major swelling and residual puffiness coexist, so the face may look heavier in the morning and lighter toward evening.",
                    "This morning‑evening difference is a very common recovery pattern and is not a sign of poor healing.",
                    "At this stage, it’s enough to simply check the overall direction of your new contour without over‑analyzing details."
                ],
                tips: [
                    "Plan outings around places where you can sit and rest, such as cafés or malls.",
                    "If you take photos, keep the same lighting and angle and use them only for tracking, not for harsh evaluation.",
                    "Light walks help circulation and swelling drainage."
                ],
                cautions: [
                    "Avoid excessive comparison with old photos or other people’s results.",
                    "Limit heavy drinking and all‑nighters, which delay recovery.",
                    "Try not to fixate on thoughts like “Why am I still swollen?”."
                ]
            },
            {
                label: "🕒 Week 3 (Day 15–21)",
                subtitle: "The outside looks more natural while the inside is still adapting",
                description: [
                    "By week 3, visible swelling is much improved and many people around you may already say you look natural.",
                    "Inside, however, the jaw muscles, joints and chewing muscles are still finishing their adaptation to the new position and usage pattern.",
                    "On days when you talk a lot or have a busy schedule, it is normal to feel fatigue or dull ache in the jaw again."
                ],
                tips: [
                    "Photo shoots and light trips are usually fine.",
                    "Intentionally schedule short rest breaks throughout the day.",
                    "On very tired days, reducing your schedule is also part of good recovery."
                ],
                cautions: [
                    "Avoid high‑intensity exercise or activities that overuse the jaw.",
                    "Don’t assume that this is the final result and overexert yourself."
                ]
            },
            {
                label: "🕓 Week 4 (Day 22–28)",
                subtitle: "Daily life feels almost normal, but recovery is still in progress",
                description: [
                    "Most people can return to work, school and general travel by week 4.",
                    "Medically, however, true stabilization of jaw and contour surgery takes about 3–6 months, so what you see now is an in‑between stage, not the final result.",
                    "Judging the outcome too strictly at this time only increases unnecessary anxiety."
                ],
                tips: [
                    "Start light exercise only within the range approved by your surgeon.",
                    "Compare with your week‑1 and week‑2 photos to see progress rather than perfection.",
                    "If you feel fatigue signals, prioritize rest over plans."
                ],
                cautions: [
                    "Do not finalize your opinion of the result at 4 weeks.",
                    "Avoid interpreting remaining discomfort as “failure.”"
                ],
                quote: "At this stage your face is recovering well and still has room to become more comfortable and refined over the coming months."
            }
        ],
        summaryTitle: "Key takeaway for this group",
        summaryBody: [
            "Recovery after jaw and facial contouring is about sequence, not speed.",
            "As long as you are following week‑appropriate care, the final result usually follows naturally afterward."
        ]
    },
    breast: {
        ...recoveryGuideContent.KR.breast,
        title: "Breast + Nipple/Areola + Gynecomastia + Accessory Breast",
        badge: "Breast surgery",
        summary: "Covers implant, fat graft, lift, reduction and nipple/areola, gynecomastia and accessory breast procedures."
    },
    body: {
        ...recoveryGuideContent.KR.body,
        title: "Body Liposuction · Lift · Revision + Hip/Buttock & Pelvic Fat Graft",
        badge: "Body contour"
    },
    upperFace: {
        ...recoveryGuideContent.KR.upperFace,
        title: "Zygoma · Temple · Forehead · Occiput · Brow Bone · Contour Revision",
        badge: "Upper‑face contour"
    },
    nose: {
        ...recoveryGuideContent.KR.nose,
        title: "Tip · Alar · Bulbous Nose · Nostril Line",
        badge: "Nose"
    },
    eyeSurgery: {
        ...recoveryGuideContent.KR.eyeSurgery,
        title: "Eye Surgery · Epicanthoplasty · Lower Fat · Revision",
        badge: "Eye surgery"
    },
    eyeVolume: {
        ...recoveryGuideContent.KR.eyeVolume,
        title: "Eye Fat Graft · Tear Trough · Aegyo‑sal · Periorbital Volume",
        badge: "Eye volume"
    },
    faceFat: {
        ...recoveryGuideContent.KR.faceFat,
        title: "Facial Fat Graft · Nasolabial Fold · Full‑face Volume",
        badge: "Facial volume"
    },
    lifting: {
        ...recoveryGuideContent.KR.lifting,
        title: "Facelift · Forehead Lift · Nasolabial Dissection · Wrinkle Surgery",
        badge: "Lifting surgery"
    },
    procedures: {
        ...recoveryGuideContent.KR.procedures,
        title: "Injectables · Fat‑dissolving · Lifting Devices · Lasers",
        badge: "Non‑surgical procedures"
    }
};
recoveryGuideContent.EN = enBase;
recoveryGuideContent.JP = enBase;
recoveryGuideContent.CN = enBase;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/RecoveryGuideSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RecoveryGuideSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuideContent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/content/recoveryGuideContent.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const recoveryGuideGroups = [
    "jaw",
    "breast",
    "body",
    "upperFace",
    "nose",
    "eyeSurgery",
    "eyeVolume",
    "faceFat",
    "lifting",
    "procedures"
];
function RecoveryGuideSection() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { language } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const content = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuideContent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["recoveryGuideContent"][language];
    const handleGuideClick = (groupKey)=>{
        router.push(`/community/recovery-guide/${groupKey}`);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xl",
                            children: "🍀"
                        }, void 0, false, {
                            fileName: "[project]/components/RecoveryGuideSection.tsx",
                            lineNumber: 37,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-lg font-bold text-gray-900",
                            children: "회복 가이드"
                        }, void 0, false, {
                            fileName: "[project]/components/RecoveryGuideSection.tsx",
                            lineNumber: 38,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/RecoveryGuideSection.tsx",
                    lineNumber: 36,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/RecoveryGuideSection.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: recoveryGuideGroups.map((groupKey)=>{
                    const guide = content[groupKey];
                    const title = `${guide.title}에 대한 회복 가이드🍀`;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>handleGuideClick(groupKey),
                        className: "w-full bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-all text-left",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 min-w-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2 mb-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs bg-primary-light/20 text-primary-main px-2 py-0.5 rounded-full font-medium",
                                                    children: guide.badge
                                                }, void 0, false, {
                                                    fileName: "[project]/components/RecoveryGuideSection.tsx",
                                                    lineNumber: 57,
                                                    columnNumber: 21
                                                }, this),
                                                guide.recommended && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs text-gray-500",
                                                    children: guide.recommended
                                                }, void 0, false, {
                                                    fileName: "[project]/components/RecoveryGuideSection.tsx",
                                                    lineNumber: 61,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/RecoveryGuideSection.tsx",
                                            lineNumber: 56,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                            className: "font-semibold text-gray-900 mb-1 text-sm line-clamp-2",
                                            children: title
                                        }, void 0, false, {
                                            fileName: "[project]/components/RecoveryGuideSection.tsx",
                                            lineNumber: 66,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-600 line-clamp-1",
                                            children: guide.summary
                                        }, void 0, false, {
                                            fileName: "[project]/components/RecoveryGuideSection.tsx",
                                            lineNumber: 69,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/RecoveryGuideSection.tsx",
                                    lineNumber: 55,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-shrink-0 ml-3",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                                        className: "text-gray-400"
                                    }, void 0, false, {
                                        fileName: "[project]/components/RecoveryGuideSection.tsx",
                                        lineNumber: 74,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/RecoveryGuideSection.tsx",
                                    lineNumber: 73,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/RecoveryGuideSection.tsx",
                            lineNumber: 54,
                            columnNumber: 15
                        }, this)
                    }, groupKey, false, {
                        fileName: "[project]/components/RecoveryGuideSection.tsx",
                        lineNumber: 49,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/components/RecoveryGuideSection.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/RecoveryGuideSection.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_s(RecoveryGuideSection, "mZhp9gyPskAQ6BottdCfEnWBrSs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = RecoveryGuideSection;
var _c;
__turbopack_context__.k.register(_c, "RecoveryGuideSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/PostList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PostList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$RecoveryGuideSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/RecoveryGuideSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const recommendedPosts = [
    {
        id: 1,
        category: "정보공유",
        username: "뷰티매니아",
        avatar: "💎",
        content: "강남역 근처 추천 클리닉 리스트 공유해요! 가격대비 품질이 좋은 곳들만 골라봤어요. 특히 리쥬란 힐러 시술 받았을 때 만족도가 높았던 곳 위주로 정리했습니다...더 보기",
        images: [
            "clinic1",
            "clinic2"
        ],
        timestamp: "5시간 전",
        upvotes: 142,
        comments: 89,
        views: 8234,
        likes: 256
    },
    {
        id: 2,
        category: "질문답변",
        username: "시술초보자",
        avatar: "🌱",
        content: "처음으로 보톡스 맞으려는데 어떤 클리닉이 좋을까요? 강남 지역 위주로 추천 부탁드려요. 가격도 궁금하고 부작용 걱정도 되네요...더 보기",
        timestamp: "8시간 전",
        upvotes: 98,
        comments: 156,
        views: 6452
    },
    {
        id: 3,
        category: "정보공유",
        username: "스킨케어러버",
        avatar: "✨",
        content: "인모드 리프팅 전후 비교 사진 공유합니다! 3개월 차인데 효과가 정말 만족스러워요. 특히 턱선이 확실히 올라간 게 보이시나요? ...더 보기",
        images: [
            "before1",
            "after1"
        ],
        timestamp: "12시간 전",
        edited: true,
        upvotes: 203,
        comments: 234,
        views: 12345,
        likes: 512
    },
    {
        id: 4,
        category: "자유수다",
        username: "코성형고민",
        avatar: "🎭",
        content: "코 재수술 고민 중인데 조언 구해요ㅠㅠ 첫 수술이 마음에 들지 않아서... 어떤 의원이 좋은지, 재수술 시 주의사항은 무엇인지 궁금합니다...더 보기",
        timestamp: "15시간 전",
        upvotes: 76,
        comments: 92,
        views: 5432
    },
    {
        id: 5,
        category: "정보공유",
        username: "필러전문가",
        avatar: "💉",
        content: "2024년 필러 가격 정보 정리했어요! 지역별, 시술별로 비교해봤는데 참고하시면 좋을 것 같아요. 특히 리쥬란, 쥬베룩 가격대가 궁금하셨던 분들...더 보기",
        timestamp: "1일 전",
        edited: true,
        upvotes: 167,
        comments: 145,
        views: 9876,
        likes: 324
    },
    {
        id: 6,
        category: "질문답변",
        username: "리프팅고민",
        avatar: "🌙",
        content: "울쎄라 vs 인모드 어떤 게 나을까요? 둘 다 받아보신 분들 의견 듣고 싶어요. 가격도 비교해주시면 감사하겠습니다! ...더 보기",
        timestamp: "1일 전",
        upvotes: 89,
        comments: 112,
        views: 7654
    }
];
const latestPosts = [
    {
        id: 1,
        category: "자유수다",
        username: "신규회원123",
        avatar: "🦋",
        content: "안녕하세요! 처음 가입했는데 정보가 많아서 좋네요. 앞으로 잘 부탁드려요~",
        timestamp: "방금 전",
        upvotes: 5,
        comments: 2,
        views: 123
    },
    {
        id: 2,
        category: "질문답변",
        username: "궁금한이",
        avatar: "🤔",
        content: "리쥬란 힐러 시술 받은 지 일주일인데 아직 효과가 안 보여요. 정상인가요?",
        timestamp: "5분 전",
        upvotes: 3,
        comments: 8,
        views: 234
    },
    {
        id: 3,
        category: "정보공유",
        username: "정보나눔",
        avatar: "📚",
        content: "강남역 신규 오픈한 클리닉 정보 공유해요! 오픈 기념 이벤트 진행 중이라고 하네요",
        timestamp: "10분 전",
        upvotes: 12,
        comments: 15,
        views: 456
    },
    {
        id: 4,
        category: "자유수다",
        username: "시술러버",
        avatar: "💖",
        content: "오늘 보톡스 맞고 왔는데 얼굴이 좀 붓네요ㅠㅠ 정상인 거 맞죠? 첫 시술이라 걱정돼요",
        images: [
            "swollen1"
        ],
        timestamp: "15분 전",
        upvotes: 7,
        comments: 12,
        views: 345
    },
    {
        id: 5,
        category: "정보공유",
        username: "가격비교왕",
        avatar: "💰",
        content: "올해부터 필러 가격이 올랐다고 들었는데 실제로 어떠세요? 최근 시술 받으신 분들 가격 정보 공유해주세요!",
        timestamp: "20분 전",
        upvotes: 18,
        comments: 24,
        views: 567
    },
    {
        id: 6,
        category: "질문답변",
        username: "초보자",
        avatar: "🌿",
        content: "눈 재수술 생각 중인데 어떤 의원 추천받을 수 있을까요? 첫 수술 실패한 경험이 있어서 더 신중하게 선택하고 싶어요",
        timestamp: "30분 전",
        upvotes: 9,
        comments: 18,
        views: 412
    },
    {
        id: 7,
        category: "자유수다",
        username: "뷰티매니아",
        avatar: "💎",
        content: "오늘 클리닉 다녀왔는데 직원분들 친절하시고 분위기도 좋았어요! 만족스러운 시술이었습니다",
        timestamp: "45분 전",
        upvotes: 14,
        comments: 7,
        views: 389
    },
    {
        id: 8,
        category: "정보공유",
        username: "리프팅전문가",
        avatar: "✨",
        content: "인모드 리프팅 시술 전 주의사항 정리해서 올려봅니다. 시술 받기 전에 꼭 확인하시면 좋을 것 같아요!",
        images: [
            "info1",
            "info2"
        ],
        timestamp: "1시간 전",
        edited: true,
        upvotes: 25,
        comments: 31,
        views: 892
    }
];
// 고민상담소 더미 데이터 (카테고리별 5~10개 정도)
const concernDummyPosts = [
    {
        id: "concern-1",
        category: "피부 고민",
        username: "트러블폭발",
        avatar: "🌋",
        content: "여드름 흉터가 너무 심한데 해외에서 잠깐 들어오는 동안 할 수 있는 치료가 있을까요? 다운타임이 길지 않았으면 좋겠어요.",
        timestamp: "3시간 전",
        upvotes: 12,
        comments: 8,
        views: 324,
        reviewType: "concern"
    },
    {
        id: "concern-2",
        category: "피부 고민",
        username: "건성인간",
        avatar: "💧",
        content: "겨울만 되면 각질+당김이 너무 심해요. 레이저를 해야 할지, 관리 위주로 가야 할지 헷갈립니다. 비슷한 분들 어떤 시술 받으셨나요?",
        timestamp: "5시간 전",
        upvotes: 7,
        comments: 5,
        views: 198,
        reviewType: "concern"
    },
    {
        id: "concern-3",
        category: "시술 고민",
        username: "첫보톡스도전",
        avatar: "😳",
        content: "이마+미간 보톡스를 처음 맞아보려는데 표정이 너무 안 어색했으면 좋겠어요. 용량이나 병원 고를 때 꼭 봐야 할 포인트가 있을까요?",
        timestamp: "1일 전",
        upvotes: 15,
        comments: 21,
        views: 512,
        reviewType: "concern"
    },
    {
        id: "concern-4",
        category: "시술 고민",
        username: "리프팅궁금",
        avatar: "✨",
        content: "인모드랑 슈링크 중에 어떤 걸 먼저 해보는 게 좋을까요? 통증이랑 붓기, 효과 지속기간 차이가 궁금합니다.",
        timestamp: "2일 전",
        upvotes: 9,
        comments: 11,
        views: 389,
        reviewType: "concern"
    },
    {
        id: "concern-5",
        category: "병원 선택",
        username: "어디가좋을까",
        avatar: "📍",
        content: "강남/신사 쪽 리프팅 잘하는 병원 어디가 괜찮을까요? 후기를 봐도 다 좋아 보여서 실제로 받아보신 분들 의견이 궁금해요.",
        timestamp: "6시간 전",
        upvotes: 6,
        comments: 9,
        views: 245,
        reviewType: "concern"
    },
    {
        id: "concern-6",
        category: "가격 문의",
        username: "예산50",
        avatar: "💸",
        content: "50만 원 안쪽으로 할 수 있는 시술 추천 부탁드려요! 얼굴 전체 분위기만 조금 상큼해졌으면 좋겠어요.",
        timestamp: "8시간 전",
        upvotes: 4,
        comments: 6,
        views: 173,
        reviewType: "concern"
    },
    {
        id: "concern-7",
        category: "회복 기간",
        username: "직장인휴가3일",
        avatar: "🏃",
        content: "휴가가 딱 3일인데, 이 기간 안에 회복 가능한 시술이 뭐가 있을까요? 붓기 심한 건 피하고 싶어요.",
        timestamp: "12시간 전",
        upvotes: 10,
        comments: 13,
        views: 301,
        reviewType: "concern"
    },
    {
        id: "concern-8",
        category: "부작용",
        username: "붓기안빠짐",
        avatar: "😥",
        content: "턱 보톡스를 맞은 지 2주가 지났는데 아직도 씹을 때 불편한 느낌이 있어요. 이런 경우 병원에 다시 가봐야 할까요?",
        timestamp: "3일 전",
        upvotes: 5,
        comments: 14,
        views: 267,
        reviewType: "concern"
    },
    {
        id: "concern-9",
        category: "기타",
        username: "해외거주자",
        avatar: "✈️",
        content: "해외에서 들어와서 시술+여행 같이 하려는데, 공항에서 가까운 지역 추천해주실 수 있나요? 일정 짜는 팁도 궁금해요.",
        timestamp: "4일 전",
        upvotes: 8,
        comments: 7,
        views: 221,
        reviewType: "concern"
    }
];
const popularPosts = [
    {
        id: 1,
        category: "정보공유",
        username: "인기작가",
        avatar: "🔥",
        content: "2024년 최고의 클리닉 랭킹 공유합니다! 직접 다녀본 곳들만 추천하는 리스트예요. 가격, 품질, 서비스 모두 고려해서 작성했습니다...더 보기",
        images: [
            "ranking1",
            "ranking2",
            "ranking3"
        ],
        timestamp: "2일 전",
        edited: true,
        upvotes: 523,
        comments: 456,
        views: 45234,
        likes: 1245
    },
    {
        id: 2,
        category: "후기",
        username: "만족러버",
        avatar: "⭐",
        content: "슈링크 유니버스 시술 받고 완전 만족해서 후기 남겨요! 효과가 정말 놀라웠고 원장님도 너무 친절하셨어요. 전후 사진 공유합니다! ...더 보기",
        images: [
            "before2",
            "after2"
        ],
        timestamp: "3일 전",
        edited: true,
        upvotes: 412,
        comments: 389,
        views: 38921,
        likes: 987
    },
    {
        id: 3,
        category: "정보공유",
        username: "가격정보왕",
        avatar: "💎",
        content: "시술별 가격대 비교표 업데이트했습니다! 지역별, 클리닉별 가격 정보를 한눈에 비교할 수 있도록 정리했어요. 많은 분들께 도움이 되면 좋겠습니다...더 보기",
        timestamp: "4일 전",
        edited: true,
        upvotes: 387,
        comments: 298,
        views: 34123,
        likes: 756
    },
    {
        id: 4,
        category: "자유수다",
        username: "화제의인물",
        avatar: "🎯",
        content: "이 클리닉 정말 추천합니다! 제가 받은 시술 중에서 최고였어요. 직원분들도 친절하고 시술도 깔끔하게 잘 끝났습니다. 여러분도 한번 가보세요! ...더 보기",
        timestamp: "5일 전",
        upvotes: 298,
        comments: 234,
        views: 28765,
        likes: 634
    },
    {
        id: 5,
        category: "질문답변",
        username: "베테랑",
        avatar: "👑",
        content: "시술 관련 질문 받아요! 여러 번 경험한 입장에서 솔직하게 답변드리겠습니다. 어떤 질문이든 환영입니다~ ...더 보기",
        timestamp: "6일 전",
        upvotes: 267,
        comments: 512,
        views: 24567,
        likes: 523
    },
    {
        id: 6,
        category: "정보공유",
        username: "리뷰마스터",
        avatar: "📸",
        content: "강남역 클리닉 투어 후기 올려요! 5곳을 직접 방문해서 비교해봤는데 각각의 특징과 장단점을 정리했습니다. 참고하시면 좋을 것 같아요...더 보기",
        images: [
            "tour1",
            "tour2",
            "tour3",
            "tour4"
        ],
        timestamp: "1주일 전",
        edited: true,
        upvotes: 445,
        comments: 367,
        views: 38945,
        likes: 892
    }
];
// 시간 포맷팅 함수
const formatTimeAgo = (dateString)=>{
    if (!dateString) return "방금 전";
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffMins < 1) return "방금 전";
    if (diffMins < 60) return `${diffMins}분 전`;
    if (diffHours < 24) return `${diffHours}시간 전`;
    if (diffDays < 7) return `${diffDays}일 전`;
    return date.toLocaleDateString("ko-KR", {
        month: "short",
        day: "numeric"
    });
};
function PostList({ activeTab, concernCategory }) {
    _s();
    const [supabaseReviews, setSupabaseReviews] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [popularSection, setPopularSection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("procedure");
    const procedureSectionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const hospitalSectionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // 최신글: Supabase에서 데이터 가져오기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PostList.useEffect": ()=>{
            if (activeTab === "latest") {
                const loadLatestReviews = {
                    "PostList.useEffect.loadLatestReviews": async ()=>{
                        try {
                            setLoading(true);
                            // Supabase에서 모든 후기 가져오기
                            const [procedureReviews, hospitalReviews, concernPosts] = await Promise.all([
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadProcedureReviews"])(50),
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadHospitalReviews"])(50),
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadConcernPosts"])(50)
                            ]);
                            // 시술 후기 변환
                            const formattedProcedureReviews = procedureReviews.map({
                                "PostList.useEffect.loadLatestReviews.formattedProcedureReviews": (review)=>({
                                        id: review.id || `procedure-${Math.random()}`,
                                        category: review.category || "후기",
                                        username: `사용자${review.user_id || 0}`,
                                        avatar: "👤",
                                        content: review.content,
                                        images: review.images,
                                        timestamp: formatTimeAgo(review.created_at),
                                        created_at: review.created_at,
                                        edited: false,
                                        upvotes: 0,
                                        comments: 0,
                                        views: 0,
                                        reviewType: "procedure"
                                    })
                            }["PostList.useEffect.loadLatestReviews.formattedProcedureReviews"]);
                            // 병원 후기 변환
                            const formattedHospitalReviews = hospitalReviews.map({
                                "PostList.useEffect.loadLatestReviews.formattedHospitalReviews": (review)=>({
                                        id: review.id || `hospital-${Math.random()}`,
                                        category: review.category_large || "병원후기",
                                        username: `사용자${review.user_id || 0}`,
                                        avatar: "👤",
                                        content: review.content,
                                        images: review.images,
                                        timestamp: formatTimeAgo(review.created_at),
                                        created_at: review.created_at,
                                        edited: false,
                                        upvotes: 0,
                                        comments: 0,
                                        views: 0,
                                        reviewType: "hospital"
                                    })
                            }["PostList.useEffect.loadLatestReviews.formattedHospitalReviews"]);
                            // 고민글 변환
                            const formattedConcernPosts = concernPosts.map({
                                "PostList.useEffect.loadLatestReviews.formattedConcernPosts": (post)=>({
                                        id: post.id || `concern-${Math.random()}`,
                                        category: post.concern_category || "고민글",
                                        username: `사용자${post.user_id || 0}`,
                                        avatar: "👤",
                                        title: post.title,
                                        content: post.content,
                                        timestamp: formatTimeAgo(post.created_at),
                                        created_at: post.created_at,
                                        edited: false,
                                        upvotes: 0,
                                        comments: 0,
                                        views: 0,
                                        reviewType: "concern"
                                    })
                            }["PostList.useEffect.loadLatestReviews.formattedConcernPosts"]);
                            // 최신순으로 정렬 (created_at 기준, 모든 후기 통합)
                            const allReviews = [
                                ...formattedProcedureReviews,
                                ...formattedHospitalReviews,
                                ...formattedConcernPosts
                            ].sort({
                                "PostList.useEffect.loadLatestReviews.allReviews": (a, b)=>{
                                    const aDate = a.created_at;
                                    const bDate = b.created_at;
                                    if (!aDate && !bDate) return 0;
                                    if (!aDate) return 1;
                                    if (!bDate) return -1;
                                    return new Date(bDate).getTime() - new Date(aDate).getTime();
                                }
                            }["PostList.useEffect.loadLatestReviews.allReviews"]).map({
                                "PostList.useEffect.loadLatestReviews.allReviews": ({ created_at, ...rest })=>rest
                            }["PostList.useEffect.loadLatestReviews.allReviews"]); // created_at 제거
                            setSupabaseReviews(allReviews);
                        } catch (error) {
                            console.error("❌ 최신글 데이터 로드 실패:", error);
                        } finally{
                            setLoading(false);
                        }
                    }
                }["PostList.useEffect.loadLatestReviews"];
                loadLatestReviews();
                // 후기 추가 이벤트 리스너
                const handleReviewAdded = {
                    "PostList.useEffect.handleReviewAdded": ()=>{
                        loadLatestReviews();
                    }
                }["PostList.useEffect.handleReviewAdded"];
                window.addEventListener("reviewAdded", handleReviewAdded);
                return ({
                    "PostList.useEffect": ()=>window.removeEventListener("reviewAdded", handleReviewAdded)
                })["PostList.useEffect"];
            }
        }
    }["PostList.useEffect"], [
        activeTab
    ]);
    // 인기글: 시술 후기/병원 후기 섹션으로 나누기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PostList.useEffect": ()=>{
            if (activeTab === "popular") {
                const loadPopularReviews = {
                    "PostList.useEffect.loadPopularReviews": async ()=>{
                        try {
                            setLoading(true);
                            // Supabase에서 모든 후기 가져오기 (인기글은 추후 좋아요/조회수 기준으로 정렬 예정)
                            const [procedureReviews, hospitalReviews] = await Promise.all([
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadProcedureReviews"])(20),
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadHospitalReviews"])(20)
                            ]);
                            // 시술 후기 변환
                            const formattedProcedureReviews = procedureReviews.map({
                                "PostList.useEffect.loadPopularReviews.formattedProcedureReviews": (review)=>({
                                        id: review.id || `procedure-${Math.random()}`,
                                        category: review.category || "후기",
                                        username: `사용자${review.user_id || 0}`,
                                        avatar: "👤",
                                        content: review.content,
                                        images: review.images,
                                        timestamp: formatTimeAgo(review.created_at),
                                        edited: false,
                                        upvotes: 0,
                                        comments: 0,
                                        views: 0,
                                        reviewType: "procedure"
                                    })
                            }["PostList.useEffect.loadPopularReviews.formattedProcedureReviews"]);
                            // 병원 후기 변환
                            const formattedHospitalReviews = hospitalReviews.map({
                                "PostList.useEffect.loadPopularReviews.formattedHospitalReviews": (review)=>({
                                        id: review.id || `hospital-${Math.random()}`,
                                        category: review.category_large || "병원후기",
                                        username: `사용자${review.user_id || 0}`,
                                        avatar: "👤",
                                        content: review.content,
                                        images: review.images,
                                        timestamp: formatTimeAgo(review.created_at),
                                        edited: false,
                                        upvotes: 0,
                                        comments: 0,
                                        views: 0,
                                        reviewType: "hospital"
                                    })
                            }["PostList.useEffect.loadPopularReviews.formattedHospitalReviews"]);
                            // 시술 후기와 병원 후기를 별도로 저장 (섹션으로 나누기 위해)
                            setSupabaseReviews([
                                ...formattedProcedureReviews,
                                ...formattedHospitalReviews
                            ]);
                        } catch (error) {
                            console.error("❌ 인기글 데이터 로드 실패:", error);
                        } finally{
                            setLoading(false);
                        }
                    }
                }["PostList.useEffect.loadPopularReviews"];
                loadPopularReviews();
            }
        }
    }["PostList.useEffect"], [
        activeTab
    ]);
    // 고민상담소: Supabase 실제 데이터 + 더미 데이터 함께 사용
    // - Supabase에서 고민글을 불러오고
    // - 아직 데이터가 적거나 없으면 concernDummyPosts를 뒤에 붙여서 보여줌
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PostList.useEffect": ()=>{
            if (activeTab === "consultation") {
                const fetchConcernPosts = {
                    "PostList.useEffect.fetchConcernPosts": async ()=>{
                        try {
                            setLoading(true);
                            let formattedConcernPosts = [];
                            try {
                                const concernPosts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadConcernPosts"])(100);
                                formattedConcernPosts = concernPosts.map({
                                    "PostList.useEffect.fetchConcernPosts": (post)=>({
                                            id: post.id || `concern-${Math.random()}`,
                                            category: post.concern_category || "고민글",
                                            username: `사용자${post.user_id || 0}`,
                                            avatar: "👤",
                                            title: post.title,
                                            content: post.content,
                                            timestamp: formatTimeAgo(post.created_at),
                                            upvotes: 0,
                                            comments: 0,
                                            views: 0,
                                            reviewType: "concern"
                                        })
                                }["PostList.useEffect.fetchConcernPosts"]);
                            } catch (error) {
                                console.warn("고민상담소 Supabase 데이터 로드 실패, 더미 데이터만 사용:", error);
                            }
                            // 실제 고민글 + 더미데이터를 함께 사용 (실제 데이터가 먼저, 부족한 부분은 더미로 보완)
                            const combinedConcernPosts = [
                                ...formattedConcernPosts,
                                ...concernDummyPosts
                            ];
                            const filteredConcernPosts = combinedConcernPosts.filter({
                                "PostList.useEffect.fetchConcernPosts.filteredConcernPosts": (post)=>{
                                    if (concernCategory === null) return true; // "전체" 선택 시 모두 표시
                                    if (!concernCategory) return true;
                                    return post.category === concernCategory;
                                }
                            }["PostList.useEffect.fetchConcernPosts.filteredConcernPosts"]);
                            setSupabaseReviews(filteredConcernPosts);
                        } finally{
                            setLoading(false);
                        }
                    }
                }["PostList.useEffect.fetchConcernPosts"];
                fetchConcernPosts();
            }
        }
    }["PostList.useEffect"], [
        activeTab,
        concernCategory
    ]);
    let posts = [];
    let procedurePosts = [];
    let hospitalPosts = [];
    if (activeTab === "recommended") {
        posts = recommendedPosts;
    } else if (activeTab === "latest") {
        // 최신글: Supabase 데이터 + 기존 하드코딩된 데이터 (섞여서 표시)
        posts = [
            ...supabaseReviews,
            ...latestPosts
        ];
    } else if (activeTab === "popular") {
        // 인기글: 시술 후기와 병원 후기를 섹션으로 나누기
        procedurePosts = supabaseReviews.filter((p)=>p.reviewType === "procedure");
        hospitalPosts = supabaseReviews.filter((p)=>p.reviewType === "hospital");
        // 기존 하드코딩된 인기글도 추가 (섹션 구분 없이)
        posts = [
            ...supabaseReviews,
            ...popularPosts
        ];
    } else if (activeTab === "consultation") {
        // 고민상담소: 고민글만 표시 (이미 필터링되어 있음)
        posts = supabaseReviews;
    }
    if (loading && (activeTab === "latest" || activeTab === "consultation")) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "px-4 py-8 text-center text-gray-500",
            children: activeTab === "consultation" ? "고민글을 불러오는 중..." : "최신글을 불러오는 중..."
        }, void 0, false, {
            fileName: "[project]/components/PostList.tsx",
            lineNumber: 713,
            columnNumber: 7
        }, this);
    }
    // 인기글: 시술 후기/병원 후기 섹션으로 나누기
    if (activeTab === "popular") {
        const scrollToSection = (section)=>{
            setPopularSection(section);
            if (section === "procedure" && procedureSectionRef.current) {
                procedureSectionRef.current.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            } else if (section === "hospital" && hospitalSectionRef.current) {
                hospitalSectionRef.current.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            }
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "pb-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sticky top-[48px] z-10 bg-white border-b border-gray-200 px-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 py-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>scrollToSection("procedure"),
                                className: `flex-1 py-2 px-4 rounded-lg font-semibold text-sm transition-colors ${popularSection === "procedure" ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                                children: "시술 후기"
                            }, void 0, false, {
                                fileName: "[project]/components/PostList.tsx",
                                lineNumber: 743,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>scrollToSection("hospital"),
                                className: `flex-1 py-2 px-4 rounded-lg font-semibold text-sm transition-colors ${popularSection === "hospital" ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                                children: "병원 후기"
                            }, void 0, false, {
                                fileName: "[project]/components/PostList.tsx",
                                lineNumber: 753,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/PostList.tsx",
                        lineNumber: 742,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/PostList.tsx",
                    lineNumber: 741,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-4 space-y-6 pt-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            ref: procedureSectionRef,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-bold text-gray-900 mb-4",
                                    children: "시술 후기"
                                }, void 0, false, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 769,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: procedurePosts.length > 0 ? procedurePosts.map((post)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "bg-primary-light/20 text-primary-main px-3 py-1 rounded-full text-xs font-medium",
                                                        children: post.category
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PostList.tsx",
                                                        lineNumber: 779,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 778,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-3 mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-2xl",
                                                            children: post.avatar
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 786,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex-1",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm font-semibold text-gray-900",
                                                                    children: post.username
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 790,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-2 mt-0.5",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs text-gray-500",
                                                                            children: post.timestamp
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/PostList.tsx",
                                                                            lineNumber: 794,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        post.edited && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs text-gray-400",
                                                                            children: "수정됨"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/PostList.tsx",
                                                                            lineNumber: 798,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 793,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 789,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 785,
                                                    columnNumber: 21
                                                }, this),
                                                post.reviewType === "concern" && post.title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-base font-bold text-gray-900 mb-2",
                                                    children: post.title
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 808,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-gray-800 text-sm mb-3 leading-relaxed line-clamp-3",
                                                    children: post.content
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 814,
                                                    columnNumber: 21
                                                }, this),
                                                post.images && post.images.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex gap-2 mb-3 flex-wrap",
                                                    children: post.images.slice(0, 4).map((img, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "relative w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg overflow-hidden flex-shrink-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "w-full h-full flex items-center justify-center text-gray-400 text-xs",
                                                                    children: "이미지"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 826,
                                                                    columnNumber: 29
                                                                }, this),
                                                                idx === 3 && post.images.length > 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center text-white font-semibold text-xs",
                                                                    children: [
                                                                        "+",
                                                                        post.images.length - 4
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 830,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, idx, true, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 822,
                                                            columnNumber: 27
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 820,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between pt-3 border-t border-gray-100",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowUp"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 843,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.upvotes
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 844,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 842,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiMessageCircle"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 849,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.comments
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 850,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 848,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiEye"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 855,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.views
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 856,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 854,
                                                                columnNumber: 25
                                                            }, this),
                                                            post.likes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHeart"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 862,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.likes
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 863,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 861,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/PostList.tsx",
                                                        lineNumber: 841,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 840,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, post.id, true, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 773,
                                            columnNumber: 19
                                        }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center py-8 text-gray-500 text-sm",
                                        children: "시술 후기가 없습니다."
                                    }, void 0, false, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 873,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 770,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 768,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            ref: hospitalSectionRef,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-bold text-gray-900 mb-4",
                                    children: "병원 후기"
                                }, void 0, false, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 882,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: hospitalPosts.length > 0 ? hospitalPosts.map((post)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "bg-primary-light/20 text-primary-main px-3 py-1 rounded-full text-xs font-medium",
                                                        children: post.category
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PostList.tsx",
                                                        lineNumber: 892,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 891,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-3 mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-2xl",
                                                            children: post.avatar
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 899,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex-1",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm font-semibold text-gray-900",
                                                                    children: post.username
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 903,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-2 mt-0.5",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs text-gray-500",
                                                                            children: post.timestamp
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/PostList.tsx",
                                                                            lineNumber: 907,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        post.edited && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs text-gray-400",
                                                                            children: "수정됨"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/PostList.tsx",
                                                                            lineNumber: 911,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 906,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 902,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 898,
                                                    columnNumber: 21
                                                }, this),
                                                post.reviewType === "concern" && post.title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-base font-bold text-gray-900 mb-2",
                                                    children: post.title
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 921,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-gray-800 text-sm mb-3 leading-relaxed line-clamp-3",
                                                    children: post.content
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 927,
                                                    columnNumber: 21
                                                }, this),
                                                post.images && post.images.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex gap-2 mb-3 flex-wrap",
                                                    children: post.images.slice(0, 4).map((img, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "relative w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg overflow-hidden flex-shrink-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "w-full h-full flex items-center justify-center text-gray-400 text-xs",
                                                                    children: "이미지"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 939,
                                                                    columnNumber: 29
                                                                }, this),
                                                                idx === 3 && post.images.length > 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center text-white font-semibold text-xs",
                                                                    children: [
                                                                        "+",
                                                                        post.images.length - 4
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 943,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, idx, true, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 935,
                                                            columnNumber: 27
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 933,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between pt-3 border-t border-gray-100",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowUp"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 956,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.upvotes
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 957,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 955,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiMessageCircle"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 962,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.comments
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 963,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 961,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiEye"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 968,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.views
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 969,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 967,
                                                                columnNumber: 25
                                                            }, this),
                                                            post.likes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHeart"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 975,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.likes
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 976,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 974,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/PostList.tsx",
                                                        lineNumber: 954,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 953,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, post.id, true, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 886,
                                            columnNumber: 19
                                        }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center py-8 text-gray-500 text-sm",
                                        children: "병원 후기가 없습니다."
                                    }, void 0, false, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 986,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 883,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 881,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/PostList.tsx",
                    lineNumber: 766,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-4 mt-8 pt-6 border-t border-gray-200",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$RecoveryGuideSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/components/PostList.tsx",
                        lineNumber: 996,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/PostList.tsx",
                    lineNumber: 995,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/PostList.tsx",
            lineNumber: 739,
            columnNumber: 7
        }, this);
    }
    // 최신글/추천글: 섞여서 표시
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "px-4 pt-3 space-y-4 pb-4",
        children: [
            posts.map((post)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-3",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "bg-primary-light/20 text-primary-main px-3 py-1 rounded-full text-xs font-medium",
                                children: post.category
                            }, void 0, false, {
                                fileName: "[project]/components/PostList.tsx",
                                lineNumber: 1012,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 1011,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3 mb-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-2xl",
                                    children: post.avatar
                                }, void 0, false, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 1019,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-sm font-semibold text-gray-900",
                                            children: post.username
                                        }, void 0, false, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1023,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2 mt-0.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs text-gray-500",
                                                    children: post.timestamp
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 1027,
                                                    columnNumber: 17
                                                }, this),
                                                post.edited && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs text-gray-400",
                                                    children: "수정됨"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 1029,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1026,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 1022,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 1018,
                            columnNumber: 11
                        }, this),
                        post.reviewType === "concern" && post.title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-base font-bold text-gray-900 mb-2",
                            children: post.title
                        }, void 0, false, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 1037,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-800 text-sm mb-3 leading-relaxed line-clamp-3",
                            children: post.content
                        }, void 0, false, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 1043,
                            columnNumber: 11
                        }, this),
                        post.images && post.images.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2 mb-3 flex-wrap",
                            children: post.images.slice(0, 4).map((img, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg overflow-hidden flex-shrink-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-full h-full flex items-center justify-center text-gray-400 text-xs",
                                            children: "이미지"
                                        }, void 0, false, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1055,
                                            columnNumber: 19
                                        }, this),
                                        idx === 3 && post.images.length > 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center text-white font-semibold text-xs",
                                            children: [
                                                "+",
                                                post.images.length - 4
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1059,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, idx, true, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 1051,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 1049,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between pt-3 border-t border-gray-100",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowUp"], {
                                                className: "text-lg"
                                            }, void 0, false, {
                                                fileName: "[project]/components/PostList.tsx",
                                                lineNumber: 1072,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-medium",
                                                children: post.upvotes
                                            }, void 0, false, {
                                                fileName: "[project]/components/PostList.tsx",
                                                lineNumber: 1073,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 1071,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiMessageCircle"], {
                                                className: "text-lg"
                                            }, void 0, false, {
                                                fileName: "[project]/components/PostList.tsx",
                                                lineNumber: 1076,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-medium",
                                                children: post.comments
                                            }, void 0, false, {
                                                fileName: "[project]/components/PostList.tsx",
                                                lineNumber: 1077,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 1075,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiEye"], {
                                                className: "text-lg"
                                            }, void 0, false, {
                                                fileName: "[project]/components/PostList.tsx",
                                                lineNumber: 1080,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-medium",
                                                children: post.views
                                            }, void 0, false, {
                                                fileName: "[project]/components/PostList.tsx",
                                                lineNumber: 1081,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 1079,
                                        columnNumber: 15
                                    }, this),
                                    post.likes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHeart"], {
                                                className: "text-lg"
                                            }, void 0, false, {
                                                fileName: "[project]/components/PostList.tsx",
                                                lineNumber: 1085,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-medium",
                                                children: post.likes
                                            }, void 0, false, {
                                                fileName: "[project]/components/PostList.tsx",
                                                lineNumber: 1086,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 1084,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/PostList.tsx",
                                lineNumber: 1070,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 1069,
                            columnNumber: 11
                        }, this)
                    ]
                }, post.id, true, {
                    fileName: "[project]/components/PostList.tsx",
                    lineNumber: 1006,
                    columnNumber: 9
                }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-8 pt-6 border-t border-gray-200",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$RecoveryGuideSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/components/PostList.tsx",
                    lineNumber: 1096,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/PostList.tsx",
                lineNumber: 1095,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/PostList.tsx",
        lineNumber: 1004,
        columnNumber: 5
    }, this);
}
_s(PostList, "USzcCn9UNOOse7tMxKKobNyBFFU=");
_c = PostList;
var _c;
__turbopack_context__.k.register(_c, "PostList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ProcedureReviewForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProcedureReviewForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ProcedureReviewForm({ onBack, onSubmit }) {
    _s();
    const [surgeryDate, setSurgeryDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [category, setCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [hospitalName, setHospitalName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureName, setProcedureName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureSearchTerm, setProcedureSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [showProcedureSuggestions, setShowProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [procedureSuggestions, setProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [cost, setCost] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureRating, setProcedureRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [hospitalRating, setHospitalRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [gender, setGender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [ageGroup, setAgeGroup] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [images, setImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // 대분류 카테고리 10개 (고정)
    const categories = [
        "눈성형",
        "리프팅",
        "보톡스",
        "안면윤곽/양악",
        "제모",
        "지방성형",
        "코성형",
        "피부",
        "필러",
        "가슴성형"
    ];
    const ageGroups = [
        "20대",
        "30대",
        "40대",
        "50대"
    ];
    // 한국어 완성형 글자 체크 (자음만 입력 방지)
    const hasCompleteCharacter = (text)=>{
        // 완성형 한글(가-힣), 영문, 숫자가 1자 이상 포함되어 있는지 확인
        return /[가-힣a-zA-Z0-9]/.test(text);
    };
    // 시술명 자동완성 데이터 로드 (서버 사이드 검색)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProcedureReviewForm.useEffect": ()=>{
            const loadAutocomplete = {
                "ProcedureReviewForm.useEffect.loadAutocomplete": async ()=>{
                    if (!procedureSearchTerm || procedureSearchTerm.trim().length < 1) {
                        setProcedureSuggestions([]);
                        setShowProcedureSuggestions(false);
                        return;
                    }
                    // 완성형 글자가 1자 이상 있어야 자동완성 표시 (자음만 입력 방지)
                    if (!hasCompleteCharacter(procedureSearchTerm)) {
                        setProcedureSuggestions([]);
                        setShowProcedureSuggestions(false);
                        return;
                    }
                    try {
                        // 카테고리가 선택되었으면 해당 카테고리의 시술 데이터를 로드해서 category_small 추출
                        if (category) {
                            // category_small 검색을 위해 직접 Supabase 쿼리 사용
                            let query = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("treatment_master").select("category_small").eq("category_large", category).not("category_small", "is", null);
                            const { data, error } = await query.limit(1000);
                            if (error) {
                                throw new Error(`Supabase 오류: ${error.message}`);
                            }
                            // category_small 추출 및 중복 제거
                            const allCategorySmall = Array.from(new Set((data || []).map({
                                "ProcedureReviewForm.useEffect.loadAutocomplete.allCategorySmall": (t)=>t.category_small
                            }["ProcedureReviewForm.useEffect.loadAutocomplete.allCategorySmall"]).filter({
                                "ProcedureReviewForm.useEffect.loadAutocomplete.allCategorySmall": (small)=>typeof small === "string" && small.trim() !== ""
                            }["ProcedureReviewForm.useEffect.loadAutocomplete.allCategorySmall"])));
                            // 검색어로 필터링
                            const searchTermLower = procedureSearchTerm.toLowerCase();
                            const suggestions = allCategorySmall.filter({
                                "ProcedureReviewForm.useEffect.loadAutocomplete.suggestions": (small)=>small.toLowerCase().includes(searchTermLower)
                            }["ProcedureReviewForm.useEffect.loadAutocomplete.suggestions"]).slice(0, 10);
                            setProcedureSuggestions(suggestions);
                            // 검색 결과가 있으면 자동완성 표시
                            if (suggestions.length > 0) {
                                setShowProcedureSuggestions(true);
                            }
                            console.log("🔍 검색어:", procedureSearchTerm);
                            console.log("🔍 선택된 카테고리:", category);
                            console.log("🔍 전체 데이터 개수:", allCategorySmall.length);
                            console.log("🔍 검색 결과 개수:", suggestions.length);
                            if (suggestions.length > 0) {
                                console.log("🔍 검색 결과:", suggestions);
                            } else {
                                console.log("🔍 해당 카테고리의 모든 category_small:", allCategorySmall);
                            }
                        } else {
                            // 카테고리가 선택되지 않았으면 기존 함수 사용
                            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTreatmentAutocomplete"])(procedureSearchTerm, 10);
                            setProcedureSuggestions(result.treatmentNames);
                            // 검색 결과가 있으면 자동완성 표시
                            if (result.treatmentNames.length > 0) {
                                setShowProcedureSuggestions(true);
                            }
                            console.log("🔍 검색어:", procedureSearchTerm);
                            console.log("🔍 선택된 카테고리: 전체");
                            console.log("🔍 검색 결과 개수:", result.treatmentNames.length);
                            if (result.treatmentNames.length > 0) {
                                console.log("🔍 검색 결과:", result.treatmentNames);
                            }
                        }
                    } catch (error) {
                        console.error("자동완성 데이터 로드 실패:", error);
                        setProcedureSuggestions([]);
                    }
                }
            }["ProcedureReviewForm.useEffect.loadAutocomplete"];
            const debounceTimer = setTimeout({
                "ProcedureReviewForm.useEffect.debounceTimer": ()=>{
                    loadAutocomplete();
                }
            }["ProcedureReviewForm.useEffect.debounceTimer"], 300);
            return ({
                "ProcedureReviewForm.useEffect": ()=>clearTimeout(debounceTimer)
            })["ProcedureReviewForm.useEffect"];
        }
    }["ProcedureReviewForm.useEffect"], [
        procedureSearchTerm,
        category
    ]);
    const handleImageUpload = (e)=>{
        if (e.target.files) {
            const files = Array.from(e.target.files);
            const newImages = files.map((file)=>URL.createObjectURL(file));
            setImages([
                ...images,
                ...newImages
            ].slice(0, 4));
        }
    };
    const removeImage = (index)=>{
        setImages(images.filter((_, i)=>i !== index));
    };
    const handleSubmit = async ()=>{
        // 필수 항목 검증
        // procedureName은 procedureSearchTerm에서 가져오거나 직접 입력된 값 사용
        const finalProcedureName = procedureName || procedureSearchTerm;
        if (!category || !finalProcedureName || !cost || content.length < 10) {
            alert("필수 항목을 모두 입력하고 글을 10자 이상 작성해주세요.");
            return;
        }
        // 성별, 연령대 검증
        if (!gender || !ageGroup) {
            alert("성별과 연령대를 선택해주세요.");
            return;
        }
        // 만족도 검증
        if (procedureRating === 0 || hospitalRating === 0) {
            alert("시술 만족도와 병원 만족도를 모두 선택해주세요.");
            return;
        }
        try {
            // 이미지 URL 배열 생성 (현재는 로컬 URL이므로 추후 Supabase Storage 업로드 필요)
            const imageUrls = images.length > 0 ? images : undefined;
            // 데이터 저장
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveProcedureReview"])({
                category,
                procedure_name: finalProcedureName,
                hospital_name: hospitalName || undefined,
                cost: parseInt(cost),
                procedure_rating: procedureRating,
                hospital_rating: hospitalRating,
                gender,
                age_group: ageGroup,
                surgery_date: surgeryDate || undefined,
                content,
                images: imageUrls,
                user_id: 0
            });
            if (result.success) {
                alert("시술후기가 성공적으로 작성되었습니다!");
                onSubmit();
            } else {
                alert(`시술후기 작성에 실패했습니다: ${result.error}`);
            }
        } catch (error) {
            console.error("시술후기 저장 오류:", error);
            alert(`시술후기 작성 중 오류가 발생했습니다: ${error.message}`);
        }
    };
    const StarRating = ({ rating, onRatingChange, label })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "block text-sm font-semibold text-gray-900 mb-2",
                    children: [
                        label,
                        " ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-red-500",
                            children: "*"
                        }, void 0, false, {
                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                            lineNumber: 241,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                    lineNumber: 240,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2",
                    children: [
                        1,
                        2,
                        3,
                        4,
                        5
                    ].map((star)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>onRatingChange(star),
                            className: "p-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiStar"], {
                                className: `text-2xl ${star <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 251,
                                columnNumber: 13
                            }, this)
                        }, star, false, {
                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                            lineNumber: 245,
                            columnNumber: 11
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                    lineNumber: 243,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/ProcedureReviewForm.tsx",
            lineNumber: 239,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onBack,
                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                            className: "text-gray-700 text-xl"
                        }, void 0, false, {
                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                            lineNumber: 272,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 268,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: "시술 후기 작성"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 274,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 267,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "시술 카테고리 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 280,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 279,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: category,
                        onChange: (e)=>{
                            setCategory(e.target.value);
                            setProcedureSearchTerm(""); // 카테고리 변경 시 검색어 초기화
                            setProcedureName("");
                            setShowProcedureSuggestions(false); // 자동완성 닫기
                            setProcedureSuggestions([]); // 자동완성 목록 초기화
                        },
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "카테고리를 선택하세요"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 293,
                                columnNumber: 11
                            }, this),
                            categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: cat,
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                                    lineNumber: 295,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 282,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 278,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "시술명(수술명) ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 305,
                                columnNumber: 20
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 304,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: procedureSearchTerm,
                        onChange: (e)=>{
                            const value = e.target.value;
                            setProcedureSearchTerm(value);
                            // 완성형 글자가 있을 때만 자동완성 표시
                            if (hasCompleteCharacter(value)) {
                                setShowProcedureSuggestions(true);
                            } else {
                                setShowProcedureSuggestions(false);
                            }
                            // 자동완성에서 선택되지 않은 값이면 procedureName도 업데이트 (직접 입력 허용)
                            if (value && !procedureSuggestions.includes(value)) {
                                setProcedureName(value);
                            }
                        },
                        onFocus: ()=>{
                            if (procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm)) {
                                setShowProcedureSuggestions(true);
                            }
                        },
                        onBlur: ()=>{
                            // 약간의 지연을 두어 클릭 이벤트가 먼저 발생하도록
                            setTimeout(()=>{
                                setShowProcedureSuggestions(false);
                                // blur 시 현재 입력값을 procedureName에 저장 (선택된 값이 없을 때)
                                if (procedureSearchTerm && !procedureName) {
                                    setProcedureName(procedureSearchTerm);
                                }
                            }, 200);
                        },
                        placeholder: "시술명을 입력해 주세요.",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 307,
                        columnNumber: 9
                    }, this),
                    showProcedureSuggestions && procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm) && procedureSuggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-xl shadow-lg max-h-60 overflow-y-auto",
                        children: procedureSuggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    setProcedureName(suggestion);
                                    setProcedureSearchTerm(suggestion);
                                    setShowProcedureSuggestions(false);
                                },
                                className: "w-full px-4 py-2 text-left hover:bg-gray-50 first:rounded-t-xl last:rounded-b-xl",
                                children: suggestion
                            }, index, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 351,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 349,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 303,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "비용 (만원) ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 371,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 370,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-gray-700",
                                children: "₩"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 374,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: cost,
                                onChange: (e)=>setCost(e.target.value),
                                placeholder: "수술 비용",
                                className: "flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 375,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-gray-700",
                                children: "만원"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 382,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 373,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 369,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: procedureRating,
                onRatingChange: setProcedureRating,
                label: "전체적인 시술 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 387,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: hospitalRating,
                onRatingChange: setHospitalRating,
                label: "병원 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 394,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "병원명(선택사항)"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 402,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: hospitalName,
                        onChange: (e)=>setHospitalName(e.target.value),
                        placeholder: "병원명을 입력하세요",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 405,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 401,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "시술 날짜(선택사항)"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 416,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "date",
                        value: surgeryDate,
                        onChange: (e)=>setSurgeryDate(e.target.value),
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 419,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 415,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "성별 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 430,
                                columnNumber: 14
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 429,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setGender("여"),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${gender === "여" ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "여"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 433,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setGender("남"),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${gender === "남" ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "남"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 444,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 432,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 428,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "연령 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 461,
                                columnNumber: 14
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 460,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: ageGroups.map((age)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setAgeGroup(age),
                                className: `py-3 rounded-xl border-2 transition-colors ${ageGroup === age ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: age
                            }, age, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 465,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 463,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 459,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "글 작성 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 484,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 483,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: content,
                        onChange: (e)=>setContent(e.target.value),
                        placeholder: "시술 경험을 자세히 작성해주세요 (10자 이상)",
                        rows: 8,
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main resize-none"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 486,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-1",
                        children: [
                            content.length,
                            "자 / 최소 10자 이상 작성해주세요"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 493,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 482,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"], {
                                className: "text-primary-main"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 501,
                                columnNumber: 11
                            }, this),
                            "사진첨부 (최대 4장)"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 500,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: [
                            images.map((img, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative aspect-square rounded-xl overflow-hidden border border-gray-300",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: img,
                                            alt: `Uploaded ${index + 1}`,
                                            fill: true,
                                            className: "object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                                            lineNumber: 510,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>removeImage(index),
                                            className: "absolute top-2 right-2 p-1 bg-black/50 rounded-full text-white hover:bg-black/70",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                                className: "text-sm"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                                lineNumber: 521,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                                            lineNumber: 516,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, index, true, {
                                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                                    lineNumber: 506,
                                    columnNumber: 13
                                }, this)),
                            images.length < 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "aspect-square border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center cursor-pointer hover:border-primary-main transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "file",
                                        accept: "image/*",
                                        multiple: true,
                                        onChange: handleImageUpload,
                                        className: "hidden"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                                        lineNumber: 527,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"], {
                                                className: "text-2xl text-gray-400 mx-auto mb-2"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                                lineNumber: 535,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-gray-500",
                                                children: "사진 추가"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                                lineNumber: 536,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                                        lineNumber: 534,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 526,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 504,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 499,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 pt-4 pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onBack,
                        className: "flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-colors",
                        children: "취소"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 545,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleSubmit,
                        className: "flex-1 py-3 bg-primary-main hover:bg-primary-light text-white rounded-xl font-semibold transition-colors",
                        children: "작성완료"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 552,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 544,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ProcedureReviewForm.tsx",
        lineNumber: 265,
        columnNumber: 5
    }, this);
}
_s(ProcedureReviewForm, "UwTr4J4mNL64hEppkMCkVQDDRIc=");
_c = ProcedureReviewForm;
var _c;
__turbopack_context__.k.register(_c, "ProcedureReviewForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/HospitalReviewForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HospitalReviewForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function HospitalReviewForm({ onBack, onSubmit }) {
    _s();
    const [hospitalName, setHospitalName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [visitDate, setVisitDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [categoryLarge, setCategoryLarge] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureSearchTerm, setProcedureSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [showProcedureSuggestions, setShowProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [procedureSuggestions, setProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedProcedure, setSelectedProcedure] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [overallSatisfaction, setOverallSatisfaction] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [hospitalKindness, setHospitalKindness] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [hasTranslation, setHasTranslation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [translationSatisfaction, setTranslationSatisfaction] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [images, setImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // 대분류 카테고리 10개 (고정)
    const categories = [
        "눈성형",
        "리프팅",
        "보톡스",
        "안면윤곽/양악",
        "제모",
        "지방성형",
        "코성형",
        "피부",
        "필러",
        "가슴성형"
    ];
    // 한국어 완성형 글자 체크 (자음만 입력 방지)
    const hasCompleteCharacter = (text)=>{
        // 완성형 한글(가-힣), 영문, 숫자가 1자 이상 포함되어 있는지 확인
        return /[가-힣a-zA-Z0-9]/.test(text);
    };
    // 시술명 자동완성 데이터 로드 (서버 사이드 검색)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HospitalReviewForm.useEffect": ()=>{
            const loadAutocomplete = {
                "HospitalReviewForm.useEffect.loadAutocomplete": async ()=>{
                    if (!procedureSearchTerm || procedureSearchTerm.trim().length < 1) {
                        setProcedureSuggestions([]);
                        setShowProcedureSuggestions(false);
                        return;
                    }
                    // 완성형 글자가 1자 이상 있어야 자동완성 표시 (자음만 입력 방지)
                    if (!hasCompleteCharacter(procedureSearchTerm)) {
                        setProcedureSuggestions([]);
                        setShowProcedureSuggestions(false);
                        return;
                    }
                    try {
                        // 카테고리가 선택되었으면 해당 카테고리의 시술 데이터를 로드해서 category_small 추출
                        if (categoryLarge) {
                            // category_small 검색을 위해 직접 Supabase 쿼리 사용
                            let query = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("treatment_master").select("category_small").eq("category_large", categoryLarge).not("category_small", "is", null);
                            const { data, error } = await query.limit(1000);
                            if (error) {
                                throw new Error(`Supabase 오류: ${error.message}`);
                            }
                            // category_small 추출 및 중복 제거
                            const allCategorySmall = Array.from(new Set((data || []).map({
                                "HospitalReviewForm.useEffect.loadAutocomplete.allCategorySmall": (t)=>t.category_small
                            }["HospitalReviewForm.useEffect.loadAutocomplete.allCategorySmall"]).filter({
                                "HospitalReviewForm.useEffect.loadAutocomplete.allCategorySmall": (small)=>typeof small === "string" && small.trim() !== ""
                            }["HospitalReviewForm.useEffect.loadAutocomplete.allCategorySmall"])));
                            // 검색어로 필터링
                            const searchTermLower = procedureSearchTerm.toLowerCase();
                            const suggestions = allCategorySmall.filter({
                                "HospitalReviewForm.useEffect.loadAutocomplete.suggestions": (small)=>small.toLowerCase().includes(searchTermLower)
                            }["HospitalReviewForm.useEffect.loadAutocomplete.suggestions"]).slice(0, 10);
                            setProcedureSuggestions(suggestions);
                            // 검색 결과가 있으면 자동완성 표시
                            if (suggestions.length > 0) {
                                setShowProcedureSuggestions(true);
                            }
                        } else {
                            // 카테고리가 선택되지 않았으면 기존 함수 사용
                            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTreatmentAutocomplete"])(procedureSearchTerm, 10);
                            setProcedureSuggestions(result.treatmentNames);
                            // 검색 결과가 있으면 자동완성 표시
                            if (result.treatmentNames.length > 0) {
                                setShowProcedureSuggestions(true);
                            }
                        }
                    } catch (error) {
                        console.error("자동완성 데이터 로드 실패:", error);
                        setProcedureSuggestions([]);
                    }
                }
            }["HospitalReviewForm.useEffect.loadAutocomplete"];
            const debounceTimer = setTimeout({
                "HospitalReviewForm.useEffect.debounceTimer": ()=>{
                    loadAutocomplete();
                }
            }["HospitalReviewForm.useEffect.debounceTimer"], 300);
            return ({
                "HospitalReviewForm.useEffect": ()=>clearTimeout(debounceTimer)
            })["HospitalReviewForm.useEffect"];
        }
    }["HospitalReviewForm.useEffect"], [
        procedureSearchTerm,
        categoryLarge
    ]);
    const handleImageUpload = (e)=>{
        if (e.target.files) {
            const files = Array.from(e.target.files);
            const newImages = files.map((file)=>URL.createObjectURL(file));
            setImages([
                ...images,
                ...newImages
            ].slice(0, 4));
        }
    };
    const removeImage = (index)=>{
        setImages(images.filter((_, i)=>i !== index));
    };
    const StarRating = ({ rating, onRatingChange, label })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "block text-sm font-semibold text-gray-900 mb-2",
                    children: label
                }, void 0, false, {
                    fileName: "[project]/components/HospitalReviewForm.tsx",
                    lineNumber: 165,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2",
                    children: [
                        1,
                        2,
                        3,
                        4,
                        5
                    ].map((star)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>onRatingChange(star),
                            className: "p-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiStar"], {
                                className: `text-2xl ${star <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 176,
                                columnNumber: 13
                            }, this)
                        }, star, false, {
                            fileName: "[project]/components/HospitalReviewForm.tsx",
                            lineNumber: 170,
                            columnNumber: 11
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/HospitalReviewForm.tsx",
                    lineNumber: 168,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/HospitalReviewForm.tsx",
            lineNumber: 164,
            columnNumber: 5
        }, this);
    const handleSubmit = async ()=>{
        // 필수 항목 검증
        if (!hospitalName || !categoryLarge || content.length < 10) {
            alert("필수 항목을 모두 입력하고 글을 10자 이상 작성해주세요.");
            return;
        }
        try {
            // 이미지 URL 배열 생성 (현재는 로컬 URL이므로 추후 Supabase Storage 업로드 필요)
            const imageUrls = images.length > 0 ? images : undefined;
            // 데이터 저장
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveHospitalReview"])({
                hospital_name: hospitalName,
                category_large: categoryLarge,
                procedure_name: selectedProcedure || undefined,
                visit_date: visitDate || undefined,
                overall_satisfaction: overallSatisfaction > 0 ? overallSatisfaction : undefined,
                hospital_kindness: hospitalKindness > 0 ? hospitalKindness : undefined,
                has_translation: hasTranslation,
                translation_satisfaction: hasTranslation && translationSatisfaction > 0 ? translationSatisfaction : undefined,
                content,
                images: imageUrls,
                user_id: 0
            });
            if (result.success) {
                alert("병원후기가 성공적으로 작성되었습니다!");
                onSubmit();
            } else {
                alert(`병원후기 작성에 실패했습니다: ${result.error}`);
            }
        } catch (error) {
            console.error("병원후기 저장 오류:", error);
            alert(`병원후기 작성 중 오류가 발생했습니다: ${error.message}`);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onBack,
                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                            className: "text-gray-700 text-xl"
                        }, void 0, false, {
                            fileName: "[project]/components/HospitalReviewForm.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 235,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: "병원 후기 작성"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 241,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 234,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "병원명 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 247,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 246,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: hospitalName,
                        onChange: (e)=>setHospitalName(e.target.value),
                        placeholder: "병원명을 입력하세요",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 249,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 245,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "시술 카테고리 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 261,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 260,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: categoryLarge,
                        onChange: (e)=>{
                            setCategoryLarge(e.target.value);
                            setProcedureSearchTerm(""); // 카테고리 변경 시 검색어 초기화
                            setSelectedProcedure("");
                            setShowProcedureSuggestions(false); // 자동완성 닫기
                            setProcedureSuggestions([]); // 자동완성 목록 초기화
                        },
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "대분류 선택"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 274,
                                columnNumber: 11
                            }, this),
                            categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: cat,
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/components/HospitalReviewForm.tsx",
                                    lineNumber: 276,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 263,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 259,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "시술명(수술명) (선택사항)"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 285,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: procedureSearchTerm,
                        onChange: (e)=>{
                            const value = e.target.value;
                            setProcedureSearchTerm(value);
                            // 완성형 글자가 있을 때만 자동완성 표시
                            if (hasCompleteCharacter(value)) {
                                setShowProcedureSuggestions(true);
                            } else {
                                setShowProcedureSuggestions(false);
                            }
                            // 자동완성에서 선택되지 않은 값이면 selectedProcedure도 업데이트 (직접 입력 허용)
                            if (value && !procedureSuggestions.includes(value)) {
                                setSelectedProcedure(value);
                            }
                        },
                        onFocus: ()=>{
                            if (procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm)) {
                                setShowProcedureSuggestions(true);
                            }
                        },
                        onBlur: ()=>{
                            // 약간의 지연을 두어 클릭 이벤트가 먼저 발생하도록
                            setTimeout(()=>{
                                setShowProcedureSuggestions(false);
                                // blur 시 현재 입력값을 selectedProcedure에 저장 (선택된 값이 없을 때)
                                if (procedureSearchTerm && !selectedProcedure) {
                                    setSelectedProcedure(procedureSearchTerm);
                                }
                            }, 200);
                        },
                        placeholder: "시술명을 입력해 주세요.",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 288,
                        columnNumber: 9
                    }, this),
                    showProcedureSuggestions && procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm) && procedureSuggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-xl shadow-lg max-h-60 overflow-y-auto",
                        children: procedureSuggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    setSelectedProcedure(suggestion);
                                    setProcedureSearchTerm(suggestion);
                                    setShowProcedureSuggestions(false);
                                },
                                className: "w-full px-4 py-2 text-left hover:bg-gray-50 first:rounded-t-xl last:rounded-b-xl",
                                children: suggestion
                            }, index, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 332,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 330,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 284,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: overallSatisfaction,
                onRatingChange: setOverallSatisfaction,
                label: "전체적인 시술 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 350,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: hospitalKindness,
                onRatingChange: setHospitalKindness,
                label: "병원 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 357,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "통역 여부"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 365,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setHasTranslation(true),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${hasTranslation ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "있음"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 369,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setHasTranslation(false),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${!hasTranslation ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "없음"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 380,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 368,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 364,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "병원 방문일"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 396,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "date",
                        value: visitDate,
                        onChange: (e)=>setVisitDate(e.target.value),
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 399,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 395,
                columnNumber: 7
            }, this),
            hasTranslation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: translationSatisfaction,
                onRatingChange: setTranslationSatisfaction,
                label: "통역 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 409,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "글 작성 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 419,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 418,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: content,
                        onChange: (e)=>setContent(e.target.value),
                        placeholder: "병원 방문 경험을 자세히 작성해주세요 (10자 이상)",
                        rows: 8,
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main resize-none"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 421,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-1",
                        children: [
                            content.length,
                            "자 / 최소 10자 이상 작성해주세요"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 428,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 417,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"], {
                                className: "text-primary-main"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 436,
                                columnNumber: 11
                            }, this),
                            "사진첨부 (최대 4장)"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 435,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: [
                            images.map((img, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative aspect-square rounded-xl overflow-hidden border border-gray-300",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: img,
                                            alt: `Uploaded ${index + 1}`,
                                            fill: true,
                                            className: "object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/components/HospitalReviewForm.tsx",
                                            lineNumber: 445,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>removeImage(index),
                                            className: "absolute top-2 right-2 p-1 bg-black/50 rounded-full text-white hover:bg-black/70",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                                className: "text-sm"
                                            }, void 0, false, {
                                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                                lineNumber: 456,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/HospitalReviewForm.tsx",
                                            lineNumber: 451,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, index, true, {
                                    fileName: "[project]/components/HospitalReviewForm.tsx",
                                    lineNumber: 441,
                                    columnNumber: 13
                                }, this)),
                            images.length < 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "aspect-square border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center cursor-pointer hover:border-primary-main transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "file",
                                        accept: "image/*",
                                        multiple: true,
                                        onChange: handleImageUpload,
                                        className: "hidden"
                                    }, void 0, false, {
                                        fileName: "[project]/components/HospitalReviewForm.tsx",
                                        lineNumber: 462,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"], {
                                                className: "text-2xl text-gray-400 mx-auto mb-2"
                                            }, void 0, false, {
                                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                                lineNumber: 470,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-gray-500",
                                                children: "사진 추가"
                                            }, void 0, false, {
                                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                                lineNumber: 471,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/HospitalReviewForm.tsx",
                                        lineNumber: 469,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 461,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 439,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 434,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 pt-4 pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onBack,
                        className: "flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-colors",
                        children: "취소"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 480,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleSubmit,
                        className: "flex-1 py-3 bg-primary-main hover:bg-primary-light text-white rounded-xl font-semibold transition-colors",
                        children: "작성완료"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 487,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 479,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/HospitalReviewForm.tsx",
        lineNumber: 232,
        columnNumber: 5
    }, this);
}
_s(HospitalReviewForm, "y55aBcHDxMgjeXqHl6Hnq6PSd0Q=");
_c = HospitalReviewForm;
var _c;
__turbopack_context__.k.register(_c, "HospitalReviewForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ConcernPostForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConcernPostForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ConcernPostForm({ onBack, onSubmit }) {
    _s();
    const [title, setTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [concernCategory, setConcernCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // 커뮤니티 - 고민상담소 카테고리 (현재 선택 가능한 카테고리대로)
    const concernCategories = [
        "피부 고민",
        "시술 고민",
        "병원 선택",
        "가격 문의",
        "회복 기간",
        "부작용",
        "기타"
    ];
    const handleSubmit = async ()=>{
        // 필수 항목 검증
        if (!title || !concernCategory || content.length < 10) {
            alert("필수 항목을 모두 입력하고 글을 10자 이상 작성해주세요.");
            return;
        }
        try {
            // 데이터 저장
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveConcernPost"])({
                title,
                concern_category: concernCategory,
                content,
                user_id: 0
            });
            if (result.success) {
                alert("고민글이 성공적으로 작성되었습니다!");
                onSubmit();
            } else {
                alert(`고민글 작성에 실패했습니다: ${result.error}`);
            }
        } catch (error) {
            console.error("고민글 저장 오류:", error);
            alert(`고민글 작성 중 오류가 발생했습니다: ${error.message}`);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onBack,
                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                            className: "text-gray-700 text-xl"
                        }, void 0, false, {
                            fileName: "[project]/components/ConcernPostForm.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: "고민글 작성"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 69,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "제목 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 75,
                                columnNumber: 14
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: title,
                        onChange: (e)=>setTitle(e.target.value),
                        placeholder: "고민글 제목을 입력하세요",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 77,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "고민 카테고리 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 89,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 88,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: concernCategory,
                        onChange: (e)=>setConcernCategory(e.target.value),
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "고민 카테고리를 선택하세요"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 96,
                                columnNumber: 11
                            }, this),
                            concernCategories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: cat,
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/components/ConcernPostForm.tsx",
                                    lineNumber: 98,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "고민 글 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 108,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: content,
                        onChange: (e)=>setContent(e.target.value),
                        placeholder: "고민이나 질문을 자세히 작성해주세요 (10자 이상)",
                        rows: 10,
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main resize-none"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-1",
                        children: [
                            content.length,
                            "자 / 최소 10자 이상 작성해주세요"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 117,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 pt-4 pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onBack,
                        className: "flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-colors",
                        children: "취소"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 124,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleSubmit,
                        className: "flex-1 py-3 bg-primary-main hover:bg-primary-light text-white rounded-xl font-semibold transition-colors",
                        children: "작성완료"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 123,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ConcernPostForm.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
_s(ConcernPostForm, "ojOAOHULwMDRAGNvV9kVTY5rtio=");
_c = ConcernPostForm;
var _c;
__turbopack_context__.k.register(_c, "ConcernPostForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/CommunityWriteModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommunityWriteModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProcedureReviewForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ProcedureReviewForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HospitalReviewForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/HospitalReviewForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ConcernPostForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ConcernPostForm.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const writeOptions = [
    {
        id: "procedure-review",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"],
        title: "시술 후기",
        description: "시술 경험을 공유해보세요",
        color: "from-pink-500 to-rose-500"
    },
    {
        id: "hospital-review",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiHome"],
        title: "병원 후기",
        description: "병원 방문 경험을 공유해보세요",
        color: "from-blue-500 to-cyan-500"
    },
    {
        id: "concern-post",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiFileText"],
        title: "고민글",
        description: "고민이나 질문을 올려보세요",
        color: "from-purple-500 to-pink-500"
    }
];
function CommunityWriteModal({ isOpen, onClose }) {
    _s();
    const [selectedOption, setSelectedOption] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    if (!isOpen) return null;
    const handleOptionClick = (optionId)=>{
        setSelectedOption(optionId);
    };
    const handleBack = ()=>{
        setSelectedOption(null);
    };
    const handleSubmit = ()=>{
        // 각 폼에서 이미 성공 메시지를 표시하므로 여기서는 alert 제거
        setSelectedOption(null);
        onClose();
        // 후기 목록 새로고침을 위한 이벤트 발생
        window.dispatchEvent(new CustomEvent("reviewAdded"));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 bg-black/50 z-[100] transition-opacity",
                onClick: onClose
            }, void 0, false, {
                fileName: "[project]/components/CommunityWriteModal.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-x-0 bottom-0 bg-white rounded-t-3xl z-[100] max-w-md mx-auto shadow-2xl animate-slide-up",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center pt-3 pb-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-12 h-1 bg-gray-300 rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/components/CommunityWriteModal.tsx",
                            lineNumber: 74,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/CommunityWriteModal.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-6 py-4 border-b border-gray-100",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-xl font-bold text-gray-900",
                                        children: "글 작성하기"
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 80,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: onClose,
                                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                            className: "text-gray-600 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                            lineNumber: 85,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 81,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/CommunityWriteModal.tsx",
                                lineNumber: 79,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-gray-500 mt-1",
                                children: "어떤 이야기를 공유하고 싶으신가요?"
                            }, void 0, false, {
                                fileName: "[project]/components/CommunityWriteModal.tsx",
                                lineNumber: 88,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/CommunityWriteModal.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-6 py-4 max-h-[70vh] overflow-y-auto",
                        children: !selectedOption ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-3",
                            children: [
                                writeOptions.map((option)=>{
                                    const Icon = option.icon;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>handleOptionClick(option.id),
                                        className: "w-full p-4 bg-gradient-to-r rounded-xl border-2 border-gray-100 hover:border-primary-main/30 hover:shadow-lg transition-all text-left group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: `bg-gradient-to-br ${option.color} p-3 rounded-xl shadow-md group-hover:scale-110 transition-transform`,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                                        className: "text-white text-xl"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                                        lineNumber: 109,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 106,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-base font-bold text-gray-900 mb-1",
                                                            children: option.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 112,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm text-gray-600",
                                                            children: option.description
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 115,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 111,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-400 group-hover:text-primary-main transition-colors",
                                                    children: "→"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 119,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                            lineNumber: 105,
                                            columnNumber: 21
                                        }, this)
                                    }, option.id, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 100,
                                        columnNumber: 19
                                    }, this);
                                }),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-t border-gray-200 pt-3 mt-3",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            // TODO: 내 글 관리 페이지로 이동
                                            alert("내 글 관리 기능은 추후 구현 예정입니다.");
                                            onClose();
                                        },
                                        className: "w-full p-4 bg-gray-50 hover:bg-gray-100 rounded-xl border-2 border-gray-200 hover:border-primary-main/30 transition-all text-left group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "bg-gradient-to-br from-gray-400 to-gray-500 p-3 rounded-xl shadow-md group-hover:scale-110 transition-transform",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiUser"], {
                                                        className: "text-white text-xl"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                                        lineNumber: 139,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 138,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-base font-bold text-gray-900 mb-1",
                                                            children: "내 글 관리"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 142,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm text-gray-600",
                                                            children: "작성한 글을 관리해보세요"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 145,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 141,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-400 group-hover:text-primary-main transition-colors",
                                                    children: "→"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 149,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                            lineNumber: 137,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 129,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 128,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/CommunityWriteModal.tsx",
                            lineNumber: 96,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                selectedOption === "procedure-review" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProcedureReviewForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onBack: handleBack,
                                    onSubmit: handleSubmit
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 159,
                                    columnNumber: 17
                                }, this),
                                selectedOption === "hospital-review" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HospitalReviewForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onBack: handleBack,
                                    onSubmit: handleSubmit
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 165,
                                    columnNumber: 17
                                }, this),
                                selectedOption === "concern-post" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ConcernPostForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onBack: handleBack,
                                    onSubmit: handleSubmit
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 171,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/CommunityWriteModal.tsx",
                            lineNumber: 157,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/CommunityWriteModal.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/CommunityWriteModal.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(CommunityWriteModal, "JA8CxE9ZrczvRffCFoauEAbBIYg=");
_c = CommunityWriteModal;
var _c;
__turbopack_context__.k.register(_c, "CommunityWriteModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/CommunityFloatingButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommunityFloatingButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityWriteModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CommunityWriteModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function CommunityFloatingButton() {
    _s();
    const [isWriteModalOpen, setIsWriteModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed bottom-20 right-0 left-0 z-40 pointer-events-none max-w-md mx-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative pointer-events-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setIsWriteModalOpen(true),
                        className: "absolute bottom-0 right-4 w-14 h-14 sm:w-16 sm:h-16 bg-primary-main hover:bg-[#2DB8A0] active:bg-primary-light text-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl active:shadow-2xl transition-all duration-300 hover:scale-110 active:scale-95 touch-manipulation",
                        style: {
                            minWidth: "56px",
                            minHeight: "56px"
                        },
                        "aria-label": "글 작성하기",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiEdit3"], {
                            className: "text-xl sm:text-2xl"
                        }, void 0, false, {
                            fileName: "[project]/components/CommunityFloatingButton.tsx",
                            lineNumber: 24,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/CommunityFloatingButton.tsx",
                        lineNumber: 15,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/CommunityFloatingButton.tsx",
                    lineNumber: 13,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/CommunityFloatingButton.tsx",
                lineNumber: 12,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityWriteModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isWriteModalOpen,
                onClose: ()=>setIsWriteModalOpen(false)
            }, void 0, false, {
                fileName: "[project]/components/CommunityFloatingButton.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(CommunityFloatingButton, "qs6szW+w+CEtWdp/v3YIVJl6HYA=");
_c = CommunityFloatingButton;
var _c;
__turbopack_context__.k.register(_c, "CommunityFloatingButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/content/recoveryGuidePosts.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// 19개 회복 가이드 글 데이터
// 각 글은 시술/수술명에 대한 회복 가이드입니다.
__turbopack_context__.s([
    "findRecoveryGuideById",
    ()=>findRecoveryGuideById,
    "findRecoveryGuideByKeyword",
    ()=>findRecoveryGuideByKeyword,
    "getAllRecoveryGuides",
    ()=>getAllRecoveryGuides,
    "recoveryGuidePosts",
    ()=>recoveryGuidePosts
]);
const recoveryGuidePosts = [
    // 예시 구조 (실제 19개 글은 사용자가 제공한 마크다운을 기반으로 채워야 함)
    {
        id: "jaw-contour-surgery",
        procedureName: "턱·윤곽·양악 수술",
        title: "턱·윤곽·양악 수술에 대한 회복 가이드🍀",
        description: "턱·윤곽·양악 등 얼굴 뼈 구조가 크게 변하는 수술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 턱·윤곽·양악 수술

권장 회복 기간 : 4주 이상

(해당 시술: V라인축소술, 사각턱수술, 턱끝수술, 턱끝축소술, 피질절골술, 교근축소술, 비절개턱성형, 이중턱근육묶기, 하악수술, 상악수술, 양악수술, 턱끝보형물삽입, 턱끝보형물제거, 턱끝이물질제거)

## 🕐 1주차 (Day 0–7)

### 얼굴 뼈 구조가 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

턱·윤곽·양악 수술은 얼굴의 연부조직이 아니라 뼈 구조 자체가 이동하거나 재배치되는 수술이기 때문에 몸의 반응이 매우 강하게 나타납니다. 이 시기에는 수술 부위뿐 아니라 얼굴 전체가 구조적으로 달라졌다는 사실을 인지하며 붓기, 멍, 압박감, 당김이 동시에 발생하는 것이 정상입니다. 뼈 위를 덮고 있던 근육과 피부, 신경이 새로운 위치에 적응하지 못한 상태이기 때문에 얼굴은 실제 결과보다 더 부어 있고 더 넓고 둔탁해 보일 수 있습니다. 이 시기의 외형은 수술 결과가 아니라 회복을 시작하기 전 나타나는 임시 모습에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 가능한 한 일정을 최소화하고 회복을 최우선으로 두기
- 수면 시 머리를 살짝만 높여 붓기 압력 줄이기
- 하루 여러 번 방 안이나 복도에서 3–5분 정도 가볍게 걷기
- 냉·온찜질은 반드시 병원 지침에 맞춰 진행

⚠ 권고사항

- 거울을 자주 보며 얼굴 폭이나 윤곽을 평가
- 무리한 외출이나 장시간 이동
- 통증·붓기를 문제 상황으로 단정

## 🕑 2주차 (Day 8–14)

### 강한 붓기는 줄고 윤곽 변화의 방향이 보이기 시작하는 시기

2주차부터는 수술 직후의 강한 염증 반응이 서서히 가라앉으며 얼굴 전체의 부피감이 줄어들기 시작합니다. 다만 이 시기는 붓기가 완전히 빠지는 단계가 아니라 큰 붓기와 잔붓기가 공존하는 과도기이기 때문에 아침과 저녁 얼굴 컨디션 차이가 뚜렷하게 나타날 수 있습니다. 이는 회복이 잘못된 것이 아니라 턱·윤곽·양악 수술에서 매우 흔한 정상 회복 패턴입니다. 이 시점에서는 세부 결과보다 윤곽이 어떤 방향으로 바뀌고 있는지 큰 흐름만 확인하는 것이 충분합니다.

✔ 이 주차에 도움 되는 팁

- 앉아서 쉴 수 있는 일정 위주의 외출
- 사진은 같은 조명과 각도로 기록용만 남기기
- 가벼운 산책으로 붓기 순환 돕기

⚠ 권고사항

- 수술 전 사진이나 타인 후기와의 과도한 비교
- 과음이나 밤샘 일정
- 아직 부어 있다는 이유로 조급해하기

## 🕒 3주차 (Day 15–21)

### 겉으로는 자연스러워 보이지만 내부는 적응을 마무리하는 시기

3주차에 접어들면 외관상 붓기는 상당 부분 정리되어 주변에서는 자연스럽다고 느끼는 경우가 많아집니다. 하지만 몸 안에서는 턱 주변 근육과 관절, 저작근이 새로운 위치와 사용 패턴에 적응하는 과정이 계속되고 있어 말이나 표정을 많이 사용한 날에는 뻐근함이나 피로감이 다시 느껴질 수 있습니다. 이는 회복이 나빠진 신호가 아니라 정상적인 적응 과정에서 나타나는 반응입니다.

✔ 이 주차에 도움 되는 팁

- 촬영이나 가벼운 여행 일정 가능
- 일정 중간중간 의도적으로 휴식 시간 넣기
- 피곤한 날은 일정을 줄이는 것도 회복의 일부로 받아들이기

⚠ 권고사항

- 격한 운동이나 턱을 과하게 사용하는 활동
- 이제 다 끝났다는 생각으로 무리

## 🕓 4주차 (Day 22–28)

### 일상은 가능하지만 회복은 아직 진행 중인 시기

4주차에는 일상생활과 출근, 일반적인 여행 일정이 대부분 가능해집니다. 다만 의학적으로 턱·윤곽·양악 수술의 안정화는 3–6개월에 걸쳐 진행되기 때문에 지금의 모습은 최종 결과라기보다 안정적으로 회복되고 있는 중간 단계에 가깝습니다. 이 시점에서 결과를 지나치게 엄격하게 평가하면 불필요한 불안만 커질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 의료진 허용 범위 내에서 가벼운 운동부터 시작
- 1·2주차 기록 사진과 비교해 변화 확인
- 피로 신호가 오면 휴식 우선

⚠ 권고사항

- 4주차에 결과를 단정
- 아직 불편하다는 이유로 실패로 연결

### 의료진 공통 안내

턱·윤곽·양악 수술의 회복은 속도가 아니라 순서입니다. 지금 주차에 맞는 관리만 유지하고 있다면 결과는 대부분 그 다음 단계에서 자연스럽게 따라옵니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "턱",
            "윤곽",
            "양악",
            "V라인",
            "사각턱",
            "턱끝",
            "하악",
            "상악"
        ]
    }
];
function findRecoveryGuideByKeyword(keyword) {
    const normalizedKeyword = keyword.toLowerCase().trim();
    for (const post of recoveryGuidePosts){
        // 시술명 직접 매칭
        if (post.procedureName.toLowerCase().includes(normalizedKeyword)) {
            return post;
        }
        // 키워드 매칭
        if (post.keywords.some((k)=>k.toLowerCase().includes(normalizedKeyword)) || post.keywords.some((k)=>normalizedKeyword.includes(k.toLowerCase()))) {
            return post;
        }
    }
    return null;
}
function findRecoveryGuideById(id) {
    return recoveryGuidePosts.find((post)=>post.id === id) || null;
}
function getAllRecoveryGuides() {
    return recoveryGuidePosts;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/InformationalContentSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InformationalContentSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuidePosts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/content/recoveryGuidePosts.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
// 정보성 컨텐츠 데이터 (임시 - 추후 API 연동)
const informationalContents = [
    {
        id: 4,
        title: "통역 서비스 이용 가이드",
        description: "한국어가 서툰 외국인을 위한 통역 서비스 안내",
        category: "정보",
        readTime: "4분",
        views: 1567
    }
];
function InformationalContentSection() {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [selectedCategory, setSelectedCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    // 회복 가이드 글 가져오기
    const recoveryGuidePosts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuidePosts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllRecoveryGuides"])();
    // 회복 가이드를 ContentItem 형식으로 변환
    const recoveryGuideItems = recoveryGuidePosts.map((post)=>({
            id: post.id,
            title: post.title,
            description: post.description,
            category: post.category,
            readTime: post.readTime,
            views: post.views || 0,
            thumbnail: post.thumbnail,
            slug: post.id
        }));
    // 모든 컨텐츠 합치기 (정보 + 회복 가이드)
    const allContents = [
        ...informationalContents,
        ...recoveryGuideItems
    ];
    const categories = [
        "all",
        "가이드",
        "정보",
        "회복 가이드🍀"
    ];
    const filteredContents = selectedCategory === "all" ? allContents : selectedCategory === "회복 가이드🍀" ? allContents.filter((item)=>item.category === "회복 가이드") : allContents.filter((item)=>item.category === selectedCategory);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-6 pt-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4 mb-4",
                children: categories.map((category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setSelectedCategory(category),
                        className: `px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${selectedCategory === category ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                        children: category === "all" ? "전체" : category
                    }, category, false, {
                        fileName: "[project]/components/InformationalContentSection.tsx",
                        lineNumber: 75,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/InformationalContentSection.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: filteredContents.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center py-8 text-gray-500 text-sm",
                    children: selectedCategory === "회복 가이드🍀" || selectedCategory === "회복 가이드" ? "회복 가이드 글이 준비 중입니다." : "컨텐츠가 없습니다."
                }, void 0, false, {
                    fileName: "[project]/components/InformationalContentSection.tsx",
                    lineNumber: 92,
                    columnNumber: 11
                }, this) : filteredContents.map((content)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            // 회복 가이드인 경우 상세 페이지로 이동
                            if (content.category === "회복 가이드" && content.slug) {
                                router.push(`/community/recovery-guide/${content.slug}`);
                            } else {
                                // 다른 컨텐츠는 추후 구현
                                console.log("Navigate to:", content.id);
                            }
                        },
                        className: "w-full bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-all text-left",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-start gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-shrink-0 w-20 h-20 bg-gradient-to-br from-primary-light/20 to-primary-main/30 rounded-lg overflow-hidden",
                                    children: content.thumbnail ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: content.thumbnail,
                                        alt: content.title,
                                        className: "w-full h-full object-cover"
                                    }, void 0, false, {
                                        fileName: "[project]/components/InformationalContentSection.tsx",
                                        lineNumber: 116,
                                        columnNumber: 21
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-full h-full flex items-center justify-center",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiBook"], {
                                            className: "text-primary-main text-2xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 123,
                                            columnNumber: 23
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/InformationalContentSection.tsx",
                                        lineNumber: 122,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                    lineNumber: 114,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 min-w-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2 mb-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs bg-primary-light/20 text-primary-main px-2 py-0.5 rounded-full font-medium",
                                                    children: content.category
                                                }, void 0, false, {
                                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                                    lineNumber: 131,
                                                    columnNumber: 21
                                                }, this),
                                                content.readTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs text-gray-500",
                                                    children: [
                                                        content.readTime,
                                                        " 읽기"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                                    lineNumber: 135,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 130,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                            className: "font-semibold text-gray-900 mb-1 text-sm line-clamp-2",
                                            children: content.title
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 140,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-600 line-clamp-1 mb-2",
                                            children: content.description
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 143,
                                            columnNumber: 19
                                        }, this),
                                        content.views && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-3 text-xs text-gray-400",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: [
                                                    "조회 ",
                                                    content.views.toLocaleString()
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/InformationalContentSection.tsx",
                                                lineNumber: 148,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 147,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                    lineNumber: 129,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-shrink-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                                        className: "text-gray-400"
                                    }, void 0, false, {
                                        fileName: "[project]/components/InformationalContentSection.tsx",
                                        lineNumber: 155,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                    lineNumber: 154,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/InformationalContentSection.tsx",
                            lineNumber: 112,
                            columnNumber: 15
                        }, this)
                    }, content.id, false, {
                        fileName: "[project]/components/InformationalContentSection.tsx",
                        lineNumber: 99,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/InformationalContentSection.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/InformationalContentSection.tsx",
        lineNumber: 71,
        columnNumber: 5
    }, this);
}
_s(InformationalContentSection, "w4mrPfbRNTB+0PtKmqTkKSrAEjI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = InformationalContentSection;
var _c;
__turbopack_context__.k.register(_c, "InformationalContentSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ConsultationPage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConsultationPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PostList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/PostList.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
// 고민상담소 카테고리 7가지
const CONCERN_CATEGORIES = [
    {
        id: null,
        label: "전체"
    },
    {
        id: "피부 고민",
        label: "피부 고민"
    },
    {
        id: "시술 고민",
        label: "시술 고민"
    },
    {
        id: "병원 선택",
        label: "병원 선택"
    },
    {
        id: "가격 문의",
        label: "가격 문의"
    },
    {
        id: "회복 기간",
        label: "회복 기간"
    },
    {
        id: "부작용",
        label: "부작용"
    },
    {
        id: "기타",
        label: "기타"
    }
];
function ConsultationPage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [selectedCategory, setSelectedCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleCategoryClick = (categoryId)=>{
        setSelectedCategory(categoryId);
    // 카테고리 선택 시 해당 카테고리 게시글만 보이도록 필터링
    // PostList에 concernCategory prop을 전달하여 필터링
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "px-4 py-3 space-y-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2 overflow-x-auto scrollbar-hide pb-2",
                    children: CONCERN_CATEGORIES.map((category)=>{
                        const isActive = selectedCategory === category.id;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>handleCategoryClick(category.id),
                            className: `flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${isActive ? "bg-primary-main text-white shadow-sm" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                            children: category.label
                        }, category.id || "all", false, {
                            fileName: "[project]/components/ConsultationPage.tsx",
                            lineNumber: 37,
                            columnNumber: 15
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/components/ConsultationPage.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ConsultationPage.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PostList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                activeTab: "consultation",
                concernCategory: selectedCategory
            }, void 0, false, {
                fileName: "[project]/components/ConsultationPage.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ConsultationPage.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
_s(ConsultationPage, "OeFPkWDdlwIZuoEML0/sGhS/NGc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = ConsultationPage;
var _c;
__turbopack_context__.k.register(_c, "ConsultationPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/CommunityPage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommunityPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Header.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/BottomNavigation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CommunityHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PostList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/PostList.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityFloatingButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CommunityFloatingButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InformationalContentSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/InformationalContentSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ConsultationPage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ConsultationPage.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function CommunityPage() {
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("popular");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CommunityPage.useEffect": ()=>{
            const tab = searchParams.get("tab");
            if (tab && [
                "popular",
                "latest",
                "info",
                "consultation"
            ].includes(tab)) {
                setActiveTab(tab);
                // 탭 변경 시 상단으로 스크롤
                window.scrollTo({
                    top: 0,
                    behavior: "smooth"
                });
            }
        }
    }["CommunityPage.useEffect"], [
        searchParams
    ]);
    const handleTabChange = (tab)=>{
        setActiveTab(tab);
        // 탭 변경 시 상단으로 스크롤
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white max-w-md mx-auto w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/CommunityPage.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                activeTab: activeTab,
                onTabChange: handleTabChange
            }, void 0, false, {
                fileName: "[project]/components/CommunityPage.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-1",
                children: activeTab === "popular" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PostList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    activeTab: "popular"
                }, void 0, false, {
                    fileName: "[project]/components/CommunityPage.tsx",
                    lineNumber: 46,
                    columnNumber: 11
                }, this) : activeTab === "latest" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PostList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    activeTab: "latest"
                }, void 0, false, {
                    fileName: "[project]/components/CommunityPage.tsx",
                    lineNumber: 48,
                    columnNumber: 11
                }, this) : activeTab === "info" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InformationalContentSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/components/CommunityPage.tsx",
                        lineNumber: 51,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/CommunityPage.tsx",
                    lineNumber: 50,
                    columnNumber: 11
                }, this) : activeTab === "consultation" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ConsultationPage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/components/CommunityPage.tsx",
                    lineNumber: 54,
                    columnNumber: 11
                }, this) : null
            }, void 0, false, {
                fileName: "[project]/components/CommunityPage.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pb-20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/components/CommunityPage.tsx",
                    lineNumber: 59,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/CommunityPage.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityFloatingButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/CommunityPage.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/CommunityPage.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_s(CommunityPage, "ou0zshv2jFNJJWv9rqbsnif7lGA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = CommunityPage;
var _c;
__turbopack_context__.k.register(_c, "CommunityPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/community/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Community
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityPage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CommunityPage.tsx [app-client] (ecmascript)");
'use client';
;
;
;
function Community() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-white flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-gray-500",
                children: "로딩 중..."
            }, void 0, false, {
                fileName: "[project]/app/community/page.tsx",
                lineNumber: 10,
                columnNumber: 9
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/app/community/page.tsx",
            lineNumber: 9,
            columnNumber: 7
        }, void 0),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityPage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/app/community/page.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/community/page.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
_c = Community;
var _c;
__turbopack_context__.k.register(_c, "Community");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_6ad999fe._.js.map