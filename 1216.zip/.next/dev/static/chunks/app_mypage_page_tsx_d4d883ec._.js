(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/lib_supabase_ts_e7ce2ba2._.js",
  "static/chunks/_bc35b3cc._.js",
  "static/chunks/node_modules_next_99e9ab92._.js",
  "static/chunks/node_modules_react-icons_fi_index_esm_00274d2f.js",
  "static/chunks/node_modules_react-icons_bs_index_esm_f37a2151.js",
  "static/chunks/node_modules_react-icons_io5_index_esm_e1ec9d20.js",
  "static/chunks/node_modules_react-icons_lib_esm_fa2222d7._.js"
],
    source: "dynamic"
});
