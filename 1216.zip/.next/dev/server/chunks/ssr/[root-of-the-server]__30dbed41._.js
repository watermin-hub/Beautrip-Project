module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/contexts/LanguageContext.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LanguageProvider",
    ()=>LanguageProvider,
    "useLanguage",
    ()=>useLanguage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const LanguageContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
// 번역 데이터
const translations = {
    KR: {
        // Header
        "header.search": "검색",
        "header.notifications": "알림",
        // Navigation
        "nav.home": "홈",
        "nav.explore": "탐색",
        "nav.community": "커뮤니티",
        "nav.nearby": "주변",
        "nav.schedule": "내 일정",
        "nav.mypage": "마이페이지",
        // Common
        "common.back": "뒤로",
        "common.close": "닫기",
        "common.confirm": "확인",
        "common.cancel": "취소",
        "common.save": "저장",
        "common.delete": "삭제",
        // Favorites
        "favorites.title": "찜 목록",
        "favorites.subtitle": "찜한 시술 및 병원",
        "favorites.empty": "찜한 항목이 없습니다",
        "favorites.emptyDesc": "시술이나 병원에 하트를 눌러 저장해보세요",
        // Cart
        "cart.title": "장바구니",
        "cart.empty": "장바구니가 비어있습니다",
        "cart.emptyDesc": "시술을 장바구니에 추가해보세요",
        // Travel Schedule
        "travel.title": "여행 일정 입력",
        "travel.period": "여행 기간",
        "travel.region": "여행 지역",
        "travel.category": "시술 카테고리",
        "travel.budget": "추정 예산",
        "travel.search": "일정 기반 시술 추천",
        // Explore
        "explore.title": "탐색",
        "explore.schedule": "여행 일정",
        "explore.ranking": "랭킹",
        "explore.theme": "테마",
        "explore.quote": "견적받기",
        // Community
        "community.title": "커뮤니티",
        "community.categories": "카테고리",
        "community.recommended": "추천글",
        "community.latest": "최신글",
        "community.popular": "인기글",
        "community.review": "후기",
        "community.write": "글쓰기",
        // MyPage
        "mypage.title": "마이페이지",
        "mypage.activity": "활동·저장내역",
        "mypage.reservations": "내 예약·결제 내역",
        "mypage.favorites": "찜 목록",
        "mypage.benefits": "혜택",
        "mypage.reviews": "후기",
        "mypage.notifications": "알림",
        // Banners
        "banner.ai.brand": "AI 피부연구소",
        "banner.ai.headline": "피부연구소 OPEN",
        "banner.ai.subheadline": "내 진짜 얼굴나이는?",
        "banner.ai.description": "셀피만 찍으면 1,000P",
        "banner.ai.title": "AI 피부 분석",
        "banner.ai.desc": "첨단 AI가 피부 수분, 탄력, 트러블 등 핵심 지표를 분석해 나만의 피부 타입을 정밀하게 진단합니다.",
        "banner.ai.start": "AI 피부분석 시작",
        "banner.ai.reviews": "유사 후기 보기",
        "banner.kbeauty.brand": "K-Beauty Special",
        "banner.kbeauty.headline": "여름 특가 이벤트!",
        "banner.kbeauty.subheadline": "최대 50% 할인",
        "banner.kbeauty.description": "인기 시술 패키지 특별 할인",
        "banner.premium.brand": "Premium Clinic",
        "banner.premium.headline": "신규 오픈 기념",
        "banner.premium.subheadline": "첫 시술 30% 할인",
        "banner.premium.description": "강남 신규 오픈 클리닉 특별 혜택",
        "banner.summer.brand": "Summer Beauty",
        "banner.summer.headline": "여름 준비 완료!",
        "banner.summer.subheadline": "피부 관리 패키지",
        "banner.summer.description": "시원한 여름을 위한 특별 케어",
        "banner.vip.brand": "VIP Membership",
        "banner.vip.headline": "VIP 멤버십 가입",
        "banner.vip.subheadline": "추가 혜택 받기",
        "banner.vip.description": "멤버십 가입 시 추가 포인트 지급",
        "banner.weekend.brand": "Weekend Special",
        "banner.weekend.headline": "주말 특별 이벤트",
        "banner.weekend.subheadline": "주말 예약 시 할인",
        "banner.weekend.description": "주말 예약 고객 특별 혜택",
        "banner.ranking.title": "실시간 인기 검색어",
        // Home Page
        "home.selectSchedule": "여행 일정을 선택해 주세요.",
        "home.selectScheduleFirst": "여행 시작일과 종료일을 먼저 선택하면 카테고리를 고를 수 있어요.",
        "home.reviewButton": "리뷰 쓰고 더 많은 정보 얻기",
        "home.reviewAlert": "리뷰 작성 기능은 추후 구현 예정입니다.",
        "home.category.skin": "피부관리",
        "home.category.scar": "흉터/자국",
        "home.category.slim": "윤곽/리프팅",
        "home.category.nose": "코성형",
        "home.category.eyes": "눈성형",
        "home.category.inject": "보톡스/필러",
        "home.category.body": "체형/지방",
        "home.category.other": "기타",
        "calendar.title": "여행 일정 선택",
        "calendar.startDate": "시작일",
        "calendar.endDate": "종료일",
        "calendar.notSelected": "선택 안 함",
        "calendar.selectCategory": "카테고리 선택",
        "calendar.selectEndDate": "종료일을 선택해주세요",
        "procedure.filter": "필터",
        "procedure.customRecommendations": "맞춤 시술 추천",
        "procedure.travelInfo": "여행 일정 정보",
        "procedure.travelPeriod": "여행 기간",
        "procedure.selectedCategory": "선택 카테고리",
        "procedure.estimatedBudget": "예정 예산",
        "procedure.avgTime": "평균 시술시간",
        "procedure.recoveryPeriod": "회복기간",
        "procedure.procedureTime": "분",
        "procedure.recoveryDays": "일",
        "procedure.matchingHospital": "맞춤 병원정보",
        "procedure.viewHospitalInfo": "병원 상세정보 보기",
        "procedure.loading": "추천 시술을 불러오는 중...",
        "procedure.error": "추천 시술을 불러오는 데 실패했습니다.",
        "procedure.noResults": "선택하신 여행 기간과 카테고리에 맞는 시술을 찾을 수 없습니다. 일정을 조정하거나 다른 카테고리를 선택해보세요.",
        "procedure.hospitalRecommendation": "입력하신 정보를 기반으로 최적의 병원을 추천해드립니다.",
        "home.hotConcerns": "인기 시술",
        "home.seeMore": "더보기",
        "home.seeLess": "접기",
        "home.trendingReviews": "지금 뜨는 리뷰",
        "home.trendingBeforeAfter": "인기 급상승 비포&애프터 리뷰",
        "home.reviewMore": "후기 더 보러가기",
        "home.more": "더 보기",
        "home.mission": "미션",
        "home.missionViewAll": "전체보기",
        "home.mission.attendance": "출석 체크",
        "home.mission.attendanceDesc": "연속 7일 출석",
        "home.mission.review": "리뷰 작성",
        "home.mission.reviewDesc": "후기 1개 작성",
        "home.mission.invite": "친구 초대",
        "home.mission.inviteDesc": "친구 3명 초대",
        "home.mission.reward": "보상",
        "home.mission.participate": "참여하기",
        "home.mission.points": "포인트",
        "home.mission.coupon": "쿠폰",
        "home.countrySearch": "국가별 인기 검색어",
        "home.country.all": "전체",
        "home.country.korea": "한국",
        "home.country.china": "중국",
        "home.country.japan": "일본",
        "home.country.usa": "미국",
        "home.country.sea": "동남아",
        "calendar.mySchedule": "내 일정",
        "calendar.noSchedule": "예정된 일정이 없습니다",
        "calendar.viewAll": "전체보기",
        "calendar.today": "오늘",
        "calendar.consultation": "상담",
        "calendar.procedure": "시술",
        "dday.title": "D-Day",
        "dday.daysUntil": "시술까지",
        "community.warmCommunity": "함께 만드는 따뜻한 커뮤니티",
        "community.warmCommunityDesc": "서로를 존중하고 배려하는 마음으로 소통해요. 여러분의 경험이 누군가에게 큰 도움이 됩니다",
        "community.section.recommended": "추천 게시글",
        "community.section.popular": "최근 인기 게시글",
        "community.section.recovery": "수술 회복 수다",
        "community.section.questions": "수술 질문하기",
        "community.section.skinConcerns": "피부 질환별 고민글",
        "community.section.travel": "여행일정 공유",
        "community.section.recoveryGuide": "회복 가이드",
        "community.item.byCategory": "카테고리별 인기글",
        "community.item.photoReview": "(시술, 수술) 카테고리별 포토 & 후기",
        "community.item.surgeryDone": "수술했어요",
        "community.item.recoveryChat": "수술 회복 수다",
        "community.item.askSurgery": "수술 질문하기",
        "community.item.skinDiseases": "피부 질환별 고민글",
        "community.item.popularItinerary": "시술별 인기 여행일정",
        "community.item.askItinerary": "여행일정 질문하기",
        "community.hospitalInfo": "병원정보 이동",
        "community.storySharing": "여러분의 이야기를 들려주세요",
        "community.storySharingDesc": "후기를 공유하면 다른 분들에게 큰 도움이 됩니다",
        "community.photoReviewWrite": "포토 후기 작성",
        "community.writePost": "글 작성하기",
        "community.noItems": "등록된 항목이 없습니다.",
        "explore.section.ranking": "카테고리별 인기 랭킹",
        "explore.section.rankingDesc": "상위 10개 시술 랭킹",
        "explore.section.recommendation": "맞춤 추천",
        "explore.section.recommendationDesc": "일정과 고민에 맞는 시술 추천",
        "explore.section.procedure": "전체 시술•수술",
        "explore.section.procedureDesc": "다양한 시술을 만나보세요",
        "explore.section.hospital": "전체 병원",
        "explore.section.hospitalDesc": "다양한 병원을 만나보세요",
        "explore.ranking.category": "카테고리별",
        "explore.ranking.kbeauty": "K-beauty",
        "explore.ranking.hospital": "추천 병원",
        // Recovery guide page
        "recovery.headerTitle": "시술별 회복기간과 주의사항",
        "recovery.headerSubtitle": "각 시술의 회복 기간과 회복 과정을 상세히 안내합니다.",
        "recovery.selectTitle": "보고 싶은 정보를 선택하세요.",
        "recovery.selectSubtitle": "각 카드는 회복 패턴이 비슷한 시술·수술들을 한데 모은 그룹입니다.🍀",
        "recovery.currentGroup": "지금 선택한 그룹",
        "recovery.week.tipsTitle": "✔ 이 주차에 도움 되는 팁",
        "recovery.week.cautionsTitle": "⚠ 권고사항"
    },
    EN: {
        // Header
        "header.search": "Search",
        "header.notifications": "Notifications",
        // Navigation
        "nav.home": "Home",
        "nav.explore": "Explore",
        "nav.community": "Community",
        "nav.nearby": "Nearby",
        "nav.schedule": "Schedule",
        "nav.mypage": "My Page",
        // Common
        "common.back": "Back",
        "common.close": "Close",
        "common.confirm": "Confirm",
        "common.cancel": "Cancel",
        "common.save": "Save",
        "common.delete": "Delete",
        // Favorites
        "favorites.title": "Favorites",
        "favorites.subtitle": "Favorited Procedures and Clinics",
        "favorites.empty": "No favorites yet",
        "favorites.emptyDesc": "Tap the heart icon to save procedures or clinics",
        // Cart
        "cart.title": "Shopping Cart",
        "cart.empty": "Your cart is empty",
        "cart.emptyDesc": "Add procedures to your cart",
        // Travel Schedule
        "travel.title": "Travel Schedule",
        "travel.period": "Travel Period",
        "travel.region": "Travel Region",
        "travel.category": "Procedure Category",
        "travel.budget": "Estimated Budget",
        "travel.search": "Get Procedure Recommendations",
        // Explore
        "explore.title": "Explore",
        "explore.schedule": "Schedule",
        "explore.ranking": "Ranking",
        "explore.theme": "Theme",
        "explore.quote": "Get Quote",
        // Community
        "community.title": "Community",
        "community.categories": "Categories",
        "community.recommended": "Recommended",
        "community.latest": "Latest",
        "community.popular": "Popular",
        "community.review": "Reviews",
        "community.write": "Write",
        // MyPage
        "mypage.title": "My Page",
        "mypage.activity": "Activity & Saved",
        "mypage.reservations": "Reservations & Payments",
        "mypage.favorites": "Favorites",
        "mypage.benefits": "Benefits",
        "mypage.reviews": "Reviews",
        "mypage.notifications": "Notifications",
        // Banners
        "banner.ai.brand": "AI Skin Lab",
        "banner.ai.headline": "Skin Lab OPEN",
        "banner.ai.subheadline": "What's my real face age?",
        "banner.ai.description": "Get 1,000P just by taking a selfie",
        "banner.ai.title": "AI Skin Analysis",
        "banner.ai.desc": "Advanced AI analyzes key indicators such as skin moisture, elasticity, and trouble to precisely diagnose your unique skin type.",
        "banner.ai.start": "Start AI Skin Analysis",
        "banner.ai.reviews": "View Similar Reviews",
        "banner.kbeauty.brand": "K-Beauty Special",
        "banner.kbeauty.headline": "Summer Special Event!",
        "banner.kbeauty.subheadline": "Up to 50% Off",
        "banner.kbeauty.description": "Special discount on popular procedure packages",
        "banner.premium.brand": "Premium Clinic",
        "banner.premium.headline": "Grand Opening",
        "banner.premium.subheadline": "30% Off First Procedure",
        "banner.premium.description": "Special benefits for new Gangnam clinic opening",
        "banner.summer.brand": "Summer Beauty",
        "banner.summer.headline": "Summer Ready!",
        "banner.summer.subheadline": "Skin Care Package",
        "banner.summer.description": "Special care for a cool summer",
        "banner.vip.brand": "VIP Membership",
        "banner.vip.headline": "Join VIP Membership",
        "banner.vip.subheadline": "Get Additional Benefits",
        "banner.vip.description": "Extra points when you join membership",
        "banner.weekend.brand": "Weekend Special",
        "banner.weekend.headline": "Weekend Special Event",
        "banner.weekend.subheadline": "Discount on Weekend Appointments",
        "banner.weekend.description": "Special benefits for weekend appointment customers",
        "banner.ranking.title": "Real-time Popular Searches",
        // Home Page
        "home.selectSchedule": "Please select your travel schedule.",
        "home.selectScheduleFirst": "Please select travel start and end dates first to choose a category.",
        "home.reviewButton": "Write a Review & Get More Information",
        "home.reviewAlert": "Review writing feature will be implemented soon.",
        "home.category.skin": "Skin Care",
        "home.category.scar": "Scars/Marks",
        "home.category.slim": "Contouring/Lifting",
        "home.category.nose": "Nose Surgery",
        "home.category.eyes": "Eye Surgery",
        "home.category.inject": "Botox/Filler",
        "home.category.body": "Body/Fat",
        "home.category.other": "Other",
        "calendar.title": "Select Travel Schedule",
        "calendar.startDate": "Start Date",
        "calendar.endDate": "End Date",
        "calendar.notSelected": "Not Selected",
        "calendar.selectCategory": "Select Category",
        "calendar.selectEndDate": "Please select end date",
        "procedure.filter": "Filter",
        "procedure.customRecommendations": "Custom Procedure Recommendations",
        "procedure.travelInfo": "Travel Schedule Information",
        "procedure.travelPeriod": "Travel Period",
        "procedure.selectedCategory": "Selected Category",
        "procedure.estimatedBudget": "Estimated Budget",
        "procedure.avgTime": "Average Procedure Time",
        "procedure.recoveryPeriod": "Recovery Period",
        "procedure.procedureTime": "min",
        "procedure.recoveryDays": "days",
        "procedure.matchingHospital": "Matching Hospital Information",
        "procedure.viewHospitalInfo": "View Hospital Details",
        "procedure.loading": "Loading recommendations...",
        "procedure.error": "Failed to load recommendations.",
        "procedure.noResults": "No procedures found matching your travel period and category. Please adjust your schedule or try a different category.",
        "procedure.hospitalRecommendation": "We recommend the best hospital based on the information you provided.",
        "home.hotConcerns": "Hot Concerns & Procedure Recommendations",
        "home.seeMore": "See More",
        "home.seeLess": "See Less",
        "home.trendingReviews": "Trending Reviews",
        "home.trendingBeforeAfter": "Trending Before & After Reviews",
        "home.reviewMore": "See More Reviews",
        "home.more": "More",
        "home.mission": "Mission",
        "home.missionViewAll": "View All",
        "home.mission.attendance": "Attendance Check",
        "home.mission.attendanceDesc": "7 consecutive days",
        "home.mission.review": "Write Review",
        "home.mission.reviewDesc": "Write 1 review",
        "home.mission.invite": "Invite Friends",
        "home.mission.inviteDesc": "Invite 3 friends",
        "home.mission.reward": "Reward",
        "home.mission.participate": "Participate",
        "home.mission.points": "points",
        "home.mission.coupon": "coupon",
        "home.countrySearch": "Popular Search Terms by Country",
        "home.country.all": "All",
        "home.country.korea": "Korea",
        "home.country.china": "China",
        "home.country.japan": "Japan",
        "home.country.usa": "USA",
        "home.country.sea": "Southeast Asia",
        "calendar.mySchedule": "My Schedule",
        "calendar.noSchedule": "No scheduled events",
        "calendar.viewAll": "View All",
        "calendar.today": "Today",
        "calendar.consultation": "Consultation",
        "calendar.procedure": "Procedure",
        "dday.title": "D-Day",
        "dday.daysUntil": "days until procedure",
        "community.warmCommunity": "A Warm Community We Make Together",
        "community.warmCommunityDesc": "Let's communicate with respect and consideration for each other. Your experience is a great help to others",
        "community.section.recommended": "Recommended Posts",
        "community.section.popular": "Recently Popular Posts",
        "community.section.recovery": "Surgery Recovery Stories",
        "community.section.questions": "Ask About Surgery",
        "community.section.skinConcerns": "Skin Concern Posts by Condition",
        "community.section.travel": "Share Travel Itinerary",
        "community.section.recoveryGuide": "Recovery Guide",
        "community.item.byCategory": "Popular Posts by Category",
        "community.item.photoReview": "(Procedure/Surgery) Photo & Reviews by Category",
        "community.item.surgeryDone": "I Had Surgery",
        "community.item.recoveryChat": "Surgery Recovery Stories",
        "community.item.askSurgery": "Ask About Surgery",
        "community.item.skinDiseases": "Skin Concern Posts by Condition",
        "community.item.popularItinerary": "Popular Travel Itineraries by Procedure",
        "community.item.askItinerary": "Ask About Travel Itinerary",
        "community.hospitalInfo": "Hospital Info",
        "community.storySharing": "Share Your Story",
        "community.storySharingDesc": "Sharing reviews helps others a lot",
        "community.photoReviewWrite": "Write Photo Review",
        "community.writePost": "Write Post",
        "community.noItems": "No items registered.",
        "explore.section.ranking": "Popular Rankings by Category",
        "explore.section.rankingDesc": "Top 10 Procedure Rankings",
        "explore.section.recommendation": "Custom Recommendations",
        "explore.section.recommendationDesc": "Procedures matched to your schedule and concerns",
        "explore.section.procedure": "Procedure List",
        "explore.section.procedureDesc": "Top 10 Popular Procedures",
        "explore.section.hospital": "Hospital List",
        "explore.section.hospitalDesc": "Top 10 Popular Hospitals",
        "explore.ranking.category": "By Category",
        "explore.ranking.kbeauty": "K-beauty",
        "explore.ranking.hospital": "Recommended Hospitals",
        // Recovery guide page
        "recovery.headerTitle": "Recovery Timeline and Precautions by Procedure",
        "recovery.headerSubtitle": "A detailed guide to the recovery period and process for each procedure.",
        "recovery.selectTitle": "Choose the information you want to see.",
        "recovery.selectSubtitle": "Each card groups together procedures and surgeries with similar recovery patterns.🍀",
        "recovery.currentGroup": "Currently selected group",
        "recovery.week.tipsTitle": "✔ Tips that help in this week",
        "recovery.week.cautionsTitle": "⚠ What to be careful about"
    },
    JP: {
        // Header
        "header.search": "検索",
        "header.notifications": "通知",
        // Navigation
        "nav.home": "ホーム",
        "nav.explore": "探す",
        "nav.community": "コミュニティ",
        "nav.nearby": "近く",
        "nav.schedule": "スケジュール",
        "nav.mypage": "マイページ",
        // Common
        "common.back": "戻る",
        "common.close": "閉じる",
        "common.confirm": "確認",
        "common.cancel": "キャンセル",
        "common.save": "保存",
        "common.delete": "削除",
        // Favorites
        "favorites.title": "お気に入り",
        "favorites.subtitle": "お気に入りの施術とクリニック",
        "favorites.empty": "お気に入りがありません",
        "favorites.emptyDesc": "ハートアイコンをタップして施術やクリニックを保存してください",
        // Cart
        "cart.title": "ショッピングカート",
        "cart.empty": "カートが空です",
        "cart.emptyDesc": "施術をカートに追加してください",
        // Travel Schedule
        "travel.title": "旅行スケジュール",
        "travel.period": "旅行期間",
        "travel.region": "旅行地域",
        "travel.category": "施術カテゴリー",
        "travel.budget": "予算",
        "travel.search": "スケジュールに基づく施術推奨",
        // Explore
        "explore.title": "探す",
        "explore.schedule": "スケジュール",
        "explore.ranking": "ランキング",
        "explore.theme": "テーマ",
        "explore.quote": "見積もり",
        // Community
        "community.title": "コミュニティ",
        "community.categories": "カテゴリー",
        "community.recommended": "おすすめ",
        "community.latest": "最新",
        "community.popular": "人気",
        "community.review": "レビュー",
        "community.write": "書く",
        // MyPage
        "mypage.title": "マイページ",
        "mypage.activity": "アクティビティ・保存",
        "mypage.reservations": "予約・支払い履歴",
        "mypage.favorites": "お気に入り",
        "mypage.benefits": "特典",
        "mypage.reviews": "レビュー",
        "mypage.notifications": "通知",
        // Banners
        "banner.ai.brand": "AI肌研究所",
        "banner.ai.headline": "肌研究所OPEN",
        "banner.ai.subheadline": "私の本当の顔年齢は？",
        "banner.ai.description": "セルフィーを撮るだけで1,000P",
        "banner.ai.title": "AI肌分析",
        "banner.ai.desc": "最先端AIが肌の水分、弾力、トラブルなどの主要指標を分析し、あなただけの肌タイプを精密に診断します。",
        "banner.ai.start": "AI肌分析開始",
        "banner.ai.reviews": "類似レビューを見る",
        "banner.kbeauty.brand": "K-Beauty Special",
        "banner.kbeauty.headline": "夏の特別イベント！",
        "banner.kbeauty.subheadline": "最大50%オフ",
        "banner.kbeauty.description": "人気施術パッケージ特別割引",
        "banner.premium.brand": "Premium Clinic",
        "banner.premium.headline": "新規オープン記念",
        "banner.premium.subheadline": "初回施術30%オフ",
        "banner.premium.description": "江南新規オープンクリニック特別特典",
        "banner.summer.brand": "Summer Beauty",
        "banner.summer.headline": "夏の準備完了！",
        "banner.summer.subheadline": "スキンケアパッケージ",
        "banner.summer.description": "涼しい夏のための特別ケア",
        "banner.vip.brand": "VIP Membership",
        "banner.vip.headline": "VIPメンバーシップ登録",
        "banner.vip.subheadline": "追加特典を受け取る",
        "banner.vip.description": "メンバーシップ登録時追加ポイント付与",
        "banner.weekend.brand": "Weekend Special",
        "banner.weekend.headline": "週末特別イベント",
        "banner.weekend.subheadline": "週末予約時割引",
        "banner.weekend.description": "週末予約のお客様特別特典",
        "banner.ranking.title": "リアルタイム人気検索語",
        // Home Page
        "home.selectSchedule": "旅行日程を選択してください。",
        "home.selectScheduleFirst": "旅行の開始日と終了日を先に選択すると、カテゴリを選択できます。",
        "home.reviewButton": "レビューを書いてより多くの情報を取得",
        "home.reviewAlert": "レビュー作成機能は今後実装予定です。",
        "home.category.skin": "スキンケア",
        "home.category.scar": "傷跡/跡",
        "home.category.slim": "輪郭/リフト",
        "home.category.nose": "鼻整形",
        "home.category.eyes": "目の整形",
        "home.category.inject": "ボトックス/フィラー",
        "home.category.body": "体型/脂肪",
        "home.category.other": "その他",
        "calendar.title": "旅行日程を選択",
        "calendar.startDate": "開始日",
        "calendar.endDate": "終了日",
        "calendar.notSelected": "選択なし",
        "calendar.selectCategory": "カテゴリを選択",
        "calendar.selectEndDate": "終了日を選択してください",
        "procedure.filter": "フィルター",
        "procedure.customRecommendations": "カスタム施術推奨",
        "procedure.travelInfo": "旅行日程情報",
        "procedure.travelPeriod": "旅行期間",
        "procedure.selectedCategory": "選択カテゴリ",
        "procedure.estimatedBudget": "予定予算",
        "procedure.avgTime": "平均施術時間",
        "procedure.recoveryPeriod": "回復期間",
        "procedure.procedureTime": "分",
        "procedure.recoveryDays": "日",
        "procedure.matchingHospital": "マッチング病院情報",
        "procedure.viewHospitalInfo": "病院詳細情報を見る",
        "procedure.loading": "推奨施術を読み込んでいます...",
        "procedure.error": "推奨施術の読み込みに失敗しました。",
        "procedure.noResults": "選択した旅行期間とカテゴリに一致する施術が見つかりません。日程を調整するか、別のカテゴリを選択してください。",
        "procedure.hospitalRecommendation": "入力された情報に基づいて最適な病院を推奨します。",
        "home.hotConcerns": "人気の悩み & 施術推奨",
        "home.seeMore": "もっと見る",
        "home.seeLess": "折りたたむ",
        "home.trendingReviews": "今話題のレビュー",
        "home.trendingBeforeAfter": "人気急上昇のビフォー&アフターレビュー",
        "home.reviewMore": "レビューをもっと見る",
        "home.more": "もっと見る",
        "home.mission": "ミッション",
        "home.missionViewAll": "すべて見る",
        "home.mission.attendance": "出席チェック",
        "home.mission.attendanceDesc": "連続7日出席",
        "home.mission.review": "レビュー作成",
        "home.mission.reviewDesc": "レビュー1件作成",
        "home.mission.invite": "友達招待",
        "home.mission.inviteDesc": "友達3人招待",
        "home.mission.reward": "報酬",
        "home.mission.participate": "参加する",
        "home.mission.points": "ポイント",
        "home.mission.coupon": "クーポン",
        "home.countrySearch": "国別人気検索語",
        "home.country.all": "すべて",
        "home.country.korea": "韓国",
        "home.country.china": "中国",
        "home.country.japan": "日本",
        "home.country.usa": "米国",
        "home.country.sea": "東南アジア",
        "calendar.mySchedule": "私のスケジュール",
        "calendar.noSchedule": "予定されたスケジュールがありません",
        "calendar.viewAll": "すべて見る",
        "calendar.today": "今日",
        "calendar.consultation": "相談",
        "calendar.procedure": "施術",
        "dday.title": "D-Day",
        "dday.daysUntil": "施術まで",
        "community.warmCommunity": "一緒に作る温かいコミュニティ",
        "community.warmCommunityDesc": "お互いを尊重し、思いやりの心でコミュニケーションしましょう。あなたの経験が誰かの大きな助けになります",
        "community.section.recommended": "おすすめの投稿",
        "community.section.popular": "最近人気の投稿",
        "community.section.recovery": "手術回復の話",
        "community.section.questions": "手術について質問",
        "community.section.skinConcerns": "皮膚疾患別の悩みの投稿",
        "community.section.travel": "旅行日程の共有",
        "community.section.recoveryGuide": "回復ガイド",
        "community.item.byCategory": "カテゴリ別人気投稿",
        "community.item.photoReview": "(施術、手術) カテゴリ別フォト & レビュー",
        "community.item.surgeryDone": "手術を受けました",
        "community.item.recoveryChat": "手術回復の話",
        "community.item.askSurgery": "手術について質問",
        "community.item.skinDiseases": "皮膚疾患別の悩みの投稿",
        "community.item.popularItinerary": "施術別人気旅行日程",
        "community.item.askItinerary": "旅行日程について質問",
        "community.hospitalInfo": "病院情報へ",
        "community.storySharing": "あなたの話を聞かせてください",
        "community.storySharingDesc": "レビューを共有すると他の方に大きな助けになります",
        "community.photoReviewWrite": "フォトレビュー作成",
        "community.writePost": "投稿作成",
        "community.noItems": "登録された項目がありません。",
        "explore.section.ranking": "カテゴリ別人気ランキング",
        "explore.section.rankingDesc": "上位10の施術ランキング",
        "explore.section.recommendation": "カスタム推奨",
        "explore.section.recommendationDesc": "日程と悩みに合った施術推奨",
        "explore.section.procedure": "施術リスト",
        "explore.section.procedureDesc": "上位10の人気施術",
        "explore.section.hospital": "病院リスト",
        "explore.section.hospitalDesc": "上位10の人気病院",
        "explore.ranking.category": "カテゴリ別",
        "explore.ranking.kbeauty": "K-beauty",
        "explore.ranking.hospital": "おすすめ病院",
        // Recovery guide page
        "recovery.headerTitle": "施術別 回復期間と注意事項",
        "recovery.headerSubtitle": "各施術の回復期間と回復プロセスを分かりやすく案内します。",
        "recovery.selectTitle": "見たい情報を選んでください。",
        "recovery.selectSubtitle": "各カードは、回復パターンが似ている施術・手術をまとめたグループです。🍀",
        "recovery.currentGroup": "現在選択中のグループ",
        "recovery.week.tipsTitle": "✔ この週に役立つポイント",
        "recovery.week.cautionsTitle": "⚠ 注意してほしいこと"
    },
    CN: {
        // Header
        "header.search": "搜索",
        "header.notifications": "通知",
        // Navigation
        "nav.home": "首页",
        "nav.explore": "探索",
        "nav.community": "社区",
        "nav.nearby": "附近",
        "nav.schedule": "日程",
        "nav.mypage": "我的",
        // Common
        "common.back": "返回",
        "common.close": "关闭",
        "common.confirm": "确认",
        "common.cancel": "取消",
        "common.save": "保存",
        "common.delete": "删除",
        // Favorites
        "favorites.title": "收藏",
        "favorites.subtitle": "收藏的疗程和诊所",
        "favorites.empty": "暂无收藏",
        "favorites.emptyDesc": "点击心形图标保存疗程或诊所",
        // Cart
        "cart.title": "购物车",
        "cart.empty": "购物车为空",
        "cart.emptyDesc": "将疗程添加到购物车",
        // Travel Schedule
        "travel.title": "旅行日程",
        "travel.period": "旅行期间",
        "travel.region": "旅行地区",
        "travel.category": "疗程类别",
        "travel.budget": "预算",
        "travel.search": "基于日程的疗程推荐",
        // Explore
        "explore.title": "探索",
        "explore.schedule": "日程",
        "explore.ranking": "排名",
        "explore.theme": "主题",
        "explore.quote": "获取报价",
        // Community
        "community.title": "社区",
        "community.categories": "分类",
        "community.recommended": "推荐",
        "community.latest": "最新",
        "community.popular": "热门",
        "community.review": "评论",
        "community.write": "写",
        // MyPage
        "mypage.title": "我的",
        "mypage.activity": "活动·保存",
        "mypage.reservations": "预约·支付记录",
        "mypage.favorites": "收藏",
        "mypage.benefits": "优惠",
        "mypage.reviews": "评论",
        "mypage.notifications": "通知",
        // Banners
        "banner.ai.brand": "AI皮肤研究所",
        "banner.ai.headline": "皮肤研究所OPEN",
        "banner.ai.subheadline": "我的真实年龄是？",
        "banner.ai.description": "只需自拍即可获得1,000P",
        "banner.ai.title": "AI皮肤分析",
        "banner.ai.desc": "先进AI分析皮肤水分、弹性、问题等关键指标，精确诊断您的专属皮肤类型。",
        "banner.ai.start": "开始AI皮肤分析",
        "banner.ai.reviews": "查看相似评论",
        "banner.kbeauty.brand": "K-Beauty Special",
        "banner.kbeauty.headline": "夏季特价活动！",
        "banner.kbeauty.subheadline": "最高50%折扣",
        "banner.kbeauty.description": "热门疗程套餐特别折扣",
        "banner.premium.brand": "Premium Clinic",
        "banner.premium.headline": "新店开业纪念",
        "banner.premium.subheadline": "首次疗程30%折扣",
        "banner.premium.description": "江南新开业诊所特别优惠",
        "banner.summer.brand": "Summer Beauty",
        "banner.summer.headline": "夏季准备完成！",
        "banner.summer.subheadline": "皮肤护理套餐",
        "banner.summer.description": "清凉夏季特别护理",
        "banner.vip.brand": "VIP Membership",
        "banner.vip.headline": "VIP会员注册",
        "banner.vip.subheadline": "获得额外优惠",
        "banner.vip.description": "注册会员时额外积分",
        "banner.weekend.brand": "Weekend Special",
        "banner.weekend.headline": "周末特别活动",
        "banner.weekend.subheadline": "周末预约折扣",
        "banner.weekend.description": "周末预约客户特别优惠",
        "banner.ranking.title": "实时热门搜索",
        // Home Page
        "home.selectSchedule": "请选择您的旅行日程。",
        "home.selectScheduleFirst": "请先选择旅行开始和结束日期，然后选择类别。",
        "home.reviewButton": "写评论并获得更多信息",
        "home.reviewAlert": "评论撰写功能将在稍后实现。",
        "home.category.skin": "皮肤护理",
        "home.category.scar": "疤痕/痕迹",
        "home.category.slim": "轮廓/提拉",
        "home.category.nose": "鼻部整形",
        "home.category.eyes": "眼部整形",
        "home.category.inject": "肉毒杆菌/填充剂",
        "home.category.body": "体型/脂肪",
        "home.category.other": "其他",
        "calendar.title": "选择旅行日程",
        "calendar.startDate": "开始日期",
        "calendar.endDate": "结束日期",
        "calendar.notSelected": "未选择",
        "calendar.selectCategory": "选择类别",
        "calendar.selectEndDate": "请选择结束日期",
        "procedure.filter": "筛选",
        "procedure.customRecommendations": "定制疗程推荐",
        "procedure.travelInfo": "旅行日程信息",
        "procedure.travelPeriod": "旅行期间",
        "procedure.selectedCategory": "选择的类别",
        "procedure.estimatedBudget": "预计预算",
        "procedure.avgTime": "平均疗程时间",
        "procedure.recoveryPeriod": "恢复期",
        "procedure.procedureTime": "分钟",
        "procedure.recoveryDays": "天",
        "procedure.matchingHospital": "匹配医院信息",
        "procedure.viewHospitalInfo": "查看医院详情",
        "procedure.loading": "正在加载推荐...",
        "procedure.error": "加载推荐失败。",
        "procedure.noResults": "找不到与您的旅行期间和类别匹配的疗程。请调整您的日程或尝试其他类别。",
        "procedure.hospitalRecommendation": "我们将根据您提供的信息推荐最佳医院。",
        "home.hotConcerns": "热门关注 & 疗程推荐",
        "home.seeMore": "查看更多",
        "home.seeLess": "收起",
        "home.trendingReviews": "热门评论",
        "home.trendingBeforeAfter": "热门前后对比评论",
        "home.reviewMore": "查看更多评论",
        "home.more": "更多",
        "home.mission": "任务",
        "home.missionViewAll": "查看全部",
        "home.mission.attendance": "签到",
        "home.mission.attendanceDesc": "连续7天签到",
        "home.mission.review": "写评论",
        "home.mission.reviewDesc": "写1条评论",
        "home.mission.invite": "邀请朋友",
        "home.mission.inviteDesc": "邀请3位朋友",
        "home.mission.reward": "奖励",
        "home.mission.participate": "参与",
        "home.mission.points": "积分",
        "home.mission.coupon": "优惠券",
        "home.countrySearch": "各国热门搜索词",
        "home.country.all": "全部",
        "home.country.korea": "韩国",
        "home.country.china": "中国",
        "home.country.japan": "日本",
        "home.country.usa": "美国",
        "home.country.sea": "东南亚",
        "calendar.mySchedule": "我的日程",
        "calendar.noSchedule": "没有预定日程",
        "calendar.viewAll": "查看全部",
        "calendar.today": "今天",
        "calendar.consultation": "咨询",
        "calendar.procedure": "疗程",
        "dday.title": "D-Day",
        "dday.daysUntil": "距离疗程",
        "community.warmCommunity": "共同创造的温暖社区",
        "community.warmCommunityDesc": "让我们以相互尊重和关怀的心沟通。您的经验对他人有很大帮助",
        "community.section.recommended": "推荐帖子",
        "community.section.popular": "最近热门帖子",
        "community.section.recovery": "手术恢复故事",
        "community.section.questions": "手术咨询",
        "community.section.skinConcerns": "按皮肤问题的困扰帖子",
        "community.section.travel": "分享旅行日程",
        "community.section.recoveryGuide": "恢复指南",
        "community.item.byCategory": "按类别热门帖子",
        "community.item.photoReview": "(疗程/手术) 按类别照片和评论",
        "community.item.surgeryDone": "我做了手术",
        "community.item.recoveryChat": "手术恢复故事",
        "community.item.askSurgery": "手术咨询",
        "community.item.skinDiseases": "按皮肤问题的困扰帖子",
        "community.item.popularItinerary": "按疗程热门旅行日程",
        "community.item.askItinerary": "旅行日程咨询",
        "community.hospitalInfo": "医院信息",
        "community.storySharing": "分享您的故事",
        "community.storySharingDesc": "分享评论对他人有很大帮助",
        "community.photoReviewWrite": "写照片评论",
        "community.writePost": "写帖子",
        "community.noItems": "没有注册的项目。",
        "explore.section.ranking": "按类别热门排名",
        "explore.section.rankingDesc": "前10个疗程排名",
        "explore.section.recommendation": "定制推荐",
        "explore.section.recommendationDesc": "匹配您日程和关注的疗程推荐",
        "explore.section.procedure": "疗程列表",
        "explore.section.procedureDesc": "前10个热门疗程",
        "explore.section.hospital": "医院列表",
        "explore.section.hospitalDesc": "前10个热门医院",
        "explore.ranking.category": "按类别",
        "explore.ranking.kbeauty": "K-beauty",
        "explore.ranking.hospital": "推荐医院",
        // Recovery guide page
        "recovery.headerTitle": "各疗程的恢复期与注意事项",
        "recovery.headerSubtitle": "为每一种疗程提供详细的恢复时间与恢复过程指引。",
        "recovery.selectTitle": "请选择想看的信息。",
        "recovery.selectSubtitle": "每张卡片汇集了恢复模式相似的手术和疗程。🍀",
        "recovery.currentGroup": "当前选择的分组",
        "recovery.week.tipsTitle": "✔ 本周有帮助的小贴士",
        "recovery.week.cautionsTitle": "⚠ 需要注意的事项"
    }
};
function LanguageProvider({ children }) {
    // 초기값은 항상 "KR"로 설정하여 서버/클라이언트 일치 보장
    const [language, setLanguageState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("KR");
    const [isMounted, setIsMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    // 클라이언트에서만 localStorage 읽기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setIsMounted(true);
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }, [
        language,
        isMounted
    ]);
    const setLanguage = (lang)=>{
        setLanguageState(lang);
    };
    const t = (key)=>{
        return translations[language][key] || key;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(LanguageContext.Provider, {
        value: {
            language,
            setLanguage,
            t
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/contexts/LanguageContext.tsx",
        lineNumber: 934,
        columnNumber: 5
    }, this);
}
function useLanguage() {
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(LanguageContext);
    if (context === undefined) {
        throw new Error("useLanguage must be used within a LanguageProvider");
    }
    return context;
}
}),
"[project]/lib/supabase.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$esm$2f$wrapper$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs [app-ssr] (ecmascript)");
;
// Supabase 클라이언트 생성
// 1순위: 환경 변수
// 2순위: 기존에 사용하던 하드코딩 값 (로컬/데모용 fallback)
const supabaseUrl = ("TURBOPACK compile-time value", "https://jkvwtdjkylzxjzvgbwud.supabase.co") || "https://jkvwtdjkylzxjzvgbwud.supabase.co";
const supabaseAnonKey = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imprdnd0ZGpreWx6eGp6dmdid3VkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU0NDMwNzgsImV4cCI6MjA4MTAxOTA3OH0.XdyU1XtDFY2Vauj_ddQ1mKqAjxjnNJts5pdW_Ob1TDI") || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imprdnd0ZGpreWx6eGp6dmdid3VkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU0NDMwNzgsImV4cCI6MjA4MTAxOTA3OH0.XdyU1XtDFY2Vauj_ddQ1mKqAjxjnNJts5pdW_Ob1TDI";
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$esm$2f$wrapper$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createClient"])(supabaseUrl, supabaseAnonKey);
}),
"[project]/lib/api/beautripApi.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Beautrip API 관련 유틸리티 함수
__turbopack_context__.s([
    "CATEGORY_MAPPING",
    ()=>CATEGORY_MAPPING,
    "calculateRecommendationScore",
    ()=>calculateRecommendationScore,
    "extractHospitalInfo",
    ()=>extractHospitalInfo,
    "getCategoryRankings",
    ()=>getCategoryRankings,
    "getHospitalAutocomplete",
    ()=>getHospitalAutocomplete,
    "getKBeautyRankings",
    ()=>getKBeautyRankings,
    "getRecoveryGuideIdByCategory",
    ()=>getRecoveryGuideIdByCategory,
    "getRecoveryInfoByCategoryMid",
    ()=>getRecoveryInfoByCategoryMid,
    "getScheduleBasedRecommendations",
    ()=>getScheduleBasedRecommendations,
    "getThumbnailUrl",
    ()=>getThumbnailUrl,
    "getTreatmentAutocomplete",
    ()=>getTreatmentAutocomplete,
    "getTreatmentRankings",
    ()=>getTreatmentRankings,
    "loadAllData",
    ()=>loadAllData,
    "loadCategoryToggleMap",
    ()=>loadCategoryToggleMap,
    "loadCategoryTreatTimeRecovery",
    ()=>loadCategoryTreatTimeRecovery,
    "loadConcernPosts",
    ()=>loadConcernPosts,
    "loadHospitalMaster",
    ()=>loadHospitalMaster,
    "loadHospitalReviews",
    ()=>loadHospitalReviews,
    "loadHospitalTreatments",
    ()=>loadHospitalTreatments,
    "loadHospitalsPaginated",
    ()=>loadHospitalsPaginated,
    "loadKeywordMonthlyTrends",
    ()=>loadKeywordMonthlyTrends,
    "loadProcedureReviews",
    ()=>loadProcedureReviews,
    "loadRelatedTreatments",
    ()=>loadRelatedTreatments,
    "loadTreatmentById",
    ()=>loadTreatmentById,
    "loadTreatments",
    ()=>loadTreatments,
    "loadTreatmentsPaginated",
    ()=>loadTreatmentsPaginated,
    "parseProcedureTime",
    ()=>parseProcedureTime,
    "parseRecoveryPeriod",
    ()=>parseRecoveryPeriod,
    "saveConcernPost",
    ()=>saveConcernPost,
    "saveHospitalReview",
    ()=>saveHospitalReview,
    "saveProcedureReview",
    ()=>saveProcedureReview,
    "sortHospitalsByPlatform",
    ()=>sortHospitalsByPlatform,
    "sortTreatmentsByPlatform",
    ()=>sortTreatmentsByPlatform
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-ssr] (ecmascript)");
;
// Supabase 테이블 이름
const TABLE_NAMES = {
    TREATMENT_MASTER: "treatment_master",
    CATEGORY_TREATTIME_RECOVERY: "category_treattime_recovery",
    HOSPITAL_MASTER: "hospital_master",
    KEYWORD_MONTHLY_TRENDS: "keyword_monthly_trends",
    CATEGORY_TOGGLE_MAP: "category_toggle_map"
};
// Supabase 클라이언트 안전 접근 헬퍼
// 환경변수가 없어서 supabase가 초기화되지 않은 경우
// 런타임 TypeError 대신 빈 결과를 반환하도록 각 함수에서 사용합니다.
function getSupabaseOrNull() {
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"]) {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        return null;
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"];
}
// ---------------------------
// 캐시 및 유틸
// ---------------------------
// category_mid -> 회복정보 캐시 (중복 호출/로그 폭주 방지)
const recoveryInfoCache = new Map();
// 이미 매칭 로그를 찍은 category_mid 모음 (콘솔 스팸 방지)
const recoveryLogPrinted = new Set();
// 공통 데이터 정리 함수 (NaN을 null로 변환)
function cleanData(data) {
    return data.map((item)=>{
        const cleaned = {};
        for(const key in item){
            const value = item[key];
            cleaned[key] = value === "NaN" || typeof value === "number" && isNaN(value) ? null : value;
        }
        return cleaned;
    });
}
async function loadTreatments() {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        const allData = [];
        const pageSize = 1000; // Supabase 기본 limit
        let from = 0;
        let hasMore = true;
        console.log("🔄 전체 데이터 로드 시작...");
        // 페이지네이션으로 모든 데이터 가져오기
        while(hasMore){
            const { data, error } = await client.from(TABLE_NAMES.TREATMENT_MASTER).select("*").range(from, from + pageSize - 1);
            if (error) {
                throw new Error(`Supabase 오류: ${error.message}`);
            }
            if (!data) {
                throw new Error("데이터를 가져올 수 없습니다.");
            }
            if (!Array.isArray(data)) {
                throw new Error("데이터 형식이 올바르지 않습니다. 배열이 아닙니다.");
            }
            // 데이터 추가
            const cleanedData = cleanData(data);
            allData.push(...cleanedData);
            console.log(`📥 ${from + 1}~${from + data.length}개 로드 완료 (총 ${allData.length}개)`);
            // 더 가져올 데이터가 있는지 확인
            if (data.length < pageSize) {
                hasMore = false;
            } else {
                from += pageSize;
            }
        }
        console.log(`✅ 전체 데이터 로드 완료: ${allData.length}개`);
        // 플랫폼 우선순위로 정렬 (gangnamunni → yeoti → babitalk)
        const sortedData = sortTreatmentsByPlatform(allData);
        console.log(`🔄 플랫폼 우선순위 정렬 완료`);
        return sortedData;
    } catch (error) {
        console.error("시술 데이터 로드 실패:", error);
        throw error;
    }
}
// Fisher-Yates 셔플 알고리즘 (랜덤 정렬)
function shuffleArray(array) {
    const shuffled = [
        ...array
    ];
    for(let i = shuffled.length - 1; i > 0; i--){
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [
            shuffled[j],
            shuffled[i]
        ];
    }
    return shuffled;
}
async function loadTreatmentsPaginated(page = 1, pageSize = 50, filters) {
    try {
        const client = getSupabaseOrNull();
        if (!client) {
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        let query = client.from(TABLE_NAMES.TREATMENT_MASTER).select("*", {
            count: "exact"
        });
        // 필터 적용 (최소 2글자 이상일 때만 검색)
        if (filters?.searchTerm && filters.searchTerm.trim().length >= 2) {
            const term = filters.searchTerm.toLowerCase().trim();
            query = query.or(`treatment_name.ilike.%${term}%,hospital_name.ilike.%${term}%,treatment_hashtags.ilike.%${term}%`);
        } else if (filters?.searchTerm && filters.searchTerm.trim().length === 1) {
            // 1글자일 때는 검색하지 않음 (빈 결과 반환)
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        if (filters?.categoryLarge) {
            // 카테고리 매핑을 사용하여 여러 카테고리를 OR 조건으로 검색
            const mappedCategories = CATEGORY_MAPPING[filters.categoryLarge] || [
                filters.categoryLarge
            ];
            if (mappedCategories.length === 0) {
            // "전체"인 경우 필터링하지 않음
            // (빈 배열이면 모든 데이터 반환)
            } else if (mappedCategories.length === 1) {
                // 단일 카테고리인 경우 정확한 일치 또는 부분 일치 검색
                query = query.ilike("category_large", `%${mappedCategories[0]}%`);
            } else {
                // 여러 카테고리인 경우 OR 조건으로 검색
                const orConditions = mappedCategories.map((cat)=>`category_large.ilike.%${cat}%`).join(",");
                query = query.or(orConditions);
            }
            console.log(`[loadTreatmentsPaginated] 대분류 필터: "${filters.categoryLarge}" -> 매핑된 카테고리:`, mappedCategories);
        }
        if (filters?.categoryMid) {
            query = query.eq("category_mid", filters.categoryMid);
        }
        let data, error, count;
        // 랜덤 정렬인 경우: Supabase에서 랜덤 정렬 후 페이지네이션
        // PostgreSQL의 RANDOM() 함수를 사용하여 서버에서 처리
        if (filters?.randomOrder) {
            try {
                // Supabase는 PostgreSQL 기반이므로 RPC 함수나 직접 쿼리로 랜덤 정렬 가능
                // 하지만 JS 클라이언트에서는 직접 지원하지 않으므로,
                // 전체 데이터를 로드하되 클라이언트(브라우저)에서 실행되므로 서버 메모리 사용 없음
                // 필터가 있으면 필터링된 결과만 로드
                const result = await query;
                data = result.data;
                error = result.error;
                count = result.count;
            } catch (fetchError) {
                // 네트워크 오류 처리
                if (fetchError instanceof TypeError && fetchError.message === "Failed to fetch") {
                    console.error("네트워크 오류: Supabase 서버에 연결할 수 없습니다.", fetchError);
                    return {
                        data: [],
                        total: 0,
                        hasMore: false
                    };
                }
                throw fetchError;
            }
            if (error) {
                console.error("Supabase 쿼리 오류:", error);
                throw new Error(`Supabase 오류: ${error.message}`);
            }
            if (!data) {
                return {
                    data: [],
                    total: 0,
                    hasMore: false
                };
            }
            const cleanedData = cleanData(data);
            // 전체 데이터 랜덤 정렬 (클라이언트에서 실행되므로 서버 메모리 사용 없음)
            const shuffledData = shuffleArray(cleanedData);
            // 클라이언트에서 페이지네이션
            const from = (page - 1) * pageSize;
            const to = from + pageSize;
            const paginatedData = shuffledData.slice(from, to);
            const total = count || shuffledData.length;
            const hasMore = to < shuffledData.length;
            return {
                data: paginatedData,
                total,
                hasMore
            };
        } else {
            // 일반 정렬: 서버에서 페이지네이션
            const from = (page - 1) * pageSize;
            const to = from + pageSize - 1;
            try {
                const result = await query.range(from, to);
                data = result.data;
                error = result.error;
                count = result.count;
            } catch (fetchError) {
                // 네트워크 오류 처리
                if (fetchError instanceof TypeError && fetchError.message === "Failed to fetch") {
                    console.error("네트워크 오류: Supabase 서버에 연결할 수 없습니다.", fetchError);
                    return {
                        data: [],
                        total: 0,
                        hasMore: false
                    };
                }
                throw fetchError;
            }
            if (error) {
                console.error("Supabase 쿼리 오류:", error);
                throw new Error(`Supabase 오류: ${error.message}`);
            }
            if (!data) {
                return {
                    data: [],
                    total: 0,
                    hasMore: false
                };
            }
            const cleanedData = cleanData(data);
            let sortedData;
            if (filters?.skipPlatformSort) {
                // 랭킹 페이지는 플랫폼 정렬을 건너뛰고 원본 순서 유지 (랭킹 알고리즘이 정렬함)
                sortedData = cleanedData;
            } else {
                // 플랫폼 우선순위 정렬
                sortedData = sortTreatmentsByPlatform(cleanedData);
            }
            const total = count || 0;
            const hasMore = to < total - 1;
            return {
                data: sortedData,
                total,
                hasMore
            };
        }
    } catch (error) {
        console.error("시술 데이터 페이지네이션 로드 실패:", error);
        throw error;
    }
}
async function getTreatmentAutocomplete(searchTerm, limit = 10) {
    try {
        if (!searchTerm || searchTerm.length < 1) {
            return {
                treatmentNames: [],
                hospitalNames: []
            };
        }
        const client = getSupabaseOrNull();
        if (!client) {
            return {
                treatmentNames: [],
                hospitalNames: []
            };
        }
        const term = searchTerm.toLowerCase();
        const { data, error } = await client.from(TABLE_NAMES.TREATMENT_MASTER).select("category_small, hospital_name").or(`category_small.ilike.%${term}%,hospital_name.ilike.%${term}%`).limit(limit * 2);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return {
                treatmentNames: [],
                hospitalNames: []
            };
        }
        // category_small만 반환 (소분류 기준)
        const treatmentNames = Array.from(new Set(data.map((t)=>t.category_small).filter((name)=>name !== null && name.toLowerCase().includes(term)))).slice(0, limit);
        const hospitalNames = Array.from(new Set(data.map((t)=>t.hospital_name).filter((name)=>name !== null && name.toLowerCase().includes(term)))).slice(0, limit);
        return {
            treatmentNames,
            hospitalNames
        };
    } catch (error) {
        console.error("자동완성 데이터 로드 실패:", error);
        return {
            treatmentNames: [],
            hospitalNames: []
        };
    }
}
async function loadCategoryTreatTimeRecovery() {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        const { data, error } = await client.from(TABLE_NAMES.CATEGORY_TREATTIME_RECOVERY).select("*");
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data || !Array.isArray(data)) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("카테고리 시술 시간/회복 기간 데이터 로드 실패:", error);
        throw error;
    }
}
async function getRecoveryInfoByCategoryMid(categoryMid) {
    try {
        if (!categoryMid) return null;
        const categoryMidTrimmed = categoryMid.trim();
        // 캐시 (중복 호출/로그 스팸 방지) - trim된 키 사용
        // ❗ null(매칭 실패)은 캐시하지 않고, 성공한 값만 캐시합니다.
        if (recoveryInfoCache.has(categoryMidTrimmed)) {
            const cached = recoveryInfoCache.get(categoryMidTrimmed);
            if (cached) return cached;
        }
        const recoveryData = await loadCategoryTreatTimeRecovery();
        // 키/샘플 확인 (디버깅용)
        console.log("🔑 recovery 첫 행 keys:", recoveryData?.[0] ? Object.keys(recoveryData[0]) : null);
        console.log("🔎 sample 중분류:", recoveryData?.slice(0, 5).map((x)=>x["중분류"] ?? x.중분류 ?? x.category_mid));
        const getMid = (item)=>String(item["중분류"] ?? item.중분류 ?? item["category_mid"] ?? item.category_mid ?? item["categoryMid"] ?? item.categoryMid ?? "");
        // 정규화 함수: NFC + zero-width 제거 + 공백 제거 + 소문자
        // (슬래시(`/`) 같은 구분 문자는 그대로 둬서 "유두/유륜성형" 등의 매칭을 보존)
        const normalize = (str)=>str.normalize("NFC").replace(/[\u200B-\u200D\uFEFF]/g, "").replace(/\s+/g, "").toLowerCase();
        // 정상화된 중분류 목록을 미리 만들어 정확/부분 일치에 사용
        const normalizedCategoryMid = normalize(categoryMidTrimmed);
        const normalizedRecoveryData = recoveryData.map((item)=>{
            const mid = getMid(item).trim();
            return {
                ...item,
                _mid: mid,
                _normalized: normalize(mid)
            };
        });
        // 디버깅: 매칭 시도 전 로그 (한번만 찍기)
        if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
            console.log(`🔍 [매칭 시도] category_mid: "${categoryMidTrimmed}"`);
            console.log(`🔍 [매칭 시도] 정규화된 값: "${normalizedCategoryMid}"`);
            console.log(`🔍 [전체 데이터] 총 ${recoveryData.length}개 항목`);
        }
        // "V라인" 또는 입력값이 포함된 모든 중분류 찾기 (디버깅용)
        const relatedItems = normalizedRecoveryData.filter((item)=>{
            if (!item._normalized) return false;
            return item._normalized.includes(normalizedCategoryMid) || normalizedCategoryMid.includes(item._normalized);
        });
        if (relatedItems.length > 0 && !recoveryLogPrinted.has(categoryMidTrimmed)) {
            console.log(`🔍 [관련 항목 발견] ${relatedItems.length}개 항목 발견:`, relatedItems.map((item)=>({
                    중분류: item.중분류,
                    정규화: normalize(item.중분류 || ""),
                    "권장체류일수(일)": item["권장체류일수(일)"] ?? item.권장체류일수
                })));
        }
        // 중분류 컬럼과 category_mid를 정확히 일치시켜서 매칭 (정확 일치만 허용)
        // 1) 원본 문자열 정확 일치 (최우선)
        let matched = normalizedRecoveryData.find((item)=>item._mid === categoryMidTrimmed);
        // 2) 정규화된 정확 일치 (공백/대소문자 차이만 허용)
        if (!matched) {
            matched = normalizedRecoveryData.find((item)=>item._normalized && item._normalized === normalizedCategoryMid);
        }
        // 부분 일치 제거: 모든 category_mid 값이 정확히 일치해야 함
        if (!matched) {
            if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
                console.error(`❌ [매칭 실패] category_mid: "${categoryMidTrimmed}" (정규화: "${normalize(categoryMidTrimmed)}")`);
            }
            // "V라인"이 포함된 모든 항목 찾기
            const vlineItems = recoveryData.filter((item)=>{
                const 중분류 = (item.중분류 || "").trim();
                return 중분류 && (중분류.includes("V라인") || 중분류.includes("v라인") || 중분류.includes("V 라인"));
            });
            if (vlineItems.length > 0 && !recoveryLogPrinted.has(categoryMidTrimmed)) {
                console.log(`🔍 [V라인 관련 항목] ${vlineItems.length}개 발견:`, vlineItems.map((item)=>({
                        중분류: item.중분류,
                        정규화: normalize(item.중분류 || ""),
                        "권장체류일수(일)": item["권장체류일수(일)"] ?? item.권장체류일수
                    })));
            }
            recoveryLogPrinted.add(categoryMidTrimmed);
            return null;
        }
        // 실제 컬럼명: 회복기간_min(일), 회복기간_max(일), 시술시간_min(분), 시술시간_max(분)
        if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
            console.log("🔍 매칭된 객체의 모든 키:", Object.keys(matched));
            console.log("🔍 매칭된 객체에서 회복기간 값 확인:", {
                "회복기간_max(일)": matched["회복기간_max(일)"],
                "회복기간_min(일)": matched["회복기간_min(일)"],
                "시술시간_max(분)": matched["시술시간_max"],
                "시술시간_min(분)": matched["시술시간_min"],
                타입_max: typeof matched["회복기간_max(일)"],
                타입_min: typeof matched["회복기간_min(일)"]
            });
        }
        const m = matched;
        const recoveryMax = m["회복기간_max(일)"] || m["회복기간_min(일)"] || 0;
        const recoveryMin = m["회복기간_min(일)"] || 0;
        const procedureTimeMax = m["시술시간_max(분)"] || m["시술시간_min(분)"] || m["시술시간_max"] || m["시술시간_min"] || 0;
        const procedureTimeMin = m["시술시간_min(분)"] || m["시술시간_min"] || 0;
        console.log(`✅ 매칭 성공! category_mid: "${categoryMidTrimmed}", 회복기간_max: ${recoveryMax}, 회복기간_min: ${recoveryMin}`);
        if (recoveryMax === 0 && recoveryMin === 0) {
            console.warn(`⚠️ 회복 기간 값이 0입니다. category_mid: "${categoryMidTrimmed}", 매칭된 항목:`, matched);
            console.warn("🔍 사용 가능한 모든 키:", Object.keys(matched));
        }
        // 회복 기간 텍스트 가이드 (전체 범위 저장)
        const recoveryGuides = {
            "1~3": matched["1~3"] || null,
            "4~7": matched["4~7"] || null,
            "8~14": matched["8~14"] || null,
            "15~21": matched["15~21"] || null
        };
        // 회복 기간에 맞는 대표 텍스트 컬럼 선택 (회복기간_max 기준)
        let recoveryText = null;
        if (recoveryMax >= 1 && recoveryMax <= 3) {
            recoveryText = recoveryGuides["1~3"];
        } else if (recoveryMax >= 4 && recoveryMax <= 7) {
            recoveryText = recoveryGuides["4~7"];
        } else if (recoveryMax >= 8 && recoveryMax <= 14) {
            recoveryText = recoveryGuides["8~14"];
        } else if (recoveryMax >= 15 && recoveryMax <= 21) {
            recoveryText = recoveryGuides["15~21"];
        }
        // 권장체류일수(일) 가져오기 - 컬럼명 변형까지 대응
        const recommendedStayDays = (()=>{
            const direct = m["권장체류일수(일)"] ?? m["권장체류일수"] ?? m.권장체류일수;
            if (typeof direct === "number" && !isNaN(direct) && direct > 0) {
                if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
                    console.log(`✅ [권장체류일수] 직접 매칭: ${direct}일`);
                }
                return direct;
            }
            const dynamicKey = Object.keys(m).find((k)=>k.replace(/\s+/g, "").includes("권장체류"));
            if (dynamicKey) {
                const value = m[dynamicKey];
                if (typeof value === "number" && !isNaN(value) && value > 0) {
                    if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
                        console.log(`✅ [권장체류일수] 동적 키 매칭 (${dynamicKey}): ${value}일`);
                    }
                    return value;
                }
            }
            if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
                console.warn(`⚠️ [권장체류일수] 찾을 수 없음. category_mid: "${categoryMidTrimmed}"`);
                console.log("🔍 [매칭된 객체의 모든 키]:", Object.keys(matched));
            }
            return 0;
        })();
        // 권장체류일수가 있으면 recoveryMax로 사용 (회복 기간 표시용)
        const finalRecoveryMax = recommendedStayDays > 0 ? recommendedStayDays : recoveryMax;
        const finalRecoveryMin = recommendedStayDays > 0 ? recommendedStayDays : recoveryMin;
        if (!recoveryLogPrinted.has(categoryMidTrimmed)) {
            console.log(`✅ [최종 회복 기간] category_mid: "${categoryMidTrimmed}", 권장체류일수: ${recommendedStayDays}일, 회복기간_max: ${recoveryMax}일, 최종 사용: ${finalRecoveryMax}일`);
        }
        const result = {
            recoveryMin: finalRecoveryMin,
            recoveryMax: finalRecoveryMax,
            recoveryText,
            procedureTimeMin,
            procedureTimeMax,
            recommendedStayDays,
            recoveryGuides
        };
        // 캐시 & 로그 기록 (성공한 경우에만 캐시)
        recoveryInfoCache.set(categoryMidTrimmed, result);
        recoveryLogPrinted.add(categoryMidTrimmed);
        return result;
    } catch (error) {
        console.error("회복 기간 정보 로드 실패:", error);
        return null;
    }
}
async function loadHospitalMaster() {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        const { data, error } = await client.from(TABLE_NAMES.HOSPITAL_MASTER).select("*");
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data || !Array.isArray(data)) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("병원 데이터 로드 실패:", error);
        throw error;
    }
}
async function loadTreatmentById(treatmentId) {
    try {
        const client = getSupabaseOrNull();
        if (!client) return null;
        const { data, error } = await client.from(TABLE_NAMES.TREATMENT_MASTER).select("*").eq("treatment_id", treatmentId).single();
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return null;
        }
        return cleanData([
            data
        ])[0];
    } catch (error) {
        console.error("시술 데이터 로드 실패:", error);
        return null;
    }
}
async function loadRelatedTreatments(treatmentName, excludeId) {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        let query = client.from(TABLE_NAMES.TREATMENT_MASTER).select("*").eq("treatment_name", treatmentName);
        if (excludeId) {
            query = query.neq("treatment_id", excludeId);
        }
        const { data, error } = await query.limit(50);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("관련 시술 데이터 로드 실패:", error);
        return [];
    }
}
async function loadHospitalTreatments(hospitalName, excludeId) {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        let query = client.from(TABLE_NAMES.TREATMENT_MASTER).select("*").eq("hospital_name", hospitalName);
        if (excludeId) {
            query = query.neq("treatment_id", excludeId);
        }
        const { data, error } = await query.limit(10);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("병원 시술 데이터 로드 실패:", error);
        return [];
    }
}
async function loadHospitalsPaginated(page = 1, pageSize = 50, filters) {
    try {
        const client = getSupabaseOrNull();
        if (!client) {
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        let query = client.from(TABLE_NAMES.HOSPITAL_MASTER).select("*", {
            count: "exact"
        });
        // 필터 적용 (최소 2글자 이상일 때만 검색)
        if (filters?.searchTerm && filters.searchTerm.trim().length >= 2) {
            const term = filters.searchTerm.toLowerCase().trim();
            query = query.ilike("hospital_name", `%${term}%`);
        } else if (filters?.searchTerm && filters.searchTerm.trim().length === 1) {
            // 1글자일 때는 검색하지 않음 (빈 결과 반환)
            return {
                data: [],
                total: 0,
                hasMore: false
            };
        }
        let data, error, count;
        // 랜덤 정렬인 경우: 전체 데이터를 로드한 후 클라이언트에서 페이지네이션
        // 클라이언트(브라우저)에서 실행되므로 서버 메모리 사용 없음
        if (filters?.randomOrder) {
            // 전체 데이터 로드 (페이지네이션 없이)
            // 필터가 있으면 필터링된 결과만 로드
            const result = await query;
            data = result.data;
            error = result.error;
            count = result.count;
            if (error) {
                throw new Error(`Supabase 오류: ${error.message}`);
            }
            if (!data) {
                return {
                    data: [],
                    total: 0,
                    hasMore: false
                };
            }
            const cleanedData = cleanData(data);
            // 전체 데이터 랜덤 정렬 (클라이언트에서 실행되므로 서버 메모리 사용 없음)
            const shuffledData = shuffleArray(cleanedData);
            // 클라이언트에서 페이지네이션
            const from = (page - 1) * pageSize;
            const to = from + pageSize;
            const paginatedData = shuffledData.slice(from, to);
            const total = count || shuffledData.length;
            const hasMore = to < shuffledData.length;
            return {
                data: paginatedData,
                total,
                hasMore
            };
        } else {
            // 일반 정렬: 서버에서 페이지네이션
            const from = (page - 1) * pageSize;
            const to = from + pageSize - 1;
            const result = await query.range(from, to);
            data = result.data;
            error = result.error;
            count = result.count;
            if (error) {
                throw new Error(`Supabase 오류: ${error.message}`);
            }
            if (!data) {
                return {
                    data: [],
                    total: 0,
                    hasMore: false
                };
            }
            const cleanedData = cleanData(data);
            // 플랫폼 우선순위 정렬
            const sortedData = sortHospitalsByPlatform(cleanedData);
            const total = count || 0;
            const hasMore = to < total - 1;
            return {
                data: sortedData,
                total,
                hasMore
            };
        }
    } catch (error) {
        console.error("병원 데이터 페이지네이션 로드 실패:", error);
        throw error;
    }
}
async function getHospitalAutocomplete(searchTerm, limit = 10) {
    try {
        if (!searchTerm || searchTerm.length < 1) {
            return [];
        }
        const client = getSupabaseOrNull();
        if (!client) return [];
        const term = searchTerm.toLowerCase();
        const { data, error } = await client.from(TABLE_NAMES.HOSPITAL_MASTER).select("hospital_name").ilike("hospital_name", `%${term}%`).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return Array.from(new Set(data.map((h)=>h.hospital_name).filter((name)=>!!name)));
    } catch (error) {
        console.error("병원 자동완성 데이터 로드 실패:", error);
        return [];
    }
}
async function loadKeywordMonthlyTrends() {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        const { data, error } = await client.from(TABLE_NAMES.KEYWORD_MONTHLY_TRENDS).select("*");
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data || !Array.isArray(data)) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("키워드 트렌드 데이터 로드 실패:", error);
        throw error;
    }
}
async function loadAllData() {
    try {
        const [treatments, categoryData, hospitals, trends] = await Promise.all([
            loadTreatments(),
            loadCategoryTreatTimeRecovery(),
            loadHospitalMaster(),
            loadKeywordMonthlyTrends()
        ]);
        return {
            treatments,
            categoryTreatTimeRecovery: categoryData,
            hospitals,
            keywordTrends: trends
        };
    } catch (error) {
        console.error("전체 데이터 로드 실패:", error);
        throw error;
    }
}
function extractHospitalInfo(treatments) {
    const hospitalMap = new Map();
    treatments.forEach((treatment)=>{
        if (!treatment.hospital_name) return;
        const hospitalName = treatment.hospital_name;
        if (!hospitalMap.has(hospitalName)) {
            hospitalMap.set(hospitalName, {
                hospital_name: hospitalName,
                treatments: [],
                averageRating: 0,
                totalReviews: 0,
                procedures: [],
                categories: new Set()
            });
        }
        const hospital = hospitalMap.get(hospitalName);
        hospital.treatments.push(treatment);
        if (treatment.treatment_name) {
            hospital.procedures.push(treatment.treatment_name);
        }
        if (treatment.category_large) {
            hospital.categories.add(treatment.category_large);
        }
        if (treatment.rating) {
            hospital.averageRating += treatment.rating;
        }
        if (treatment.review_count) {
            hospital.totalReviews += treatment.review_count;
        }
    });
    // 평균 평점 계산 및 데이터 정리
    const hospitals = Array.from(hospitalMap.values()).map((hospital)=>{
        const treatmentCount = hospital.treatments.length;
        const avgRating = treatmentCount > 0 && hospital.averageRating > 0 ? hospital.averageRating / treatmentCount : 0;
        // 중복 제거 및 정렬
        const uniqueProcedures = Array.from(new Set(hospital.procedures)).slice(0, 10);
        return {
            ...hospital,
            averageRating: Math.round(avgRating * 10) / 10,
            procedures: uniqueProcedures,
            categories: hospital.categories
        };
    });
    // 평점 순으로 정렬
    return hospitals.sort((a, b)=>b.averageRating - a.averageRating);
}
function getThumbnailUrl(treatment) {
    // API에서 제공하는 main_image_url이 있으면 우선 사용
    if (treatment.main_image_url && treatment.main_image_url.trim() !== "") {
        return treatment.main_image_url;
    }
    // main_image_url이 없을 경우 고유한 플레이스홀더 생성
    const categoryColors = {
        리프팅: "667eea",
        피부: "f093fb",
        눈: "4facfe",
        코: "43e97b",
        입술: "fa709a",
        볼: "fee140",
        쁘띠: "30cfd0",
        기타: "667eea"
    };
    const category = treatment.category_large || "기타";
    const color = categoryColors[category] || "667eea";
    // treatment_id를 기반으로 고유한 이미지 생성
    const treatmentId = treatment.treatment_id || Math.random() * 1000;
    const seed = treatmentId % 1000;
    // 시술명의 첫 글자
    const firstChar = treatment.treatment_name ? treatment.treatment_name.charAt(0) : category.charAt(0);
    // data URI로 플레이스홀더 생성 (외부 서비스 의존성 제거)
    return `data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="300"%3E%3Crect fill="%23${color}" width="400" height="300"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="white" font-size="48" font-weight="bold"%3E${encodeURIComponent(firstChar)}%3C/text%3E%3C/svg%3E`;
}
function calculateRecommendationScore(treatment) {
    const rating = treatment.rating || 0;
    const reviewCount = treatment.review_count || 0;
    const price = treatment.selling_price || 0;
    // 평점 가중치 (40%)
    const ratingScore = rating * 40;
    // 리뷰 수 가중치 (30%) - 리뷰가 많을수록 좋음 (로그 스케일 사용)
    const reviewScore = Math.log10(reviewCount + 1) * 10 * 3;
    // 가격 인기도 점수 (20%) - 합리적인 가격대일수록 높은 점수
    // 평균 가격대 근처일수록 높은 점수 (간단한 휴리스틱)
    const priceScore = price > 0 && price < 1000000 ? 20 : 10;
    // 할인율 보너스 (10%)
    const discountBonus = treatment.dis_rate ? treatment.dis_rate * 0.1 : 0;
    return ratingScore + reviewScore + priceScore + discountBonus;
}
function getCategoryRankings(treatments, category) {
    let filtered = treatments;
    if (category) {
        filtered = treatments.filter((t)=>t.category_large === category || t.category_mid === category);
    }
    // 추천 점수 계산 후 정렬
    return filtered.map((treatment)=>({
            ...treatment,
            recommendationScore: calculateRecommendationScore(treatment)
        })).sort((a, b)=>b.recommendationScore - a.recommendationScore);
}
function getTreatmentRankings(treatments) {
    const treatmentMap = new Map();
    // 시술명으로 그룹화
    treatments.forEach((treatment)=>{
        if (!treatment.treatment_name) return;
        const name = treatment.treatment_name;
        if (!treatmentMap.has(name)) {
            treatmentMap.set(name, []);
        }
        treatmentMap.get(name).push(treatment);
    });
    // 랭킹 데이터 생성
    const rankings = Array.from(treatmentMap.entries()).map(([treatmentName, treatmentList])=>{
        const ratings = treatmentList.map((t)=>t.rating || 0).filter((r)=>r > 0);
        const reviews = treatmentList.map((t)=>t.review_count || 0).reduce((sum, count)=>sum + count, 0);
        const prices = treatmentList.map((t)=>t.selling_price || 0).filter((p)=>p > 0);
        const averageRating = ratings.length > 0 ? ratings.reduce((sum, r)=>sum + r, 0) / ratings.length : 0;
        const averagePrice = prices.length > 0 ? prices.reduce((sum, p)=>sum + p, 0) / prices.length : 0;
        // 대표 시술 3개 선택 (평점 높은 순)
        const topTreatments = [
            ...treatmentList
        ].sort((a, b)=>(b.rating || 0) - (a.rating || 0)).slice(0, 3);
        // 추천 점수 계산
        const representativeTreatment = {
            ...topTreatments[0],
            rating: averageRating,
            review_count: reviews
        };
        const recommendationScore = calculateRecommendationScore(representativeTreatment);
        return {
            treatmentName,
            treatments: treatmentList,
            averageRating,
            totalReviews: reviews,
            averagePrice,
            recommendationScore,
            topTreatments
        };
    }).sort((a, b)=>b.recommendationScore - a.recommendationScore);
    return rankings;
}
// K-beauty 관련 시술 필터링 (키워드 기반)
const KBEAUTY_KEYWORDS = [
    "리쥬란",
    "인모드",
    "슈링크",
    "윤곽",
    "주사",
    "보톡스",
    "필러",
    "리프팅",
    "탄력",
    "미백",
    "백옥",
    "프락셀",
    "피코",
    "레이저"
];
function getKBeautyRankings(treatments) {
    return treatments.filter((treatment)=>{
        const name = (treatment.treatment_name || "").toLowerCase();
        const hashtags = (treatment.treatment_hashtags || "").toLowerCase();
        const category = (treatment.category_large || "").toLowerCase();
        return KBEAUTY_KEYWORDS.some((keyword)=>name.includes(keyword.toLowerCase()) || hashtags.includes(keyword.toLowerCase()) || category.includes(keyword.toLowerCase()));
    }).map((treatment)=>({
            ...treatment,
            recommendationScore: calculateRecommendationScore(treatment)
        })).sort((a, b)=>b.recommendationScore - a.recommendationScore);
}
function parseRecoveryPeriod(downtime) {
    if (!downtime) return 0;
    if (typeof downtime === "number") return downtime;
    // 문자열인 경우 "1일", "2일", "1-2일" 등의 형식 파싱
    const match = downtime.toString().match(/(\d+)/);
    return match ? parseInt(match[1]) : 0;
}
function parseProcedureTime(surgeryTime) {
    if (!surgeryTime) return 0;
    if (typeof surgeryTime === "number") return surgeryTime;
    // 문자열인 경우 "30분", "60분" 등의 형식 파싱
    const match = surgeryTime.toString().match(/(\d+)/);
    return match ? parseInt(match[1]) : 0;
}
const CATEGORY_MAPPING = {
    눈성형: [
        "눈",
        "눈성형"
    ],
    리프팅: [
        "리프팅",
        "윤곽",
        "볼륨"
    ],
    보톡스: [
        "보톡스",
        "주사"
    ],
    "안면윤곽/양악": [
        "안면",
        "윤곽",
        "양악",
        "턱"
    ],
    제모: [
        "제모",
        "레이저"
    ],
    지방성형: [
        "지방",
        "체형",
        "다이어트",
        "지방흡입"
    ],
    코성형: [
        "코",
        "코성형"
    ],
    피부: [
        "피부",
        "피부관리"
    ],
    필러: [
        "필러",
        "주사"
    ],
    가슴성형: [
        "가슴",
        "유방",
        "보형물"
    ],
    기타: [
        "기타"
    ],
    전체: []
};
async function getScheduleBasedRecommendations(treatments, categoryLarge, startDate, endDate) {
    console.log(`🚀 [일정 기반 추천 시작] 입력 데이터: ${treatments.length}개 시술, 카테고리: "${categoryLarge}"`);
    // 여행 일수 계산
    const start = new Date(startDate);
    const end = new Date(endDate);
    const travelDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1; // n박 n일
    // 아주 짧은 일정(당일 or 1박 2일)일 때는,
    // 회복친화적인 3일짜리 시술까지는 보여주기 위해
    // 필터 기준을 최소 3일로 완화
    // const effectiveTravelDays = travelDays <= 2 ? 3 : travelDays;
    const effectiveTravelDays = travelDays; // 임시: 1박2일에서 3일짜리 포함 로직 주석 처리 (확인용)
    console.log(`📅 [여행 일수 계산] 시작: ${startDate}, 종료: ${endDate}, 여행일수: ${travelDays}일, effectiveTravelDays: ${effectiveTravelDays}일`);
    // 대분류 카테고리로 필터링
    const mappedCategories = CATEGORY_MAPPING[categoryLarge] || [
        categoryLarge
    ];
    console.log(`🔍 [카테고리 매핑] "${categoryLarge}" → 매핑된 카테고리:`, mappedCategories);
    const categoryFiltered = treatments.filter((t)=>{
        if (!t.category_large) return false;
        // 디버깅: 피부관리 중분류 확인
        if (t.category_mid === "피부관리") {
            console.log(`🔍 [피부관리 대분류 필터링] category_large: "${t.category_large}", category_mid: "${t.category_mid}", 선택된 대분류: "${categoryLarge}"`);
        }
        // "전체"인 경우 모든 시술 포함
        if (categoryLarge === "전체") {
            return true;
        }
        // "기타"인 경우: 다른 카테고리에 속하지 않는 것만
        if (categoryLarge === "기타") {
            const allOtherCategories = [
                "눈",
                "눈성형",
                "리프팅",
                "윤곽",
                "볼륨",
                "보톡스",
                "주사",
                "안면",
                "양악",
                "턱",
                "제모",
                "레이저",
                "지방",
                "체형",
                "다이어트",
                "지방흡입",
                "코",
                "코성형",
                "피부",
                "피부관리",
                "필러",
                "가슴",
                "유방",
                "보형물"
            ];
            const categoryLower = t.category_large?.toLowerCase() || "";
            const midCategoryLower = t.category_mid?.toLowerCase() || "";
            // 다른 카테고리에 속하지 않는지 확인
            const isInOtherCategory = allOtherCategories.some((otherCat)=>categoryLower.includes(otherCat.toLowerCase()) || midCategoryLower.includes(otherCat.toLowerCase()));
            return !isInOtherCategory;
        }
        // 일반 카테고리: category_large와 category_mid 모두 확인
        // category_large 또는 category_mid가 매핑된 카테고리 중 하나와 일치하는 경우 포함
        const categoryLargeLower = (t.category_large || "").toLowerCase();
        const categoryMidLower = (t.category_mid || "").toLowerCase();
        // category_large가 매핑된 카테고리 중 하나와 일치하는 경우
        const matchesLarge = mappedCategories.some((mapped)=>{
            const mappedLower = mapped.toLowerCase();
            return categoryLargeLower.includes(mappedLower);
        });
        if (matchesLarge) {
            return true;
        }
        // category_mid도 확인 (예: "피부관리" 중분류는 "피부" 대분류 선택 시 포함되어야 함)
        const matchesMid = mappedCategories.some((mapped)=>{
            const mappedLower = mapped.toLowerCase();
            return categoryMidLower.includes(mappedLower);
        });
        if (matchesMid) {
            return true;
        }
        return false;
    });
    console.log(`✅ [대분류 필터링 완료] 선택 카테고리: "${categoryLarge}", 여행일수: ${effectiveTravelDays}일, 필터링된 데이터: ${categoryFiltered.length}개 (전체 ${treatments.length}개 중)`);
    // 디버깅: 모든 카테고리에 대한 필터링 결과 확인
    const categoryMids = new Set();
    categoryFiltered.forEach((t)=>{
        if (t.category_mid) categoryMids.add(t.category_mid);
        if (t.category_large) console.log(`  - category_large: "${t.category_large}", category_mid: "${t.category_mid || "없음"}"`);
    });
    console.log(`🔍 [중분류 목록] 필터링된 시술의 중분류들 (${categoryMids.size}개):`, Array.from(categoryMids).slice(0, 20));
    // "피부" 카테고리 특별 로그
    if (categoryLarge === "피부") {
        const pibuCategoryMids = new Set();
        categoryFiltered.forEach((t)=>{
            if (t.category_mid) pibuCategoryMids.add(t.category_mid);
        });
        console.log(`🔍 [피부 카테고리 상세] 총 ${categoryFiltered.length}개 시술, 중분류 (${pibuCategoryMids.size}개):`, Array.from(pibuCategoryMids));
        // "피부관리" 중분류가 있는지 확인
        if (pibuCategoryMids.has("피부관리")) {
            const pibuGwanriCount = categoryFiltered.filter((t)=>t.category_mid === "피부관리").length;
            console.log(`✅ [피부관리 발견] ${pibuGwanriCount}개 시술 발견!`);
        } else {
            console.warn(`❌ [피부관리 없음] 필터링된 시술 중 "피부관리" 중분류가 없습니다!`);
        }
    }
    // 중분류별로 그룹화 (대분류 + 중분류 조합으로 키 생성하여 중복 방지)
    const midCategoryMap = new Map();
    // "정맥주사" 중복 확인을 위한 디버깅
    const jeongmaekjusaTreatments = [];
    categoryFiltered.forEach((treatment)=>{
        const categoryLarge = treatment.category_large || "";
        const midCategory = treatment.category_mid || "기타";
        // "정맥주사" 데이터 수집 (선택된 카테고리 정보 포함)
        if (midCategory === "정맥주사" || midCategory.includes("정맥주사")) {
            jeongmaekjusaTreatments.push({
                categoryLarge,
                categoryMid: midCategory,
                treatmentName: treatment.treatment_name || "이름 없음",
                treatmentId: treatment.treatment_id,
                selectedCategory: categoryLarge
            });
        }
        // 대분류와 중분류를 조합하여 고유 키 생성
        const uniqueKey = `${categoryLarge}::${midCategory}`;
        if (!midCategoryMap.has(uniqueKey)) {
            midCategoryMap.set(uniqueKey, []);
        }
        midCategoryMap.get(uniqueKey).push(treatment);
    });
    // 디버깅: "피부" 카테고리 선택 시 중분류별 그룹화 결과
    if (categoryLarge === "피부") {
        console.log(`🔍 [피부 중분류 그룹화] 총 ${midCategoryMap.size}개 중분류 그룹:`, Array.from(midCategoryMap.keys()).filter((k)=>k.includes("피부")).slice(0, 10));
    }
    // "정맥주사" 중복 확인 로그 - 각 대분류별로 다른 시술인지 확인
    if (jeongmaekjusaTreatments.length > 0) {
        const categoryLargeSet = new Set(jeongmaekjusaTreatments.map((t)=>t.categoryLarge));
        console.log("🔍 [정맥주사 데이터 분석]");
        console.log(`- 선택된 카테고리: ${categoryLarge}`);
        console.log(`- 총 ${jeongmaekjusaTreatments.length}개의 정맥주사 시술 발견`);
        console.log(`- 속한 대분류(category_large): ${Array.from(categoryLargeSet).join(", ")}`);
        console.log(`- 대분류 개수: ${categoryLargeSet.size}개`);
        // 대분류별로 그룹화하여 상세 정보 출력
        const byCategory = new Map();
        jeongmaekjusaTreatments.forEach((t)=>{
            const existing = byCategory.get(t.categoryLarge) || {
                count: 0,
                treatments: []
            };
            existing.count += 1;
            existing.treatments.push({
                name: t.treatmentName,
                id: t.treatmentId
            });
            byCategory.set(t.categoryLarge, existing);
        });
        // 각 대분류별 시술 목록 출력
        byCategory.forEach((data, cat)=>{
            console.log(`\n📋 [${cat}] 대분류의 정맥주사 시술 (${data.count}개):`);
            const treatmentNames = data.treatments.map((t)=>t.name);
            const treatmentIds = data.treatments.map((t)=>t.id).filter((id)=>id !== undefined);
            console.log(`  시술명: ${treatmentNames.slice(0, 5).join(", ")}${treatmentNames.length > 5 ? ` ... 외 ${treatmentNames.length - 5}개` : ""}`);
            console.log(`  시술 ID: ${treatmentIds.slice(0, 5).join(", ")}${treatmentIds.length > 5 ? ` ... 외 ${treatmentIds.length - 5}개` : ""}`);
        });
        // 중복 시술 확인 (같은 시술 ID가 여러 대분류에 있는지)
        const allTreatmentIds = new Map();
        jeongmaekjusaTreatments.forEach((t)=>{
            if (t.treatmentId !== undefined) {
                const existing = allTreatmentIds.get(t.treatmentId) || [];
                if (!existing.includes(t.categoryLarge)) {
                    existing.push(t.categoryLarge);
                }
                allTreatmentIds.set(t.treatmentId, existing);
            }
        });
        const duplicateTreatments = [];
        allTreatmentIds.forEach((categories, id)=>{
            if (categories.length > 1) {
                const treatment = jeongmaekjusaTreatments.find((t)=>t.treatmentId === id);
                if (treatment) {
                    duplicateTreatments.push({
                        id,
                        name: treatment.treatmentName,
                        categories
                    });
                }
            }
        });
        if (duplicateTreatments.length > 0) {
            console.error("❌ [문제 발견] 같은 시술이 여러 대분류에 중복되어 있습니다:");
            duplicateTreatments.forEach((d)=>{
                console.error(`  - 시술 ID ${d.id} (${d.name}): ${d.categories.join(", ")} 대분류에 중복`);
            });
            console.error("💡 이는 필터링 로직 문제로 인해 발생할 수 있습니다. 각 대분류별로 다른 시술이 표시되어야 합니다.");
        } else {
            console.log("✅ 각 대분류별로 다른 시술이 표시되고 있습니다.");
        }
        if (categoryLargeSet.size > 1) {
            console.warn("⚠️ 정맥주사가 여러 대분류에 속해있습니다:", Array.from(categoryLargeSet));
            console.log("💡 이는 데이터 상에서 '정맥주사' 중분류가 실제로 여러 대분류에 속해있기 때문입니다.");
        }
    }
    // 중분류별로 추천 데이터 생성
    const recommendationsPromises = Array.from(midCategoryMap.entries()).map(async ([uniqueKey, treatmentList])=>{
        // uniqueKey에서 중분류 이름만 추출 (대분류::중분류 형식)
        // ⚠️ 중요: treatment_master의 category_mid와 정확히 일치해야 함
        const categoryMid = uniqueKey.split("::")[1] || "기타";
        // 디버깅: category_mid 정확 일치 확인
        const allCategoryMidsInGroup = new Set(treatmentList.map((t)=>t.category_mid || "").filter(Boolean));
        if (allCategoryMidsInGroup.size > 1 || !allCategoryMidsInGroup.has(categoryMid)) {
            console.warn(`⚠️ [중분류 그룹 불일치] uniqueKey: "${uniqueKey}", categoryMid: "${categoryMid}", 실제 category_mid들:`, Array.from(allCategoryMidsInGroup));
        }
        // 먼저 category_treattime_recovery 테이블에서 권장체류일수 및 회복기간 범위 가져오기
        // ⚠️ 중요: 정확히 같은 category_mid로만 매칭 (부분 일치 제거)
        let recommendedStayDays = 0;
        let recoveryMin = 0;
        let recoveryMax = 0;
        let procedureTimeMin = 0;
        let procedureTimeMax = 0;
        try {
            const recoveryInfo = await getRecoveryInfoByCategoryMid(categoryMid);
            if (recoveryInfo) {
                recoveryMin = recoveryInfo.recoveryMin;
                recoveryMax = recoveryInfo.recoveryMax;
                procedureTimeMin = recoveryInfo.procedureTimeMin;
                procedureTimeMax = recoveryInfo.procedureTimeMax;
                recommendedStayDays = recoveryInfo.recommendedStayDays;
                // 디버깅: 모든 중분류에 대한 매칭 결과 로그
                console.log(`📊 [중분류 매칭] "${categoryMid}": 권장체류일수=${recommendedStayDays}일, 시술수=${treatmentList.length}개`);
            } else {
                console.warn(`⚠️ [중분류 매칭 실패] "${categoryMid}": category_treattime_recovery에서 찾을 수 없음, 시술수=${treatmentList.length}개`);
            }
        } catch (error) {
            console.warn(`회복 기간 정보 로드 실패 (category_mid: ${categoryMid}):`, error);
        }
        // 권장체류일수(일)만 사용하여 여행 기간에 맞는 시술만 필터링
        // - 결정 기준은 category_treattime_recovery 테이블의 "권장체류일수(일)" 컬럼
        // - 이 값이 없을 때만 기존 로직(downtime)으로 fallback
        const groupStayDays = recommendedStayDays;
        // 디버깅: 피부관리 카테고리 확인
        if (categoryMid === "피부관리") {
            console.log(`🔍 [피부관리 디버깅] category_mid: "${categoryMid}", 권장체류일수: ${groupStayDays}, effectiveTravelDays: ${effectiveTravelDays}, 여행일수: ${effectiveTravelDays}일`);
        }
        // 권장체류일수가 여행 일수보다 크면, 이 중분류 전체를 추천에서 제외
        // 단, 당일/1박 2일은 effectiveTravelDays=3으로 간주하여 3일짜리 시술까지 허용
        // (임시 주석 처리: 1박2일에서 3일짜리 포함 로직 비활성화)
        if (groupStayDays > 0 && groupStayDays > effectiveTravelDays) {
            console.log(`❌ [필터링 제외] "${categoryMid}": 권장체류일수 ${groupStayDays}일 > 여행일수 ${effectiveTravelDays}일로 제외됨`);
            return null;
        }
        // 권장체류일수가 0이 아니고 여행일수 이하이면 포함 (로그 추가)
        if (groupStayDays > 0) {
            console.log(`✅ [필터링 포함] "${categoryMid}": 권장체류일수 ${groupStayDays}일 <= 여행일수 ${effectiveTravelDays}일로 포함됨`);
        }
        let suitableTreatments;
        if (groupStayDays > 0) {
            // 권장체류일수가 여행 일수 이내면 해당 중분류 전체를 포함
            if (categoryMid === "피부관리") {
                console.log(`✅ [피부관리 포함] 권장체류일수 ${groupStayDays}일 <= 여행일수 ${effectiveTravelDays}일, 시술 ${treatmentList.length}개 포함`);
            }
            suitableTreatments = treatmentList;
        } else {
            // 권장체류일수가 없으면 기존 로직 사용 (downtime 기반)
            suitableTreatments = treatmentList.filter((treatment)=>{
                const recoveryPeriod = parseRecoveryPeriod(treatment.downtime);
                // 회복기간 정보가 없으면 포함 (기본적으로 표시)
                if (recoveryPeriod === 0) return true;
                // 여행 일수에서 최소 1일은 여유를 둠 (시술 당일 제외)
                // 당일/1박 2일의 경우 effectiveTravelDays=3이므로 2일까지 허용
                // (임시 주석 처리: 1박2일에서 3일짜리 포함 로직 비활성화)
                return recoveryPeriod <= effectiveTravelDays - 1;
            });
        }
        // 필터링 결과가 없거나 회복기간 정보가 없으면 전체 시술 표시 (최대 20개)
        // 권장체류일수 또는 개별 downtime 정보가 있는 경우에만 필터링 적용
        const hasRecoveryData = recommendedStayDays > 0 || treatmentList.some((t)=>parseRecoveryPeriod(t.downtime) > 0);
        const finalTreatments = hasRecoveryData && suitableTreatments.length > 0 ? suitableTreatments : [
            ...treatmentList
        ].sort((a, b)=>{
            // 추천 점수로 정렬
            const scoreA = calculateRecommendationScore(a);
            const scoreB = calculateRecommendationScore(b);
            return scoreB - scoreA;
        }).slice(0, 20); // 최대 20개
        // 회복 기간 정보가 없으면 downtime에서 계산
        if (recoveryMin === 0 && recoveryMax === 0) {
            const recoveryPeriods = finalTreatments.map((t)=>parseRecoveryPeriod(t.downtime)).filter((r)=>r > 0);
            if (recoveryPeriods.length > 0) {
                recoveryMin = Math.min(...recoveryPeriods);
                recoveryMax = Math.max(...recoveryPeriods);
            }
        }
        // 시술 시간 정보가 없으면 surgery_time에서 계산
        if (procedureTimeMin === 0 && procedureTimeMax === 0) {
            const procedureTimes = finalTreatments.map((t)=>parseProcedureTime(t.surgery_time)).filter((t)=>t > 0);
            if (procedureTimes.length > 0) {
                procedureTimeMin = Math.min(...procedureTimes);
                procedureTimeMax = Math.max(...procedureTimes);
            }
        }
        // 평균 회복 기간 계산 (표시용)
        const recoveryPeriods = finalTreatments.map((t)=>parseRecoveryPeriod(t.downtime)).filter((r)=>r > 0);
        const averageRecoveryPeriod = recoveryPeriods.length > 0 ? recoveryPeriods.reduce((sum, r)=>sum + r, 0) / recoveryPeriods.length : recoveryMax > 0 ? (recoveryMin + recoveryMax) / 2 : 0;
        // 평균 시술 시간 계산 (표시용)
        const procedureTimes = finalTreatments.map((t)=>parseProcedureTime(t.surgery_time)).filter((t)=>t > 0);
        const averageProcedureTime = procedureTimes.length > 0 ? procedureTimes.reduce((sum, t)=>sum + t, 0) / procedureTimes.length : procedureTimeMax > 0 ? (procedureTimeMin + procedureTimeMax) / 2 : 0;
        // 추천 점수로 정렬
        const sortedTreatments = finalTreatments.map((treatment)=>({
                ...treatment,
                recommendationScore: calculateRecommendationScore(treatment)
            })).sort((a, b)=>b.recommendationScore - a.recommendationScore);
        const result = {
            categoryMid,
            treatments: sortedTreatments,
            averageRecoveryPeriod: Math.round(averageRecoveryPeriod * 10) / 10,
            averageRecoveryPeriodMin: recoveryMin,
            averageRecoveryPeriodMax: recoveryMax,
            averageProcedureTime: Math.round(averageProcedureTime),
            averageProcedureTimeMin: procedureTimeMin,
            averageProcedureTimeMax: procedureTimeMax
        };
        // 디버깅: 최종 결과 로그
        console.log(`✅ [최종 추천] "${categoryMid}": ${sortedTreatments.length}개 시술 포함, 권장체류일수=${recommendedStayDays}일, 여행일수=${effectiveTravelDays}일`);
        return result;
    });
    const recommendations = (await Promise.all(recommendationsPromises)).filter((rec)=>rec !== null);
    console.log(`📋 [일정 기반 추천 완료] 총 ${recommendations.length}개 중분류 추천 생성됨 (여행일수: ${effectiveTravelDays}일)`);
    const filteredRecommendations = recommendations.filter((rec)=>rec.treatments.length > 0); // 시술이 있는 중분류만
    console.log(`📋 [최종 필터링] 시술이 있는 중분류: ${filteredRecommendations.length}개`);
    if (categoryLarge === "피부") {
        console.log(`🔍 [피부 최종 결과] 중분류 목록:`, filteredRecommendations.map((r)=>({
                중분류: r.categoryMid,
                시술수: r.treatments.length
            })));
    }
    return filteredRecommendations.sort((a, b)=>{
        // 1순위: 인기 점수(가장 상위 시술의 recommendationScore) 높은 순
        const scoreA = a.treatments[0]?.recommendationScore || 0;
        const scoreB = b.treatments[0]?.recommendationScore || 0;
        if (scoreA !== scoreB) {
            return scoreB - scoreA;
        }
        // 2순위: 평균 회복 기간이 짧은 순 (동점일 때 여행 친화적인 순서)
        if (a.averageRecoveryPeriod !== b.averageRecoveryPeriod) {
            return a.averageRecoveryPeriod - b.averageRecoveryPeriod;
        }
        return 0;
    });
}
// 플랫폼 우선순위 (높을수록 우선)
const PLATFORM_PRIORITY = {
    gangnamunni: 3,
    yeoti: 2,
    babitalk: 1
};
function sortTreatmentsByPlatform(treatments) {
    return [
        ...treatments
    ].sort((a, b)=>{
        const platformA = (a.platform || "").toLowerCase();
        const platformB = (b.platform || "").toLowerCase();
        const priorityA = PLATFORM_PRIORITY[platformA] || 0;
        const priorityB = PLATFORM_PRIORITY[platformB] || 0;
        // 우선순위가 높은 것이 앞에 오도록 (내림차순)
        return priorityB - priorityA;
    });
}
function sortHospitalsByPlatform(hospitals) {
    return [
        ...hospitals
    ].sort((a, b)=>{
        const platformA = (a.platform || "").toLowerCase();
        const platformB = (b.platform || "").toLowerCase();
        const priorityA = PLATFORM_PRIORITY[platformA] || 0;
        const priorityB = PLATFORM_PRIORITY[platformB] || 0;
        // 우선순위가 높은 것이 앞에 오도록 (내림차순)
        return priorityB - priorityA;
    });
}
async function saveProcedureReview(data) {
    try {
        const reviewData = {
            user_id: data.user_id ?? 0,
            category: data.category,
            procedure_name: data.procedure_name,
            hospital_name: data.hospital_name || null,
            cost: data.cost,
            procedure_rating: data.procedure_rating,
            hospital_rating: data.hospital_rating,
            gender: data.gender,
            age_group: data.age_group,
            surgery_date: data.surgery_date || null,
            content: data.content,
            images: data.images && data.images.length > 0 ? data.images : null
        };
        const { data: insertedData, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("procedure_reviews").insert([
            reviewData
        ]).select("id").single();
        if (error) {
            console.error("시술후기 저장 실패:", error);
            return {
                success: false,
                error: error.message
            };
        }
        return {
            success: true,
            id: insertedData?.id
        };
    } catch (error) {
        console.error("시술후기 저장 중 오류:", error);
        return {
            success: false,
            error: error?.message || "시술후기 저장에 실패했습니다."
        };
    }
}
async function saveHospitalReview(data) {
    try {
        const reviewData = {
            user_id: data.user_id ?? 0,
            hospital_name: data.hospital_name,
            category_large: data.category_large,
            procedure_name: data.procedure_name || null,
            visit_date: data.visit_date || null,
            overall_satisfaction: data.overall_satisfaction || null,
            hospital_kindness: data.hospital_kindness || null,
            has_translation: data.has_translation ?? false,
            translation_satisfaction: data.has_translation && data.translation_satisfaction ? data.translation_satisfaction : null,
            content: data.content,
            images: data.images && data.images.length > 0 ? data.images : null
        };
        const { data: insertedData, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("hospital_reviews").insert([
            reviewData
        ]).select("id").single();
        if (error) {
            console.error("병원후기 저장 실패:", error);
            return {
                success: false,
                error: error.message
            };
        }
        return {
            success: true,
            id: insertedData?.id
        };
    } catch (error) {
        console.error("병원후기 저장 중 오류:", error);
        return {
            success: false,
            error: error?.message || "병원후기 저장에 실패했습니다."
        };
    }
}
async function saveConcernPost(data) {
    try {
        const postData = {
            user_id: data.user_id ?? 0,
            title: data.title,
            concern_category: data.concern_category,
            content: data.content
        };
        const { data: insertedData, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("concern_posts").insert([
            postData
        ]).select("id").single();
        if (error) {
            console.error("고민글 저장 실패:", error);
            return {
                success: false,
                error: error.message
            };
        }
        return {
            success: true,
            id: insertedData?.id
        };
    } catch (error) {
        console.error("고민글 저장 중 오류:", error);
        return {
            success: false,
            error: error?.message || "고민글 저장에 실패했습니다."
        };
    }
}
async function loadProcedureReviews(limit = 50) {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("procedure_reviews").select("*").order("created_at", {
            ascending: false
        }).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return data;
    } catch (error) {
        console.error("시술 후기 로드 실패:", error);
        return [];
    }
}
async function loadHospitalReviews(limit = 50) {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("hospital_reviews").select("*").order("created_at", {
            ascending: false
        }).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return data;
    } catch (error) {
        console.error("병원 후기 로드 실패:", error);
        return [];
    }
}
async function loadConcernPosts(limit = 50) {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("concern_posts").select("*").order("created_at", {
            ascending: false
        }).limit(limit);
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data) {
            return [];
        }
        return data;
    } catch (error) {
        console.error("고민글 로드 실패:", error);
        return [];
    }
}
async function loadCategoryToggleMap() {
    try {
        const client = getSupabaseOrNull();
        if (!client) return [];
        const { data, error } = await client.from(TABLE_NAMES.CATEGORY_TOGGLE_MAP).select("*");
        if (error) {
            throw new Error(`Supabase 오류: ${error.message}`);
        }
        if (!data || !Array.isArray(data)) {
            return [];
        }
        return cleanData(data);
    } catch (error) {
        console.error("category_toggle_map 데이터 로드 실패:", error);
        return [];
    }
}
async function getRecoveryGuideIdByCategory(categoryMid, keyword) {
    try {
        if (!categoryMid && !keyword) return null;
        const toggleMap = await loadCategoryToggleMap();
        // category_mid로 먼저 찾기
        if (categoryMid) {
            const matched = toggleMap.find((item)=>item.category_mid?.toLowerCase().trim() === categoryMid.toLowerCase().trim());
            if (matched?.recovery_guide_id) {
                return matched.recovery_guide_id;
            }
        }
        // keyword로 찾기
        if (keyword) {
            const normalizedKeyword = keyword.toLowerCase().trim();
            const matched = toggleMap.find((item)=>item.keyword?.toLowerCase().includes(normalizedKeyword) || item.recovery_guide_keyword?.toLowerCase().includes(normalizedKeyword));
            if (matched?.recovery_guide_id) {
                return matched.recovery_guide_id;
            }
        }
        return null;
    } catch (error) {
        console.error("회복 가이드 ID 조회 실패:", error);
        return null;
    }
}
}),
"[project]/contexts/RankingDataContext.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RankingDataProvider",
    ()=>RankingDataProvider,
    "useRankingData",
    ()=>useRankingData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
const RankingDataContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function RankingDataProvider({ children }) {
    const [allTreatments, setAllTreatments] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [lastUpdated, setLastUpdated] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const loadAllData = async ()=>{
        try {
            setLoading(true);
            setError(null);
            // 여러 번 호출하여 모든 데이터 가져오기 (최대 5000개)
            let allData = [];
            let page = 1;
            const pageSize = 1000; // Supabase 최대 limit
            let hasMore = true;
            const maxData = 5000; // 최대 로드 개수 제한
            console.log("🔄 [RankingDataContext] 전체 랭킹 데이터 로드 시작...");
            while(hasMore && allData.length < maxData){
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadTreatmentsPaginated"])(page, pageSize, {
                    skipPlatformSort: true,
                    categoryLarge: undefined,
                    categoryMid: undefined
                });
                allData = [
                    ...allData,
                    ...result.data
                ];
                hasMore = result.hasMore && result.data.length === pageSize;
                page++;
                console.log(`📥 [RankingDataContext] ${allData.length}개 로드 완료 (${page - 1}회 호출)`);
                // 무한 루프 방지
                if (page > 10) {
                    console.warn("⚠️ [RankingDataContext] 최대 호출 횟수 도달, 중단");
                    break;
                }
            }
            setAllTreatments(allData);
            setLastUpdated(new Date());
            console.log(`✅ [RankingDataContext] 전체 데이터 로드 완료: ${allData.length}개`);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : "데이터 로드 실패";
            setError(errorMessage);
            console.error("❌ [RankingDataContext] 데이터 로드 실패:", err);
        } finally{
            setLoading(false);
        }
    };
    // 초기 로드 (컴포넌트 마운트 시 한 번만)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        loadAllData();
    }, []);
    const refreshData = async ()=>{
        await loadAllData();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(RankingDataContext.Provider, {
        value: {
            allTreatments,
            loading,
            error,
            refreshData,
            lastUpdated
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/contexts/RankingDataContext.tsx",
        lineNumber: 93,
        columnNumber: 5
    }, this);
}
function useRankingData() {
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(RankingDataContext);
    if (context === undefined) {
        throw new Error("useRankingData must be used within RankingDataProvider");
    }
    return context;
}
}),
"[project]/components/AppShell.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AppShell
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$RankingDataContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/RankingDataContext.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
function AppShell({ children }) {
    const [showSplash, setShowSplash] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const timer = setTimeout(()=>{
            setShowSplash(false);
        }, 1500); // 1.5초 후 스플래시 종료
        return ()=>clearTimeout(timer);
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$RankingDataContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RankingDataProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-md bg-white min-h-screen shadow-lg relative overflow-hidden",
            children: [
                children,
                showSplash && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "fixed inset-0 z-50 flex flex-col items-center justify-center bg-white",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: "/beautrip-logo.png",
                        alt: "BeauTrip",
                        className: "w-40 h-auto object-contain"
                    }, void 0, false, {
                        fileName: "[project]/components/AppShell.tsx",
                        lineNumber: 23,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/AppShell.tsx",
                    lineNumber: 22,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/AppShell.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/AppShell.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__30dbed41._.js.map