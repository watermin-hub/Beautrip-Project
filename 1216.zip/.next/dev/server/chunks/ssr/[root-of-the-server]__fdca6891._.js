module.exports = [
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/components/AutocompleteInput.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AutocompleteInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
"use client";
;
;
;
function AutocompleteInput({ value, onChange, placeholder = "검색...", suggestions, onSuggestionSelect, onEnter, className = "" }) {
    const [showSuggestions, setShowSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [focusedIndex, setFocusedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(-1);
    const [isComposing, setIsComposing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false); // 한글 입력 조합 중인지 추적
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const suggestionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // 외부 클릭 시 자동완성 닫기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleClickOutside = (event)=>{
            if (inputRef.current && !inputRef.current.contains(event.target) && suggestionsRef.current && !suggestionsRef.current.contains(event.target)) {
                setShowSuggestions(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>document.removeEventListener("mousedown", handleClickOutside);
    }, []);
    // 자동완성 선택으로 인한 value 변경인지 추적
    const isSuggestionSelectedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(false);
    // 검색어가 변경되면 자동완성 표시
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // 자동완성 선택으로 인한 value 변경이면 자동완성을 다시 열지 않음
        if (isSuggestionSelectedRef.current) {
            isSuggestionSelectedRef.current = false;
            return;
        }
        setShowSuggestions(value.length > 0 && suggestions.length > 0);
        setFocusedIndex(-1);
    }, [
        value,
        suggestions
    ]);
    const handleInputChange = (e)=>{
        // 항상 onChange 호출 (입력 필드가 업데이트되도록)
        onChange(e.target.value);
    };
    // 한글 입력 조합 시작
    const handleCompositionStart = ()=>{
        setIsComposing(true);
    };
    // 한글 입력 조합 종료
    const handleCompositionEnd = (e)=>{
        setIsComposing(false);
        // 조합이 완료되면 최종 값을 onChange로 전달 (이미 handleInputChange에서 호출되지만 확실히 하기 위해)
        onChange(e.currentTarget.value);
    };
    const handleSuggestionClick = (suggestion)=>{
        // 자동완성 선택 플래그 설정 (value 변경으로 인해 자동완성이 다시 열리지 않도록)
        isSuggestionSelectedRef.current = true;
        // 먼저 자동완성을 닫고, 그 다음에 onChange 호출
        setShowSuggestions(false);
        onChange(suggestion);
        if (onSuggestionSelect) {
            onSuggestionSelect(suggestion);
        }
        inputRef.current?.blur();
    };
    const handleKeyDown = (e)=>{
        if (e.key === "Enter") {
            if (showSuggestions && suggestions.length > 0 && focusedIndex >= 0) {
                // 자동완성 항목이 선택된 경우
                e.preventDefault();
                handleSuggestionClick(suggestions[focusedIndex]);
            } else if (onEnter && value.trim().length >= 2) {
                // 자동완성 항목이 선택되지 않은 경우 Enter 키 처리 (2글자 이상일 때만)
                e.preventDefault();
                onEnter();
            }
            return;
        }
        if (!showSuggestions || suggestions.length === 0) return;
        if (e.key === "ArrowDown") {
            e.preventDefault();
            setFocusedIndex((prev)=>prev < suggestions.length - 1 ? prev + 1 : prev);
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setFocusedIndex((prev)=>prev > 0 ? prev - 1 : -1);
        } else if (e.key === "Escape") {
            setShowSuggestions(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-3 top-1/2 transform -translate-y-1/2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiSearch"], {
                            className: "text-gray-400 text-sm"
                        }, void 0, false, {
                            fileName: "[project]/components/AutocompleteInput.tsx",
                            lineNumber: 124,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 123,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: inputRef,
                        type: "text",
                        value: value,
                        onChange: handleInputChange,
                        onCompositionStart: handleCompositionStart,
                        onCompositionEnd: handleCompositionEnd,
                        onKeyDown: handleKeyDown,
                        onFocus: ()=>{
                            if (value.length > 0 && suggestions.length > 0) {
                                setShowSuggestions(true);
                            }
                        },
                        placeholder: placeholder,
                        className: `w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-main ${className}`
                    }, void 0, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/AutocompleteInput.tsx",
                lineNumber: 122,
                columnNumber: 7
            }, this),
            showSuggestions && suggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: suggestionsRef,
                className: "absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto",
                children: suggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>handleSuggestionClick(suggestion),
                        onMouseEnter: ()=>setFocusedIndex(index),
                        className: `w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${index === focusedIndex ? "bg-gray-50" : ""}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiSearch"], {
                                    className: "text-gray-400 text-xs"
                                }, void 0, false, {
                                    fileName: "[project]/components/AutocompleteInput.tsx",
                                    lineNumber: 161,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: suggestion
                                }, void 0, false, {
                                    fileName: "[project]/components/AutocompleteInput.tsx",
                                    lineNumber: 162,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/AutocompleteInput.tsx",
                            lineNumber: 160,
                            columnNumber: 15
                        }, this)
                    }, index, false, {
                        fileName: "[project]/components/AutocompleteInput.tsx",
                        lineNumber: 151,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/AutocompleteInput.tsx",
                lineNumber: 146,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/AutocompleteInput.tsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/SearchModal.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SearchModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AutocompleteInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/AutocompleteInput.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
const MAX_RECENT_SEARCHES = 10; // 최대 최근 검색어 개수
const recommendedSearches = [
    {
        id: 1,
        name: "리쥬란힐러",
        badge: "BEST"
    },
    {
        id: 2,
        name: "써마지",
        badge: "BEST"
    },
    {
        id: 3,
        name: "쥬베룩",
        badge: "BEST"
    },
    {
        id: 4,
        name: "울쎄라",
        badge: "up"
    },
    {
        id: 5,
        name: "LDM",
        badge: "up"
    },
    {
        id: 6,
        name: "스킨부"
    },
    {
        id: 7,
        name: "올리지"
    },
    {
        id: 8,
        name: "튠페"
    },
    {
        id: 9,
        name: "쎄라플"
    },
    {
        id: 10,
        name: "리프터"
    }
];
const quickIcons = [
    {
        id: 1,
        label: "블프 세일 대축제",
        icon: "🛍️"
    },
    {
        id: 2,
        label: "요즘인기시술",
        icon: "⭐"
    },
    {
        id: 3,
        label: "혜택 플러스",
        icon: "💎"
    },
    {
        id: 4,
        label: "포인트 적립백서",
        icon: "📝"
    },
    {
        id: 5,
        label: "부작용 안심케어",
        icon: "🛡️"
    }
];
const recentEvents = [
    {
        id: 1,
        title: "Shurink Universe",
        clinic: "본연_슈링크 유니버스",
        location: "서울 강남역·본연성...",
        price: "120,000원",
        image: ""
    },
    {
        id: 2,
        title: "Eight longtime #인모드 #슈링크",
        clinic: "지방소멸 롱타임 인모드리프팅 슈링...",
        location: "서울 압구정역·에이...",
        price: "₩108,900",
        image: ""
    },
    {
        id: 3,
        title: "시술 시간 걱정 없이 인모드는 롱~모드로!",
        clinic: "롱모드 인모드 풀페이스 10분 FX...",
        location: "서울 홍대입구역·리...",
        price: "99,000원",
        image: ""
    },
    {
        id: 4,
        title: "후기 6,000+ 디에이 자려한 코성형",
        clinic: "예쁘면DA야_자려한 코성형_비순각코수...",
        location: "서울 역삼역·디에이...",
        price: "1,088,000원",
        image: ""
    }
];
const interestProcedures = [
    "인모드리프팅",
    "슈링크리프팅",
    "슈링크유니버스",
    "코재수술",
    "아이슈링크"
];
const categories = [
    {
        icon: "👁️",
        label: "눈성형"
    },
    {
        icon: "👃",
        label: "코성형"
    },
    {
        icon: "😊",
        label: "안면윤곽/양악"
    },
    {
        icon: "💪",
        label: "가슴성형"
    },
    {
        icon: "🏃",
        label: "지방성형"
    },
    {
        icon: "💉",
        label: "필러"
    },
    {
        icon: "💉",
        label: "보톡스"
    },
    {
        icon: "✨",
        label: "리프팅"
    },
    {
        icon: "🌟",
        label: "피부"
    },
    {
        icon: "✂️",
        label: "제모"
    },
    {
        icon: "💇",
        label: "모발이식"
    },
    {
        icon: "🦷",
        label: "치아"
    },
    {
        icon: "🍵",
        label: "한방"
    },
    {
        icon: "📦",
        label: "기타"
    }
];
function SearchModal({ isOpen, onClose }) {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedRegion, setSelectedRegion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("지역");
    const [recentSearches, setRecentSearches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [autocompleteSuggestions, setAutocompleteSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    // localStorage에서 최근 검색어 불러오기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }, []);
    // 자동완성 데이터 로드
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const loadAutocomplete = async ()=>{
            if (searchQuery.length < 1) {
                setAutocompleteSuggestions([]);
                return;
            }
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTreatmentAutocomplete"])(searchQuery, 10);
            const allSuggestions = [
                ...result.treatmentNames,
                ...result.hospitalNames
            ];
            setAutocompleteSuggestions(allSuggestions);
        };
        const debounceTimer = setTimeout(()=>{
            loadAutocomplete();
        }, 300);
        return ()=>clearTimeout(debounceTimer);
    }, [
        searchQuery
    ]);
    // 최근 검색어에 추가하는 함수
    const addToRecentSearches = (query)=>{
        const trimmedQuery = query.trim();
        if (!trimmedQuery) return;
        setRecentSearches((prev)=>{
            // 중복 제거 (기존 항목 제거 후 맨 앞에 추가)
            const filtered = prev.filter((item)=>item !== trimmedQuery);
            const updated = [
                trimmedQuery,
                ...filtered
            ].slice(0, MAX_RECENT_SEARCHES);
            // localStorage에 저장
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            return updated;
        });
    };
    // 개별 검색어 삭제
    const removeRecentSearch = (query, e)=>{
        e.stopPropagation(); // 버튼 클릭 이벤트 전파 방지
        setRecentSearches((prev)=>{
            const updated = prev.filter((item)=>item !== query);
            // localStorage에 저장
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            return updated;
        });
    };
    // 전체 검색어 삭제
    const clearAllRecentSearches = ()=>{
        setRecentSearches([]);
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    };
    const handleSearch = ()=>{
        if (searchQuery.trim()) {
            // 최근 검색어에 추가
            addToRecentSearches(searchQuery.trim());
            // 탐색 페이지로 이동하면서 검색어와 섹션 정보 전달
            router.push(`/explore?search=${encodeURIComponent(searchQuery.trim())}&section=procedure`);
            onClose();
        }
    };
    const handleKeyPress = (e)=>{
        if (e.key === "Enter") {
            handleSearch();
        }
    };
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[100] bg-white overflow-y-auto max-w-md mx-auto left-1/2 transform -translate-x-1/2 pb-20 w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sticky top-0 z-50 bg-white border-b border-gray-100 px-4 py-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClose,
                                className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                                    className: "text-gray-700 text-xl"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 218,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 214,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 relative",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$AutocompleteInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    value: searchQuery,
                                    onChange: setSearchQuery,
                                    placeholder: "시술명/수술명을 입력해 주세요.",
                                    suggestions: autocompleteSuggestions,
                                    onSuggestionSelect: (suggestion)=>{
                                        setSearchQuery(suggestion);
                                        // 자동완성 선택 시 바로 검색 실행
                                        setTimeout(()=>{
                                            handleSearch();
                                        }, 100);
                                    },
                                    onEnter: handleSearch,
                                    className: "bg-gray-50 border border-gray-200"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 221,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 220,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleSearch,
                                className: "px-3 py-2 text-primary-main text-sm font-medium hover:bg-primary-main/10 rounded-lg transition-colors",
                                children: "검색"
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 237,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 213,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "flex items-center gap-1 text-gray-700 text-sm hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: selectedRegion
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 248,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiChevronDown"], {
                                    className: "text-gray-500 text-sm"
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 249,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/SearchModal.tsx",
                            lineNumber: 247,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 246,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SearchModal.tsx",
                lineNumber: 212,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 py-6 space-y-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative bg-black rounded-2xl overflow-hidden p-6 min-h-[160px] flex items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute inset-0 opacity-5",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-0",
                                    style: {
                                        backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.1) 10px, rgba(255,255,255,0.1) 20px)"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/components/SearchModal.tsx",
                                    lineNumber: 259,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 258,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative w-full",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start justify-between mb-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-white text-xs",
                                                children: "K-피부시술 세일 페스타, 모든 시술이 한자리에!"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 269,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-primary-main text-white px-3 py-1 rounded-full text-xs font-bold flex-shrink-0 ml-2",
                                                children: "~49% off"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 272,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 268,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-4xl font-black mb-3 leading-tight",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white",
                                                children: "BLACK"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 277,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-primary-light relative",
                                                children: [
                                                    "BEAUTY",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "absolute -top-1 -right-3 text-primary-main text-xs",
                                                        children: "★"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 280,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 278,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white",
                                                children: "FRIDAY"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 284,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 276,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-white text-sm",
                                        children: "11.11 — 12.10"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 286,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 267,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 257,
                        columnNumber: 9
                    }, this),
                    recentSearches.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-base font-bold text-gray-900",
                                        children: "최근 검색어"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 294,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: clearAllRecentSearches,
                                        className: "text-sm text-gray-500 hover:text-gray-700",
                                        children: "전체삭제"
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 295,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 293,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 flex-wrap",
                                children: recentSearches.map((search, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setSearchQuery(search);
                                            addToRecentSearches(search); // 클릭 시에도 최근 검색어에 추가 (순서 업데이트)
                                            router.push(`/explore?search=${encodeURIComponent(search)}&section=procedure`);
                                            onClose();
                                        },
                                        className: "flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-full text-sm transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: search
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 318,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                onClick: (e)=>{
                                                    e.stopPropagation();
                                                    removeRecentSearch(search, e);
                                                },
                                                className: "hover:bg-gray-300 rounded-full p-0.5 transition-colors cursor-pointer",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IoClose"], {
                                                    className: "text-gray-500 text-sm"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/SearchModal.tsx",
                                                    lineNumber: 326,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 319,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, index, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 304,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 302,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 292,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-5 gap-4",
                        children: quickIcons.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "flex flex-col items-center gap-2 p-3 hover:bg-gray-50 rounded-xl transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-12 h-12 bg-gradient-to-br from-primary-light/20 to-primary-main/30 rounded-full flex items-center justify-center text-xl",
                                        children: item.icon
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 341,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-700 text-center leading-tight",
                                        children: item.label
                                    }, void 0, false, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 344,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, item.id, true, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 337,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 335,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-base font-bold text-gray-900 mb-4",
                                children: "추천 검색어"
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 353,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-4",
                                children: recommendedSearches.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setSearchQuery(item.name);
                                            addToRecentSearches(item.name); // 추천 검색어 클릭 시에도 최근 검색어에 추가
                                            router.push(`/explore?search=${encodeURIComponent(item.name)}&section=procedure`);
                                            onClose();
                                        },
                                        className: "flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors text-left",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-primary-main font-bold text-sm min-w-[20px]",
                                                        children: item.id
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 373,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-gray-900 text-sm",
                                                        children: item.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/SearchModal.tsx",
                                                        lineNumber: 376,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 372,
                                                columnNumber: 17
                                            }, this),
                                            item.badge === "BEST" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "bg-primary-light/20 text-primary-main px-2 py-0.5 rounded text-xs font-semibold",
                                                children: "BEST"
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 379,
                                                columnNumber: 19
                                            }, this),
                                            item.badge === "up" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-3 h-3 text-primary-main",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    fillRule: "evenodd",
                                                    d: "M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z",
                                                    clipRule: "evenodd"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/SearchModal.tsx",
                                                    lineNumber: 389,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/SearchModal.tsx",
                                                lineNumber: 384,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, item.id, true, {
                                        fileName: "[project]/components/SearchModal.tsx",
                                        lineNumber: 358,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/SearchModal.tsx",
                                lineNumber: 356,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/SearchModal.tsx",
                        lineNumber: 352,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/SearchModal.tsx",
                lineNumber: 255,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/SearchModal.tsx",
        lineNumber: 210,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/Header.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/bs/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SearchModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SearchModal.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
function Header({ hasRankingBanner = false }) {
    const [isSearchOpen, setIsSearchOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLanguageOpen, setIsLanguageOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [logoError, setLogoError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const globeButtonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { language, setLanguage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLanguage"])();
    const [dropdownPosition, setDropdownPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        top: 0,
        right: 0
    });
    const languages = [
        {
            code: "KR",
            name: "한국어",
            flag: "🇰🇷"
        },
        {
            code: "EN",
            name: "English",
            flag: "🇺🇸"
        },
        {
            code: "JP",
            name: "日本語",
            flag: "🇯🇵"
        },
        {
            code: "CN",
            name: "中文",
            flag: "🇨🇳"
        }
    ];
    const selectedLanguage = languages.find((lang)=>lang.code === language) || languages[0];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (isLanguageOpen && globeButtonRef.current) {
            const rect = globeButtonRef.current.getBoundingClientRect();
            setDropdownPosition({
                top: rect.bottom + 8,
                right: window.innerWidth - rect.right
            });
        }
    }, [
        isLanguageOpen
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: `sticky ${hasRankingBanner ? "top-[41px]" : "top-0"} z-40 bg-white border-b border-gray-100 px-4 py-3`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>router.push("/"),
                            className: "flex items-center gap-2 hover:opacity-80 transition-opacity cursor-pointer",
                            children: !logoError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/beautrip-logo.png",
                                alt: "BeauTrip",
                                className: "h-6 w-auto object-contain",
                                onError: ()=>setLogoError(true)
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 63,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$bs$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BsCloud"], {
                                className: "text-primary-main text-xl"
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 70,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4 relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setIsSearchOpen(true),
                                    className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiSearch"], {
                                        className: "text-gray-700 text-xl"
                                    }, void 0, false, {
                                        fileName: "[project]/components/Header.tsx",
                                        lineNumber: 81,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            ref: globeButtonRef,
                                            onClick: ()=>setIsLanguageOpen(!isLanguageOpen),
                                            className: "p-2 hover:bg-gray-50 rounded-full transition-colors relative z-[100]",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiGlobe"], {
                                                className: "text-gray-700 text-xl"
                                            }, void 0, false, {
                                                fileName: "[project]/components/Header.tsx",
                                                lineNumber: 89,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this),
                                        isLanguageOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "fixed inset-0 z-[99]",
                                                    onClick: ()=>setIsLanguageOpen(false)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Header.tsx",
                                                    lineNumber: 93,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "fixed bg-white border border-gray-200 rounded-lg shadow-lg z-[100] min-w-[150px]",
                                                    style: {
                                                        top: `${dropdownPosition.top}px`,
                                                        right: `${dropdownPosition.right}px`
                                                    },
                                                    children: languages.map((lang)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>{
                                                                setLanguage(lang.code);
                                                                setIsLanguageOpen(false);
                                                            },
                                                            className: `w-full text-left px-4 py-2 hover:bg-gray-50 transition-colors flex items-center gap-2 ${selectedLanguage.code === lang.code ? "bg-primary-main/10" : ""}`,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: lang.flag
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 117,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-gray-700",
                                                                    children: lang.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 118,
                                                                    columnNumber: 25
                                                                }, this),
                                                                selectedLanguage.code === lang.code && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "ml-auto text-primary-main",
                                                                    children: "✓"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/Header.tsx",
                                                                    lineNumber: 122,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, lang.code, true, {
                                                            fileName: "[project]/components/Header.tsx",
                                                            lineNumber: 105,
                                                            columnNumber: 23
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Header.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 83,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "p-2 hover:bg-gray-50 rounded-full transition-colors relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiBell"], {
                                            className: "text-gray-700 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 131,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Header.tsx",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Header.tsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/Header.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/Header.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SearchModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isSearchOpen,
                onClose: ()=>setIsSearchOpen(false)
            }, void 0, false, {
                fileName: "[project]/components/Header.tsx",
                lineNumber: 137,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/components/BottomNavigation.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BottomNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
const navItems = [
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiHome"],
        labelKey: "nav.home",
        path: "/"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiCompass"],
        labelKey: "nav.explore",
        path: "/explore"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiUsers"],
        labelKey: "nav.community",
        path: "/community"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiCalendar"],
        labelKey: "nav.schedule",
        path: "/schedule"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiUser"],
        labelKey: "nav.mypage",
        path: "/mypage"
    }
];
function BottomNavigation({ disabled = false }) {
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLanguage"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: `fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 z-50 ${disabled ? "pointer-events-none" : ""}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-around items-center py-2",
            children: navItems.map((item)=>{
                const Icon = item.icon;
                const isActive = pathname === item.path;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    href: item.path,
                    className: `flex flex-col items-center justify-center gap-1 py-1 px-2 min-w-0 flex-1 transition-colors ${disabled ? "text-gray-300 cursor-not-allowed" : isActive ? "text-primary-main" : "text-gray-500"}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                            className: `text-xl ${disabled ? "text-gray-300" : isActive ? "text-primary-main" : "text-gray-500"}`
                        }, void 0, false, {
                            fileName: "[project]/components/BottomNavigation.tsx",
                            lineNumber: 43,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: `text-xs whitespace-nowrap ${disabled ? "text-gray-300" : isActive ? "text-primary-main font-medium" : "text-gray-500"}`,
                            children: t(item.labelKey)
                        }, void 0, false, {
                            fileName: "[project]/components/BottomNavigation.tsx",
                            lineNumber: 52,
                            columnNumber: 15
                        }, this)
                    ]
                }, item.path, true, {
                    fileName: "[project]/components/BottomNavigation.tsx",
                    lineNumber: 32,
                    columnNumber: 13
                }, this);
            })
        }, void 0, false, {
            fileName: "[project]/components/BottomNavigation.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/BottomNavigation.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/ReviewWriteModal.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ReviewWriteModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
'use client';
;
;
;
function ReviewWriteModal({ isOpen, onClose, filterData }) {
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [rating, setRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [procedure, setProcedure] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [clinic, setClinic] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [images, setImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (filterData?.category && filterData.category !== 'All') {
            setProcedure(filterData.category);
        }
        if (filterData?.rating && filterData.rating !== 'All') {
            setRating(parseInt(filterData.rating));
        }
    }, [
        filterData
    ]);
    if (!isOpen) return null;
    const handleImageUpload = (e)=>{
        if (e.target.files) {
            const files = Array.from(e.target.files);
            const newImages = files.map((file)=>URL.createObjectURL(file));
            setImages([
                ...images,
                ...newImages
            ].slice(0, 5));
        }
    };
    const handleSubmit = ()=>{
        if (!content.trim()) {
            alert('리뷰 내용을 입력해주세요.');
            return;
        }
        const newReview = {
            id: Date.now(),
            category: '후기',
            username: '사용자',
            avatar: '👤',
            content: content,
            images: images.length > 0 ? images : undefined,
            timestamp: '방금 전',
            upvotes: 0,
            comments: 0,
            views: 0,
            rating: rating > 0 ? rating : undefined,
            procedure: procedure || undefined,
            clinic: clinic || undefined
        };
        // 로컬 스토리지에 저장
        const existingReviews = JSON.parse(localStorage.getItem('reviews') || '[]');
        existingReviews.unshift(newReview);
        localStorage.setItem('reviews', JSON.stringify(existingReviews));
        // 이벤트 발생하여 최신글 업데이트
        window.dispatchEvent(new Event('reviewAdded'));
        alert('리뷰가 작성되었습니다!');
        setContent('');
        setRating(0);
        setProcedure('');
        setClinic('');
        setImages([]);
        onClose();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[100] bg-black/50 flex items-center justify-center p-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-md mx-auto bg-white rounded-2xl max-h-[90vh] overflow-y-auto pb-20",
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sticky top-0 bg-white border-b border-gray-200 px-4 py-4 flex items-center justify-between z-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-lg font-bold text-gray-900",
                            children: "리뷰 작성"
                        }, void 0, false, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 106,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "p-2 hover:bg-gray-100 rounded-full transition-colors",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiX"], {
                                className: "text-xl text-gray-700"
                            }, void 0, false, {
                                fileName: "[project]/components/ReviewWriteModal.tsx",
                                lineNumber: 111,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 107,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ReviewWriteModal.tsx",
                    lineNumber: 105,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-4 py-6 space-y-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-semibold text-gray-900 mb-2 block",
                                    children: "시술 종류"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 119,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    value: procedure,
                                    onChange: (e)=>setProcedure(e.target.value),
                                    placeholder: "받으신 시술을 입력해주세요",
                                    className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-main"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 120,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 118,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-semibold text-gray-900 mb-2 block",
                                    children: "병원/클리닉"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 131,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    value: clinic,
                                    onChange: (e)=>setClinic(e.target.value),
                                    placeholder: "병원 또는 클리닉 이름을 입력해주세요",
                                    className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-main"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 132,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 130,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-semibold text-gray-900 mb-2 block",
                                    children: "평점"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 143,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-2",
                                    children: [
                                        1,
                                        2,
                                        3,
                                        4,
                                        5
                                    ].map((star)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>setRating(star),
                                            className: "p-2",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiStar"], {
                                                className: `text-2xl ${star <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`
                                            }, void 0, false, {
                                                fileName: "[project]/components/ReviewWriteModal.tsx",
                                                lineNumber: 151,
                                                columnNumber: 19
                                            }, this)
                                        }, star, false, {
                                            fileName: "[project]/components/ReviewWriteModal.tsx",
                                            lineNumber: 146,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 144,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 142,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-semibold text-gray-900 mb-2 block",
                                    children: "리뷰 내용"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 165,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                    value: content,
                                    onChange: (e)=>setContent(e.target.value),
                                    placeholder: "시술 경험을 자세히 작성해주세요...",
                                    rows: 8,
                                    className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-main resize-none"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 166,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 164,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-semibold text-gray-900 mb-2 block",
                                    children: "사진 첨부 (최대 5장)"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 177,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-2 flex-wrap",
                                    children: [
                                        images.map((img, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative w-24 h-24 rounded-lg overflow-hidden",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: img,
                                                        alt: `Upload ${idx + 1}`,
                                                        className: "w-full h-full object-cover"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ReviewWriteModal.tsx",
                                                        lineNumber: 181,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>setImages(images.filter((_, i)=>i !== idx)),
                                                        className: "absolute top-1 right-1 bg-black/50 text-white rounded-full p-1",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiX"], {
                                                            className: "text-xs"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ReviewWriteModal.tsx",
                                                            lineNumber: 186,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ReviewWriteModal.tsx",
                                                        lineNumber: 182,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, idx, true, {
                                                fileName: "[project]/components/ReviewWriteModal.tsx",
                                                lineNumber: 180,
                                                columnNumber: 17
                                            }, this)),
                                        images.length < 5 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "w-24 h-24 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center cursor-pointer hover:border-primary-main transition-colors",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "file",
                                                    accept: "image/*",
                                                    multiple: true,
                                                    onChange: handleImageUpload,
                                                    className: "hidden"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                                    lineNumber: 192,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiImage"], {
                                                    className: "text-2xl text-gray-400"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                                    lineNumber: 199,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/ReviewWriteModal.tsx",
                                            lineNumber: 191,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ReviewWriteModal.tsx",
                                    lineNumber: 178,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 176,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ReviewWriteModal.tsx",
                    lineNumber: 116,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sticky bottom-0 bg-white border-t border-gray-200 px-4 py-4 flex gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-semibold transition-colors hover:bg-gray-200",
                            children: "취소"
                        }, void 0, false, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 208,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleSubmit,
                            className: "flex-1 bg-primary-main text-white py-3 rounded-lg font-semibold transition-colors hover:bg-[#2DB8A0]",
                            children: "작성 완료"
                        }, void 0, false, {
                            fileName: "[project]/components/ReviewWriteModal.tsx",
                            lineNumber: 214,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ReviewWriteModal.tsx",
                    lineNumber: 207,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/ReviewWriteModal.tsx",
            lineNumber: 100,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ReviewWriteModal.tsx",
        lineNumber: 99,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/ReviewFilterModal.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ReviewFilterModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ReviewWriteModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ReviewWriteModal.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
function ReviewFilterModal({ isOpen, onClose }) {
    const [selectedGender, setSelectedGender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('All');
    const [selectedCategory, setSelectedCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('All');
    const [selectedRating, setSelectedRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('All');
    const [selectedDistance, setSelectedDistance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('All');
    const [showWriteModal, setShowWriteModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    if (!isOpen) return null;
    const handleApplyFilter = ()=>{
        setShowWriteModal(true);
    };
    const handleReset = ()=>{
        setSelectedGender('All');
        setSelectedCategory('All');
        setSelectedRating('All');
        setSelectedDistance('All');
    };
    const handleCloseWriteModal = ()=>{
        setShowWriteModal(false);
        onClose();
    };
    const genders = [
        'All',
        'Male',
        'Female',
        'Others'
    ];
    const categories = [
        'All',
        '눈성형',
        '코성형',
        '리프팅',
        '피부',
        '보톡스/필러'
    ];
    const ratings = [
        'All',
        '5',
        '4',
        '3',
        '2',
        '1'
    ];
    const distances = [
        'All',
        '1 Km',
        '1-3 Km',
        '3-5 Km',
        '5 Km 이상'
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-[100] bg-black/50 flex items-end justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full max-w-md bg-white rounded-t-3xl max-h-[85vh] overflow-y-auto animate-slide-up pb-20",
                    onClick: (e)=>e.stopPropagation(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "sticky top-0 bg-white border-b border-gray-200 px-4 py-4 flex items-center justify-between z-10",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-bold text-gray-900",
                                    children: "Filter your Need"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onClose,
                                    className: "p-2 hover:bg-gray-100 rounded-full transition-colors",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiX"], {
                                        className: "text-xl text-gray-700"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ReviewFilterModal.tsx",
                                        lineNumber: 56,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 52,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewFilterModal.tsx",
                            lineNumber: 50,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-4 py-6 space-y-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-semibold text-gray-900 mb-3 block",
                                            children: "성별"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 64,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2 flex-wrap",
                                            children: genders.map((gender)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>setSelectedGender(gender),
                                                    className: `px-4 py-2 rounded-full text-sm font-medium transition-colors ${selectedGender === gender ? 'bg-primary-main text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`,
                                                    children: gender === 'All' ? '전체' : gender === 'Male' ? '남성' : gender === 'Female' ? '여성' : '기타'
                                                }, gender, false, {
                                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                                    lineNumber: 67,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 63,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-semibold text-gray-900 mb-3 block",
                                            children: "시술 카테고리"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2 flex-wrap",
                                            children: categories.map((category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>setSelectedCategory(category),
                                                    className: `px-4 py-2 rounded-full text-sm font-medium transition-colors ${selectedCategory === category ? 'bg-primary-main text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`,
                                                    children: category
                                                }, category, false, {
                                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                                    lineNumber: 87,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 85,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 83,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-semibold text-gray-900 mb-3 block",
                                            children: "평점"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 104,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2 flex-wrap",
                                            children: ratings.map((rating)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>setSelectedRating(rating),
                                                    className: `px-4 py-2 rounded-full text-sm font-medium transition-colors flex items-center gap-1 ${selectedRating === rating ? 'bg-primary-main text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`,
                                                    children: [
                                                        rating !== 'All' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: "⭐"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                                            lineNumber: 116,
                                                            columnNumber: 42
                                                        }, this),
                                                        rating === 'All' ? '전체' : rating
                                                    ]
                                                }, rating, true, {
                                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                                    lineNumber: 107,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 105,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 103,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-semibold text-gray-900 mb-3 block",
                                            children: "거리"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 125,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2 flex-wrap",
                                            children: distances.map((distance)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>setSelectedDistance(distance),
                                                    className: `px-4 py-2 rounded-full text-sm font-medium transition-colors ${selectedDistance === distance ? 'bg-primary-main text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`,
                                                    children: distance === 'All' ? '전체' : distance
                                                }, distance, false, {
                                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                                    lineNumber: 128,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/components/ReviewFilterModal.tsx",
                                            lineNumber: 126,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 124,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewFilterModal.tsx",
                            lineNumber: 61,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "sticky bottom-0 bg-white border-t border-gray-200 px-4 py-4 flex gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleReset,
                                    className: "flex-1 bg-white border border-gray-300 text-gray-700 py-3 rounded-lg font-semibold transition-colors hover:bg-gray-50",
                                    children: "Reset"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 146,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleApplyFilter,
                                    className: "flex-1 bg-primary-main text-white py-3 rounded-lg font-semibold transition-colors hover:bg-[#2DB8A0]",
                                    children: "Apply Filter"
                                }, void 0, false, {
                                    fileName: "[project]/components/ReviewFilterModal.tsx",
                                    lineNumber: 152,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ReviewFilterModal.tsx",
                            lineNumber: 145,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ReviewFilterModal.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ReviewFilterModal.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            showWriteModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ReviewWriteModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showWriteModal,
                onClose: handleCloseWriteModal,
                filterData: {
                    gender: selectedGender,
                    category: selectedCategory,
                    rating: selectedRating,
                    distance: selectedDistance
                }
            }, void 0, false, {
                fileName: "[project]/components/ReviewFilterModal.tsx",
                lineNumber: 163,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/components/CommunityHeader.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommunityHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ReviewFilterModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ReviewFilterModal.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function CommunityHeader({ activeTab, onTabChange }) {
    const [isFilterOpen, setIsFilterOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const tabs = [
        {
            id: "popular",
            label: "인기글"
        },
        {
            id: "latest",
            label: "최신글"
        },
        {
            id: "info",
            label: "정보컨텐츠"
        },
        {
            id: "consultation",
            label: "고민상담소"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sticky top-[48px] z-20 bg-white border-b border-gray-100",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between px-4 py-4 border-b border-gray-100",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-xl font-bold text-gray-900",
                                children: "커뮤니티"
                            }, void 0, false, {
                                fileName: "[project]/components/CommunityHeader.tsx",
                                lineNumber: 31,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiSend"], {
                                            className: "text-gray-700 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/CommunityHeader.tsx",
                                            lineNumber: 34,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityHeader.tsx",
                                        lineNumber: 33,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setIsFilterOpen(true),
                                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiEdit3"], {
                                            className: "text-gray-700 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/CommunityHeader.tsx",
                                            lineNumber: 40,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityHeader.tsx",
                                        lineNumber: 36,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/CommunityHeader.tsx",
                                lineNumber: 32,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/CommunityHeader.tsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-6 px-4 py-3",
                        children: tabs.map((tab)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>onTabChange(tab.id),
                                className: `text-sm font-medium transition-colors pb-2 relative ${activeTab === tab.id ? "text-gray-900" : "text-gray-500"}`,
                                children: [
                                    tab.label,
                                    activeTab === tab.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute bottom-0 left-0 right-0 h-0.5 bg-primary-main"
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityHeader.tsx",
                                        lineNumber: 57,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, tab.id, true, {
                                fileName: "[project]/components/CommunityHeader.tsx",
                                lineNumber: 48,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/CommunityHeader.tsx",
                        lineNumber: 46,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/CommunityHeader.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ReviewFilterModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isFilterOpen,
                onClose: ()=>setIsFilterOpen(false)
            }, void 0, false, {
                fileName: "[project]/components/CommunityHeader.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/components/PostList.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PostList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const recommendedPosts = [
    {
        id: 1,
        category: "정보공유",
        username: "뷰티매니아",
        avatar: "💎",
        content: "강남역 근처 추천 클리닉 리스트 공유해요! 가격대비 품질이 좋은 곳들만 골라봤어요. 특히 리쥬란 힐러 시술 받았을 때 만족도가 높았던 곳 위주로 정리했습니다...더 보기",
        images: [
            "clinic1",
            "clinic2"
        ],
        timestamp: "5시간 전",
        upvotes: 142,
        comments: 89,
        views: 8234,
        likes: 256
    },
    {
        id: 2,
        category: "질문답변",
        username: "시술초보자",
        avatar: "🌱",
        content: "처음으로 보톡스 맞으려는데 어떤 클리닉이 좋을까요? 강남 지역 위주로 추천 부탁드려요. 가격도 궁금하고 부작용 걱정도 되네요...더 보기",
        timestamp: "8시간 전",
        upvotes: 98,
        comments: 156,
        views: 6452
    },
    {
        id: 3,
        category: "정보공유",
        username: "스킨케어러버",
        avatar: "✨",
        content: "인모드 리프팅 전후 비교 사진 공유합니다! 3개월 차인데 효과가 정말 만족스러워요. 특히 턱선이 확실히 올라간 게 보이시나요? ...더 보기",
        images: [
            "before1",
            "after1"
        ],
        timestamp: "12시간 전",
        edited: true,
        upvotes: 203,
        comments: 234,
        views: 12345,
        likes: 512
    },
    {
        id: 4,
        category: "자유수다",
        username: "코성형고민",
        avatar: "🎭",
        content: "코 재수술 고민 중인데 조언 구해요ㅠㅠ 첫 수술이 마음에 들지 않아서... 어떤 의원이 좋은지, 재수술 시 주의사항은 무엇인지 궁금합니다...더 보기",
        timestamp: "15시간 전",
        upvotes: 76,
        comments: 92,
        views: 5432
    },
    {
        id: 5,
        category: "정보공유",
        username: "필러전문가",
        avatar: "💉",
        content: "2024년 필러 가격 정보 정리했어요! 지역별, 시술별로 비교해봤는데 참고하시면 좋을 것 같아요. 특히 리쥬란, 쥬베룩 가격대가 궁금하셨던 분들...더 보기",
        timestamp: "1일 전",
        edited: true,
        upvotes: 167,
        comments: 145,
        views: 9876,
        likes: 324
    },
    {
        id: 6,
        category: "질문답변",
        username: "리프팅고민",
        avatar: "🌙",
        content: "울쎄라 vs 인모드 어떤 게 나을까요? 둘 다 받아보신 분들 의견 듣고 싶어요. 가격도 비교해주시면 감사하겠습니다! ...더 보기",
        timestamp: "1일 전",
        upvotes: 89,
        comments: 112,
        views: 7654
    }
];
const latestPosts = [
    {
        id: 1,
        category: "자유수다",
        username: "신규회원123",
        avatar: "🦋",
        content: "안녕하세요! 처음 가입했는데 정보가 많아서 좋네요. 앞으로 잘 부탁드려요~",
        timestamp: "방금 전",
        upvotes: 5,
        comments: 2,
        views: 123
    },
    {
        id: 2,
        category: "질문답변",
        username: "궁금한이",
        avatar: "🤔",
        content: "리쥬란 힐러 시술 받은 지 일주일인데 아직 효과가 안 보여요. 정상인가요?",
        timestamp: "5분 전",
        upvotes: 3,
        comments: 8,
        views: 234
    },
    {
        id: 3,
        category: "정보공유",
        username: "정보나눔",
        avatar: "📚",
        content: "강남역 신규 오픈한 클리닉 정보 공유해요! 오픈 기념 이벤트 진행 중이라고 하네요",
        timestamp: "10분 전",
        upvotes: 12,
        comments: 15,
        views: 456
    },
    {
        id: 4,
        category: "자유수다",
        username: "시술러버",
        avatar: "💖",
        content: "오늘 보톡스 맞고 왔는데 얼굴이 좀 붓네요ㅠㅠ 정상인 거 맞죠? 첫 시술이라 걱정돼요",
        images: [
            "swollen1"
        ],
        timestamp: "15분 전",
        upvotes: 7,
        comments: 12,
        views: 345
    },
    {
        id: 5,
        category: "정보공유",
        username: "가격비교왕",
        avatar: "💰",
        content: "올해부터 필러 가격이 올랐다고 들었는데 실제로 어떠세요? 최근 시술 받으신 분들 가격 정보 공유해주세요!",
        timestamp: "20분 전",
        upvotes: 18,
        comments: 24,
        views: 567
    },
    {
        id: 6,
        category: "질문답변",
        username: "초보자",
        avatar: "🌿",
        content: "눈 재수술 생각 중인데 어떤 의원 추천받을 수 있을까요? 첫 수술 실패한 경험이 있어서 더 신중하게 선택하고 싶어요",
        timestamp: "30분 전",
        upvotes: 9,
        comments: 18,
        views: 412
    },
    {
        id: 7,
        category: "자유수다",
        username: "뷰티매니아",
        avatar: "💎",
        content: "오늘 클리닉 다녀왔는데 직원분들 친절하시고 분위기도 좋았어요! 만족스러운 시술이었습니다",
        timestamp: "45분 전",
        upvotes: 14,
        comments: 7,
        views: 389
    },
    {
        id: 8,
        category: "정보공유",
        username: "리프팅전문가",
        avatar: "✨",
        content: "인모드 리프팅 시술 전 주의사항 정리해서 올려봅니다. 시술 받기 전에 꼭 확인하시면 좋을 것 같아요!",
        images: [
            "info1",
            "info2"
        ],
        timestamp: "1시간 전",
        edited: true,
        upvotes: 25,
        comments: 31,
        views: 892
    }
];
// 고민상담소 더미 데이터 (카테고리별 5~10개 정도)
const concernDummyPosts = [
    {
        id: "concern-1",
        category: "피부 고민",
        username: "트러블폭발",
        avatar: "🌋",
        content: "여드름 흉터가 너무 심한데 해외에서 잠깐 들어오는 동안 할 수 있는 치료가 있을까요? 다운타임이 길지 않았으면 좋겠어요.",
        timestamp: "3시간 전",
        upvotes: 12,
        comments: 8,
        views: 324,
        reviewType: "concern"
    },
    {
        id: "concern-2",
        category: "피부 고민",
        username: "건성인간",
        avatar: "💧",
        content: "겨울만 되면 각질+당김이 너무 심해요. 레이저를 해야 할지, 관리 위주로 가야 할지 헷갈립니다. 비슷한 분들 어떤 시술 받으셨나요?",
        timestamp: "5시간 전",
        upvotes: 7,
        comments: 5,
        views: 198,
        reviewType: "concern"
    },
    {
        id: "concern-3",
        category: "시술 고민",
        username: "첫보톡스도전",
        avatar: "😳",
        content: "이마+미간 보톡스를 처음 맞아보려는데 표정이 너무 안 어색했으면 좋겠어요. 용량이나 병원 고를 때 꼭 봐야 할 포인트가 있을까요?",
        timestamp: "1일 전",
        upvotes: 15,
        comments: 21,
        views: 512,
        reviewType: "concern"
    },
    {
        id: "concern-4",
        category: "시술 고민",
        username: "리프팅궁금",
        avatar: "✨",
        content: "인모드랑 슈링크 중에 어떤 걸 먼저 해보는 게 좋을까요? 통증이랑 붓기, 효과 지속기간 차이가 궁금합니다.",
        timestamp: "2일 전",
        upvotes: 9,
        comments: 11,
        views: 389,
        reviewType: "concern"
    },
    {
        id: "concern-5",
        category: "병원 선택",
        username: "어디가좋을까",
        avatar: "📍",
        content: "강남/신사 쪽 리프팅 잘하는 병원 어디가 괜찮을까요? 후기를 봐도 다 좋아 보여서 실제로 받아보신 분들 의견이 궁금해요.",
        timestamp: "6시간 전",
        upvotes: 6,
        comments: 9,
        views: 245,
        reviewType: "concern"
    },
    {
        id: "concern-6",
        category: "가격 문의",
        username: "예산50",
        avatar: "💸",
        content: "50만 원 안쪽으로 할 수 있는 시술 추천 부탁드려요! 얼굴 전체 분위기만 조금 상큼해졌으면 좋겠어요.",
        timestamp: "8시간 전",
        upvotes: 4,
        comments: 6,
        views: 173,
        reviewType: "concern"
    },
    {
        id: "concern-7",
        category: "회복 기간",
        username: "직장인휴가3일",
        avatar: "🏃",
        content: "휴가가 딱 3일인데, 이 기간 안에 회복 가능한 시술이 뭐가 있을까요? 붓기 심한 건 피하고 싶어요.",
        timestamp: "12시간 전",
        upvotes: 10,
        comments: 13,
        views: 301,
        reviewType: "concern"
    },
    {
        id: "concern-8",
        category: "부작용",
        username: "붓기안빠짐",
        avatar: "😥",
        content: "턱 보톡스를 맞은 지 2주가 지났는데 아직도 씹을 때 불편한 느낌이 있어요. 이런 경우 병원에 다시 가봐야 할까요?",
        timestamp: "3일 전",
        upvotes: 5,
        comments: 14,
        views: 267,
        reviewType: "concern"
    },
    {
        id: "concern-9",
        category: "기타",
        username: "해외거주자",
        avatar: "✈️",
        content: "해외에서 들어와서 시술+여행 같이 하려는데, 공항에서 가까운 지역 추천해주실 수 있나요? 일정 짜는 팁도 궁금해요.",
        timestamp: "4일 전",
        upvotes: 8,
        comments: 7,
        views: 221,
        reviewType: "concern"
    }
];
const popularPosts = [
    {
        id: 1,
        category: "정보공유",
        username: "인기작가",
        avatar: "🔥",
        content: "2024년 최고의 클리닉 랭킹 공유합니다! 직접 다녀본 곳들만 추천하는 리스트예요. 가격, 품질, 서비스 모두 고려해서 작성했습니다...더 보기",
        images: [
            "ranking1",
            "ranking2",
            "ranking3"
        ],
        timestamp: "2일 전",
        edited: true,
        upvotes: 523,
        comments: 456,
        views: 45234,
        likes: 1245
    },
    {
        id: 2,
        category: "후기",
        username: "만족러버",
        avatar: "⭐",
        content: "슈링크 유니버스 시술 받고 완전 만족해서 후기 남겨요! 효과가 정말 놀라웠고 원장님도 너무 친절하셨어요. 전후 사진 공유합니다! ...더 보기",
        images: [
            "before2",
            "after2"
        ],
        timestamp: "3일 전",
        edited: true,
        upvotes: 412,
        comments: 389,
        views: 38921,
        likes: 987
    },
    {
        id: 3,
        category: "정보공유",
        username: "가격정보왕",
        avatar: "💎",
        content: "시술별 가격대 비교표 업데이트했습니다! 지역별, 클리닉별 가격 정보를 한눈에 비교할 수 있도록 정리했어요. 많은 분들께 도움이 되면 좋겠습니다...더 보기",
        timestamp: "4일 전",
        edited: true,
        upvotes: 387,
        comments: 298,
        views: 34123,
        likes: 756
    },
    {
        id: 4,
        category: "자유수다",
        username: "화제의인물",
        avatar: "🎯",
        content: "이 클리닉 정말 추천합니다! 제가 받은 시술 중에서 최고였어요. 직원분들도 친절하고 시술도 깔끔하게 잘 끝났습니다. 여러분도 한번 가보세요! ...더 보기",
        timestamp: "5일 전",
        upvotes: 298,
        comments: 234,
        views: 28765,
        likes: 634
    },
    {
        id: 5,
        category: "질문답변",
        username: "베테랑",
        avatar: "👑",
        content: "시술 관련 질문 받아요! 여러 번 경험한 입장에서 솔직하게 답변드리겠습니다. 어떤 질문이든 환영입니다~ ...더 보기",
        timestamp: "6일 전",
        upvotes: 267,
        comments: 512,
        views: 24567,
        likes: 523
    },
    {
        id: 6,
        category: "정보공유",
        username: "리뷰마스터",
        avatar: "📸",
        content: "강남역 클리닉 투어 후기 올려요! 5곳을 직접 방문해서 비교해봤는데 각각의 특징과 장단점을 정리했습니다. 참고하시면 좋을 것 같아요...더 보기",
        images: [
            "tour1",
            "tour2",
            "tour3",
            "tour4"
        ],
        timestamp: "1주일 전",
        edited: true,
        upvotes: 445,
        comments: 367,
        views: 38945,
        likes: 892
    }
];
// 시간 포맷팅 함수
const formatTimeAgo = (dateString)=>{
    if (!dateString) return "방금 전";
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffMins < 1) return "방금 전";
    if (diffMins < 60) return `${diffMins}분 전`;
    if (diffHours < 24) return `${diffHours}시간 전`;
    if (diffDays < 7) return `${diffDays}일 전`;
    return date.toLocaleDateString("ko-KR", {
        month: "short",
        day: "numeric"
    });
};
function PostList({ activeTab, concernCategory }) {
    const [supabaseReviews, setSupabaseReviews] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [popularSection, setPopularSection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("procedure");
    const procedureSectionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const hospitalSectionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // 최신글: Supabase에서 데이터 가져오기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (activeTab === "latest") {
            const loadLatestReviews = async ()=>{
                try {
                    setLoading(true);
                    // Supabase에서 모든 후기 가져오기
                    const [procedureReviews, hospitalReviews, concernPosts] = await Promise.all([
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadProcedureReviews"])(50),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadHospitalReviews"])(50),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadConcernPosts"])(50)
                    ]);
                    // 시술 후기 변환
                    const formattedProcedureReviews = procedureReviews.map((review)=>({
                            id: review.id || `procedure-${Math.random()}`,
                            category: review.category || "후기",
                            username: `사용자${review.user_id || 0}`,
                            avatar: "👤",
                            content: review.content,
                            images: review.images,
                            timestamp: formatTimeAgo(review.created_at),
                            created_at: review.created_at,
                            edited: false,
                            upvotes: 0,
                            comments: 0,
                            views: 0,
                            reviewType: "procedure"
                        }));
                    // 병원 후기 변환
                    const formattedHospitalReviews = hospitalReviews.map((review)=>({
                            id: review.id || `hospital-${Math.random()}`,
                            category: review.category_large || "병원후기",
                            username: `사용자${review.user_id || 0}`,
                            avatar: "👤",
                            content: review.content,
                            images: review.images,
                            timestamp: formatTimeAgo(review.created_at),
                            created_at: review.created_at,
                            edited: false,
                            upvotes: 0,
                            comments: 0,
                            views: 0,
                            reviewType: "hospital"
                        }));
                    // 고민글 변환
                    const formattedConcernPosts = concernPosts.map((post)=>({
                            id: post.id || `concern-${Math.random()}`,
                            category: post.concern_category || "고민글",
                            username: `사용자${post.user_id || 0}`,
                            avatar: "👤",
                            title: post.title,
                            content: post.content,
                            timestamp: formatTimeAgo(post.created_at),
                            created_at: post.created_at,
                            edited: false,
                            upvotes: 0,
                            comments: 0,
                            views: 0,
                            reviewType: "concern"
                        }));
                    // 최신순으로 정렬 (created_at 기준, 모든 후기 통합)
                    const allReviews = [
                        ...formattedProcedureReviews,
                        ...formattedHospitalReviews,
                        ...formattedConcernPosts
                    ].sort((a, b)=>{
                        const aDate = a.created_at;
                        const bDate = b.created_at;
                        if (!aDate && !bDate) return 0;
                        if (!aDate) return 1;
                        if (!bDate) return -1;
                        return new Date(bDate).getTime() - new Date(aDate).getTime();
                    }).map(({ created_at, ...rest })=>rest); // created_at 제거
                    setSupabaseReviews(allReviews);
                } catch (error) {
                    console.error("❌ 최신글 데이터 로드 실패:", error);
                } finally{
                    setLoading(false);
                }
            };
            loadLatestReviews();
            // 후기 추가 이벤트 리스너
            const handleReviewAdded = ()=>{
                loadLatestReviews();
            };
            window.addEventListener("reviewAdded", handleReviewAdded);
            return ()=>window.removeEventListener("reviewAdded", handleReviewAdded);
        }
    }, [
        activeTab
    ]);
    // 인기글: 시술 후기/병원 후기 섹션으로 나누기
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (activeTab === "popular") {
            const loadPopularReviews = async ()=>{
                try {
                    setLoading(true);
                    // Supabase에서 모든 후기 가져오기 (인기글은 추후 좋아요/조회수 기준으로 정렬 예정)
                    const [procedureReviews, hospitalReviews] = await Promise.all([
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadProcedureReviews"])(20),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadHospitalReviews"])(20)
                    ]);
                    // 시술 후기 변환
                    const formattedProcedureReviews = procedureReviews.map((review)=>({
                            id: review.id || `procedure-${Math.random()}`,
                            category: review.category || "후기",
                            username: `사용자${review.user_id || 0}`,
                            avatar: "👤",
                            content: review.content,
                            images: review.images,
                            timestamp: formatTimeAgo(review.created_at),
                            edited: false,
                            upvotes: 0,
                            comments: 0,
                            views: 0,
                            reviewType: "procedure"
                        }));
                    // 병원 후기 변환
                    const formattedHospitalReviews = hospitalReviews.map((review)=>({
                            id: review.id || `hospital-${Math.random()}`,
                            category: review.category_large || "병원후기",
                            username: `사용자${review.user_id || 0}`,
                            avatar: "👤",
                            content: review.content,
                            images: review.images,
                            timestamp: formatTimeAgo(review.created_at),
                            edited: false,
                            upvotes: 0,
                            comments: 0,
                            views: 0,
                            reviewType: "hospital"
                        }));
                    // 시술 후기와 병원 후기를 별도로 저장 (섹션으로 나누기 위해)
                    setSupabaseReviews([
                        ...formattedProcedureReviews,
                        ...formattedHospitalReviews
                    ]);
                } catch (error) {
                    console.error("❌ 인기글 데이터 로드 실패:", error);
                } finally{
                    setLoading(false);
                }
            };
            loadPopularReviews();
        }
    }, [
        activeTab
    ]);
    // 고민상담소: Supabase 실제 데이터 + 더미 데이터 함께 사용
    // - Supabase에서 고민글을 불러오고
    // - 아직 데이터가 적거나 없으면 concernDummyPosts를 뒤에 붙여서 보여줌
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (activeTab === "consultation") {
            const fetchConcernPosts = async ()=>{
                try {
                    setLoading(true);
                    let formattedConcernPosts = [];
                    try {
                        const concernPosts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadConcernPosts"])(100);
                        formattedConcernPosts = concernPosts.map((post)=>({
                                id: post.id || `concern-${Math.random()}`,
                                category: post.concern_category || "고민글",
                                username: `사용자${post.user_id || 0}`,
                                avatar: "👤",
                                title: post.title,
                                content: post.content,
                                timestamp: formatTimeAgo(post.created_at),
                                upvotes: 0,
                                comments: 0,
                                views: 0,
                                reviewType: "concern"
                            }));
                    } catch (error) {
                        console.warn("고민상담소 Supabase 데이터 로드 실패, 더미 데이터만 사용:", error);
                    }
                    // 실제 고민글 + 더미데이터를 함께 사용 (실제 데이터가 먼저, 부족한 부분은 더미로 보완)
                    const combinedConcernPosts = [
                        ...formattedConcernPosts,
                        ...concernDummyPosts
                    ];
                    const filteredConcernPosts = combinedConcernPosts.filter((post)=>{
                        if (concernCategory === null) return true; // "전체" 선택 시 모두 표시
                        if (!concernCategory) return true;
                        return post.category === concernCategory;
                    });
                    setSupabaseReviews(filteredConcernPosts);
                } finally{
                    setLoading(false);
                }
            };
            fetchConcernPosts();
        }
    }, [
        activeTab,
        concernCategory
    ]);
    let posts = [];
    let procedurePosts = [];
    let hospitalPosts = [];
    if (activeTab === "recommended") {
        posts = recommendedPosts;
    } else if (activeTab === "latest") {
        // 최신글: Supabase 데이터 + 기존 하드코딩된 데이터 (섞여서 표시)
        posts = [
            ...supabaseReviews,
            ...latestPosts
        ];
    } else if (activeTab === "popular") {
        // 인기글: 시술 후기와 병원 후기를 섹션으로 나누기
        procedurePosts = supabaseReviews.filter((p)=>p.reviewType === "procedure");
        hospitalPosts = supabaseReviews.filter((p)=>p.reviewType === "hospital");
        // 기존 하드코딩된 인기글도 추가 (섹션 구분 없이)
        posts = [
            ...supabaseReviews,
            ...popularPosts
        ];
    } else if (activeTab === "consultation") {
        // 고민상담소: 고민글만 표시 (이미 필터링되어 있음)
        posts = supabaseReviews;
    }
    if (loading && (activeTab === "latest" || activeTab === "consultation")) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "px-4 py-8 text-center text-gray-500",
            children: activeTab === "consultation" ? "고민글을 불러오는 중..." : "최신글을 불러오는 중..."
        }, void 0, false, {
            fileName: "[project]/components/PostList.tsx",
            lineNumber: 712,
            columnNumber: 7
        }, this);
    }
    // 인기글: 시술 후기/병원 후기 섹션으로 나누기
    if (activeTab === "popular") {
        const scrollToSection = (section)=>{
            setPopularSection(section);
            if (section === "procedure" && procedureSectionRef.current) {
                procedureSectionRef.current.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            } else if (section === "hospital" && hospitalSectionRef.current) {
                hospitalSectionRef.current.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            }
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "pb-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sticky top-[48px] z-10 bg-white border-b border-gray-200 px-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 py-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>scrollToSection("procedure"),
                                className: `flex-1 py-2 px-4 rounded-lg font-semibold text-sm transition-colors ${popularSection === "procedure" ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                                children: "시술 후기"
                            }, void 0, false, {
                                fileName: "[project]/components/PostList.tsx",
                                lineNumber: 742,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>scrollToSection("hospital"),
                                className: `flex-1 py-2 px-4 rounded-lg font-semibold text-sm transition-colors ${popularSection === "hospital" ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                                children: "병원 후기"
                            }, void 0, false, {
                                fileName: "[project]/components/PostList.tsx",
                                lineNumber: 752,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/PostList.tsx",
                        lineNumber: 741,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/PostList.tsx",
                    lineNumber: 740,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-4 space-y-6 pt-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            ref: procedureSectionRef,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-bold text-gray-900 mb-4",
                                    children: "시술 후기"
                                }, void 0, false, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 768,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: procedurePosts.length > 0 ? procedurePosts.map((post)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `bg-white border border-gray-200 rounded-xl hover:shadow-md transition-shadow ${post.reviewType === "concern" ? "p-5" : "p-4"}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "bg-primary-light/20 text-primary-main px-3 py-1 rounded-full text-xs font-medium",
                                                        children: post.category
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PostList.tsx",
                                                        lineNumber: 780,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 779,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-3 mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-2xl",
                                                            children: post.avatar
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 787,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex-1",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm font-semibold text-gray-900",
                                                                    children: post.username
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 791,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-2 mt-0.5",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs text-gray-500",
                                                                            children: post.timestamp
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/PostList.tsx",
                                                                            lineNumber: 795,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        post.edited && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs text-gray-400",
                                                                            children: "수정됨"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/PostList.tsx",
                                                                            lineNumber: 799,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 794,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 790,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 786,
                                                    columnNumber: 21
                                                }, this),
                                                post.reviewType === "concern" && post.title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-bold text-gray-900 mb-4 leading-relaxed",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "bg-yellow-200/60 px-2 py-1 rounded-sm",
                                                        children: post.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PostList.tsx",
                                                        lineNumber: 810,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 809,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: `text-gray-800 text-sm leading-[1.8] line-clamp-3 ${post.reviewType === "concern" ? "mb-4" : "mb-3"}`,
                                                    children: post.content
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 817,
                                                    columnNumber: 21
                                                }, this),
                                                post.images && post.images.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex gap-2 mb-3 flex-wrap",
                                                    children: post.images.slice(0, 4).map((img, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "relative w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg overflow-hidden flex-shrink-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "w-full h-full flex items-center justify-center text-gray-400 text-xs",
                                                                    children: "이미지"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 833,
                                                                    columnNumber: 29
                                                                }, this),
                                                                idx === 3 && post.images.length > 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center text-white font-semibold text-xs",
                                                                    children: [
                                                                        "+",
                                                                        post.images.length - 4
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 837,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, idx, true, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 829,
                                                            columnNumber: 27
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 827,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between pt-3 border-t border-gray-100",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowUp"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 850,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.upvotes
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 851,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 849,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiMessageCircle"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 856,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.comments
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 857,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 855,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiEye"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 862,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.views
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 863,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 861,
                                                                columnNumber: 25
                                                            }, this),
                                                            post.likes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiHeart"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 869,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.likes
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 870,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 868,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/PostList.tsx",
                                                        lineNumber: 848,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 847,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, post.id, true, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 772,
                                            columnNumber: 19
                                        }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center py-8 text-gray-500 text-sm",
                                        children: "시술 후기가 없습니다."
                                    }, void 0, false, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 880,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 769,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 767,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            ref: hospitalSectionRef,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-bold text-gray-900 mb-4",
                                    children: "병원 후기"
                                }, void 0, false, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 889,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: hospitalPosts.length > 0 ? hospitalPosts.map((post)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `bg-white border border-gray-200 rounded-xl hover:shadow-md transition-shadow ${post.reviewType === "concern" ? "p-5" : "p-4"}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "bg-primary-light/20 text-primary-main px-3 py-1 rounded-full text-xs font-medium",
                                                        children: post.category
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PostList.tsx",
                                                        lineNumber: 901,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 900,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-3 mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-2xl",
                                                            children: post.avatar
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 908,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex-1",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm font-semibold text-gray-900",
                                                                    children: post.username
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 912,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-2 mt-0.5",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs text-gray-500",
                                                                            children: post.timestamp
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/PostList.tsx",
                                                                            lineNumber: 916,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        post.edited && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs text-gray-400",
                                                                            children: "수정됨"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/components/PostList.tsx",
                                                                            lineNumber: 920,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 915,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 911,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 907,
                                                    columnNumber: 21
                                                }, this),
                                                post.reviewType === "concern" && post.title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-bold text-gray-900 mb-4 leading-relaxed",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "bg-yellow-200/60 px-2 py-1 rounded-sm",
                                                        children: post.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PostList.tsx",
                                                        lineNumber: 931,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 930,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: `text-gray-800 text-sm leading-[1.8] line-clamp-3 ${post.reviewType === "concern" ? "mb-4" : "mb-3"}`,
                                                    children: post.content
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 938,
                                                    columnNumber: 21
                                                }, this),
                                                post.images && post.images.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex gap-2 mb-3 flex-wrap",
                                                    children: post.images.slice(0, 4).map((img, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "relative w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg overflow-hidden flex-shrink-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "w-full h-full flex items-center justify-center text-gray-400 text-xs",
                                                                    children: "이미지"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 954,
                                                                    columnNumber: 29
                                                                }, this),
                                                                idx === 3 && post.images.length > 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center text-white font-semibold text-xs",
                                                                    children: [
                                                                        "+",
                                                                        post.images.length - 4
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/components/PostList.tsx",
                                                                    lineNumber: 958,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, idx, true, {
                                                            fileName: "[project]/components/PostList.tsx",
                                                            lineNumber: 950,
                                                            columnNumber: 27
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 948,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between pt-3 border-t border-gray-100",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowUp"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 971,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.upvotes
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 972,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 970,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiMessageCircle"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 977,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.comments
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 978,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 976,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiEye"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 983,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.views
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 984,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 982,
                                                                columnNumber: 25
                                                            }, this),
                                                            post.likes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiHeart"], {
                                                                        className: "text-lg"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 990,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-medium",
                                                                        children: post.likes
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/PostList.tsx",
                                                                        lineNumber: 991,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/PostList.tsx",
                                                                lineNumber: 989,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/PostList.tsx",
                                                        lineNumber: 969,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/PostList.tsx",
                                                    lineNumber: 968,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, post.id, true, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 893,
                                            columnNumber: 19
                                        }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center py-8 text-gray-500 text-sm",
                                        children: "병원 후기가 없습니다."
                                    }, void 0, false, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 1001,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 890,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 888,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/PostList.tsx",
                    lineNumber: 765,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/PostList.tsx",
            lineNumber: 738,
            columnNumber: 7
        }, this);
    }
    // 최신글/추천글: 섞여서 표시
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "px-4 pt-3 space-y-4 pb-4",
        children: posts.map((post)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `bg-white border border-gray-200 rounded-xl hover:shadow-md transition-shadow ${post.reviewType === "concern" ? "p-5" : "p-4"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "bg-primary-light/20 text-primary-main px-3 py-1 rounded-full text-xs font-medium",
                            children: post.category
                        }, void 0, false, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 1024,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/PostList.tsx",
                        lineNumber: 1023,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3 mb-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-2xl",
                                children: post.avatar
                            }, void 0, false, {
                                fileName: "[project]/components/PostList.tsx",
                                lineNumber: 1031,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-sm font-semibold text-gray-900",
                                        children: post.username
                                    }, void 0, false, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 1035,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 mt-0.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-gray-500",
                                                children: post.timestamp
                                            }, void 0, false, {
                                                fileName: "[project]/components/PostList.tsx",
                                                lineNumber: 1039,
                                                columnNumber: 17
                                            }, this),
                                            post.edited && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-gray-400",
                                                children: "수정됨"
                                            }, void 0, false, {
                                                fileName: "[project]/components/PostList.tsx",
                                                lineNumber: 1041,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 1038,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/PostList.tsx",
                                lineNumber: 1034,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/PostList.tsx",
                        lineNumber: 1030,
                        columnNumber: 11
                    }, this),
                    post.reviewType === "concern" && post.title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900 mb-4 leading-relaxed",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "bg-yellow-200/60 px-2 py-1 rounded-sm",
                            children: post.title
                        }, void 0, false, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 1050,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/PostList.tsx",
                        lineNumber: 1049,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: `text-gray-800 text-sm leading-[1.8] line-clamp-3 ${post.reviewType === "concern" ? "mb-4" : "mb-3"}`,
                        children: post.content
                    }, void 0, false, {
                        fileName: "[project]/components/PostList.tsx",
                        lineNumber: 1057,
                        columnNumber: 11
                    }, this),
                    post.images && post.images.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 mb-3 flex-wrap",
                        children: post.images.slice(0, 4).map((img, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg overflow-hidden flex-shrink-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-full h-full flex items-center justify-center text-gray-400 text-xs",
                                        children: "이미지"
                                    }, void 0, false, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 1073,
                                        columnNumber: 19
                                    }, this),
                                    idx === 3 && post.images.length > 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center text-white font-semibold text-xs",
                                        children: [
                                            "+",
                                            post.images.length - 4
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/PostList.tsx",
                                        lineNumber: 1077,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, idx, true, {
                                fileName: "[project]/components/PostList.tsx",
                                lineNumber: 1069,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/PostList.tsx",
                        lineNumber: 1067,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between pt-3 border-t border-gray-100",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowUp"], {
                                            className: "text-lg"
                                        }, void 0, false, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1090,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs font-medium",
                                            children: post.upvotes
                                        }, void 0, false, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1091,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 1089,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiMessageCircle"], {
                                            className: "text-lg"
                                        }, void 0, false, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1094,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs font-medium",
                                            children: post.comments
                                        }, void 0, false, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1095,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 1093,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiEye"], {
                                            className: "text-lg"
                                        }, void 0, false, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1098,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs font-medium",
                                            children: post.views
                                        }, void 0, false, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1099,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 1097,
                                    columnNumber: 15
                                }, this),
                                post.likes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "flex items-center gap-1.5 text-gray-600 hover:text-primary-main transition-colors",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiHeart"], {
                                            className: "text-lg"
                                        }, void 0, false, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1103,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs font-medium",
                                            children: post.likes
                                        }, void 0, false, {
                                            fileName: "[project]/components/PostList.tsx",
                                            lineNumber: 1104,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/PostList.tsx",
                                    lineNumber: 1102,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PostList.tsx",
                            lineNumber: 1088,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/PostList.tsx",
                        lineNumber: 1087,
                        columnNumber: 11
                    }, this)
                ]
            }, post.id, true, {
                fileName: "[project]/components/PostList.tsx",
                lineNumber: 1016,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/components/PostList.tsx",
        lineNumber: 1014,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/ProcedureReviewForm.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProcedureReviewForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
function ProcedureReviewForm({ onBack, onSubmit }) {
    const [surgeryDate, setSurgeryDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [category, setCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [hospitalName, setHospitalName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureName, setProcedureName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureSearchTerm, setProcedureSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [showProcedureSuggestions, setShowProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [procedureSuggestions, setProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [cost, setCost] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureRating, setProcedureRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [hospitalRating, setHospitalRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [gender, setGender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [ageGroup, setAgeGroup] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [images, setImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    // 대분류 카테고리 10개 (고정)
    const categories = [
        "눈성형",
        "리프팅",
        "보톡스",
        "안면윤곽/양악",
        "제모",
        "지방성형",
        "코성형",
        "피부",
        "필러",
        "가슴성형"
    ];
    const ageGroups = [
        "20대",
        "30대",
        "40대",
        "50대"
    ];
    // 한국어 완성형 글자 체크 (자음만 입력 방지)
    const hasCompleteCharacter = (text)=>{
        // 완성형 한글(가-힣), 영문, 숫자가 1자 이상 포함되어 있는지 확인
        return /[가-힣a-zA-Z0-9]/.test(text);
    };
    // 시술명 자동완성 데이터 로드 (서버 사이드 검색)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const loadAutocomplete = async ()=>{
            if (!procedureSearchTerm || procedureSearchTerm.trim().length < 1) {
                setProcedureSuggestions([]);
                setShowProcedureSuggestions(false);
                return;
            }
            // 완성형 글자가 1자 이상 있어야 자동완성 표시 (자음만 입력 방지)
            if (!hasCompleteCharacter(procedureSearchTerm)) {
                setProcedureSuggestions([]);
                setShowProcedureSuggestions(false);
                return;
            }
            try {
                // 카테고리가 선택되었으면 해당 카테고리의 시술 데이터를 로드해서 category_small 추출
                if (category) {
                    // category_small 검색을 위해 직접 Supabase 쿼리 사용
                    let query = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("treatment_master").select("category_small").eq("category_large", category).not("category_small", "is", null);
                    const { data, error } = await query.limit(1000);
                    if (error) {
                        throw new Error(`Supabase 오류: ${error.message}`);
                    }
                    // category_small 추출 및 중복 제거
                    const allCategorySmall = Array.from(new Set((data || []).map((t)=>t.category_small).filter((small)=>typeof small === "string" && small.trim() !== "")));
                    // 검색어로 필터링
                    const searchTermLower = procedureSearchTerm.toLowerCase();
                    const suggestions = allCategorySmall.filter((small)=>small.toLowerCase().includes(searchTermLower)).slice(0, 10);
                    setProcedureSuggestions(suggestions);
                    // 검색 결과가 있으면 자동완성 표시
                    if (suggestions.length > 0) {
                        setShowProcedureSuggestions(true);
                    }
                    console.log("🔍 검색어:", procedureSearchTerm);
                    console.log("🔍 선택된 카테고리:", category);
                    console.log("🔍 전체 데이터 개수:", allCategorySmall.length);
                    console.log("🔍 검색 결과 개수:", suggestions.length);
                    if (suggestions.length > 0) {
                        console.log("🔍 검색 결과:", suggestions);
                    } else {
                        console.log("🔍 해당 카테고리의 모든 category_small:", allCategorySmall);
                    }
                } else {
                    // 카테고리가 선택되지 않았으면 기존 함수 사용
                    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTreatmentAutocomplete"])(procedureSearchTerm, 10);
                    setProcedureSuggestions(result.treatmentNames);
                    // 검색 결과가 있으면 자동완성 표시
                    if (result.treatmentNames.length > 0) {
                        setShowProcedureSuggestions(true);
                    }
                    console.log("🔍 검색어:", procedureSearchTerm);
                    console.log("🔍 선택된 카테고리: 전체");
                    console.log("🔍 검색 결과 개수:", result.treatmentNames.length);
                    if (result.treatmentNames.length > 0) {
                        console.log("🔍 검색 결과:", result.treatmentNames);
                    }
                }
            } catch (error) {
                console.error("자동완성 데이터 로드 실패:", error);
                setProcedureSuggestions([]);
            }
        };
        const debounceTimer = setTimeout(()=>{
            loadAutocomplete();
        }, 300);
        return ()=>clearTimeout(debounceTimer);
    }, [
        procedureSearchTerm,
        category
    ]);
    const handleImageUpload = (e)=>{
        if (e.target.files) {
            const files = Array.from(e.target.files);
            const newImages = files.map((file)=>URL.createObjectURL(file));
            setImages([
                ...images,
                ...newImages
            ].slice(0, 4));
        }
    };
    const removeImage = (index)=>{
        setImages(images.filter((_, i)=>i !== index));
    };
    const handleSubmit = async ()=>{
        // 필수 항목 검증
        // procedureName은 procedureSearchTerm에서 가져오거나 직접 입력된 값 사용
        const finalProcedureName = procedureName || procedureSearchTerm;
        if (!category || !finalProcedureName || !cost || content.length < 10) {
            alert("필수 항목을 모두 입력하고 글을 10자 이상 작성해주세요.");
            return;
        }
        // 성별, 연령대 검증
        if (!gender || !ageGroup) {
            alert("성별과 연령대를 선택해주세요.");
            return;
        }
        // 만족도 검증
        if (procedureRating === 0 || hospitalRating === 0) {
            alert("시술 만족도와 병원 만족도를 모두 선택해주세요.");
            return;
        }
        try {
            // 이미지 URL 배열 생성 (현재는 로컬 URL이므로 추후 Supabase Storage 업로드 필요)
            const imageUrls = images.length > 0 ? images : undefined;
            // 데이터 저장
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["saveProcedureReview"])({
                category,
                procedure_name: finalProcedureName,
                hospital_name: hospitalName || undefined,
                cost: parseInt(cost),
                procedure_rating: procedureRating,
                hospital_rating: hospitalRating,
                gender,
                age_group: ageGroup,
                surgery_date: surgeryDate || undefined,
                content,
                images: imageUrls,
                user_id: 0
            });
            if (result.success) {
                alert("시술후기가 성공적으로 작성되었습니다!");
                onSubmit();
            } else {
                alert(`시술후기 작성에 실패했습니다: ${result.error}`);
            }
        } catch (error) {
            console.error("시술후기 저장 오류:", error);
            alert(`시술후기 작성 중 오류가 발생했습니다: ${error.message}`);
        }
    };
    const StarRating = ({ rating, onRatingChange, label })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "block text-sm font-semibold text-gray-900 mb-2",
                    children: [
                        label,
                        " ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-red-500",
                            children: "*"
                        }, void 0, false, {
                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                            lineNumber: 241,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                    lineNumber: 240,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2",
                    children: [
                        1,
                        2,
                        3,
                        4,
                        5
                    ].map((star)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>onRatingChange(star),
                            className: "p-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiStar"], {
                                className: `text-2xl ${star <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 251,
                                columnNumber: 13
                            }, this)
                        }, star, false, {
                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                            lineNumber: 245,
                            columnNumber: 11
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                    lineNumber: 243,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/ProcedureReviewForm.tsx",
            lineNumber: 239,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onBack,
                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                            className: "text-gray-700 text-xl"
                        }, void 0, false, {
                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                            lineNumber: 272,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 268,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: "시술 후기 작성"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 274,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 267,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "시술 카테고리 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 280,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 279,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: category,
                        onChange: (e)=>{
                            setCategory(e.target.value);
                            setProcedureSearchTerm(""); // 카테고리 변경 시 검색어 초기화
                            setProcedureName("");
                            setShowProcedureSuggestions(false); // 자동완성 닫기
                            setProcedureSuggestions([]); // 자동완성 목록 초기화
                        },
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "카테고리를 선택하세요"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 293,
                                columnNumber: 11
                            }, this),
                            categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: cat,
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                                    lineNumber: 295,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 282,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 278,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "시술명(수술명) ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 305,
                                columnNumber: 20
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 304,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: procedureSearchTerm,
                        onChange: (e)=>{
                            const value = e.target.value;
                            setProcedureSearchTerm(value);
                            // 완성형 글자가 있을 때만 자동완성 표시
                            if (hasCompleteCharacter(value)) {
                                setShowProcedureSuggestions(true);
                            } else {
                                setShowProcedureSuggestions(false);
                            }
                            // 자동완성에서 선택되지 않은 값이면 procedureName도 업데이트 (직접 입력 허용)
                            if (value && !procedureSuggestions.includes(value)) {
                                setProcedureName(value);
                            }
                        },
                        onFocus: ()=>{
                            if (procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm)) {
                                setShowProcedureSuggestions(true);
                            }
                        },
                        onBlur: ()=>{
                            // 약간의 지연을 두어 클릭 이벤트가 먼저 발생하도록
                            setTimeout(()=>{
                                setShowProcedureSuggestions(false);
                                // blur 시 현재 입력값을 procedureName에 저장 (선택된 값이 없을 때)
                                if (procedureSearchTerm && !procedureName) {
                                    setProcedureName(procedureSearchTerm);
                                }
                            }, 200);
                        },
                        placeholder: "시술명을 입력해 주세요.",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 307,
                        columnNumber: 9
                    }, this),
                    showProcedureSuggestions && procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm) && procedureSuggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-xl shadow-lg max-h-60 overflow-y-auto",
                        children: procedureSuggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    setProcedureName(suggestion);
                                    setProcedureSearchTerm(suggestion);
                                    setShowProcedureSuggestions(false);
                                },
                                className: "w-full px-4 py-2 text-left hover:bg-gray-50 first:rounded-t-xl last:rounded-b-xl",
                                children: suggestion
                            }, index, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 351,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 349,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 303,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "비용 (만원) ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 371,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 370,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-gray-700",
                                children: "₩"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 374,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: cost,
                                onChange: (e)=>setCost(e.target.value),
                                placeholder: "수술 비용",
                                className: "flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 375,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-gray-700",
                                children: "만원"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 382,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 373,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 369,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: procedureRating,
                onRatingChange: setProcedureRating,
                label: "전체적인 시술 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 387,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: hospitalRating,
                onRatingChange: setHospitalRating,
                label: "병원 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 394,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "병원명(선택사항)"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 402,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: hospitalName,
                        onChange: (e)=>setHospitalName(e.target.value),
                        placeholder: "병원명을 입력하세요",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 405,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 401,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "시술 날짜(선택사항)"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 416,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "date",
                        value: surgeryDate,
                        onChange: (e)=>setSurgeryDate(e.target.value),
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 419,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 415,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "성별 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 430,
                                columnNumber: 14
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 429,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setGender("여"),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${gender === "여" ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "여"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 433,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setGender("남"),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${gender === "남" ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "남"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 444,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 432,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 428,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "연령 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 461,
                                columnNumber: 14
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 460,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: ageGroups.map((age)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setAgeGroup(age),
                                className: `py-3 rounded-xl border-2 transition-colors ${ageGroup === age ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: age
                            }, age, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 465,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 463,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 459,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "글 작성 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 484,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 483,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: content,
                        onChange: (e)=>setContent(e.target.value),
                        placeholder: "시술 경험을 자세히 작성해주세요 (10자 이상)",
                        rows: 8,
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main resize-none"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 486,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-1",
                        children: [
                            content.length,
                            "자 / 최소 10자 이상 작성해주세요"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 493,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 482,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiCamera"], {
                                className: "text-primary-main"
                            }, void 0, false, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 501,
                                columnNumber: 11
                            }, this),
                            "사진첨부 (최대 4장)"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 500,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: [
                            images.map((img, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative aspect-square rounded-xl overflow-hidden border border-gray-300",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            src: img,
                                            alt: `Uploaded ${index + 1}`,
                                            fill: true,
                                            className: "object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                                            lineNumber: 510,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>removeImage(index),
                                            className: "absolute top-2 right-2 p-1 bg-black/50 rounded-full text-white hover:bg-black/70",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiX"], {
                                                className: "text-sm"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                                lineNumber: 521,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/ProcedureReviewForm.tsx",
                                            lineNumber: 516,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, index, true, {
                                    fileName: "[project]/components/ProcedureReviewForm.tsx",
                                    lineNumber: 506,
                                    columnNumber: 13
                                }, this)),
                            images.length < 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "aspect-square border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center cursor-pointer hover:border-primary-main transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "file",
                                        accept: "image/*",
                                        multiple: true,
                                        onChange: handleImageUpload,
                                        className: "hidden"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                                        lineNumber: 527,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiCamera"], {
                                                className: "text-2xl text-gray-400 mx-auto mb-2"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                                lineNumber: 535,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-gray-500",
                                                children: "사진 추가"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                                lineNumber: 536,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                                        lineNumber: 534,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ProcedureReviewForm.tsx",
                                lineNumber: 526,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 504,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 499,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 pt-4 pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onBack,
                        className: "flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-colors",
                        children: "취소"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 545,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleSubmit,
                        className: "flex-1 py-3 bg-primary-main hover:bg-primary-light text-white rounded-xl font-semibold transition-colors",
                        children: "작성완료"
                    }, void 0, false, {
                        fileName: "[project]/components/ProcedureReviewForm.tsx",
                        lineNumber: 552,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ProcedureReviewForm.tsx",
                lineNumber: 544,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ProcedureReviewForm.tsx",
        lineNumber: 265,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/HospitalReviewForm.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HospitalReviewForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
function HospitalReviewForm({ onBack, onSubmit }) {
    const [hospitalName, setHospitalName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [visitDate, setVisitDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [categoryLarge, setCategoryLarge] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [procedureSearchTerm, setProcedureSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [showProcedureSuggestions, setShowProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [procedureSuggestions, setProcedureSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedProcedure, setSelectedProcedure] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [overallSatisfaction, setOverallSatisfaction] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [hospitalKindness, setHospitalKindness] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [hasTranslation, setHasTranslation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [translationSatisfaction, setTranslationSatisfaction] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [images, setImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    // 대분류 카테고리 10개 (고정)
    const categories = [
        "눈성형",
        "리프팅",
        "보톡스",
        "안면윤곽/양악",
        "제모",
        "지방성형",
        "코성형",
        "피부",
        "필러",
        "가슴성형"
    ];
    // 한국어 완성형 글자 체크 (자음만 입력 방지)
    const hasCompleteCharacter = (text)=>{
        // 완성형 한글(가-힣), 영문, 숫자가 1자 이상 포함되어 있는지 확인
        return /[가-힣a-zA-Z0-9]/.test(text);
    };
    // 시술명 자동완성 데이터 로드 (서버 사이드 검색)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const loadAutocomplete = async ()=>{
            if (!procedureSearchTerm || procedureSearchTerm.trim().length < 1) {
                setProcedureSuggestions([]);
                setShowProcedureSuggestions(false);
                return;
            }
            // 완성형 글자가 1자 이상 있어야 자동완성 표시 (자음만 입력 방지)
            if (!hasCompleteCharacter(procedureSearchTerm)) {
                setProcedureSuggestions([]);
                setShowProcedureSuggestions(false);
                return;
            }
            try {
                // 카테고리가 선택되었으면 해당 카테고리의 시술 데이터를 로드해서 category_small 추출
                if (categoryLarge) {
                    // category_small 검색을 위해 직접 Supabase 쿼리 사용
                    let query = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["supabase"].from("treatment_master").select("category_small").eq("category_large", categoryLarge).not("category_small", "is", null);
                    const { data, error } = await query.limit(1000);
                    if (error) {
                        throw new Error(`Supabase 오류: ${error.message}`);
                    }
                    // category_small 추출 및 중복 제거
                    const allCategorySmall = Array.from(new Set((data || []).map((t)=>t.category_small).filter((small)=>typeof small === "string" && small.trim() !== "")));
                    // 검색어로 필터링
                    const searchTermLower = procedureSearchTerm.toLowerCase();
                    const suggestions = allCategorySmall.filter((small)=>small.toLowerCase().includes(searchTermLower)).slice(0, 10);
                    setProcedureSuggestions(suggestions);
                    // 검색 결과가 있으면 자동완성 표시
                    if (suggestions.length > 0) {
                        setShowProcedureSuggestions(true);
                    }
                } else {
                    // 카테고리가 선택되지 않았으면 기존 함수 사용
                    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTreatmentAutocomplete"])(procedureSearchTerm, 10);
                    setProcedureSuggestions(result.treatmentNames);
                    // 검색 결과가 있으면 자동완성 표시
                    if (result.treatmentNames.length > 0) {
                        setShowProcedureSuggestions(true);
                    }
                }
            } catch (error) {
                console.error("자동완성 데이터 로드 실패:", error);
                setProcedureSuggestions([]);
            }
        };
        const debounceTimer = setTimeout(()=>{
            loadAutocomplete();
        }, 300);
        return ()=>clearTimeout(debounceTimer);
    }, [
        procedureSearchTerm,
        categoryLarge
    ]);
    const handleImageUpload = (e)=>{
        if (e.target.files) {
            const files = Array.from(e.target.files);
            const newImages = files.map((file)=>URL.createObjectURL(file));
            setImages([
                ...images,
                ...newImages
            ].slice(0, 4));
        }
    };
    const removeImage = (index)=>{
        setImages(images.filter((_, i)=>i !== index));
    };
    const StarRating = ({ rating, onRatingChange, label })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "block text-sm font-semibold text-gray-900 mb-2",
                    children: label
                }, void 0, false, {
                    fileName: "[project]/components/HospitalReviewForm.tsx",
                    lineNumber: 165,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2",
                    children: [
                        1,
                        2,
                        3,
                        4,
                        5
                    ].map((star)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>onRatingChange(star),
                            className: "p-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiStar"], {
                                className: `text-2xl ${star <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 176,
                                columnNumber: 13
                            }, this)
                        }, star, false, {
                            fileName: "[project]/components/HospitalReviewForm.tsx",
                            lineNumber: 170,
                            columnNumber: 11
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/HospitalReviewForm.tsx",
                    lineNumber: 168,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/HospitalReviewForm.tsx",
            lineNumber: 164,
            columnNumber: 5
        }, this);
    const handleSubmit = async ()=>{
        // 필수 항목 검증
        if (!hospitalName || !categoryLarge || content.length < 10) {
            alert("필수 항목을 모두 입력하고 글을 10자 이상 작성해주세요.");
            return;
        }
        try {
            // 이미지 URL 배열 생성 (현재는 로컬 URL이므로 추후 Supabase Storage 업로드 필요)
            const imageUrls = images.length > 0 ? images : undefined;
            // 데이터 저장
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["saveHospitalReview"])({
                hospital_name: hospitalName,
                category_large: categoryLarge,
                procedure_name: selectedProcedure || undefined,
                visit_date: visitDate || undefined,
                overall_satisfaction: overallSatisfaction > 0 ? overallSatisfaction : undefined,
                hospital_kindness: hospitalKindness > 0 ? hospitalKindness : undefined,
                has_translation: hasTranslation,
                translation_satisfaction: hasTranslation && translationSatisfaction > 0 ? translationSatisfaction : undefined,
                content,
                images: imageUrls,
                user_id: 0
            });
            if (result.success) {
                alert("병원후기가 성공적으로 작성되었습니다!");
                onSubmit();
            } else {
                alert(`병원후기 작성에 실패했습니다: ${result.error}`);
            }
        } catch (error) {
            console.error("병원후기 저장 오류:", error);
            alert(`병원후기 작성 중 오류가 발생했습니다: ${error.message}`);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onBack,
                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                            className: "text-gray-700 text-xl"
                        }, void 0, false, {
                            fileName: "[project]/components/HospitalReviewForm.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 235,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: "병원 후기 작성"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 241,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 234,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "병원명 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 247,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 246,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: hospitalName,
                        onChange: (e)=>setHospitalName(e.target.value),
                        placeholder: "병원명을 입력하세요",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 249,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 245,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "시술 카테고리 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 261,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 260,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: categoryLarge,
                        onChange: (e)=>{
                            setCategoryLarge(e.target.value);
                            setProcedureSearchTerm(""); // 카테고리 변경 시 검색어 초기화
                            setSelectedProcedure("");
                            setShowProcedureSuggestions(false); // 자동완성 닫기
                            setProcedureSuggestions([]); // 자동완성 목록 초기화
                        },
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "대분류 선택"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 274,
                                columnNumber: 11
                            }, this),
                            categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: cat,
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/components/HospitalReviewForm.tsx",
                                    lineNumber: 276,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 263,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 259,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "시술명(수술명) (선택사항)"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 285,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: procedureSearchTerm,
                        onChange: (e)=>{
                            const value = e.target.value;
                            setProcedureSearchTerm(value);
                            // 완성형 글자가 있을 때만 자동완성 표시
                            if (hasCompleteCharacter(value)) {
                                setShowProcedureSuggestions(true);
                            } else {
                                setShowProcedureSuggestions(false);
                            }
                            // 자동완성에서 선택되지 않은 값이면 selectedProcedure도 업데이트 (직접 입력 허용)
                            if (value && !procedureSuggestions.includes(value)) {
                                setSelectedProcedure(value);
                            }
                        },
                        onFocus: ()=>{
                            if (procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm)) {
                                setShowProcedureSuggestions(true);
                            }
                        },
                        onBlur: ()=>{
                            // 약간의 지연을 두어 클릭 이벤트가 먼저 발생하도록
                            setTimeout(()=>{
                                setShowProcedureSuggestions(false);
                                // blur 시 현재 입력값을 selectedProcedure에 저장 (선택된 값이 없을 때)
                                if (procedureSearchTerm && !selectedProcedure) {
                                    setSelectedProcedure(procedureSearchTerm);
                                }
                            }, 200);
                        },
                        placeholder: "시술명을 입력해 주세요.",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 288,
                        columnNumber: 9
                    }, this),
                    showProcedureSuggestions && procedureSearchTerm && hasCompleteCharacter(procedureSearchTerm) && procedureSuggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-xl shadow-lg max-h-60 overflow-y-auto",
                        children: procedureSuggestions.map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    setSelectedProcedure(suggestion);
                                    setProcedureSearchTerm(suggestion);
                                    setShowProcedureSuggestions(false);
                                },
                                className: "w-full px-4 py-2 text-left hover:bg-gray-50 first:rounded-t-xl last:rounded-b-xl",
                                children: suggestion
                            }, index, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 332,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 330,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 284,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: overallSatisfaction,
                onRatingChange: setOverallSatisfaction,
                label: "전체적인 시술 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 350,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: hospitalKindness,
                onRatingChange: setHospitalKindness,
                label: "병원 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 357,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "통역 여부"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 365,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setHasTranslation(true),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${hasTranslation ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "있음"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 369,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setHasTranslation(false),
                                className: `flex-1 py-3 rounded-xl border-2 transition-colors ${!hasTranslation ? "border-primary-main bg-primary-main/10 text-primary-main" : "border-gray-300 text-gray-700"}`,
                                children: "없음"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 380,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 368,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 364,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: "병원 방문일"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 396,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "date",
                        value: visitDate,
                        onChange: (e)=>setVisitDate(e.target.value),
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 399,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 395,
                columnNumber: 7
            }, this),
            hasTranslation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StarRating, {
                rating: translationSatisfaction,
                onRatingChange: setTranslationSatisfaction,
                label: "통역 만족도 (1~5)"
            }, void 0, false, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 409,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "글 작성 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 419,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 418,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: content,
                        onChange: (e)=>setContent(e.target.value),
                        placeholder: "병원 방문 경험을 자세히 작성해주세요 (10자 이상)",
                        rows: 8,
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main resize-none"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 421,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-1",
                        children: [
                            content.length,
                            "자 / 최소 10자 이상 작성해주세요"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 428,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 417,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2 flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiCamera"], {
                                className: "text-primary-main"
                            }, void 0, false, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 436,
                                columnNumber: 11
                            }, this),
                            "사진첨부 (최대 4장)"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 435,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: [
                            images.map((img, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative aspect-square rounded-xl overflow-hidden border border-gray-300",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            src: img,
                                            alt: `Uploaded ${index + 1}`,
                                            fill: true,
                                            className: "object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/components/HospitalReviewForm.tsx",
                                            lineNumber: 445,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>removeImage(index),
                                            className: "absolute top-2 right-2 p-1 bg-black/50 rounded-full text-white hover:bg-black/70",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiX"], {
                                                className: "text-sm"
                                            }, void 0, false, {
                                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                                lineNumber: 456,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/HospitalReviewForm.tsx",
                                            lineNumber: 451,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, index, true, {
                                    fileName: "[project]/components/HospitalReviewForm.tsx",
                                    lineNumber: 441,
                                    columnNumber: 13
                                }, this)),
                            images.length < 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "aspect-square border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center cursor-pointer hover:border-primary-main transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "file",
                                        accept: "image/*",
                                        multiple: true,
                                        onChange: handleImageUpload,
                                        className: "hidden"
                                    }, void 0, false, {
                                        fileName: "[project]/components/HospitalReviewForm.tsx",
                                        lineNumber: 462,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiCamera"], {
                                                className: "text-2xl text-gray-400 mx-auto mb-2"
                                            }, void 0, false, {
                                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                                lineNumber: 470,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-gray-500",
                                                children: "사진 추가"
                                            }, void 0, false, {
                                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                                lineNumber: 471,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/HospitalReviewForm.tsx",
                                        lineNumber: 469,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/HospitalReviewForm.tsx",
                                lineNumber: 461,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 439,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 434,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 pt-4 pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onBack,
                        className: "flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-colors",
                        children: "취소"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 480,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleSubmit,
                        className: "flex-1 py-3 bg-primary-main hover:bg-primary-light text-white rounded-xl font-semibold transition-colors",
                        children: "작성완료"
                    }, void 0, false, {
                        fileName: "[project]/components/HospitalReviewForm.tsx",
                        lineNumber: 487,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HospitalReviewForm.tsx",
                lineNumber: 479,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/HospitalReviewForm.tsx",
        lineNumber: 232,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/ConcernPostForm.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConcernPostForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api/beautripApi.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function ConcernPostForm({ onBack, onSubmit }) {
    const [title, setTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [concernCategory, setConcernCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    // 커뮤니티 - 고민상담소 카테고리 (현재 선택 가능한 카테고리대로)
    const concernCategories = [
        "피부 고민",
        "시술 고민",
        "병원 선택",
        "가격 문의",
        "회복 기간",
        "부작용",
        "기타"
    ];
    const handleSubmit = async ()=>{
        // 필수 항목 검증
        if (!title || !concernCategory || content.length < 10) {
            alert("필수 항목을 모두 입력하고 글을 10자 이상 작성해주세요.");
            return;
        }
        try {
            // 데이터 저장
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2f$beautripApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["saveConcernPost"])({
                title,
                concern_category: concernCategory,
                content,
                user_id: 0
            });
            if (result.success) {
                alert("고민글이 성공적으로 작성되었습니다!");
                onSubmit();
            } else {
                alert(`고민글 작성에 실패했습니다: ${result.error}`);
            }
        } catch (error) {
            console.error("고민글 저장 오류:", error);
            alert(`고민글 작성 중 오류가 발생했습니다: ${error.message}`);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onBack,
                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowLeft"], {
                            className: "text-gray-700 text-xl"
                        }, void 0, false, {
                            fileName: "[project]/components/ConcernPostForm.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-gray-900",
                        children: "고민글 작성"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 69,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "제목 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 75,
                                columnNumber: 14
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: title,
                        onChange: (e)=>setTitle(e.target.value),
                        placeholder: "고민글 제목을 입력하세요",
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 77,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "고민 카테고리 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 89,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 88,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: concernCategory,
                        onChange: (e)=>setConcernCategory(e.target.value),
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "고민 카테고리를 선택하세요"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 96,
                                columnNumber: 11
                            }, this),
                            concernCategories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: cat,
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/components/ConcernPostForm.tsx",
                                    lineNumber: 98,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-sm font-semibold text-gray-900 mb-2",
                        children: [
                            "고민 글 ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-red-500",
                                children: "*"
                            }, void 0, false, {
                                fileName: "[project]/components/ConcernPostForm.tsx",
                                lineNumber: 108,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: content,
                        onChange: (e)=>setContent(e.target.value),
                        placeholder: "고민이나 질문을 자세히 작성해주세요 (10자 이상)",
                        rows: 10,
                        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-main resize-none"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-1",
                        children: [
                            content.length,
                            "자 / 최소 10자 이상 작성해주세요"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 117,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 pt-4 pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onBack,
                        className: "flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-colors",
                        children: "취소"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 124,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleSubmit,
                        className: "flex-1 py-3 bg-primary-main hover:bg-primary-light text-white rounded-xl font-semibold transition-colors",
                        children: "작성완료"
                    }, void 0, false, {
                        fileName: "[project]/components/ConcernPostForm.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ConcernPostForm.tsx",
                lineNumber: 123,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ConcernPostForm.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/CommunityWriteModal.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommunityWriteModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProcedureReviewForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ProcedureReviewForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HospitalReviewForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/HospitalReviewForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ConcernPostForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ConcernPostForm.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
const writeOptions = [
    {
        id: "procedure-review",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiCamera"],
        title: "시술 후기",
        description: "시술 경험을 공유해보세요",
        color: "from-pink-500 to-rose-500"
    },
    {
        id: "hospital-review",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiHome"],
        title: "병원 후기",
        description: "병원 방문 경험을 공유해보세요",
        color: "from-blue-500 to-cyan-500"
    },
    {
        id: "concern-post",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiFileText"],
        title: "고민글",
        description: "고민이나 질문을 올려보세요",
        color: "from-purple-500 to-pink-500"
    }
];
function CommunityWriteModal({ isOpen, onClose }) {
    const [selectedOption, setSelectedOption] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    if (!isOpen) return null;
    const handleOptionClick = (optionId)=>{
        setSelectedOption(optionId);
    };
    const handleBack = ()=>{
        setSelectedOption(null);
    };
    const handleSubmit = ()=>{
        // 각 폼에서 이미 성공 메시지를 표시하므로 여기서는 alert 제거
        setSelectedOption(null);
        onClose();
        // 후기 목록 새로고침을 위한 이벤트 발생
        window.dispatchEvent(new CustomEvent("reviewAdded"));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 bg-black/50 z-[100] transition-opacity",
                onClick: onClose
            }, void 0, false, {
                fileName: "[project]/components/CommunityWriteModal.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-x-0 bottom-0 bg-white rounded-t-3xl z-[100] max-w-md mx-auto shadow-2xl animate-slide-up",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center pt-3 pb-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-12 h-1 bg-gray-300 rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/components/CommunityWriteModal.tsx",
                            lineNumber: 74,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/CommunityWriteModal.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-6 py-4 border-b border-gray-100",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-xl font-bold text-gray-900",
                                        children: "글 작성하기"
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 80,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: onClose,
                                        className: "p-2 hover:bg-gray-50 rounded-full transition-colors",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiX"], {
                                            className: "text-gray-600 text-xl"
                                        }, void 0, false, {
                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                            lineNumber: 85,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 81,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/CommunityWriteModal.tsx",
                                lineNumber: 79,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-gray-500 mt-1",
                                children: "어떤 이야기를 공유하고 싶으신가요?"
                            }, void 0, false, {
                                fileName: "[project]/components/CommunityWriteModal.tsx",
                                lineNumber: 88,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/CommunityWriteModal.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-6 py-4 max-h-[70vh] overflow-y-auto",
                        children: !selectedOption ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-3",
                            children: [
                                writeOptions.map((option)=>{
                                    const Icon = option.icon;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>handleOptionClick(option.id),
                                        className: "w-full p-4 bg-gradient-to-r rounded-xl border-2 border-gray-100 hover:border-primary-main/30 hover:shadow-lg transition-all text-left group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: `bg-gradient-to-br ${option.color} p-3 rounded-xl shadow-md group-hover:scale-110 transition-transform`,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                                        className: "text-white text-xl"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                                        lineNumber: 109,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 106,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-base font-bold text-gray-900 mb-1",
                                                            children: option.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 112,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm text-gray-600",
                                                            children: option.description
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 115,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 111,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-400 group-hover:text-primary-main transition-colors",
                                                    children: "→"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 119,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                            lineNumber: 105,
                                            columnNumber: 21
                                        }, this)
                                    }, option.id, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 100,
                                        columnNumber: 19
                                    }, this);
                                }),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-t border-gray-200 pt-3 mt-3",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            // TODO: 내 글 관리 페이지로 이동
                                            alert("내 글 관리 기능은 추후 구현 예정입니다.");
                                            onClose();
                                        },
                                        className: "w-full p-4 bg-gray-50 hover:bg-gray-100 rounded-xl border-2 border-gray-200 hover:border-primary-main/30 transition-all text-left group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "bg-gradient-to-br from-gray-400 to-gray-500 p-3 rounded-xl shadow-md group-hover:scale-110 transition-transform",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiUser"], {
                                                        className: "text-white text-xl"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                                        lineNumber: 139,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 138,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-base font-bold text-gray-900 mb-1",
                                                            children: "내 글 관리"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 142,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm text-gray-600",
                                                            children: "작성한 글을 관리해보세요"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                                            lineNumber: 145,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 141,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-400 group-hover:text-primary-main transition-colors",
                                                    children: "→"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                                    lineNumber: 149,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/CommunityWriteModal.tsx",
                                            lineNumber: 137,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/CommunityWriteModal.tsx",
                                        lineNumber: 129,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 128,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/CommunityWriteModal.tsx",
                            lineNumber: 96,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                selectedOption === "procedure-review" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProcedureReviewForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    onBack: handleBack,
                                    onSubmit: handleSubmit
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 159,
                                    columnNumber: 17
                                }, this),
                                selectedOption === "hospital-review" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HospitalReviewForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    onBack: handleBack,
                                    onSubmit: handleSubmit
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 165,
                                    columnNumber: 17
                                }, this),
                                selectedOption === "concern-post" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ConcernPostForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    onBack: handleBack,
                                    onSubmit: handleSubmit
                                }, void 0, false, {
                                    fileName: "[project]/components/CommunityWriteModal.tsx",
                                    lineNumber: 171,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/CommunityWriteModal.tsx",
                            lineNumber: 157,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/CommunityWriteModal.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/CommunityWriteModal.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/components/CommunityFloatingButton.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommunityFloatingButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityWriteModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CommunityWriteModal.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function CommunityFloatingButton() {
    const [isWriteModalOpen, setIsWriteModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed bottom-20 right-0 left-0 z-40 pointer-events-none max-w-md mx-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative pointer-events-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setIsWriteModalOpen(true),
                        className: "absolute bottom-0 right-4 w-14 h-14 sm:w-16 sm:h-16 bg-primary-main hover:bg-[#2DB8A0] active:bg-primary-light text-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl active:shadow-2xl transition-all duration-300 hover:scale-110 active:scale-95 touch-manipulation",
                        style: {
                            minWidth: "56px",
                            minHeight: "56px"
                        },
                        "aria-label": "글 작성하기",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiEdit3"], {
                            className: "text-xl sm:text-2xl"
                        }, void 0, false, {
                            fileName: "[project]/components/CommunityFloatingButton.tsx",
                            lineNumber: 24,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/CommunityFloatingButton.tsx",
                        lineNumber: 15,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/CommunityFloatingButton.tsx",
                    lineNumber: 13,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/CommunityFloatingButton.tsx",
                lineNumber: 12,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityWriteModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isWriteModalOpen,
                onClose: ()=>setIsWriteModalOpen(false)
            }, void 0, false, {
                fileName: "[project]/components/CommunityFloatingButton.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/lib/content/recoveryGuidePosts.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// 19개 회복 가이드 글 데이터
// 각 글은 시술/수술명에 대한 회복 가이드입니다.
__turbopack_context__.s([
    "findRecoveryGuideById",
    ()=>findRecoveryGuideById,
    "findRecoveryGuideByKeyword",
    ()=>findRecoveryGuideByKeyword,
    "getAllRecoveryGuides",
    ()=>getAllRecoveryGuides,
    "recoveryGuidePosts",
    ()=>recoveryGuidePosts
]);
const recoveryGuidePosts = [
    // 예시 구조 (실제 19개 글은 사용자가 제공한 마크다운을 기반으로 채워야 함)
    {
        id: "jaw-contour-surgery",
        procedureName: "턱·윤곽·양악 수술",
        title: "턱·윤곽·양악 수술에 대한 회복 가이드🍀",
        description: "턱·윤곽·양악 등 얼굴 뼈 구조가 크게 변하는 수술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 턱·윤곽·양악 수술

권장 회복 기간 : 4주 이상

(해당 시술: V라인축소술, 사각턱수술, 턱끝수술, 턱끝축소술, 피질절골술, 교근축소술, 비절개턱성형, 이중턱근육묶기, 하악수술, 상악수술, 양악수술, 턱끝보형물삽입, 턱끝보형물제거, 턱끝이물질제거)

## 🕐 1주차 (Day 0–7)

### 얼굴 뼈 구조가 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

턱·윤곽·양악 수술은 얼굴의 연부조직이 아니라 뼈 구조 자체가 이동하거나 재배치되는 수술이기 때문에 몸의 반응이 매우 강하게 나타납니다. 이 시기에는 수술 부위뿐 아니라 얼굴 전체가 구조적으로 달라졌다는 사실을 인지하며 붓기, 멍, 압박감, 당김이 동시에 발생하는 것이 정상입니다. 뼈 위를 덮고 있던 근육과 피부, 신경이 새로운 위치에 적응하지 못한 상태이기 때문에 얼굴은 실제 결과보다 더 부어 있고 더 넓고 둔탁해 보일 수 있습니다. 이 시기의 외형은 수술 결과가 아니라 회복을 시작하기 전 나타나는 임시 모습에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 가능한 한 일정을 최소화하고 회복을 최우선으로 두기
- 수면 시 머리를 살짝만 높여 붓기 압력 줄이기
- 하루 여러 번 방 안이나 복도에서 3–5분 정도 가볍게 걷기
- 냉·온찜질은 반드시 병원 지침에 맞춰 진행

⚠ 권고사항

- 거울을 자주 보며 얼굴 폭이나 윤곽을 평가
- 무리한 외출이나 장시간 이동
- 통증·붓기를 문제 상황으로 단정

## 🕑 2주차 (Day 8–14)

### 강한 붓기는 줄고 윤곽 변화의 방향이 보이기 시작하는 시기

2주차부터는 수술 직후의 강한 염증 반응이 서서히 가라앉으며 얼굴 전체의 부피감이 줄어들기 시작합니다. 다만 이 시기는 붓기가 완전히 빠지는 단계가 아니라 큰 붓기와 잔붓기가 공존하는 과도기이기 때문에 아침과 저녁 얼굴 컨디션 차이가 뚜렷하게 나타날 수 있습니다. 이는 회복이 잘못된 것이 아니라 턱·윤곽·양악 수술에서 매우 흔한 정상 회복 패턴입니다. 이 시점에서는 세부 결과보다 윤곽이 어떤 방향으로 바뀌고 있는지 큰 흐름만 확인하는 것이 충분합니다.

✔ 이 주차에 도움 되는 팁

- 앉아서 쉴 수 있는 일정 위주의 외출
- 사진은 같은 조명과 각도로 기록용만 남기기
- 가벼운 산책으로 붓기 순환 돕기

⚠ 권고사항

- 수술 전 사진이나 타인 후기와의 과도한 비교
- 과음이나 밤샘 일정
- 아직 부어 있다는 이유로 조급해하기

## 🕒 3주차 (Day 15–21)

### 겉으로는 자연스러워 보이지만 내부는 적응을 마무리하는 시기

3주차에 접어들면 외관상 붓기는 상당 부분 정리되어 주변에서는 자연스럽다고 느끼는 경우가 많아집니다. 하지만 몸 안에서는 턱 주변 근육과 관절, 저작근이 새로운 위치와 사용 패턴에 적응하는 과정이 계속되고 있어 말이나 표정을 많이 사용한 날에는 뻐근함이나 피로감이 다시 느껴질 수 있습니다. 이는 회복이 나빠진 신호가 아니라 정상적인 적응 과정에서 나타나는 반응입니다.

✔ 이 주차에 도움 되는 팁

- 촬영이나 가벼운 여행 일정 가능
- 일정 중간중간 의도적으로 휴식 시간 넣기
- 피곤한 날은 일정을 줄이는 것도 회복의 일부로 받아들이기

⚠ 권고사항

- 격한 운동이나 턱을 과하게 사용하는 활동
- 이제 다 끝났다는 생각으로 무리

## 🕓 4주차 (Day 22–28)

### 일상은 가능하지만 회복은 아직 진행 중인 시기

4주차에는 일상생활과 출근, 일반적인 여행 일정이 대부분 가능해집니다. 다만 의학적으로 턱·윤곽·양악 수술의 안정화는 3–6개월에 걸쳐 진행되기 때문에 지금의 모습은 최종 결과라기보다 안정적으로 회복되고 있는 중간 단계에 가깝습니다. 이 시점에서 결과를 지나치게 엄격하게 평가하면 불필요한 불안만 커질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 의료진 허용 범위 내에서 가벼운 운동부터 시작
- 1·2주차 기록 사진과 비교해 변화 확인
- 피로 신호가 오면 휴식 우선

⚠ 권고사항

- 4주차에 결과를 단정
- 아직 불편하다는 이유로 실패로 연결

### 의료진 공통 안내

턱·윤곽·양악 수술의 회복은 속도가 아니라 순서입니다. 지금 주차에 맞는 관리만 유지하고 있다면 결과는 대부분 그 다음 단계에서 자연스럽게 따라옵니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "턱",
            "윤곽",
            "양악",
            "V라인",
            "사각턱",
            "턱끝",
            "하악",
            "상악"
        ]
    },
    {
        id: "cheek-temple-forehead-revision",
        procedureName: "광대 · 관자 · 이마 · 뒤통수 · 눈썹뼈 · 안면윤곽 재수술",
        title: "광대 · 관자 · 이마 · 뒤통수 · 눈썹뼈 · 안면윤곽 재수술에 대한 회복 가이드🍀",
        description: "광대, 관자, 이마, 뒤통수, 눈썹뼈 등 얼굴 상·중안면과 두상 구조가 함께 바뀌는 수술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 광대 · 관자 · 이마 · 뒤통수 · 눈썹뼈 · 안면윤곽 재수술

권장 회복 기간 : 3–4주

(해당 시술: 광대축소술, 앞광대축소술, 옆광대축소술, 전체광대축소술, 퀵광대축소술, 광대보형물삽입, 앞광대보형물삽입, 관자놀이보형물삽입, 관자놀이축소술, 이마보형물삽입, 이마축소술, 눈썹뼈축소술, 뒤통수보형물삽입, 광대이물질제거, 관자놀이이물질제거, 이마이물질제거, 안면윤곽재수술)

## 🕐 1주차 (Day 0–7)

### 얼굴 상·중안면과 두상 구조가 함께 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

광대, 관자, 이마, 뒤통수, 눈썹뼈 수술은 얼굴의 앞면뿐 아니라 옆면과 위쪽 구조까지 동시에 변화시키는 수술입니다. 한 부위만 수술했더라도 몸은 얼굴 전체와 두상이 하나의 구조로 바뀌었다고 인식하며 반응합니다. 이 시기에는 얼굴 윗부분이 단단하게 조여진 느낌이 들거나 헬멧을 쓴 것처럼 무겁게 느껴질 수 있고, 고개를 돌리거나 씹는 동작에서도 당김과 욱신거림이 동반될 수 있습니다. 겉으로 보이는 얼굴은 실제 결과보다 폭이 넓어 보이거나 이마·광대 윤곽이 과장돼 보일 수 있는데 이는 조직과 근막이 새로운 위치에 적응하지 못해 나타나는 정상 반응입니다.

✔ 이 주차에 도움 되는 팁

- 머리를 과하게 높이지 말고 살짝만 올린 상태로 휴식
- 얼굴 윤곽을 손으로 만지거나 눌러 확인하지 않기
- 실내 위주로 조용히 지내며 자극 최소화
- 냉·온찜질은 병원 지침에 맞춰 정확히 진행

⚠ 권고사항

- 거울을 자주 보며 광대 폭이나 이마 크기 평가
- 모자를 깊게 눌러 쓰거나 얼굴을 압박
- 웃음·표정을 과도하게 사용하는 행동
- 전보다 더 이상해 보인다는 생각으로 불안해하기

## 🕑 2주차 (Day 8–14)

### 붓기 속에서 윤곽이 정리되는 방향이 느껴지기 시작하는 시기

2주차부터는 수술 직후의 강한 염증 반응이 서서히 가라앉으며 얼굴 전체 부피감이 줄어들기 시작합니다. 다만 붓기가 한 번에 빠지지 않고 부위별로 이동하기 때문에 어떤 날은 광대가 더 도드라져 보이고, 어떤 날은 이마나 관자 쪽이 더 부어 보일 수 있습니다. 정면에서는 아직 넓어 보이더라도 측면이나 45도 각도에서 윤곽의 입체감이 이전과 다르게 느껴지기 시작하는 시기입니다. 이 단계에서는 세부 모양보다 윤곽이 정리되는 방향만 가볍게 확인하는 것이 적절합니다.

✔ 이 주차에 도움 되는 팁

- 오전보다 오후 얼굴 컨디션 기준으로 일정 조절
- 카페·전시처럼 앉아서 쉴 수 있는 일정 위주로 외출
- 사진은 같은 각도와 조명으로 기록
- 충분한 수분 섭취로 순환 돕기

⚠ 권고사항

- 하루 단위로 얼굴 윤곽을 세밀하게 비교
- 강한 햇빛이나 사우나·찜질방
- 붓기가 남아 있다는 이유로 조급해하기

## 🕒 3주차 (Day 15–21)

### 주변에서 변화가 먼저 인지되기 시작하는 시기

3주차에 접어들면 외관상 붓기는 상당 부분 정리되어 주변 사람들은 얼굴이 작아졌거나 인상이 부드러워졌다고 느끼는 경우가 많아집니다. 사진에서는 광대와 이마 윤곽이 자연스럽게 이어져 보이고 두상 라인도 안정적으로 정돈된 인상을 줍니다. 다만 일정이 많거나 표정을 많이 사용한 날에는 뻐근함이나 피로감이 다시 느껴질 수 있는데 이는 회복이 나빠진 것이 아니라 구조 적응 과정에서 나타나는 정상 반응입니다.

✔ 이 주차에 도움 되는 팁

- 촬영·가벼운 여행 일정 무리 없이 가능
- 장시간 일정 중간중간 휴식 시간 확보
- 머리카락 스타일로 윤곽을 자연스럽게 보완
- 자연광에서 사진으로 변화 기록

⚠ 권고사항

- 격한 표정 사용이나 장시간 웃음 유지
- 밤샘이나 과음으로 붓기 재발
- 이제 다 끝났다는 생각으로 관리 소홀

## 🕓 4주차 (Day 22–28)

### 겉보기엔 자연스럽지만 내부 구조는 계속 안정되는 중

4주차에는 타인이 보기엔 수술 여부를 알아채기 어려울 정도로 윤곽이 자연스럽게 보일 수 있습니다. 하지만 광대·관자·이마·두상 윤곽 수술은 뼈와 근막, 연부조직이 함께 적응하는 과정이기 때문에 진짜 안정화는 3–6개월에 걸쳐 진행됩니다. 지금의 얼굴은 최종 결과라기보다 안정적으로 회복되고 있는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 일상생활 대부분 무리 없이 가능
- 가벼운 산책과 스트레칭부터 단계적으로 활동 재개
- 3개월 차를 기준으로 변화 관찰 계획 세우기
- 피로 신호가 오면 즉시 휴식

⚠ 권고사항

- 경락이나 윤곽 마사지 성급히 시작
- 미세한 비대칭을 과도하게 확대 해석
- 1개월 차 얼굴을 최종 결과로 규정

### 의료진 공통 안내

광대·관자·이마·두상 윤곽 수술의 회복은 빠르게 보이는 변화보다 안정적으로 자리 잡는 과정이 더 중요합니다. 지금의 회복 흐름이 유지되고 있다면 시간이 지날수록 더욱 부드럽고 자연스러운 윤곽으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "광대",
            "관자",
            "이마",
            "뒤통수",
            "눈썹뼈",
            "안면윤곽",
            "재수술",
            "광대축소",
            "관자놀이",
            "이마축소"
        ]
    },
    {
        id: "nose-surgery-non-surgical",
        procedureName: "코 수술·비절개·코 시술",
        title: "코 수술·비절개·코 시술에 대한 회복 가이드🍀",
        description: "코 수술, 비절개 코 교정, 코 시술 등 얼굴 중심 축이 바뀌는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 코 수술·비절개·코 시술

권장 회복 기간 : 2–4주

(해당 시술: 콧대보형물삽입, 콧대자가조직이식, 콧대인공조직삽입, 비주연장술, 코길이연장술, 복코교정수술, 비절개코교정, 미스코, 하이코, 고양이수술, 코필러, 코보톡스)

## 🕐 1주차 (Day 0–7)

### 얼굴 중심 축이 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

코는 얼굴의 중심이자 호흡·발음·표정과 연결된 구조이기 때문에 작은 변화에도 몸의 반응이 크게 나타납니다. 이 시기에는 붓기, 압박감, 당김, 이물감이 동시에 느껴질 수 있고 코가 실제 결과보다 더 커 보이거나 둔해 보이는 착시가 흔합니다. 수술과 비절개, 시술 모두 조직 자극이 겹치면서 코 라인이 과장돼 보일 수 있으며 이는 결과가 아니라 회복 전 단계의 정상 반응에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 얼굴을 베개나 손에 파묻지 않고 정면을 향한 수면 자세 유지
- 수분 섭취를 늘려 비강 건조 예방
- 병원 안내에 따른 세척·연고·찜질 루틴 정확히 지키기
- 외출은 최소화하고 실내 위주로 휴식

⚠ 권고사항

- 코를 비비거나 만져 모양 확인
- 마스크를 코에 강하게 눌러 착용
- 뜨거운 음식과 과음
- 초반 사진만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 붓기 속에서 코 라인의 방향성이 보이기 시작하는 시기

2주차부터는 초기 염증 반응이 가라앉으며 정면·측면에서 이전과 다른 실루엣이 느껴지기 시작합니다. 수술 계열은 단단함과 당김이 남아 있을 수 있고 비절개·시술 계열은 이 시점에서 비교적 라인이 또렷해지는 경우가 많습니다. 다만 붓기가 부위별로 이동해 하루하루 인상이 달라 보일 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 사람 많은 곳에서만 마스크 착용해 압박 최소화
- 카페·쇼핑 등 가벼운 외출 가능
- 자연광에서 정면·45도 각도로 사진 기록
- 코 안쪽 건조 시 처방 제품만 사용

⚠ 권고사항

- 콧대나 코끝을 눌러 모양 확인
- 강한 햇빛·사우나·찜질방
- 어색함을 과도하게 확대 해석

## 🕒 3주차 (Day 15–21)

### 코 라인이 얼굴 인상에 자연스럽게 섞이는 시기

3주차에는 코가 얼굴 전체 인상에 자연스럽게 어우러지기 시작합니다. 웃거나 말할 때의 어색함이 줄고 촬영이나 약속 일정이 비교적 자유로워집니다. 다만 일정이 많았던 날에는 미세한 뻐근함이 남을 수 있으나 이는 적응 과정에서 흔히 나타나는 반응입니다.

✔ 이 주차에 도움 되는 팁

- 촬영·여행 일정 무리 없이 가능
- 살짝 위에서 아래로 찍는 각도가 안정적
- 가벼운 메이크업부터 단계적 복귀
- 코 주변 자외선 차단 유지

⚠ 권고사항

- 사람 많은 곳에서 부딪힘 주의
- 과음·밤샘으로 붓기 재발
- 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정되지만 내부 조직은 계속 적응 중

4주차에는 외관상 충분히 자연스럽게 보일 수 있습니다. 하지만 코는 연골·연부조직·피부가 함께 적응하는 구조라 미세한 변화가 3–6개월까지 이어질 수 있습니다. 지금의 코는 최종 결과라기보다 안정적으로 자리 잡아가는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 일상·여행·비행 대부분 무리 없이 가능
- 3개월 차 사진을 기준으로 변화 비교 계획
- 자극 없는 생활 습관 유지
- 건조감·당김이 남으면 보습 관리 지속

⚠ 권고사항

- 코 마사지·경락·강한 압박
- 미세한 높이·각도 차이에 집착
- 1개월 차를 최종 결과로 규정

### 의료진 공통 안내

코 수술·비절개·코 시술은 회복 과정에서 심리적 흔들림이 큰 편이지만 현재의 변화는 정상적인 흐름 안에 있습니다. 주차에 맞는 관리만 유지한다면 시간이 지날수록 얼굴과 조화로운 코 라인으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "코",
            "비절개",
            "콧대",
            "코필러",
            "코보톡스",
            "비주연장",
            "복코",
            "미스코",
            "하이코"
        ]
    },
    {
        id: "eye-surgery-revision",
        procedureName: "눈 성형·트임·재수술",
        title: "눈 성형·트임·재수술에 대한 회복 가이드🍀",
        description: "쌍꺼풀 수술, 눈매교정, 트임 수술, 눈 재수술 등 미세한 근육·피부 구조 변화에 눈이 반응하는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 눈 성형·트임·재수술

권장 회복 기간 : 2–4주

(해당 시술: 쌍꺼풀수술(절개법), 쌍꺼풀수술(매몰법), 쌍꺼풀재수술, 눈매교정수술, 상안검수술, 하안검수술, 앞트임수술, 뒤트임수술, 밑트임수술, 복합트임수술, 눈재수술)

## 🕐 1주차 (Day 0–7)

### 미세한 근육·피부 구조 변화에 눈이 가장 예민하게 반응하는 시기

눈은 피부가 얇고 표정 근육 사용이 잦아 작은 구조 변화에도 반응이 크게 나타납니다. 이 시기에는 붓기, 멍, 당김, 압박감이 동시에 나타날 수 있고 눈이 실제 결과보다 더 커 보이거나 과하게 올라가 보이는 착시가 흔합니다. 절개·재수술의 경우 봉합 부위 긴장으로 눈매가 강해 보일 수 있으며 트임 수술은 눈꼬리 주변이 당겨져 어색하게 느껴질 수 있습니다. 지금의 인상은 결과가 아니라 회복을 시작하기 전의 정상 반응입니다.

✔ 이 주차에 도움 되는 팁

- 눈을 세게 뜨거나 찡그리는 표정 최소화
- 수면 시 머리를 살짝 높여 부종 압력 줄이기
- 냉찜질은 병원 지침에 맞춰 짧게 진행
- 실내 위주 일정으로 휴식 우선

⚠ 권고사항

- 눈을 문지르거나 라인을 눌러 확인
- 장시간 화면 응시
- 진한 아이메이크업
- 초반 사진만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 붓기는 줄고 라인의 방향성이 보이기 시작하는 시기

2주차부터는 강한 붓기와 멍이 서서히 가라앉으며 쌍꺼풀 라인과 눈매 교정 방향이 느껴지기 시작합니다. 다만 아침에는 눈두덩이 두툼해 보이고 오후로 갈수록 가벼워지는 일중 차이가 흔합니다. 트임 수술은 눈꼬리 당김이 남아 있을 수 있으나 점차 완화되는 흐름이 정상입니다.

✔ 이 주차에 도움 되는 팁

- 오전보다 오후 컨디션 기준으로 상태 판단
- 자연광에서 정면 사진으로만 기록
- 처방 연고·안약 루틴 정확히 유지
- 가벼운 외출 가능하되 자극 최소화

⚠ 권고사항

- 좌우 라인을 하루 단위로 비교
- 사우나·찜질방
- "아직 어색하다"는 이유로 조급해하기

## 🕒 3주차 (Day 15–21)

### 눈매가 얼굴 인상에 자연스럽게 섞이는 시기

3주차에는 눈의 붓기가 상당 부분 정리되어 사진과 영상에서 인상이 한결 부드러워집니다. 쌍꺼풀 라인은 피부 움직임에 따라 자연스럽게 접히기 시작하고 눈매교정·트임 효과도 얼굴 전체와 조화롭게 느껴집니다. 다만 피로한 날에는 미세한 붓기나 당김이 다시 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 촬영·약속 일정 무리 없이 가능
- 가벼운 아이메이크업부터 단계적 복귀
- 충분한 수면으로 붓기 재발 방지
- 전체 인상 기준으로 변화 평가

⚠ 권고사항

- 격한 표정 연습
- 과음·밤샘
- 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정되지만 내부 조직은 계속 적응 중

4주차에는 외관상 눈매가 비교적 안정돼 보일 수 있습니다. 그러나 절개·재수술의 경우 내부 조직 안정화는 3–6개월에 걸쳐 진행됩니다. 지금의 눈은 최종 결과라기보다 안정적으로 자리 잡아가는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 일상·여행 대부분 무리 없이 가능
- 자외선 차단과 눈가 보습 루틴 유지
- 3개월 차를 기준으로 변화 비교 계획
- 피로 신호가 오면 휴식 우선

⚠ 권고사항

- 눈가 마사지·경락 성급히 시작
- 미세한 좌우 차이에 집착
- 1개월 차를 최종 결과로 규정

### 의료진 공통 안내

눈 성형·트임·재수술의 회복은 미세한 변화가 누적되며 완성됩니다. 주차에 맞는 관리만 유지한다면 시간이 지날수록 더 자연스럽고 안정적인 눈매로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "눈",
            "쌍꺼풀",
            "눈매교정",
            "트임",
            "눈재수술",
            "상안검",
            "하안검",
            "앞트임",
            "뒤트임"
        ]
    },
    {
        id: "under-eye-fat-dark-circle",
        procedureName: "눈밑·눈 지방·다크서클",
        title: "눈밑·눈 지방·다크서클에 대한 회복 가이드🍀",
        description: "눈밑 지방재배치, 지방제거, 지방이식, 다크서클 개선 등 얇은 피부층과 혈관 변화에 몸이 반응하는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 눈밑·눈 지방·다크서클

권장 회복 기간 : 2–3주

(해당 시술: 눈밑지방재배치, 눈밑지방제거, 눈밑지방이식, 눈물고랑교정, 다크서클지방이식, 눈밑보형물, 눈밑필러)

## 🕐 1주차 (Day 0–7)

### 얇은 피부층과 혈관 변화에 몸이 가장 예민하게 반응하는 시기

눈밑은 얼굴에서 피부가 가장 얇고 혈관과 지방층이 밀집된 부위라 작은 자극에도 색감과 부피 변화가 크게 느껴집니다. 이 시기에는 붓기와 멍, 당김이 동시에 나타나며 눈밑이 실제보다 더 어둡거나 도톰해 보이는 착시가 흔합니다. 눈밑지방재배치나 지방이식 후에는 울퉁불퉁함이나 좌우 차이가 더 도드라져 보일 수 있으나 이는 조직이 아직 자리를 잡지 못한 정상 반응입니다. 지금의 인상은 결과가 아니라 회복을 준비하는 초기 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 냉찜질은 병원 지침에 맞춰 짧게 진행
- 눈을 과도하게 사용하지 않고 휴식 위주 생활
- 수면 시 머리를 살짝 높여 부종 압력 줄이기
- 인공눈물로 눈가 건조 관리

⚠ 권고사항

- 눈밑을 눌러 모양 확인
- 장시간 화면 응시
- 진한 아이메이크업
- 멍이나 색감만으로 결과 단정

## 🕑 2주차 (Day 8–14)

### 색감과 볼륨이 분리되어 보이기 시작하는 시기

2주차부터는 멍과 강한 붓기가 줄어들며 눈밑의 색감과 부피가 구분되어 보이기 시작합니다. 다크서클은 밝아지는 방향성이 느껴질 수 있고 지방 계열 시술은 도톰함이 퍼지며 라인이 정리됩니다. 다만 아침과 저녁, 컨디션에 따라 눈밑 색이 다시 진해 보일 수 있는데 이는 혈류와 순환 변화에 따른 정상적인 회복 패턴입니다.

✔ 이 주차에 도움 되는 팁

- 가벼운 외출과 촬영 일정 가능
- 자연광에서 정면 사진으로 변화 기록
- 눈가 보습과 자외선 차단 유지
- 오후 컨디션 기준으로 상태 판단

⚠ 권고사항

- 하루 단위로 색 변화 집요하게 비교
- 사우나·찜질방
- 수면 부족으로 회복 지연

## 🕒 3주차 (Day 15–21)

### 눈밑 인상이 얼굴 전체에 자연스럽게 섞이는 시기

3주차에 들어서면 눈밑이 얼굴 인상에 자연스럽게 녹아들기 시작합니다. 사진과 영상에서 피곤해 보이던 느낌이 줄고 컨실러 사용량이 줄어드는 경우가 많습니다. 다만 일정이 많았던 날에는 미세한 부종이나 색감 변화가 다시 느껴질 수 있으나 이는 회복 흐름 안에 있는 정상 반응입니다.

✔ 이 주차에 도움 되는 팁

- 일상·여행 일정 무리 없이 가능
- 가벼운 메이크업 단계적 복귀
- 충분한 수면과 수분 섭취 유지
- 월 단위 사진으로 변화 비교

⚠ 권고사항

- 밤샘이나 과음
- 눈가 마사지 성급히 시작
- 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정되지만 미세 변화는 계속되는 시기

4주차에는 외관상 눈밑이 비교적 안정돼 보일 수 있습니다. 다만 지방의 생착과 재배치, 혈관 색감 변화는 3–6개월까지 이어질 수 있어 미세한 인상 변화가 남아 있을 수 있습니다. 지금의 눈밑은 최종 결과라기보다 안정적으로 자리 잡아가는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 생활 리듬을 일정하게 유지
- 눈가 보습·자외선 차단 루틴 지속
- 3개월 차를 기준으로 변화 관찰 계획
- 피로 신호가 오면 휴식 우선

⚠ 권고사항

- 미세한 좌우 차이에 집착
- 1개월 차를 최종 결과로 규정
- 즉흥적인 추가 시술 결정

### 의료진 공통 안내

눈밑·눈 지방·다크서클 개선은 작은 변화가 인상에 크게 작용하는 영역입니다. 회복 주차에 맞는 관리만 유지한다면 시간이 지날수록 더 맑고 안정적인 눈밑 인상으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "눈밑",
            "눈밑지방",
            "다크서클",
            "눈물고랑",
            "눈밑보형물",
            "눈밑필러"
        ]
    },
    {
        id: "eye-area-volume",
        procedureName: "눈 주변 볼륨 시술",
        title: "눈 주변 볼륨 시술에 대한 회복 가이드🍀",
        description: "애교살 필러, 눈물고랑 필러, 눈밑 필러 등 미세한 볼륨 변화가 시야와 표정 감각을 자극하는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 눈 주변 볼륨 시술

권장 회복 기간 : 1–2주

(해당 시술: 애교살필러, 눈물고랑필러, 눈밑필러, 앞볼볼륨시술, 뒤볼볼륨시술, 눈가스킨부스터, 눈가리프팅시술)

## 🕐 1주차 (Day 0–7)

### 미세한 볼륨 변화가 시야와 표정 감각을 동시에 자극하는 시기

눈 주변은 피부가 얇고 움직임이 잦아 소량의 볼륨 변화에도 인상이 크게 달라 보입니다. 이 시기에는 주입 자극과 조직 반응으로 인해 붓기, 당김, 미세한 압박감이 함께 느껴질 수 있으며 애교살이나 눈물고랑이 실제보다 더 도톰하거나 좌우가 달라 보이는 착시가 흔합니다. 주입 부위가 단단하게 만져지거나 표정에 따라 울퉁불퉁해 보일 수 있는데 이는 볼륨이 아직 퍼지지 않은 정상 반응입니다. 지금의 모습은 결과가 아니라 볼륨이 자리를 찾기 전의 임시 상태에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 눈가를 누르거나 만지지 않기
- 수분 섭취를 늘려 조직 순환 돕기
- 화면 사용 시간을 줄이고 휴식 위주로 생활
- 냉찜질은 필요 시 짧게만 진행

⚠ 권고사항

- 눈가 마사지나 문지르기
- 진한 아이메이크업
- 초반 사진만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 볼륨이 퍼지며 인상에 자연스럽게 섞이기 시작하는 시기

2주차에는 초기 붓기가 가라앉으며 눈 주변 볼륨이 퍼져 자연스러운 곡선으로 이어지기 시작합니다. 애교살필러는 웃을 때 더 자연스럽게 보이고 눈물고랑필러는 음영이 완화되는 방향성이 느껴질 수 있습니다. 다만 아침과 저녁, 컨디션에 따라 볼륨감이 달라 보일 수 있는데 이는 순환 차이에 따른 정상적인 변화입니다.

✔ 이 주차에 도움 되는 팁

- 가벼운 외출과 촬영 일정 가능
- 자연광에서 정면·45도 각도로 사진 기록
- 눈가 보습과 자외선 차단 유지
- 오후 컨디션 기준으로 변화 확인

⚠ 권고사항

- 하루 단위로 볼륨 높낮이 비교
- 사우나·찜질방
- 즉흥적인 추가 시술 결정

## 🕒 3주차 (Day 15–21)

### 표정과 함께 볼륨이 자연스럽게 작동하는 시기

3주차에 들어서면 눈 주변 볼륨이 표정에 자연스럽게 반응하며 인상에 안정적으로 녹아듭니다. 사진과 영상에서 과한 티가 줄고 또렷하지만 부드러운 눈매로 보이는 경우가 많습니다. 다만 일정이 많거나 수면이 부족한 날에는 미세한 붓기가 다시 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 메이크업 루틴 단계적 복귀
- 충분한 수면과 수분 섭취 유지
- 월 단위 사진으로 변화 기록
- 눈가 자극 최소화

⚠ 권고사항

- 과음·밤샘
- 눈가 경락·강한 압박
- 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정적이며 유지 관리 시점을 판단하는 시기

4주차에는 외관상 볼륨이 충분히 안정돼 보입니다. 다만 필러·볼륨 시술은 유지 관리가 중요한 영역이므로 이 시점은 완성이라기보다 현재 상태를 기준으로 다음 관리 시점을 계획하는 단계에 가깝습니다.

✔ 이 주차에 도움 되는 팁

- 현재 상태를 기준으로 유지 기간 메모
- 자외선 차단·보습 루틴 지속
- 과한 욕심보다 현 상태 유지에 집중
- 장기 관리 계획 세우기

⚠ 권고사항

- 미세한 좌우 차이에 집착
- 유지 기간을 넘긴 무리한 방치
- 1개월 차를 최종 결과로 규정

### 의료진 공통 안내

눈 주변 볼륨 시술은 소량의 변화가 인상 전체에 크게 작용합니다. 회복 주차에 맞는 관리만 유지한다면 시간이 지날수록 표정과 자연스럽게 어우러진 안정적인 눈가로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "애교살",
            "눈물고랑",
            "눈밑필러",
            "앞볼볼륨",
            "뒤볼볼륨",
            "눈가스킨부스터",
            "눈가리프팅"
        ]
    },
    {
        id: "face-fat-grafting-volume",
        procedureName: "얼굴 지방이식 · 팔자 · 풀페이스 볼륨",
        title: "얼굴 지방이식 · 팔자 · 풀페이스 볼륨에 대한 회복 가이드🍀",
        description: "얼굴 지방이식, 풀페이스 지방이식, 팔자주름 지방이식 등 얼굴 전체의 볼륨 중심이 바뀌는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 얼굴 지방이식 · 팔자 · 풀페이스 볼륨

권장 회복 기간 : 2–4주

(해당 시술: 얼굴지방이식, 풀페이스지방이식, 이마지방이식, 관자지방이식, 앞광대지방이식, 볼지방이식, 팔자주름지방이식, 인디언주름지방이식, 마리오넷라인지방이식, 입가주름지방이식, 얼굴지방이식재수술, 볼꺼짐교정, 얼굴볼륨교정)

## 🕐 1주차 (Day 0–7)

### 얼굴 전체의 볼륨 중심이 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

특정 부위만 지방이식이나 볼륨 교정을 했더라도 얼굴은 이를 부분 변화가 아닌 전체 구조 변화로 인식합니다. 이 시기에는 지방이 들어간 부위뿐 아니라 주변 조직까지 함께 반응하면서 얼굴이 실제보다 더 둥글고 커 보이거나 과하게 통통해 보일 수 있습니다. 붓기, 묵직함, 당김, 압박감이 동시에 느껴지는 것이 정상이며 좌우 비대칭이나 울퉁불퉁함이 더 도드라져 보일 수 있습니다. 이는 지방이 자리를 잡기 전 조직 반응이 가장 활발한 단계로 지금의 외형은 결과가 아니라 회복 전 단계의 임시 모습에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 얼굴을 아래로 오래 숙이지 않고 정면 자세 유지
- 수면 시 베개를 살짝 높여 부종 압력 줄이기
- 냉찜질은 병원 지침에 맞춰 제한적으로 진행
- 외출은 최소화하고 휴식 위주로 생활

⚠ 권고사항

- 얼굴을 눌러 볼륨 확인
- 과한 표정 사용이나 크게 웃기
- Day 3~5 얼굴만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 볼륨이 퍼지며 얼굴 비율이 정리되기 시작하는 시기

2주차부터는 강한 붓기가 서서히 가라앉으며 얼굴에 몰려 있던 볼륨이 퍼지기 시작합니다. 이마와 관자, 앞광대 부위는 비교적 먼저 안정되는 편이고 팔자주름지방이식이나 입가주름지방이식 부위는 상대적으로 붓기가 늦게 빠질 수 있습니다. 지방이식 특성상 빠진 것처럼 보였다가 다시 차오르는 느낌을 받을 수 있는데 이는 흡수와 생착이 동시에 진행되는 정상적인 회복 과정입니다.

✔ 이 주차에 도움 되는 팁

- 자연광에서 정면·45도 사진으로 변화 기록
- 가벼운 메이크업 단계적 복귀
- 수분 섭취를 늘려 순환 도움
- 오전보다 오후 컨디션 기준으로 판단

⚠ 권고사항

- 얼굴 마사지·경락·롤러 사용
- 거울을 가까이 대고 확대 비교
- 하루 단위로 볼륨 변화 집요하게 분석

## 🕒 3주차 (Day 15–21)

### 인상이 부드러워지고 볼륨감이 자연스럽게 느껴지는 시기

3주차에 접어들면 얼굴이 과하게 통통해 보이던 느낌이 줄고 전체 인상이 한결 부드러워집니다. 사진에서 광대와 팔자, 입가 라인이 자연스럽게 이어져 보이며 피곤해 보이던 인상이 완화되는 경우가 많습니다. 다만 일부 부위는 만졌을 때 딱딱함이나 뭉침이 남아 있을 수 있는데 이는 대부분 정상적인 회복 과정에 포함됩니다.

✔ 이 주차에 도움 되는 팁

- 촬영·약속·데이트 일정 무리 없이 가능
- 평소 스타일 메이크업으로 점진적 복귀
- 얼굴 스트레칭은 짧고 가볍게 진행
- 충분한 수면으로 생착 환경 유지

⚠ 권고사항

- 강한 경락이나 압박 마사지
- 급격한 체중 감량 시도
- 이제 다 됐다는 생각으로 관리 중단

## 🕓 4주차 (Day 22–28)

### 볼륨은 안정되지만 최종 판단은 아직 이른 시기

4주차에는 외관상 얼굴 볼륨이 상당히 자연스럽게 느껴질 수 있습니다. 하지만 얼굴지방이식은 1개월은 안정 단계에 해당하며 최종 생착 판단은 3개월을 기준으로 하는 것이 적절합니다. 지금의 얼굴은 이미 충분히 조화롭지만 앞으로 더 잔잔하게 정리될 여지가 남아 있는 중간 단계입니다.

✔ 이 주차에 도움 되는 팁

- 일상·여행·촬영 대부분 가능
- 자외선 차단과 보습 관리 지속
- 체중 변화 없이 생활 리듬 유지
- 3개월 차 사진 기준으로 변화 비교 계획

⚠ 권고사항

- 얼굴 마사지·고주파 시술 성급히 시작
- 미세한 볼륨 차이에 과도하게 집착
- 1개월 차 얼굴을 최종 결과로 단정

### 의료진 공통 안내

얼굴 지방이식과 볼륨 교정은 짧은 시간에 완성되는 시술이 아니라 시간을 두고 자연스럽게 자리 잡는 과정입니다. 현재의 회복 흐름이 유지된다면 시간이 지날수록 표정과 더욱 조화로운 얼굴로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "지방이식",
            "풀페이스",
            "팔자",
            "인디언주름",
            "마리오넷라인",
            "볼륨교정",
            "볼꺼짐"
        ]
    },
    {
        id: "lifting-surgery-thread-laser",
        procedureName: "리프팅 수술 · 실리프팅 · 레이저·고주파 리프팅",
        title: "리프팅 수술 · 실리프팅 · 레이저·고주파 리프팅에 대한 회복 가이드🍀",
        description: "안면거상, 실리프팅, 울쎄라, 써마지, 인모드 등 피부·근막·지지 구조가 동시에 당겨지는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 리프팅 수술 · 실리프팅 · 레이저·고주파 리프팅

권장 회복 기간 : 2–4주

(해당 시술: 안면거상술, 미니거상술, SMAS거상술, 목거상술, 실리프팅, 민트실리프팅, 울쎄라리프팅, 써마지리프팅, 슈링크리프팅, 인모드리프팅, 온다리프팅, 티타늄리프팅, 고주파리프팅, 레이저리프팅 전반)

## 🕐 1주차 (Day 0–7)

### 피부·근막·지지 구조가 동시에 당겨졌다는 사실을 몸이 가장 강하게 인지하는 시기

리프팅 수술과 실리프팅, 레이저·고주파 리프팅은 방식은 다르지만 공통적으로 피부와 그 아래 구조에 당김과 열 자극, 고정 변화가 발생합니다. 이 시기에는 붓기, 뻐근함, 당김, 열감이 동시에 느껴질 수 있으며 얼굴이 실제보다 더 당겨져 보이거나 표정이 어색하게 느껴질 수 있습니다. 특히 울쎄라리프팅, 써마지리프팅, 인모드리프팅 같은 에너지 기반 시술은 겉으로 큰 변화가 없어 보여도 내부 조직 반응이 강하게 일어나는 단계입니다. 지금의 인상은 결과가 아니라 조직이 자극을 인지하고 안정화를 준비하는 초기 반응에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 표정 사용을 최소화하고 얼굴 근육 휴식 우선
- 수면 시 머리를 살짝 높여 붓기 압력 줄이기
- 자외선 차단과 보습을 즉시 루틴화
- 실내 위주 일정으로 열·자극 최소화

⚠ 권고사항

- 얼굴을 눌러 당김 정도 확인
- 사우나·찜질방·격한 운동
- 즉각적인 리프팅 효과를 기대하며 거울 반복 확인

## 🕑 2주차 (Day 8–14)

### 당김은 줄고 리프팅 방향성이 느껴지기 시작하는 시기

2주차부터는 강한 붓기와 열감이 가라앉으며 얼굴이 조금씩 편안해지기 시작합니다. 실리프팅은 고정된 방향이 느껴지고 레이저·고주파 리프팅은 피부결이 정리되며 탄탄해지는 느낌이 먼저 옵니다. 다만 아침과 저녁, 활동량에 따라 당김 정도가 달라질 수 있는데 이는 회복 과정에서 매우 흔한 패턴입니다. 이 시기에는 얼마나 당겨졌는지를 보기보다 얼굴이 어떤 방향으로 정리되는지만 가볍게 확인하는 것이 적절합니다.

✔ 이 주차에 도움 되는 팁

- 앉아서 쉴 수 있는 일정 위주로 외출
- 자연광에서 정면·45도 각도로 사진 기록
- 보습 제품을 평소보다 충분히 사용
- 오후 컨디션 기준으로 상태 판단

⚠ 권고사항

- 하루 단위로 탄력 변화를 집요하게 비교
- 추가 리프팅 시술 즉흥 결정
- 강한 클렌징·마사지

## 🕒 3주차 (Day 15–21)

### 얼굴 인상이 자연스럽게 정돈돼 보이는 시기

3주차에 접어들면 타인이 보기에 인상이 한결 정돈돼 보이고 얼굴선이 부드러워졌다는 느낌을 받는 경우가 많습니다. 실리프팅과 수술 리프팅은 고정감이 안정되고 레이저·고주파 리프팅은 피부 탄력과 결 개선이 체감되기 시작합니다. 다만 일정이 많거나 말을 많이 한 날에는 당김이나 피로감이 다시 느껴질 수 있는데 이는 회복이 후퇴한 것이 아니라 적응 과정의 일부입니다.

✔ 이 주차에 도움 되는 팁

- 촬영·약속·여행 일정 무리 없이 가능
- 가벼운 스트레칭과 산책으로 순환 도움
- 피부 컨디션 좋은 날을 기준으로 변화 기억
- 월 단위 사진 기록 시작

⚠ 권고사항

- 고강도 운동·안면 마사지
- 밤샘·과음으로 붓기 재발
- 이제 끝났다는 생각으로 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정적이지만 내부 구조는 계속 적응 중인 시기

4주차에는 외관상 리프팅 효과가 비교적 안정돼 보입니다. 하지만 수술 리프팅과 실리프팅, 레이저·고주파 리프팅 모두 피부와 근막의 진짜 안정은 3–6개월에 걸쳐 진행됩니다. 지금의 모습은 최종 결과라기보다 효과가 자리 잡아가는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 일상·출근·여행 대부분 무리 없이 가능
- 자외선 차단·보습 루틴 생활화
- 3개월 차를 기준으로 유지·추가 관리 계획
- 피로 신호가 오면 즉시 휴식

⚠ 권고사항

- 리프팅 효과를 단기간으로 단정
- 미세한 처짐 변화에 과도하게 집착
- 1개월 차 얼굴을 최종 결과로 규정

### 의료진 공통 안내

리프팅 수술과 실리프팅, 레이저·고주파 리프팅은 즉각적인 변화보다 시간이 지날수록 자연스럽게 완성되는 관리입니다. 주차에 맞는 생활 관리만 유지한다면 현재의 효과는 보다 안정적으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "리프팅",
            "실리프팅",
            "안면거상",
            "울쎄라",
            "써마지",
            "인모드",
            "고주파",
            "레이저리프팅"
        ]
    },
    {
        id: "face-lift-forehead-wrinkle",
        procedureName: "안면거상·이마거상·주름 개선 수술",
        title: "안면거상·이마거상·주름 개선 수술에 대한 회복 가이드🍀",
        description: "안면거상, 이마거상, 팔자박리, 마리오넷라인박리 등 피부와 근막이 재배치되는 수술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 안면거상·이마거상·주름 개선 수술

권장 회복 기간 : 3–4주

(해당 시술: 안면거상술, 미니거상술, SMAS거상술, 중안면거상술, 하안면거상술, 목거상술, 이마거상술, 눈썹거상술, 팔자박리술, 마리오넷라인박리, 주름개선수술, 거상재수술)

## 🕐 1주차 (Day 0–7)

### 피부와 근막이 재배치되었다는 사실을 몸이 가장 강하게 인지하는 시기

안면거상과 이마거상, 주름 개선 수술은 피부 표면만의 변화가 아니라 근막(SMAS)과 연부조직의 위치가 함께 이동하는 수술입니다. 이 시기에는 강한 당김, 압박감, 묵직함이 느껴질 수 있고 귀 주변·두피·턱선이 어색하게 느껴질 수 있습니다. 겉으로 보이는 얼굴은 실제 결과보다 더 팽팽하거나 당겨져 보일 수 있으나 이는 고정과 부종이 겹친 정상 반응입니다. 지금의 인상은 결과 판단의 기준이 아니라 조직이 새로운 위치에 고정되기 위한 초기 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 표정 사용을 최소화하고 말수 줄이기
- 수면 시 머리를 살짝 높여 부종 압력 완화
- 병원에서 안내한 압박밴드·거즈 관리 철저
- 실내 위주로 조용히 휴식

⚠ 권고사항

- 입을 크게 벌리거나 하품 참기
- 귀 주변·두피 절개 부위 만지기
- 거울로 당김 정도를 반복 확인

## 🕑 2주차 (Day 8–14)

### 당김은 줄고 붓기와 뻣뻣함이 남는 시기

2주차부터는 초기의 강한 당김이 서서히 완화되고 뻣뻣함, 묵직함, 감각 둔함이 중심이 됩니다. 이마거상술은 눈 위가 무겁게 느껴질 수 있고 안면거상술·팔자박리술은 입 주변과 턱선 감각이 둔하게 느껴질 수 있습니다. 이는 신경과 조직이 새로운 위치에 적응하는 과정에서 흔히 나타나는 반응입니다.

✔ 이 주차에 도움 되는 팁

- 짧은 외출과 카페 일정 가능
- 부드러운 음식 위주로 천천히 식사
- 얼굴을 아래로 오래 숙이지 않기
- 오후 컨디션 기준으로 상태 판단

⚠ 권고사항

- 경락·마사지·롤러 사용
- 절개 부위를 눌러 확인
- 하루 단위로 주름 변화를 집요하게 비교

## 🕒 3주차 (Day 15–21)

### 윤곽과 주름 개선 효과가 눈에 띄기 시작하는 시기

3주차에 접어들면 팔자주름과 마리오넷라인, 턱선이 전보다 정돈돼 보이기 시작합니다. 주변에서는 인상이 단정해졌다는 말을 먼저 듣는 경우도 많습니다. 다만 표정을 크게 사용하면 여전히 약간의 뻣뻣함이나 당김 잔여감이 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 촬영·약속·가벼운 여행 일정 가능
- 웃는 표정은 자연스럽게, 과하지 않게
- 자외선 차단과 보습 관리 강화
- 자연광에서 변화 기록

⚠ 권고사항

- 장시간 웃거나 말해야 하는 일정 무리
- 밤샘·과음으로 붓기 재발
- 이제 끝났다는 생각으로 관리 중단

## 🕓 4주차 (Day 22–28)

### 겉보기엔 정리됐지만 내부 구조는 계속 안정 중인 시기

4주차에는 외관상 주름 개선과 윤곽 변화가 자연스럽게 느껴질 수 있습니다. 하지만 안면거상과 박리 수술은 피부가 아닌 근막과 조직의 위치를 바꾸는 수술이므로 진짜 안정화는 3–6개월에 걸쳐 진행됩니다. 지금의 얼굴은 완성이라기보다 안정적으로 자리 잡아가는 중간 단계입니다.

✔ 이 주차에 도움 되는 팁

- 일상·출근·외출 대부분 무리 없이 가능
- 가벼운 산책·스트레칭부터 단계적 운동 재개
- 흉터 관리 루틴 생활화
- 3개월 차를 기준으로 변화 관찰 계획

⚠ 권고사항

- 강한 얼굴 마사지·고주파 시술 성급히 시작
- 미세한 주름·비대칭에 과도하게 집착
- 1개월 차 얼굴을 최종 결과로 규정

### 의료진 공통 안내

안면거상과 이마거상, 주름 개선 수술은 시간이 지나면서 자연스럽게 완성되는 수술입니다. 주차에 맞는 관리만 유지한다면 현재의 변화는 보다 안정적으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "안면거상",
            "이마거상",
            "주름개선",
            "팔자박리",
            "마리오넷라인",
            "SMAS",
            "목거상",
            "거상재수술"
        ]
    },
    {
        id: "breast-surgery",
        procedureName: "가슴·부유방·여유증 수술",
        title: "가슴·부유방·여유증 수술에 대한 회복 가이드🍀",
        description: "가슴보형물, 가슴지방이식, 가슴거상, 부유방제거, 여유증수술 등 상체 구조와 무게 중심이 바뀌는 수술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 가슴·부유방·여유증 수술

권장 회복 기간 : 3–4주

(해당 시술: 가슴보형물, 가슴보형물지방이식, 가슴지방이식, 가슴거상술, 가슴거상확대술, 가슴축소술, 가슴보형물제거, 가슴이물질제거, 가슴재수술, 부유방흡입, 부유방제거수술, 몽고메리결절제거, 유두축소술, 유륜축소술, 유륜미백, 유륜문신, 함몰유두교정, 여유증시술, 여유증수술)

## 🕐 1주차 (Day 0–7)

### 상체 구조와 무게 중심이 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

가슴 수술은 단순히 가슴 부위만의 변화가 아니라 흉곽, 겨드랑이, 어깨, 등까지 포함한 상체 전체의 균형이 달라지는 수술입니다. 이 시기에는 통증, 압박감, 묵직함, 당김이 동시에 나타날 수 있으며 보형물이나 거상 수술 후에는 가슴이 실제보다 더 위에 위치해 있고 단단하게 느껴지는 것이 정상입니다. 부유방흡입이나 여유증수술을 함께 진행한 경우 겨드랑이와 팔 안쪽 당김이 더 뚜렷하게 느껴질 수 있습니다. 지금의 모양은 결과가 아니라 조직이 새로운 위치에 안착하기 전의 임시 상태에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 상체를 완전히 눕히지 말고 베개로 살짝 세운 자세 유지
- 압박브라·붕대는 불편해도 지시된 기간 동안 착용
- 팔 사용을 최소화하고 모든 동작은 천천히
- 방 안에서 짧게 자주 움직여 순환 유지

⚠ 권고사항

- 팔을 머리 위로 드는 동작
- 캐리어·무거운 가방 들기
- 거울로 가슴 모양을 반복 평가

## 🕑 2주차 (Day 8–14)

### 통증은 줄고 묵직함과 당김이 중심이 되는 시기

2주차부터는 날카로운 통증은 줄어들고 묵직함과 뻐근함이 회복의 중심이 됩니다. 가슴보형물이나 가슴거상술을 한 경우 윗가슴이 여전히 높고 단단하게 느껴질 수 있는데 이는 보형물과 조직이 아직 자연스럽게 내려오는 과정 중이기 때문입니다. 가슴축소술이나 여유증수술을 한 경우 상체가 가벼워진 느낌과 함께 절개 부위 주변이 더 예민하게 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 앉아서 쉴 수 있는 일정 위주로 외출
- 앞에서 여미는 옷과 부드러운 면 소재 착용
- 흉터 부위는 문지르지 말고 처방 연고만 사용
- 오전보다 오후 컨디션 기준으로 일정 조절

⚠ 권고사항

- 와이어 브라 착용
- 팔을 반복적으로 사용하는 쇼핑 일정
- 흉터 색과 가슴 위치를 하루 단위로 비교

## 🕒 3주차 (Day 15–21)

### 일상 동작은 가능하지만 상체 보호는 계속 필요한 시기

3주차에 접어들면 카페, 쇼핑, 가벼운 외출 등 일상적인 이동이 대부분 가능해집니다. 가슴지방이식이나 가슴보형물 수술 후에는 사진상으로는 자연스러워 보이지만 촉감이나 움직임에서는 아직 완전히 내 몸이 된 느낌은 아닐 수 있습니다. 부유방제거수술이나 여유증수술을 한 경우 옷 핏 변화가 뚜렷해져 만족감을 느끼기 쉬운 시기입니다.

✔ 이 주차에 도움 되는 팁

- 실내 위주 일정과 짧은 이동 추천
- 오래 서 있기보다는 앉아서 쉬는 동선 선택
- 사진 촬영은 가능하되 장시간 촬영은 피하기
- 쿠션 있는 의자 사용으로 상체 부담 줄이기

⚠ 권고사항

- 점프·상체 근력 운동
- 브라톱·코르셋 스타일 의상
- 이제 다 괜찮다는 생각으로 관리 소홀

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정적이지만 조직은 계속 자리 잡는 중인 시기

4주차에는 외출과 출근, 여행 일정 대부분이 가능해지고 타인이 보기엔 수술 티가 거의 나지 않을 수 있습니다. 하지만 가슴 수술은 겉모양보다 내부 조직의 안정이 훨씬 늦게 완성되며 보형물 위치와 지방이식 생착, 거상 후 피부 적응은 3–6개월까지도 이어질 수 있습니다. 지금의 가슴은 완성이 아니라 안정적인 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 일상 복귀는 가능하되 피로 누적 시 휴식 우선
- 의료진 허용 시 가벼운 유산소 운동부터 시작
- 흉터 관리 루틴을 생활화
- 몸의 불편 신호를 기준으로 일정 조절

⚠ 권고사항

- 고강도 운동·수영·웨이트 성급히 시작
- 가슴 모양을 매일 세밀하게 평가
- 1개월 차를 최종 결과로 확정

### 의료진 공통 안내

가슴·부유방·여유증 수술은 시간이 지나면서 점점 자연스러워지는 수술입니다. 현재의 회복 흐름이 유지된다면 앞으로 더 편안하고 안정적인 형태로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "가슴",
            "가슴보형물",
            "가슴지방이식",
            "가슴거상",
            "부유방",
            "여유증",
            "유두",
            "유륜"
        ]
    },
    {
        id: "body-liposuction-lift-revision",
        procedureName: "바디 지방흡입·거상·재수술",
        title: "바디 지방흡입·거상·재수술에 대한 회복 가이드🍀",
        description: "복부지방흡입, 허벅지지방흡입, 복부거상, 허벅지거상 등 체형의 부피와 무게 중심이 바뀌는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 바디 지방흡입·거상·재수술

권장 회복 기간 : 3–4주

(해당 시술: 복부지방흡입, 허벅지지방흡입, 팔지방흡입, 등지방흡입, 옆구리지방흡입, 복부거상술, 하복부거상술, 허벅지거상술, 팔거상술, 엉덩이거상술, 바디라인재수술, 지방흡입재수술, 거상재수술)

## 🕐 1주차 (Day 0–7)

### 체형의 부피와 무게 중심이 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

바디 지방흡입과 거상 수술은 특정 부위만의 변화가 아니라 체형 전체의 균형과 움직임 감각에 영향을 주는 시술입니다. 이 시기에는 강한 붓기, 멍, 압통, 묵직함이 동시에 나타날 수 있고 압박복 착용으로 인해 몸이 더 둔하고 불편하게 느껴질 수 있습니다. 거상 수술을 병행한 경우 절개 부위 주변 당김이 뚜렷하며 자세를 바꾸는 것만으로도 피로가 빠르게 누적될 수 있습니다. 지금의 체형은 결과가 아니라 조직이 자리를 잡기 전의 임시 상태에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 압박복은 불편해도 지시된 시간 동안 유지
- 누워 있을 때는 수술 부위가 과도하게 접히지 않도록 베개 활용
- 실내에서 짧게 자주 움직여 순환 유지
- 통증이 줄었다고 무리하지 않기

⚠ 권고사항

- 압박복 임의로 벗기
- 한 자세로 오래 앉거나 누워 있기
- 거울로 라인을 반복 확인

## 🕑 2주차 (Day 8–14)

### 큰 붓기는 줄고 뻣뻣함과 당김이 남는 시기

2주차에는 전반적인 부피감은 줄어들지만 피부 아래가 단단하게 느껴지고 만졌을 때 울퉁불퉁한 느낌이 남아 있을 수 있습니다. 이는 지방층과 피부, 근막이 재배치되며 나타나는 정상적인 회복 반응입니다. 복부거상술이나 팔·허벅지거상술을 한 경우 움직임에 따라 절개 부위가 더 당기게 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 짧은 외출 가능하되 앉아서 쉬는 일정 포함
- 수분 섭취를 늘려 순환과 붓기 관리
- 오후 컨디션을 기준으로 일정 조절
- 압박복 주름이 생기지 않도록 착용 상태 점검

⚠ 권고사항

- 강한 셀프 마사지
- 사우나·찜질방
- 하루 단위로 라인 변화를 세밀하게 비교

## 🕒 3주차 (Day 15–21)

### 라인의 방향성이 눈에 띄기 시작하는 시기

3주차가 되면 옷을 입었을 때 라인이 달라졌다는 느낌을 받는 경우가 많아집니다. 지방흡입 부위는 붓기 속에서도 전체적인 윤곽 방향이 보이기 시작하고 거상 수술 부위는 피부가 점점 밀착되는 감각이 느껴집니다. 다만 장시간 서 있거나 많이 움직인 날에는 다시 묵직함이 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 옷 핏 변화 위주로 체형 변화 확인
- 짧은 산책과 가벼운 스트레칭 가능
- 장시간 이동 시 중간 휴식 필수
- 사진은 동일한 옷·각도로 기록

⚠ 권고사항

- 고강도 유산소·하체 근력 운동
- 장시간 서서 촬영하는 일정
- 이제 다 끝났다는 생각으로 관리 중단

## 🕓 4주차 (Day 22–28)

### 일상은 가능하지만 체형 안정은 계속 진행 중인 시기

4주차에는 대부분의 일상 활동과 외출이 가능해집니다. 다만 지방흡입과 거상 수술은 피부와 지방층이 완전히 밀착되고 안정화되기까지 3–6개월이 걸릴 수 있습니다. 지금의 바디라인은 완성이 아니라 점점 정리되어 가는 중간 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 의료진 허용 범위 내에서 가벼운 운동 시작
- 압박복 착용 단계적 조정
- 장기 체형 관리 계획 세우기
- 피로 신호가 오면 즉시 휴식

⚠ 권고사항

- 무리한 다이어트 병행
- 경락·고주파 시술 성급히 시작
- 1개월 차 라인을 최종 결과로 규정

### 의료진 공통 안내

바디 지방흡입과 거상 수술은 시간이 지나면서 체형이 점점 정리되는 수술입니다. 현재의 회복 흐름을 유지한다면 앞으로 더 자연스럽고 안정적인 라인으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "지방흡입",
            "복부거상",
            "허벅지거상",
            "팔거상",
            "바디라인",
            "복부",
            "허벅지",
            "옆구리"
        ]
    },
    {
        id: "hip-up-pelvis-fat-grafting",
        procedureName: "힙업·골반·지방이식",
        title: "힙업·골반·지방이식에 대한 회복 가이드🍀",
        description: "힙지방이식, 골반지방이식, 힙업거상술 등 하체와 골반의 무게 중심이 바뀌는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 힙업·골반·지방이식

권장 회복 기간 : 3–4주

(해당 시술: 힙지방이식, 힙업지방이식, 골반지방이식, 힙딥지방이식, 엉덩이지방이식재수술, 골반보형물, 엉덩이보형물, 힙업거상술, 엉덩이거상술)

## 🕐 1주차 (Day 0–7)

### 하체와 골반의 무게 중심이 바뀌었다는 사실을 몸이 가장 강하게 인지하는 시기

힙업과 골반, 지방이식 수술은 엉덩이 자체뿐 아니라 허리–골반–허벅지로 이어지는 하체 전체의 균형 감각을 바꾸는 시술입니다. 이 시기에는 엉덩이와 허벅지, 허리 아래가 동시에 묵직하게 느껴질 수 있고 앉거나 일어날 때 강한 당김과 압박감이 동반될 수 있습니다. 지방이식 부위는 실제 결과보다 더 크게 부어 보이거나 단단하게 느껴지는 것이 정상이며 이는 지방이 자리를 잡기 전의 임시 상태입니다.

✔ 이 주차에 도움 되는 팁

- 가능한 한 엎드리거나 옆으로 눕는 자세 유지
- 장시간 앉아야 할 경우 쿠션 활용
- 짧게 자주 움직이며 혈액순환 유지
- 지방채취 부위와 이식 부위 모두 압박·자극 최소화

⚠ 권고사항

- 딱딱한 의자에 오래 앉기
- 엉덩이 부위를 직접 눌러 모양 확인
- 초반 볼륨만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 큰 붓기는 줄고 볼륨감과 당김이 함께 느껴지는 시기

2주차부터는 전반적인 부종이 서서히 가라앉으며 힙과 골반의 윤곽 방향이 조금씩 느껴지기 시작합니다. 지방이식 부위는 여전히 도톰하고 단단하게 느껴질 수 있으나 이는 생착 과정 중 나타나는 정상 반응입니다. 힙거상술이나 보형물을 병행한 경우 앉을 때의 이질감이 남아 있을 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 짧은 외출과 가벼운 이동 가능
- 앉을 때는 체중을 허벅지 쪽으로 분산
- 수분 섭취 늘려 순환 관리
- 오후 컨디션 기준으로 상태 판단

⚠ 권고사항

- 장시간 차량 이동
- 강한 스트레칭이나 하체 운동
- 좌우 볼륨을 하루 단위로 비교

## 🕒 3주차 (Day 15–21)

### 라인과 볼륨의 방향성이 눈에 띄기 시작하는 시기

3주차에는 옷을 입었을 때 힙 라인과 골반 실루엣이 이전과 다르다는 느낌을 받는 경우가 많습니다. 지방이식의 경우 일부 볼륨이 빠진 듯 느껴질 수 있으나 이는 생착이 정리되는 과정에서 흔히 나타나는 변화입니다. 보행과 일상 동작은 비교적 편해지지만 오래 앉아 있으면 피로감이 다시 느껴질 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 힙 라인을 살려주는 옷으로 변화 확인
- 짧은 산책 위주의 활동 가능
- 사진은 동일한 각도와 의상으로 기록
- 충분한 단백질 섭취로 회복 지원

⚠ 권고사항

- 힙업 운동·스쿼트
- 힙 부위 마사지·경락
- 볼륨 감소에 과도하게 불안해하기

## 🕓 4주차 (Day 22–28)

### 겉보기엔 안정되지만 생착과 밀착은 계속 진행 중인 시기

4주차에는 일상생활과 외출 대부분이 가능해지고 힙 라인이 자연스럽게 보이기 시작합니다. 다만 지방이식은 생착률에 따라 3–6개월에 걸쳐 볼륨이 최종적으로 안정되므로 지금의 모습은 완성이라기보다 중간 단계에 가깝습니다.

✔ 이 주차에 도움 되는 팁

- 일상 복귀 가능하되 하체 피로 시 즉시 휴식
- 의료진 허용 시 가벼운 스트레칭부터 시작
- 장기 볼륨 유지 계획 세우기
- 체중 변동 관리

⚠ 권고사항

- 급격한 다이어트
- 고강도 하체 운동 성급히 시작
- 1개월 차 볼륨을 최종 결과로 규정

### 의료진 공통 안내

힙업·골반·지방이식은 시간이 지날수록 자연스러운 곡선으로 완성되는 시술입니다. 현재의 회복 흐름을 유지한다면 보다 안정적이고 균형 잡힌 하체 라인으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "힙업",
            "골반",
            "지방이식",
            "힙지방이식",
            "골반지방이식",
            "힙업거상",
            "엉덩이"
        ]
    },
    {
        id: "fat-dissolving-body-injection",
        procedureName: "지방분해·바디 주사",
        title: "지방분해·바디 주사에 대한 회복 가이드🍀",
        description: "지방분해주사, 윤곽주사, 바디보톡스 등 지방층과 근육층이 자극되는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 지방분해·바디 주사

권장 회복 기간 : 1–2주

(해당 시술: 지방분해주사, 윤곽주사, PPC주사, HPL주사, 카복시주사, 메조테라피, 바디보톡스, 종아리보톡스, 승모근보톡스, 허벅지보톡스, 팔뚝보톡스)

## 🕐 1주차 (Day 0–7)

### 지방층과 근육층이 자극되었다는 사실을 몸이 인지하는 시기

지방분해·바디 주사는 절개가 없더라도 지방층과 근육층에 직접적인 자극을 주는 시술입니다. 이 시기에는 주사 부위 중심으로 붓기, 열감, 압통, 멍이 동시에 나타날 수 있고 만졌을 때 단단하거나 울퉁불퉁하게 느껴질 수 있습니다. 이는 약물이 지방과 조직에 퍼지며 작용하는 정상적인 반응이며 실제 결과보다 부피가 더 커 보이는 착시가 흔합니다. 지금의 라인은 결과가 아니라 반응 단계의 모습에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 주사 부위를 문지르지 말고 자연스럽게 두기
- 수분 섭취를 늘려 대사와 순환 지원
- 짧은 산책으로 림프 순환 돕기
- 처방된 연고나 진통제만 사용

⚠ 권고사항

- 주사 부위 마사지·경락
- 사우나·찜질방·고온 환경
- 초반 붓기만 보고 효과 판단

## 🕑 2주차 (Day 8–14)

### 붓기가 빠지며 라인의 변화가 느껴지기 시작하는 시기

2주차에는 주사 부위의 붓기와 압통이 점차 줄어들고 옷 핏이나 만졌을 때의 촉감에서 변화가 느껴지기 시작합니다. 지방분해주사와 메조테라피는 부위별로 반응 속도가 다를 수 있고 보톡스 계열은 근육 긴장이 서서히 완화되는 느낌이 나타납니다. 다만 효과는 한 번에 완성되기보다 누적되며 드러나는 경우가 많습니다.

✔ 이 주차에 도움 되는 팁

- 체중보다 옷 핏 변화로 효과 확인
- 가벼운 스트레칭과 유산소 운동 가능
- 수분·단백질 섭취 유지
- 2–3주 간격 관리 계획 정리

⚠ 권고사항

- 하루 단위로 사이즈 비교
- 즉각적인 체형 변화 기대
- 다른 시술과 무리하게 병행

### 의료진 공통 안내

지방분해·바디 주사는 절개 수술과 달리 누적 효과로 체형이 정리되는 시술입니다. 현재의 변화가 미미해 보여도 회복 흐름 안에 있다면 시간이 지나며 점진적인 라인 개선으로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "지방분해",
            "바디주사",
            "윤곽주사",
            "바디보톡스",
            "종아리보톡스",
            "승모근보톡스",
            "메조테라피"
        ]
    },
    {
        id: "filler-botox-contour-injection",
        procedureName: "필러·보톡스·윤곽주사",
        title: "필러·보톡스·윤곽주사에 대한 회복 가이드🍀",
        description: "이마필러, 미간필러, 사각턱보톡스, 윤곽주사 등 주입된 물질과 근육 반응이 동시에 나타나는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 필러·보톡스·윤곽주사

권장 회복 기간 : 1–2주

(해당 시술: 이마필러, 미간필러, 관자필러, 앞볼필러, 뒤볼필러, 팔자필러, 입술필러, 턱끝필러, 코필러, 애교필러, 사각턱보톡스, 턱보톡스, 침샘보톡스, 종아리보톡스, 승모근보톡스, 윤곽주사, 이중턱윤곽주사)

## 🕐 1주차 (Day 0–7)

### 주입된 물질과 근육 반응이 동시에 나타나는 시기

필러·보톡스·윤곽주사는 절개 없이 진행되지만 주입 직후에는 조직 내에 약물과 볼륨이 공존하는 상태가 됩니다. 이 시기에는 붓기, 압통, 미세한 멍, 이물감이 느껴질 수 있고 필러 부위는 실제보다 더 도톰하거나 단단하게 만져질 수 있습니다. 보톡스 계열은 즉각적인 변화보다 근육 긴장이 서서히 완화되기 전 단계이기 때문에 초반에는 효과가 불분명하게 느껴질 수 있습니다. 지금의 모습은 결과가 아니라 약물이 자리 잡기 전의 반응 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 주입 부위를 만지거나 눌러 모양 확인하지 않기
- 수분 섭취를 늘려 조직 순환 돕기
- 세안·메이크업은 가볍게 진행
- 멍이 생긴 부위는 냉찜질을 짧게 적용

⚠ 권고사항

- 필러 부위 마사지·경락
- 사우나·찜질방·격한 운동
- 시술 직후 사진만 보고 결과 단정

## 🕑 2주차 (Day 8–14)

### 볼륨과 라인이 얼굴·체형에 자연스럽게 섞이기 시작하는 시기

2주차에는 필러의 볼륨이 퍼지며 얼굴 윤곽에 자연스럽게 녹아들고 윤곽주사는 붓기 감소와 함께 라인의 방향성이 느껴지기 시작합니다. 보톡스 계열은 근육 사용이 줄어들며 얼굴이나 바디 라인이 한층 부드러워지는 변화를 체감하는 경우가 많습니다. 다만 부위별로 반응 속도는 다를 수 있어 변화 시점에 차이가 날 수 있습니다.

✔ 이 주차에 도움 되는 팁

- 자연광에서 정면·45도 각도로 변화 기록
- 체형·윤곽은 옷 핏 위주로 확인
- 다음 관리·리터치 여부는 최소 3–4주 이후 판단
- 충분한 수면과 수분 섭취 유지

⚠ 권고사항

- 하루 단위로 미세한 좌우 차이 비교
- 즉각적인 완성도 기대
- 다른 주입 시술을 겹쳐 진행

### 의료진 공통 안내

필러·보톡스·윤곽주사는 서서히 자리 잡으며 인상과 라인을 완성하는 시술입니다. 주차에 맞는 관리만 유지한다면 현재의 변화는 보다 자연스럽고 안정적인 결과로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "필러",
            "보톡스",
            "윤곽주사",
            "이마필러",
            "팔자필러",
            "입술필러",
            "사각턱보톡스",
            "이중턱"
        ]
    },
    {
        id: "skin-injection-skinbooster",
        procedureName: "피부 주사·스킨부스터",
        title: "피부 주사·스킨부스터에 대한 회복 가이드🍀",
        description: "리쥬란힐러, 쥬베룩, 샤넬주사, 물광주사 등 피부층이 직접적으로 자극되고 재생 신호가 시작되는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 피부 주사·스킨부스터

권장 회복 기간 : 3–7일

(해당 시술: 리쥬란힐러, 리쥬란아이, 리쥬란HB, 쥬베룩, 쥬베룩볼륨, 샤넬주사, 물광주사, 엑소좀주사, 스킨보톡스, PN주사, PDRN주사)

## 🕐 1주차 (Day 0–7)

### 피부층이 직접적으로 자극되고 재생 신호가 시작되는 시기

피부 주사와 스킨부스터는 피부 진피층에 직접 약물을 주입해 재생을 유도하는 시술입니다. 이 시기에는 주사 자국, 붉은기, 미세한 멍, 울퉁불퉁함이 동시에 나타날 수 있고 피부결이 일시적으로 거칠어 보이거나 화장이 잘 먹지 않는 느낌을 받을 수 있습니다. 이는 피부가 손상된 것이 아니라 재생을 시작하기 위한 정상적인 반응입니다. 지금의 피부 상태는 결과가 아니라 회복을 준비하는 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 시술 당일은 세안·메이크업 최소화
- 보습제를 충분히 발라 수분 유지
- 외출 시 자외선 차단 철저
- 미스트·재생크림 위주로 관리

⚠ 권고사항

- 각질 제거·필링 제품 사용
- 사우나·찜질방·격한 운동
- 피부결만 보고 효과 판단

## 🕑 2주차 (Day 8–14)

### 피부결과 광이 서서히 살아나기 시작하는 시기

2주차에는 붉은기와 주사 자국이 대부분 사라지고 피부결이 정돈되는 느낌을 받기 시작합니다. 리쥬란힐러나 쥬베룩 계열은 피부 속에서 재생 반응이 진행되며 피부 밀도와 탄력이 서서히 느껴질 수 있습니다. 다만 드라마틱한 변화보다는 전체적인 컨디션 개선이 중심이 됩니다.

✔ 이 주차에 도움 되는 팁

- 가벼운 메이크업부터 단계적 복귀
- 수분 섭취와 수면 루틴 유지
- 동일한 조명에서 피부 상태 기록
- 다음 시술 간격은 최소 3–4주 유지

⚠ 권고사항

- 즉각적인 광·탄력 효과 기대
- 여러 스킨부스터를 단기간에 병행
- 피부 상태를 하루 단위로 과도하게 비교

### 의료진 공통 안내

피부 주사·스킨부스터는 누적 관리로 피부 컨디션을 끌어올리는 시술입니다. 현재의 변화는 정상적인 재생 과정에 해당하며 시간이 지날수록 보다 안정적이고 건강한 피부 상태로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "리쥬란",
            "쥬베룩",
            "샤넬주사",
            "물광주사",
            "스킨부스터",
            "PN주사",
            "PDRN",
            "스킨보톡스"
        ]
    },
    {
        id: "skin-laser-toning-texture",
        procedureName: "피부 레이저·토닝·결 개선",
        title: "피부 레이저·토닝·결 개선에 대한 회복 가이드🍀",
        description: "레이저토닝, 듀얼토닝, 피코토닝, 루비레이저 등 피부 표면과 색소층이 동시에 자극을 인지하는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 피부 레이저·토닝·결 개선

권장 회복 기간 : 3–7일

(해당 시술: 레이저토닝, 듀얼토닝, 레블라이트토닝, 피코토닝, 루비레이저, 루메카레이저, 브이빔퍼펙타, 시너지MPX, IPL레이저, 골드PTT, 레이저페이셜, 시카레이저, LDM, 뉴스무스빔)

## 🕐 1주차 (Day 0–7)

### 피부 표면과 색소층이 동시에 자극을 인지하는 시기

레이저·토닝·결 개선 시술은 표피와 진피, 색소층에 열·광 자극을 주어 피부 반응을 유도합니다. 이 시기에는 붉은기, 화끈거림, 건조감, 미세한 각질이 나타날 수 있고 피부톤이 일시적으로 더 얼룩져 보이거나 어두워 보이는 착시가 생길 수 있습니다. 이는 색소가 올라왔다가 정리되는 정상적인 과정으로 지금의 피부 상태는 결과가 아니라 반응 단계에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 보습제를 평소보다 넉넉히 사용
- 외출 시 자외선 차단제 수시 덧바르기
- 세안은 미온수로 짧게 진행
- 시술 후 48시간은 열 자극 최소화

⚠ 권고사항

- 각질 제거·필링 제품 사용
- 사우나·찜질방·격한 운동
- 붉은기만 보고 시술 실패 판단

## 🕑 2주차 (Day 8–14)

### 피부톤과 결이 서서히 정돈되어 보이기 시작하는 시기

2주차에는 붉은기와 열감이 대부분 사라지고 피부톤이 균일해 보이기 시작합니다. 토닝 계열은 색소가 정리되는 방향성이 느껴지고 결 개선 레이저는 피부가 매끈해진 느낌을 주는 경우가 많습니다. 다만 잡티나 기미는 한 번에 사라지기보다 반복 시술을 통해 점진적으로 옅어집니다.

✔ 이 주차에 도움 되는 팁

- 자연광에서 피부톤 변화 기록
- 수분 섭취와 충분한 수면 유지
- 동일 레이저 기준으로 시술 간격 관리
- 피부 컨디션 좋은 날 기준으로 상태 판단

⚠ 권고사항

- 하루 단위로 잡티 색 비교
- 여러 레이저를 짧은 간격으로 병행
- 즉각적인 미백 효과 기대

### 의료진 공통 안내

피부 레이저·토닝·결 개선 시술은 누적 관리로 피부톤과 결을 안정적으로 끌어올리는 시술입니다. 현재의 반응은 정상적인 회복 흐름에 있으며 시간이 지날수록 보다 균일하고 깨끗한 피부 상태로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "레이저토닝",
            "듀얼토닝",
            "피코토닝",
            "루비레이저",
            "IPL",
            "레이저페이셜",
            "결개선"
        ]
    },
    {
        id: "acne-pore-redness",
        procedureName: "여드름·모공·홍조 관리",
        title: "여드름·모공·홍조 관리에 대한 회복 가이드🍀",
        description: "여드름압출, 아그네스, PDT레이저, 모공레이저 등 염증 반응과 혈관 반응이 동시에 조절되는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 여드름·모공·홍조 관리

권장 회복 기간 : 3–7일

(해당 시술: 여드름압출, 아그네스, 더마아크네, PDT레이저, PTT레이저, 브이빔퍼펙타, 엑셀V레이저, 시너지MPX, 모공레이저, 프락셀레이저, 피지조절레이저, 홍조레이저)

## 🕐 1주차 (Day 0–7)

### 염증 반응과 혈관 반응이 동시에 조절되는 시기

여드름·모공·홍조 관리는 피부 염증, 피지 분비, 혈관 반응을 동시에 조절하는 시술군입니다. 이 시기에는 붉은기, 열감, 미세한 딱지, 압통이 나타날 수 있고 여드름압출이나 아그네스 후에는 기존 트러블이 더 도드라져 보이는 현상이 생길 수 있습니다. 이는 악화가 아니라 염증이 표면으로 정리되는 정상적인 반응입니다. 지금의 피부는 결과가 아니라 정리 과정에 있는 상태입니다.

✔ 이 주차에 도움 되는 팁

- 손으로 트러블 부위 만지지 않기
- 저자극 세안과 보습 위주 관리
- 냉찜질은 필요 시 짧게만 적용
- 외출 시 자외선 차단 철저

⚠ 권고사항

- 여드름 부위 짜기·뜯기
- 각질 제거·스크럽 사용
- 붉은기만 보고 시술 실패 판단

## 🕑 2주차 (Day 8–14)

### 염증은 가라앉고 피부 표면이 정돈되기 시작하는 시기

2주차에는 큰 붉은기와 열감이 줄어들며 여드름은 마무리 단계로 접어들고 모공과 피부결이 서서히 정돈되는 느낌을 받을 수 있습니다. 홍조 레이저 계열은 얼굴 색이 한층 균일해 보이는 방향성이 느껴지기 시작합니다. 다만 새로운 트러블이 간헐적으로 올라오는 경우도 있으나 이는 회복 흐름 안에 있는 반응입니다.

✔ 이 주차에 도움 되는 팁

- 피부 컨디션 좋은 날을 기준으로 변화 확인
- 수분 섭취와 수면 루틴 유지
- 동일 조명에서 피부 상태 기록
- 필요 시 다음 관리 시점 정리

⚠ 권고사항

- 하루 단위로 트러블 개수 비교
- 여러 여드름·홍조 시술을 단기간에 병행
- 즉각적인 모공 축소 기대

### 의료진 공통 안내

여드름·모공·홍조 관리는 한 번의 시술보다 피부 리듬을 안정시키는 과정이 중요합니다. 현재의 반응이 유지된다면 시간이 지날수록 보다 깨끗하고 균일한 피부 상태로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "여드름",
            "모공",
            "홍조",
            "아그네스",
            "PDT",
            "모공레이저",
            "프락셀",
            "피지조절"
        ]
    },
    {
        id: "peeling-exfoliation-skin-care",
        procedureName: "필링·각질·피부관리",
        title: "필링·각질·피부관리에 대한 회복 가이드🍀",
        description: "아쿠아필링, 밀크필, 라라필, CO2레이저필링 등 피부 표면 장벽이 정리되고 재정렬되는 시술의 회복 과정을 안내합니다.",
        category: "회복 가이드",
        content: `## 필링·각질·피부관리

권장 회복 기간 : 1–3일

(해당 시술: 아쿠아필링, 밀크필, 라라필, 블랙필, 산소필, PHA필링, 쎄라필, 알라딘필링, CO2레이저필링, 모공스케일링, 각질관리, 진정관리, 수분관리)

## 🕐 1주차 (Day 0–7)

### 피부 표면 장벽이 정리되고 재정렬되는 시기

필링·각질·피부관리는 표피의 오래된 각질을 정리하고 피부 장벽 리듬을 재설정하는 시술입니다. 이 시기에는 따끔거림, 건조감, 미세한 각질 들뜸이 나타날 수 있고 피부톤이 일시적으로 밝아졌다가 다시 칙칙해 보이는 착시가 생길 수 있습니다. 이는 각질 탈락과 수분 재균형 과정에서 흔히 나타나는 반응입니다. 지금의 피부는 결과가 아니라 표면이 재정렬되는 과정에 해당합니다.

✔ 이 주차에 도움 되는 팁

- 세안은 미온수로 짧게 진행
- 보습제를 평소보다 넉넉히 사용
- 외출 시 자외선 차단 필수
- 각질이 보여도 자연 탈락 유도

⚠ 권고사항

- 손으로 각질 뜯기
- 필링 직후 스크럽·각질 제거제 사용
- 건조함만 보고 관리 실패 판단

## 🕑 2주차 (Day 8–14)

### 피부결과 톤이 정돈되어 보이기 시작하는 시기

2주차에는 각질 탈락이 마무리되며 피부결이 매끈해지고 화장이 고르게 올라가는 느낌을 받는 경우가 많습니다. 아쿠아필링·라라필·밀크필 계열은 피부가 촉촉하고 맑아 보이는 방향성이 느껴질 수 있습니다. 다만 관리 효과는 일회성보다는 주기적 관리로 유지됩니다.

✔ 이 주차에 도움 되는 팁

- 동일한 조명에서 피부결 변화 확인
- 수분 섭취와 수면 루틴 유지
- 필요 시 다음 필링 간격 메모
- 자극 없는 기초 제품 위주 유지

⚠ 권고사항

- 즉각적인 잡티·모공 개선 기대
- 다른 레이저·주사 시술과 무리한 병행
- 피부 상태를 하루 단위로 과도하게 비교

### 의료진 공통 안내

필링·각질·피부관리는 피부 컨디션을 리셋하고 다음 시술의 효과를 높이는 기반 관리입니다. 현재의 정돈 흐름을 유지한다면 시간이 지날수록 더 안정적이고 건강한 피부 상태로 이어질 가능성이 충분합니다.`,
        readTime: "10분",
        views: 0,
        keywords: [
            "필링",
            "각질",
            "아쿠아필링",
            "밀크필",
            "라라필",
            "CO2필링",
            "모공스케일링",
            "피부관리"
        ]
    }
];
function findRecoveryGuideByKeyword(keyword) {
    const normalizedKeyword = keyword.toLowerCase().trim();
    for (const post of recoveryGuidePosts){
        // 시술명 직접 매칭
        if (post.procedureName.toLowerCase().includes(normalizedKeyword)) {
            return post;
        }
        // 키워드 매칭
        if (post.keywords.some((k)=>k.toLowerCase().includes(normalizedKeyword)) || post.keywords.some((k)=>normalizedKeyword.includes(k.toLowerCase()))) {
            return post;
        }
    }
    return null;
}
function findRecoveryGuideById(id) {
    return recoveryGuidePosts.find((post)=>post.id === id) || null;
}
function getAllRecoveryGuides() {
    return recoveryGuidePosts;
}
}),
"[project]/components/InformationalContentSection.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InformationalContentSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/LanguageContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuidePosts$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/content/recoveryGuidePosts.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
// 정보성 컨텐츠 데이터 (임시 - 추후 API 연동)
const informationalContents = [
    {
        id: 4,
        title: "통역 서비스 이용 가이드",
        description: "한국어가 서툰 외국인을 위한 통역 서비스 안내",
        category: "정보",
        readTime: "4분",
        views: 1567
    }
];
function InformationalContentSection() {
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$LanguageContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLanguage"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [selectedCategory, setSelectedCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("all");
    // 회복 가이드 글 가져오기
    const recoveryGuidePosts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$content$2f$recoveryGuidePosts$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getAllRecoveryGuides"])();
    // 회복 가이드를 ContentItem 형식으로 변환
    const recoveryGuideItems = recoveryGuidePosts.map((post)=>({
            id: post.id,
            title: post.title,
            description: post.description,
            category: post.category,
            readTime: post.readTime,
            views: post.views || 0,
            thumbnail: post.thumbnail,
            slug: post.id
        }));
    // 모든 컨텐츠 합치기 (정보 + 회복 가이드)
    const allContents = [
        ...informationalContents,
        ...recoveryGuideItems
    ];
    const categories = [
        "all",
        "가이드",
        "정보",
        "회복 가이드🍀"
    ];
    const filteredContents = selectedCategory === "all" ? (()=>{
        // 전체 탭에서는 회복 가이드를 5개만 표시
        const recoveryGuides = allContents.filter((item)=>item.category === "회복 가이드");
        const otherContents = allContents.filter((item)=>item.category !== "회복 가이드");
        return [
            ...otherContents,
            ...recoveryGuides.slice(0, 5)
        ];
    })() : selectedCategory === "회복 가이드🍀" ? allContents.filter((item)=>item.category === "회복 가이드") : allContents.filter((item)=>item.category === selectedCategory);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-6 pt-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4 mb-4",
                children: categories.map((category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setSelectedCategory(category),
                        className: `px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${selectedCategory === category ? "bg-primary-main text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                        children: category === "all" ? "전체" : category
                    }, category, false, {
                        fileName: "[project]/components/InformationalContentSection.tsx",
                        lineNumber: 84,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/InformationalContentSection.tsx",
                lineNumber: 82,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-2",
                children: filteredContents.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center py-8 text-gray-500 text-sm",
                    children: selectedCategory === "회복 가이드🍀" || selectedCategory === "회복 가이드" ? "회복 가이드 글이 준비 중입니다." : "컨텐츠가 없습니다."
                }, void 0, false, {
                    fileName: "[project]/components/InformationalContentSection.tsx",
                    lineNumber: 101,
                    columnNumber: 11
                }, this) : filteredContents.map((content)=>{
                    const isRecoveryGuide = content.category === "회복 가이드";
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            // 회복 가이드인 경우 상세 페이지로 이동
                            if (content.category === "회복 가이드" && content.slug) {
                                router.push(`/community/recovery-guide/${content.slug}`);
                            } else {
                                // 다른 컨텐츠는 추후 구현
                                console.log("Navigate to:", content.id);
                            }
                        },
                        className: `w-full bg-white border border-gray-200 rounded-lg hover:shadow-md transition-all text-left ${isRecoveryGuide ? "p-3" : "p-3"}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-start gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-shrink-0 w-14 h-14 bg-gradient-to-br from-primary-light/20 to-primary-main/30 rounded-lg overflow-hidden",
                                    children: content.thumbnail ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: content.thumbnail,
                                        alt: content.title,
                                        className: "w-full h-full object-cover"
                                    }, void 0, false, {
                                        fileName: "[project]/components/InformationalContentSection.tsx",
                                        lineNumber: 130,
                                        columnNumber: 23
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-full h-full flex items-center justify-center",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiBook"], {
                                            className: "text-primary-main text-lg"
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 137,
                                            columnNumber: 25
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/InformationalContentSection.tsx",
                                        lineNumber: 136,
                                        columnNumber: 23
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                    lineNumber: 128,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 min-w-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2 mb-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-[10px] bg-primary-light/20 text-primary-main px-1.5 py-0.5 rounded-full font-medium",
                                                    children: content.category
                                                }, void 0, false, {
                                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                                    lineNumber: 145,
                                                    columnNumber: 23
                                                }, this),
                                                content.readTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-[10px] text-gray-500",
                                                    children: [
                                                        content.readTime,
                                                        " 읽기"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                                    lineNumber: 149,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 144,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                            className: "font-semibold text-gray-900 line-clamp-2 leading-snug text-sm mb-1",
                                            children: content.title
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 154,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-gray-600 line-clamp-1 leading-snug text-xs mb-1",
                                            children: content.description
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 157,
                                            columnNumber: 21
                                        }, this),
                                        content.views !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2 text-[10px] text-gray-400",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: [
                                                    "조회 ",
                                                    content.views.toLocaleString()
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/InformationalContentSection.tsx",
                                                lineNumber: 162,
                                                columnNumber: 25
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/InformationalContentSection.tsx",
                                            lineNumber: 161,
                                            columnNumber: 23
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                    lineNumber: 143,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-shrink-0 mt-1",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                                        className: "text-gray-400 text-sm"
                                    }, void 0, false, {
                                        fileName: "[project]/components/InformationalContentSection.tsx",
                                        lineNumber: 169,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/InformationalContentSection.tsx",
                                    lineNumber: 168,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/InformationalContentSection.tsx",
                            lineNumber: 126,
                            columnNumber: 17
                        }, this)
                    }, content.id, false, {
                        fileName: "[project]/components/InformationalContentSection.tsx",
                        lineNumber: 111,
                        columnNumber: 15
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/components/InformationalContentSection.tsx",
                lineNumber: 99,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/InformationalContentSection.tsx",
        lineNumber: 80,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/ConsultationPage.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConsultationPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PostList$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/PostList.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
// 고민상담소 카테고리 7가지
const CONCERN_CATEGORIES = [
    {
        id: null,
        label: "전체"
    },
    {
        id: "피부 고민",
        label: "피부 고민"
    },
    {
        id: "시술 고민",
        label: "시술 고민"
    },
    {
        id: "병원 선택",
        label: "병원 선택"
    },
    {
        id: "가격 문의",
        label: "가격 문의"
    },
    {
        id: "회복 기간",
        label: "회복 기간"
    },
    {
        id: "부작용",
        label: "부작용"
    },
    {
        id: "기타",
        label: "기타"
    }
];
function ConsultationPage() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [selectedCategory, setSelectedCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleCategoryClick = (categoryId)=>{
        setSelectedCategory(categoryId);
    // 카테고리 선택 시 해당 카테고리 게시글만 보이도록 필터링
    // PostList에 concernCategory prop을 전달하여 필터링
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "px-4 py-3 space-y-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2 overflow-x-auto scrollbar-hide pb-2",
                    children: CONCERN_CATEGORIES.map((category)=>{
                        const isActive = selectedCategory === category.id;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>handleCategoryClick(category.id),
                            className: `flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${isActive ? "bg-primary-main text-white shadow-sm" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                            children: category.label
                        }, category.id || "all", false, {
                            fileName: "[project]/components/ConsultationPage.tsx",
                            lineNumber: 37,
                            columnNumber: 15
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/components/ConsultationPage.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ConsultationPage.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PostList$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                activeTab: "consultation",
                concernCategory: selectedCategory
            }, void 0, false, {
                fileName: "[project]/components/ConsultationPage.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ConsultationPage.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/CommunityPage.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CommunityPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Header.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/BottomNavigation.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityHeader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CommunityHeader.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PostList$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/PostList.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityFloatingButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CommunityFloatingButton.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InformationalContentSection$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/InformationalContentSection.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ConsultationPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ConsultationPage.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
function CommunityPage() {
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("popular");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const tab = searchParams.get("tab");
        if (tab && [
            "popular",
            "latest",
            "info",
            "consultation"
        ].includes(tab)) {
            setActiveTab(tab);
            // 탭 변경 시 상단으로 스크롤
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        }
    }, [
        searchParams
    ]);
    const handleTabChange = (tab)=>{
        setActiveTab(tab);
        // 탭 변경 시 상단으로 스크롤
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white max-w-md mx-auto w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Header$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/CommunityPage.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityHeader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                activeTab: activeTab,
                onTabChange: handleTabChange
            }, void 0, false, {
                fileName: "[project]/components/CommunityPage.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-1",
                children: activeTab === "popular" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PostList$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    activeTab: "popular"
                }, void 0, false, {
                    fileName: "[project]/components/CommunityPage.tsx",
                    lineNumber: 46,
                    columnNumber: 11
                }, this) : activeTab === "latest" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PostList$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    activeTab: "latest"
                }, void 0, false, {
                    fileName: "[project]/components/CommunityPage.tsx",
                    lineNumber: 48,
                    columnNumber: 11
                }, this) : activeTab === "info" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InformationalContentSection$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/components/CommunityPage.tsx",
                        lineNumber: 51,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/CommunityPage.tsx",
                    lineNumber: 50,
                    columnNumber: 11
                }, this) : activeTab === "consultation" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ConsultationPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/components/CommunityPage.tsx",
                    lineNumber: 54,
                    columnNumber: 11
                }, this) : null
            }, void 0, false, {
                fileName: "[project]/components/CommunityPage.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pb-20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BottomNavigation$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/components/CommunityPage.tsx",
                    lineNumber: 59,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/CommunityPage.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityFloatingButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/CommunityPage.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/CommunityPage.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/community/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Community
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CommunityPage.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
function Community() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-white flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-gray-500",
                children: "로딩 중..."
            }, void 0, false, {
                fileName: "[project]/app/community/page.tsx",
                lineNumber: 10,
                columnNumber: 9
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/app/community/page.tsx",
            lineNumber: 9,
            columnNumber: 7
        }, void 0),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CommunityPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/app/community/page.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/community/page.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__fdca6891._.js.map