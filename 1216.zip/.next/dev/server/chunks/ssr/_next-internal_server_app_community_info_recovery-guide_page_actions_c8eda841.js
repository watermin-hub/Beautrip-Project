module.exports = [
"[project]/.next-internal/server/app/community/info/recovery-guide/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_community_info_recovery-guide_page_actions_c8eda841.js.map