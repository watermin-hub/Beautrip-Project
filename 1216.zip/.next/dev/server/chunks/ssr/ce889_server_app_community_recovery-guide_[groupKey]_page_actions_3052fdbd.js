module.exports = [
"[project]/.next-internal/server/app/community/recovery-guide/[groupKey]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_community_recovery-guide_%5BgroupKey%5D_page_actions_3052fdbd.js.map